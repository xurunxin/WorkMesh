import datetime, hashlib, json, pathlib, subprocess
root=pathlib.Path(__file__).resolve().parents[2]
folder='docs/plan/agent-mcp-m1/'
paths=[folder+'product-ci410-report.md',folder+'product-evidence/ci410-original-index.json',
    folder+'product-evidence/ci410-originals.zip',folder+'product-evidence/ci410-test-summaries.json']
commands=[]
def command(args):
    result=subprocess.run(args,cwd=root,capture_output=True)
    commands.append(dict(command=args,exitCode=result.returncode,stdout=result.stdout.decode(errors='replace'),stderr=result.stderr.decode(errors='replace')))
    assert result.returncode==0
    return result.stdout
command(['git','add','--',*paths])
command(['git','diff','--cached','--check','e49eda142d61bdd248ddc42ec16f5563abd4bbc6','--'])
changed=command(['git','diff','--cached','--name-only','394401880cb687d1a682b56d57b1342a86531c5c','--']).decode().splitlines()
assert changed==sorted(paths),changed
rows=[]
for path in paths:
    data=(root/path).read_bytes()
    staged=subprocess.check_output(['git','show',':'+path],cwd=root)
    rows.append(dict(path=path,worktreeBytes=len(data),worktreeSha256=hashlib.sha256(data).hexdigest(),
        stagedBytes=len(staged),stagedSha256=hashlib.sha256(staged).hexdigest()))
    if path.endswith('.zip'): assert data==staged
result=dict(observedAt=datetime.datetime.now(datetime.timezone.utc).isoformat(),
    result='passed',parent='394401880cb687d1a682b56d57b1342a86531c5c',productChanges=[],
    commands=commands,files=rows,limitation='Pre-push staged and worktree bytes; final commit identity must be observed after push.')
out=root/folder/'product-evidence/ci410-static.json'
out.write_text(json.dumps(result,ensure_ascii=False,indent=2)+'\n',encoding='utf8',newline='\n')
print(json.dumps(dict(result=result['result'],files=len(rows),productChanges=[])))
