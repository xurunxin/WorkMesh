import hashlib,json,pathlib,subprocess,zipfile
root=pathlib.Path(__file__).resolve().parents[2]
head=subprocess.check_output(['git','rev-parse','HEAD'],cwd=root).decode().strip()
candidate='394401880cb687d1a682b56d57b1342a86531c5c'
source=json.loads((root/'docs/plan/agent-mcp-m1/product-evidence/review-queued-source-index.json').read_text(encoding='utf8'))
for row in source:
    old=subprocess.check_output(['git','show',candidate+':'+row['path']],cwd=root)
    current=subprocess.check_output(['git','show',head+':'+row['path']],cwd=root)
    assert old==current,row['path']
    assert hashlib.sha256((root/row['path']).read_bytes()).hexdigest()==row['worktreeSha256'],row['path']
name='docs/plan/agent-mcp-m1/product-evidence/ci410-originals.zip'
data=(root/name).read_bytes()
assert subprocess.check_output(['git','show',head+':'+name],cwd=root)==data
index=json.loads((root/'docs/plan/agent-mcp-m1/product-evidence/ci410-original-index.json').read_text(encoding='utf8'))
assert hashlib.sha256(data).hexdigest()==index['sha256']
with zipfile.ZipFile(root/name) as archive:
    assert archive.testzip() is None
    for row in index['entries']:
        raw=archive.read(row['member'])
        assert len(raw)==row['bytes'] and hashlib.sha256(raw).hexdigest()==row['sha256']
changed=subprocess.check_output(['git','diff','--name-only',candidate,head,'--'],cwd=root).decode().splitlines()
assert len(changed)==5 and all(path.startswith('docs/plan/agent-mcp-m1/') for path in changed)
assert subprocess.check_output(['git','status','--porcelain'],cwd=root)==b''
print(json.dumps(dict(result='passed',head=head,candidate=candidate,sourceMembers=len(source),archiveMembers=len(index['entries']),changedFiles=changed,productChanges=[])))
