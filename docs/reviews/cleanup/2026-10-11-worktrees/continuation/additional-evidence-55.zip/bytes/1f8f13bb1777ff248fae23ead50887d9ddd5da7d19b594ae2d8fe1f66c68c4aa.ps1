$ErrorActionPreference = 'Stop'
$m1Workspace = (Resolve-Path -LiteralPath '.').Path
$m1Gate = Join-Path $m1Workspace 'node_modules\.m1-runtime\m1-ci-gate'
$m1Active = @(Get-CimInstance Win32_Process | Where-Object {
  $_.ProcessId -ne $PID -and $_.CommandLine -match 'm1-ci-(observe|collect|archive|merge-binding|retention-proof)\.py'
})
if ($m1Active.Count -gt 0) { throw 'Owned CI recorder or collector remains active; retain buffers.' }
$m1Receipt = @()
foreach ($m1Run in @('37971202936', '37973142192')) {
  $m1Target = (Resolve-Path -LiteralPath (Join-Path $m1Gate $m1Run)).Path
  if ($m1Target -ne (Join-Path $m1Gate $m1Run) -or -not $m1Target.StartsWith($m1Workspace + '\', [StringComparison]::OrdinalIgnoreCase)) {
    throw 'Resolved owned target is outside the exact workspace path.'
  }
  $m1Nodes = @(Get-Item -LiteralPath $m1Target) + @(Get-ChildItem -LiteralPath $m1Target -Recurse)
  if (@($m1Nodes | Where-Object { ($_.Attributes -band [IO.FileAttributes]::ReparsePoint) -ne 0 }).Count -gt 0) {
    throw 'Link or reparse target present; retain buffers.'
  }
  $m1Files = @($m1Nodes | Where-Object { -not $_.PSIsContainer })
  $m1Bytes = ($m1Files | Measure-Object -Property Length -Sum).Sum
  Remove-Item -LiteralPath $m1Target -Recurse
  if (Test-Path -LiteralPath $m1Target) { throw 'Owned buffer removal did not complete.' }
  $m1Receipt += [pscustomobject]@{
    target = $m1Target; runId = $m1Run; fileCount = $m1Files.Count; bytes = $m1Bytes
    activeOwnedCommands = 0; links = 0; result = 'removed'; existsAfter = $false
    preservation = $(if ($m1Run -eq '37971202936') {'Committed ci410-originals.zip exact member hashes verified'} else {'GitHub Actions full job logs and twelve artifacts; twelve server digests matched, retention 14 days'})
  }
}
$m1Receipt | ConvertTo-Json -Depth 5 | Set-Content -LiteralPath (Join-Path $m1Gate 'cleanup-receipt.json') -Encoding UTF8
$m1Receipt | ConvertTo-Json -Depth 5
