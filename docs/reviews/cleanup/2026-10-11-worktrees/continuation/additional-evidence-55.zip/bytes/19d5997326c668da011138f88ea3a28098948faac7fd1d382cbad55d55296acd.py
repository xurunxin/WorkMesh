import hashlib,json,pathlib,zipfile
root=pathlib.Path(__file__).resolve().parents[2]
gate=root/'node_modules/.m1-runtime/m1-ci-gate'
saved=json.loads((root/'docs/plan/agent-mcp-m1/product-evidence/ci410-original-index.json').read_text(encoding='utf8'))
by_path={row['path']:row for row in saved['entries']}
for path in (gate/'37971202936').iterdir():
    if path.is_file():
        row=by_path[path.relative_to(root/'node_modules/.m1-runtime').as_posix()]
        assert hashlib.sha256(path.read_bytes()).hexdigest()==row['sha256']
current=gate/'37973142192'
run=json.loads((current/'run.json').read_bytes())
jobs=json.loads((current/'jobs.json').read_bytes())['jobs']
assert run['status']=='completed' and run['conclusion']=='success'
assert len(jobs)==10 and all(row['conclusion']=='success' for row in jobs)
receipts=json.loads((current/'collection-receipt.json').read_bytes())
assert all(row['exitCode']==0 for row in receipts)
artifacts=json.loads((current/'artifacts.json').read_bytes())['artifacts']
rows=[]
for artifact in artifacts:
    path=current/f"artifact-{artifact['id']}.zip"
    data=path.read_bytes()
    sha=hashlib.sha256(data).hexdigest()
    expected=artifact.get('digest')
    if expected: assert expected=='sha256:'+sha,artifact['name']
    with zipfile.ZipFile(path) as archive: assert archive.testzip() is None
    assert not artifact['expired'] and artifact['workflow_run']['head_sha']==run['head_sha']
    rows.append(dict(id=artifact['id'],name=artifact['name'],sha256=sha,serverDigest=expected,expiresAt=artifact['expires_at']))
proof=dict(result='passed',head=run['head_sha'],runId=run['id'],runNumber=run['run_number'],
    jobs=[dict(id=row['id'],name=row['name'],conclusion=row['conclusion'],startedAt=row['started_at'],completedAt=row['completed_at']) for row in jobs],
    collectionCommands=receipts,artifacts=rows,
    retainedOriginals='CI410 exact originals in committed ZIP; CI411 full job logs and 12 original artifacts in GitHub Actions, retention 14 days for artifacts.',
    limitation='This local observation receipt is retained as a small buffer; it is not a new committed report nor a replacement for the remote originals.')
(gate/'latest-retention-proof.json').write_text(json.dumps(proof,indent=2)+'\n',encoding='utf8')
print(json.dumps(dict(result=proof['result'],head=proof['head'],jobs=len(jobs),commands=len(receipts),artifacts=len(rows),serverDigestsMatched=sum(bool(row['serverDigest']) for row in rows))))
