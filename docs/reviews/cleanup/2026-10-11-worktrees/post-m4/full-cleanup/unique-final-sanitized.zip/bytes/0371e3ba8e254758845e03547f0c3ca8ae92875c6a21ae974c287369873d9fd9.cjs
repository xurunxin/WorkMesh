const fs=require('fs');
const root='docs/reviews/d1a/evidence'; const files=[`${root}/check-index.json`,`${root}/reverification-index.json`,...fs.readdirSync(root).filter(x=>x.startsWith('reverification-')).map(x=>`${root}/${x}/run-binding.json`).filter(fs.existsSync)];
function walk(v,p,out){if(Array.isArray(v))v.forEach((x,i)=>walk(x,`${p}/${i}`,out));else if(v&&typeof v==='object'){if(typeof v.log==='string'&&v.log.endsWith('.log'))out.push({pointer:p+'/log',path:v.log,archivedLog:v.archivedLog??null});for(const [k,x]of Object.entries(v))if(k!=='archivedLog')walk(x,`${p}/${k}`,out)}}
for(const f of files){const o=JSON.parse(fs.readFileSync(f));const out=[];walk(o,'',out);if(out.length)console.log(JSON.stringify({file:f,logs:out}));}
