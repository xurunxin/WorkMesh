from pathlib import Path
import datetime,hashlib,json,os,subprocess,sys,time
sys.stdout.reconfigure(encoding='utf8',errors='replace')
root=Path.cwd();out=root/'.tmp/m5-runtime/review-opencode';out.mkdir(parents=True,exist_ok=True)
def now():return datetime.datetime.now(datetime.timezone.utc).isoformat()
paths=['packages/conformance/src/joint-clients.drivers.ts','packages/conformance/src/joint-clients.model.ts','packages/conformance/src/joint-clients.external.ts','packages/conformance/src/joint-clients.acceptance.ts','packages/conformance/src/joint-clients.fixture.ts','packages/conformance/src/fixtures/model-test-ca.pem']
def sources():return [{'path':p,'bytes':len((root/p).read_bytes()),'sha256':hashlib.sha256((root/p).read_bytes()).hexdigest()} for p in paths]
label=sys.argv[1];argv=sys.argv[2:];env=json.loads((root/'.tmp/m5-runtime/environment.json').read_text());env['M5_EVIDENCE_ROOT']=str(out/label/'evidence')
row={'label':label,'argv':argv,'cwd':str(root),'owner':'m5-opencode-review','startedAt':now(),'sourceBefore':sources()};started=time.monotonic()
p=subprocess.Popen(argv,cwd=root,env=env,stdout=subprocess.PIPE,stderr=subprocess.PIPE);row['pid']=p.pid;(out/(label+'.json')).write_text(json.dumps(row,indent=2))
a,b=p.communicate();row.update(endedAt=now(),runtimeSeconds=time.monotonic()-started,nativeExit=p.returncode,sourceAfter=sources())
for channel,raw in [('stdout',a),('stderr',b)]:
 text=raw.decode('utf8',errors='replace')
 for k,v in env.items():
  if any(s in k for s in ['TOKEN','SECRET','PASSWORD','MASTER_KEY','DATABASE_URL']) and len(v)>5:text=text.replace(v,'[redacted]')
 (out/(label+'-'+channel+'.txt')).write_text(text,encoding='utf8');row[channel]={'bytes':len(raw),'rawSha256':hashlib.sha256(raw).hexdigest(),'publicSha256':hashlib.sha256(text.encode()).hexdigest()}
row['sourceUnchanged']=row['sourceBefore']==row['sourceAfter'];(out/(label+'.json')).write_text(json.dumps(row,indent=2),encoding='utf8')
print(json.dumps({k:row[k] for k in ['label','pid','argv','startedAt','endedAt','runtimeSeconds','nativeExit','sourceUnchanged']}));print((out/(label+'-stdout.txt')).read_text(encoding='utf8')[-1500:]);print((out/(label+'-stderr.txt')).read_text(encoding='utf8')[-1500:]);sys.exit(p.returncode)
