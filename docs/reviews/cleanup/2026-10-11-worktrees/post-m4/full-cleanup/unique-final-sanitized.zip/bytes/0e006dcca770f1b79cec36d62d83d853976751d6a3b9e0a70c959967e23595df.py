import hashlib
import json
import re
import shutil
import zipfile
from pathlib import Path

root = Path('docs/reviews/d1a/evidence/reverification-environment-07')
direct = root / 'e2e-failure-captures/trace-sanitized.zip'
report_zip = root / 'e2e-html-report/data/d69f056ec411e76e5d9f9e4664b013966ee3cc75.zip'
temp = Path('.tmp/trace-sanitized-rebuilt.zip')
redacted_value = '[REDACTED]'
key_pattern = re.compile(r'(csrf|xsrf|authorization|cookie|bootstrap.?token|password|secret|api.?key)', re.I)
field_counts = {}
serialized_field_counts = {}
original_sensitive_values = set()
renames = {}

def collect_strings(value):
    if isinstance(value, str):
        if value and value != redacted_value:
            original_sensitive_values.add(value)
    elif isinstance(value, dict):
        for child in value.values():
            collect_strings(child)
    elif isinstance(value, list):
        for child in value:
            collect_strings(child)

def redact(value):
    if isinstance(value, dict):
        out = {}
        serialized_key = value.get('k')
        if isinstance(serialized_key, str) and key_pattern.search(serialized_key) and 'v' in value:
            collect_strings(value['v'])
            serialized_field_counts[serialized_key] = serialized_field_counts.get(serialized_key, 0) + 1
            serialized_value = dict(value['v']) if isinstance(value['v'], dict) else {'value': value['v']}
            if 's' in serialized_value:
                serialized_value['s'] = redacted_value
            else:
                serialized_value = redact(serialized_value)
            value = {**value, 'v': serialized_value}
        for key, child in value.items():
            if key_pattern.search(str(key)) and child not in (None, '', redacted_value):
                collect_strings(child)
                field_counts[str(key)] = field_counts.get(str(key), 0) + 1
                out[key] = redacted_value
            else:
                out[key] = redact(child)
        return out
    if isinstance(value, list):
        return [redact(child) for child in value]
    return value

with zipfile.ZipFile(direct, 'r') as src, zipfile.ZipFile(temp, 'w', compression=zipfile.ZIP_DEFLATED, compresslevel=6) as dst:
    if src.testzip() is not None:
        raise SystemExit('source trace ZIP CRC failure')
    contents = []
    for info in src.infolist():
        data = src.read(info.filename)
        if info.filename.startswith('resources/') and info.filename.endswith('.json'):
            try:
                parsed = json.loads(data.decode('utf-8'))
            except (UnicodeDecodeError, json.JSONDecodeError):
                continue
            clean = json.dumps(redact(parsed), ensure_ascii=False, separators=(',', ':')).encode('utf-8')
            if clean != data:
                old_name = info.filename
                new_hash = hashlib.sha1(clean).hexdigest()
                new_name = f'resources/{new_hash}.json'
                renames[old_name] = new_name
                data = clean
        elif info.filename.endswith(('.trace', '.network')):
            try:
                lines = data.decode('utf-8').splitlines()
                cleaned_lines = []
                for line in lines:
                    try:
                        cleaned_lines.append(json.dumps(redact(json.loads(line)), ensure_ascii=False, separators=(',', ':')))
                    except json.JSONDecodeError:
                        cleaned_lines.append(line)
                data = ('\n'.join(cleaned_lines) + ('\n' if data.endswith(b'\n') else '')).encode('utf-8')
            except UnicodeDecodeError:
                pass
        contents.append((info, data))
    if not original_sensitive_values:
        raise SystemExit('no original serialized sensitive values were found to redact')
    for index, (info, data) in enumerate(contents):
        for secret in original_sensitive_values:
            data = data.replace(secret.encode('utf-8'), redacted_value.encode('utf-8'))
        contents[index] = (info, data)
    written = {}
    for info, data in contents:
        original_name = info.filename
        if original_name in renames:
            info.filename = renames[original_name]
        if renames and info.filename.endswith(('.trace', '.network', '.json', '.txt')):
            for old_name, new_name in renames.items():
                data = data.replace(old_name.encode(), new_name.encode())
                old_base = old_name.removeprefix('resources/').removesuffix('.json')
                new_base = new_name.removeprefix('resources/').removesuffix('.json')
                data = data.replace(old_base.encode(), new_base.encode())
        if info.filename in written:
            if written[info.filename] != data:
                raise SystemExit(f'content-hash collision for {info.filename}')
            continue
        written[info.filename] = data
        dst.writestr(info, data)

with zipfile.ZipFile(temp, 'r') as check:
    bad = check.testzip()
    if bad is not None:
        raise SystemExit(f'rebuilt trace ZIP CRC failure: {bad}')
    leaks = []
    for name in check.namelist():
        data = check.read(name)
        if any(secret.encode('utf-8') in data for secret in original_sensitive_values):
            raise SystemExit(f'captured original sensitive value remains in {name}')
        if name.startswith('resources/') and name.endswith('.json'):
            try:
                parsed = json.loads(data.decode('utf-8'))
            except (UnicodeDecodeError, json.JSONDecodeError):
                continue
            def find_sensitive(value, at=''):
                if isinstance(value, dict):
                    for key, child in value.items():
                        if key_pattern.search(str(key)) and child not in (None, '', redacted_value):
                            leaks.append(f'{name}:{at}/{key}')
                        find_sensitive(child, f'{at}/{key}')
                elif isinstance(value, list):
                    for index, child in enumerate(value):
                        find_sensitive(child, f'{at}/{index}')
            find_sensitive(parsed)
        elif name.endswith(('.trace', '.network')):
            try:
                lines = data.decode('utf-8').splitlines()
            except UnicodeDecodeError:
                continue
            def find_serialized(value):
                if isinstance(value, dict):
                    key = value.get('k')
                    child = value.get('v')
                    if isinstance(key, str) and key_pattern.search(key):
                        if isinstance(child, dict) and any(v not in (None, '', redacted_value) for v in child.values() if isinstance(v, str)):
                            leaks.append(f'{name}:serialized/{key}')
                    for child_value in value.values():
                        find_serialized(child_value)
                elif isinstance(value, list):
                    for child_value in value:
                        find_serialized(child_value)
            for line in lines:
                try:
                    find_serialized(json.loads(line))
                except json.JSONDecodeError:
                    continue
    if leaks:
        raise SystemExit('sensitive JSON fields remain: ' + ', '.join(leaks[:10]))

new_bytes = temp.read_bytes()
direct.write_bytes(new_bytes)
report_zip.write_bytes(new_bytes)
prior_report_path = root / 'e2e-failure-captures/trace-redaction-report.json'
prior = json.loads(prior_report_path.read_text(encoding='utf-8')) if prior_report_path.exists() else {}
reported_counts = dict(prior.get('redactedFieldCountsByName', {}))
for name, count in field_counts.items():
    reported_counts[name] = max(reported_counts.get(name, 0), count)
reported_renames = dict(prior.get('resourceRenames', {}))
reported_renames.update(renames)
reported_serialized_counts = dict(prior.get('redactedSerializedFieldCountsByName', {}))
for name, count in serialized_field_counts.items():
    reported_serialized_counts[name] = max(reported_serialized_counts.get(name, 0), count)
summary = {
    'sourceArchiveSha256': hashlib.sha256(new_bytes).hexdigest(),
    'archiveBytes': len(new_bytes),
    'redactedFieldCountsByName': reported_counts,
    'redactedSerializedFieldCountsByName': reported_serialized_counts,
    'resourceRenames': reported_renames,
    'crcVerified': True,
    'sensitiveResourceFieldsRemaining': 0,
    'originalSensitiveValuesRemaining': 0,
    'updatedCopies': [str(direct).replace('\\', '/'), str(report_zip).replace('\\', '/')],
}
(root / 'e2e-failure-captures/trace-redaction-report.json').write_text(json.dumps(summary, indent=2) + '\n', encoding='utf-8')
print(json.dumps(summary, indent=2))
