import json,pathlib,sys,re
sys.stdout.reconfigure(encoding='utf8')
env=json.loads(pathlib.Path('.tmp/m5-runtime/environment.json').read_text())
b=pathlib.Path(env['M5_CLIENT_EXECUTABLE']).read_bytes()
for term in sys.argv[1:]:
  needle=term.encode()
  indices=[m.start() for m in re.finditer(re.escape(needle),b)]
  print(term, 'count', len(indices))
  for pos in indices[-5:]: print(b[max(0,pos-300):pos+800].decode('utf8',errors='replace'))
