import { createOpenCodeRuntime } from '../../../packages/conformance/src/joint-clients.drivers.js'
import { writeFileSync } from 'node:fs'
import { resolve } from 'node:path'
const root = process.env.M5_EVIDENCE_ROOT!
const driver = await createOpenCodeRuntime({ executable: process.env.M5_CLIENT_EXECUTABLE!, evidenceRoot: root })
try {
  for (const command of ['run', 'serve']) {
    const receipt = await driver.output([command, '--help'])
    writeFileSync(resolve(root, `${command}-help.json`), JSON.stringify(receipt, null, 2))
    console.log(receipt.stdout)
  }
} finally { await driver.close() }
