const fs=require('node:fs');
const p='docs/reviews/d1a/evidence/reverification-index.json';const d=JSON.parse(fs.readFileSync(p,'utf8'));
const old=d.runs.find(x=>x.id==='reverification-environment-07');
old.e2eHtmlReport='evidence/reverification-environment-07/e2e-html-report/index.html';
old.e2eFailureCaptures=[...old.e2eFailureCaptures,'evidence/reverification-environment-07/e2e-failure-captures/video.webm','evidence/reverification-environment-07/e2e-failure-captures/trace-sanitized.zip'];
const vp='docs/reviews/d1a/verification.md';let t=fs.readFileSync(vp,'utf8').replace(/^\uFEFF/,'');
t=t.replace('| `pnpm lint` / `pnpm typecheck` | 各 18/18 Turbo 任务通过 | 同上，`lint` / `typecheck` |','| `pnpm lint` / `pnpm typecheck` | 环境 08 重跑均为 18/18 Turbo 任务通过 | [`reverification-environment-08/run-binding.json`](evidence/reverification-environment-08/run-binding.json)，`lint` / `typecheck` |');
t=t.replace('[`stage0.spec.ts`](../../../../apps/web/e2e/stage0.spec.ts)','[`stage0.spec.ts`](../../../apps/web/e2e/stage0.spec.ts)');
fs.writeFileSync(p,JSON.stringify(d,null,2)+'\n');fs.writeFileSync(vp,t);
