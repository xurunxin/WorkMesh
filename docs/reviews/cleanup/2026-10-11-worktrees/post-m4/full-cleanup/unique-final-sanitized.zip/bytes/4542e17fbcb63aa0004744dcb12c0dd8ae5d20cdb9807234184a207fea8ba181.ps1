$ErrorActionPreference = 'Stop'
$root = (Get-Location).Path
$evidence = Join-Path $root 'docs/reviews/d1a/evidence/reverification-environment-07'
$logs = Join-Path $evidence 'logs'
New-Item -ItemType Directory -Force $logs | Out-Null
$sourcePaths = @('packages/ui/src/tokens.css','apps/web/features/navigation/theme.test.tsx','apps/web/features/navigation/theme-token-baseline.json','apps/web/e2e/theme-unification.spec.ts')
$containers = @('wm-d1a-env07-pg','wm-d1a-env07-redis','wm-d1a-env07-rustfs')
$envNames = @('RUN_INTEGRATION','DATABASE_URL','REDIS_URL','SESSION_SECRET','WORKMESH_MASTER_KEY','WORKMESH_BOOTSTRAP_TOKEN','WORKMESH_RUNNER_SERVICE_TOKEN','S3_ENDPOINT','S3_REGION','S3_BUCKET','S3_ACCESS_KEY_ID','S3_SECRET_ACCESS_KEY','S3_FORCE_PATH_STYLE','WEB_ORIGIN','NEXT_PUBLIC_API_URL','WORKMESH_PLAYWRIGHT_RUN_DIR')
$savedEnv = @{}
foreach ($name in $envNames) { $item = Get-Item "Env:$name" -ErrorAction SilentlyContinue; $savedEnv[$name] = if ($null -eq $item) { [pscustomobject]@{ exists = $false; value = $null } } else { [pscustomobject]@{ exists = $true; value = $item.Value } } }
$ops = [System.Collections.Generic.List[object]]::new()
$checks = [System.Collections.Generic.List[object]]::new()
$setupCommands = [System.Collections.Generic.List[object]]::new()
$cleanupCommands = [System.Collections.Generic.List[object]]::new()
$secretValues = @()
function Write-JsonFile($path, $value) { $value | ConvertTo-Json -Depth 30 | Set-Content -LiteralPath $path -Encoding utf8 }
function Get-SourceState {
  $parts = @("HEAD=$((git rev-parse HEAD).Trim())", "TREE=$((git rev-parse 'HEAD^{tree}').Trim())")
  $files = @()
  foreach ($path in $sourcePaths) { $oid = (git rev-parse "HEAD:$path").Trim(); $sha = (Get-FileHash -LiteralPath $path -Algorithm SHA256).Hash.ToLowerInvariant(); $files += [pscustomobject]@{ path = $path; gitBlob = $oid; worktreeSha256 = $sha }; $parts += "$path=$oid/$sha" }
  $dirty = @(git status --porcelain -- $sourcePaths); $parts += "sourceDirty=$($dirty -join '|')"
  $digest = [System.Security.Cryptography.SHA256]::HashData([System.Text.Encoding]::UTF8.GetBytes(($parts -join "`n")))
  [pscustomobject]@{ head = (git rev-parse HEAD).Trim(); tree = (git rev-parse 'HEAD^{tree}').Trim(); fingerprint = ([Convert]::ToHexString($digest).ToLowerInvariant()); sourceDirty = $dirty; files = $files }
}
function Invoke-Logged($label, $exe, $argv, $sink) {
  $output = @(& $exe @argv 2>&1 | ForEach-Object { $_.ToString() })
  $code = $LASTEXITCODE
  $row = [pscustomobject]@{ command = $label; exitCode = $code; output = $output }
  $sink.Add($row)
  if ($code -ne 0) { throw "$label failed with exit $code" }
  return $output
}
function Save-Transcript($path, $rows) { $lines = foreach ($row in $rows) { "COMMAND: $($row.command)`nEXIT: $($row.exitCode)`n$($row.output -join "`n")`n" }; Set-Content -LiteralPath $path -Value $lines -Encoding utf8 }
$baseHead = (git rev-parse HEAD).Trim()
$baseTree = (git rev-parse 'HEAD^{tree}').Trim()
$pgPassword = $null; $s3Access = $null; $s3Secret = $null; $sessionSecret = $null; $masterKey = $null; $bootstrapToken = $null
$testExit = 1
try {
  Write-Output 'ENV07: checking names'
  foreach ($container in $containers) { $found = @(& docker ps -a --filter "name=^/$container$" --format '{{.Names}}'); if ($found.Count) { throw "Refusing to reuse existing container $container" } }
  $pgPassword = [Convert]::ToHexString([System.Security.Cryptography.RandomNumberGenerator]::GetBytes(24)).ToLowerInvariant()
  $s3Access = 'd1a' + [Convert]::ToHexString([System.Security.Cryptography.RandomNumberGenerator]::GetBytes(8)).ToLowerInvariant()
  $s3Secret = [Convert]::ToHexString([System.Security.Cryptography.RandomNumberGenerator]::GetBytes(32)).ToLowerInvariant()
  $sessionSecret = [Convert]::ToHexString([System.Security.Cryptography.RandomNumberGenerator]::GetBytes(32)).ToLowerInvariant()
  $masterKey = [Convert]::ToHexString([System.Security.Cryptography.RandomNumberGenerator]::GetBytes(32)).ToLowerInvariant()
  $secretValues = @($pgPassword,$s3Access,$s3Secret,$sessionSecret,$masterKey)
  $bootstrapToken = ((& pnpm --silent bootstrap:token 2>$null) -join '').Trim()
  Write-Output 'ENV07: token command returned'
  if ($LASTEXITCODE -ne 0 -or $bootstrapToken -notmatch '^[A-Za-z0-9_-]{43,342}$') { throw 'Random bootstrap token generation/shape check failed' }
  $secretValues += $bootstrapToken
  Invoke-Logged 'docker run postgres:16-alpine on 127.0.0.1:25452 (password redacted)' 'docker' @('run','--detach','--name',$containers[0],'--publish','127.0.0.1:25452:5432','--env','POSTGRES_USER=workmesh','--env',"POSTGRES_PASSWORD=$pgPassword",'--env','POSTGRES_DB=workmesh_d1a_theme_e2e_test','postgres:16-alpine') $setupCommands | Out-Null
  Write-Output 'ENV07: postgres started'
  Invoke-Logged 'docker run redis:7-alpine on 127.0.0.1:26399' 'docker' @('run','--detach','--name',$containers[1],'--publish','127.0.0.1:26399:6379','redis:7-alpine') $setupCommands | Out-Null
  Invoke-Logged 'docker run rustfs/rustfs:1.0.0 on 127.0.0.1:29020 (credentials redacted)' 'docker' @('run','--detach','--name',$containers[2],'--publish','127.0.0.1:29020:9000','--env',"RUSTFS_ACCESS_KEY=$s3Access",'--env',"RUSTFS_SECRET_KEY=$s3Secret",'rustfs/rustfs:1.0.0') $setupCommands | Out-Null
  Write-Output 'ENV07: services started'
  Save-Transcript (Join-Path $evidence 'setup-commands.log') $setupCommands
  $ready = @{ postgres = $false; redis = $false; rustfs = $false }
  for ($i = 0; $i -lt 60; $i++) {
    & docker exec $containers[0] pg_isready -U workmesh -d workmesh_d1a_theme_e2e_test *> $null; if ($LASTEXITCODE -eq 0) { $ready.postgres = $true }
    & docker exec $containers[1] redis-cli ping *> $null; if ($LASTEXITCODE -eq 0) { $ready.redis = $true }
    try { $response = Invoke-WebRequest -Uri 'http://127.0.0.1:29020/health/ready' -TimeoutSec 2; if ($response.StatusCode -eq 200) { $ready.rustfs = $true } } catch {}
    if ($i % 10 -eq 0) { Write-Output "ENV07 readiness attempt=$i state=$($ready | ConvertTo-Json -Compress)" }
    if ($ready.postgres -and $ready.redis -and $ready.rustfs) { break }
    Start-Sleep -Seconds 2
  }
  if (-not ($ready.postgres -and $ready.redis -and $ready.rustfs)) { throw "Service readiness failed: $($ready | ConvertTo-Json -Compress)" }
  $probe = [pscustomobject]@{ command = 'docker exec pg_isready / redis-cli ping / GET http://127.0.0.1:29020/health/ready'; exitCode = 0; output = @('postgres: accepting connections; redis: PONG; rustfs readiness endpoint: HTTP 200') }; $setupCommands.Add($probe)
  $setupCommands.Add([pscustomobject]@{ command = 'PostgreSQL container initialization created POSTGRES_DB=workmesh_d1a_theme_e2e_test'; exitCode = 0; output = @('Database readiness verified by pg_isready against the named test database') })
  $env:RUN_INTEGRATION = '1'; $env:DATABASE_URL = "postgres://workmesh:$pgPassword@127.0.0.1:25452/workmesh_d1a_theme_e2e_test"
  $env:REDIS_URL = 'redis://127.0.0.1:26399'; $env:SESSION_SECRET = $sessionSecret; $env:WORKMESH_MASTER_KEY = $masterKey; $env:WORKMESH_BOOTSTRAP_TOKEN = $bootstrapToken
  $env:S3_ENDPOINT = 'http://127.0.0.1:29020'; $env:S3_REGION = 'us-east-1'; $env:S3_BUCKET = 'workmesh-artifacts'; $env:S3_ACCESS_KEY_ID = $s3Access; $env:S3_SECRET_ACCESS_KEY = $s3Secret; $env:S3_FORCE_PATH_STYLE = 'true'
  $env:WEB_ORIGIN = 'http://127.0.0.1:3100'; $env:NEXT_PUBLIC_API_URL = 'http://127.0.0.1:3101'; $env:WORKMESH_PLAYWRIGHT_RUN_DIR = [System.IO.Path]::GetFullPath((Join-Path $root '.tmp/d1a-bound-e2e-env07'))
  $nodeCode = 'const {createRequire}=require("node:module");const req=createRequire(process.cwd()+"/package.json");const {S3Client,CreateBucketCommand,ListBucketsCommand}=req("@aws-sdk/client-s3");(async()=>{const c=new S3Client({endpoint:process.env.S3_ENDPOINT,region:process.env.S3_REGION,forcePathStyle:true,credentials:{accessKeyId:process.env.S3_ACCESS_KEY_ID,secretAccessKey:process.env.S3_SECRET_ACCESS_KEY}});await c.send(new CreateBucketCommand({Bucket:"workmesh-artifacts",ObjectLockEnabledForBucket:true}));const r=await c.send(new ListBucketsCommand({}));if(!r.Buckets.some(b=>b.Name==="workmesh-artifacts"))throw Error("test bucket missing");console.log("Created and verified isolated bucket workmesh-artifacts");c.destroy()})().catch(e=>{console.error(e.name+":"+e.message);process.exit(1)})'
  Push-Location packages/recovery; try { Invoke-Logged 'create and verify isolated S3 bucket through RustFS (credentials redacted)' 'pnpm' @('exec','node','-e',$nodeCode) $setupCommands | Out-Null } finally { Pop-Location }
  $containerInfo = @{}
  foreach ($container in $containers) { $info = (& docker inspect $container | ConvertFrom-Json)[0]; $containerInfo[$container] = [pscustomobject]@{ image = $info.Config.Image; imageId = $info.Image; running = $info.State.Running; health = if ($info.State.Health) { $info.State.Health.Status } else { 'no-healthcheck; direct probe passed' }; portBindings = $info.NetworkSettings.Ports } }
  $state = Get-SourceState
  if ($state.sourceDirty.Count) { throw 'Protected source is dirty before targeted E2E' }
  Write-JsonFile (Join-Path $evidence 'source-before.json') $state
  Write-JsonFile (Join-Path $evidence 'service-setup.json') ([pscustomobject]@{ purpose = 'new independent re-execution; does not reconstruct the missing bound-02 setup'; head = $baseHead; tree = $baseTree; readiness = $ready; containers = $containerInfo; testDatabase = 'workmesh_d1a_theme_e2e_test'; testBucket = 'workmesh-artifacts'; environment = @{ RUN_INTEGRATION = '1'; DATABASE_URL = 'dedicated loopback PostgreSQL test database; password redacted'; REDIS_URL = 'loopback dedicated Redis'; S3_ENDPOINT = 'loopback dedicated RustFS'; WORKMESH_BOOTSTRAP_TOKEN = 'random token generated and redacted'; otherSecrets = 'random ephemeral values, redacted' }; tokenGenerated = $true; tokenPrintedOrPersisted = $false })
  Save-Transcript (Join-Path $evidence 'setup-commands.log') $setupCommands
  $before = Get-SourceState
  $log = Join-Path $logs 'theme-e2e.log'
  & pnpm --filter @workmesh/web test:e2e e2e/theme-unification.spec.ts 2>&1 | Tee-Object -FilePath $log
  $testExit = $LASTEXITCODE
  $after = Get-SourceState
  $check = [pscustomobject]@{ id = 'theme-e2e'; command = 'pnpm --filter @workmesh/web test:e2e e2e/theme-unification.spec.ts'; exitCode = $testExit; log = 'logs/theme-e2e.log'; logBytes = (Get-Item $log).Length; logSha256 = (Get-FileHash $log -Algorithm SHA256).Hash.ToLowerInvariant(); sourceBeforeFingerprint = $before.fingerprint; sourceAfterFingerprint = $after.fingerprint; headBefore = $before.head; headAfter = $after.head; treeBefore = $before.tree; treeAfter = $after.tree; dirtyBefore = $before.sourceDirty; dirtyAfter = $after.sourceDirty }
  $checks.Add($check)
  $fullBefore = Get-SourceState
  $fullLog = Join-Path $logs 'e2e-suite.log'
  & pnpm test:e2e 2>&1 | Tee-Object -FilePath $fullLog
  $fullExit = $LASTEXITCODE; if ($fullExit -ne 0) { $testExit = $fullExit }
  $fullAfter = Get-SourceState
  $checks.Add([pscustomobject]@{ id = 'e2e-suite'; command = 'pnpm test:e2e'; exitCode = $fullExit; log = 'logs/e2e-suite.log'; logBytes = (Get-Item $fullLog).Length; logSha256 = (Get-FileHash $fullLog -Algorithm SHA256).Hash.ToLowerInvariant(); sourceBeforeFingerprint = $fullBefore.fingerprint; sourceAfterFingerprint = $fullAfter.fingerprint; headBefore = $fullBefore.head; headAfter = $fullAfter.head; treeBefore = $fullBefore.tree; treeAfter = $fullAfter.tree; dirtyBefore = $fullBefore.sourceDirty; dirtyAfter = $fullAfter.sourceDirty })
  $d0Before = Get-SourceState
  $d0Log = Join-Path $logs 'd0-baseline.log'
  & pnpm --dir apps/web exec playwright test --config playwright.d0.config.ts --update-snapshots=none 2>&1 | Tee-Object -FilePath $d0Log
  $d0Exit = $LASTEXITCODE; if ($d0Exit -ne 0) { $testExit = $d0Exit }
  $d0After = Get-SourceState
  $checks.Add([pscustomobject]@{ id = 'd0-baseline'; command = 'pnpm --dir apps/web exec playwright test --config playwright.d0.config.ts --update-snapshots=none'; exitCode = $d0Exit; log = 'logs/d0-baseline.log'; logBytes = (Get-Item $d0Log).Length; logSha256 = (Get-FileHash $d0Log -Algorithm SHA256).Hash.ToLowerInvariant(); sourceBeforeFingerprint = $d0Before.fingerprint; sourceAfterFingerprint = $d0After.fingerprint; headBefore = $d0Before.head; headAfter = $d0After.head; treeBefore = $d0Before.tree; treeAfter = $d0After.tree; dirtyBefore = $d0Before.sourceDirty; dirtyAfter = $d0After.sourceDirty })
  Write-JsonFile (Join-Path $evidence 'source-after.json') $d0After
  Write-JsonFile (Join-Path $evidence 'run-binding.json') ([pscustomobject]@{ id = 'reverification-environment-07'; head = $baseHead; tree = $baseTree; initialFingerprint = $before.fingerprint; finalFingerprint = $d0After.fingerprint; runtime = @{ node = (node --version); pnpm = (pnpm --version); playwright = (pnpm --filter @workmesh/web exec playwright --version); os = [System.Runtime.InteropServices.RuntimeInformation]::OSDescription; architecture = [System.Runtime.InteropServices.RuntimeInformation]::OSArchitecture.ToString() }; checks = @($checks) })
} catch {
  $err = $_.Exception.Message
  Set-Content -LiteralPath (Join-Path $evidence 'setup-error.txt') -Value $err -Encoding utf8
  if (-not (Test-Path (Join-Path $evidence 'source-before.json'))) { $state = Get-SourceState; Write-JsonFile (Join-Path $evidence 'source-before.json') $state }
  $testExit = 1
} finally {
  foreach ($container in $containers) {
    $exists = @(& docker ps -a --filter "name=^/$container$" --format '{{.Names}}')
    if ($exists.Count) {
      $out = @(& docker rm --force $container 2>&1 | ForEach-Object { $_.ToString() }); $code = $LASTEXITCODE
      $cleanupCommands.Add([pscustomobject]@{ command = "docker rm --force $container"; exitCode = $code; output = $out })
    } else { $cleanupCommands.Add([pscustomobject]@{ command = "docker rm --force $container (container absent)"; exitCode = 0; output = @('container absent') }) }
  }
  $remaining = @(& docker ps -a --filter 'name=wm-d1a-env07-' --format '{{.Names}}')
  $cleanupCommands.Add([pscustomobject]@{ command = "docker ps -a --filter name=wm-d1a-env07- --format {{.Names}}"; exitCode = $LASTEXITCODE; output = $remaining })
  $restoreRows = @()
  foreach ($name in $envNames) {
    $old = $savedEnv[$name]
    if ($old.exists) { Set-Item "Env:$name" $old.value; $operation = "Set-Item Env:$name (original value retained, redacted)" } else { Remove-Item "Env:$name" -ErrorAction SilentlyContinue; $operation = "Remove-Item Env:$name" }
    $now = Get-Item "Env:$name" -ErrorAction SilentlyContinue
    $same = if ($old.exists) { $null -ne $now -and $now.Value -ceq $old.value } else { $null -eq $now }
    $restoreRows += [pscustomobject]@{ name = $name; operation = $operation; wasSet = $old.exists; verified = $same; exitCode = 0 }
  }
  Save-Transcript (Join-Path $evidence 'cleanup-commands.log') $cleanupCommands
  Write-JsonFile (Join-Path $evidence 'cleanup.json') ([pscustomobject]@{ cleanupCommands = $cleanupCommands; remainingTaskContainers = $remaining; containersDestroyed = ($remaining.Count -eq 0 -and @($cleanupCommands | Where-Object { $_.exitCode -ne 0 }).Count -eq 0); environmentRestoreOperations = $restoreRows; environmentRestored = (@($restoreRows | Where-Object { -not $_.verified }).Count -eq 0); dedicatedDatabaseAndBucketDestroyedWithContainerFilesystems = ($remaining.Count -eq 0) })
}
Write-Output "RUN=environment-07 exit=$testExit head=$baseHead"
if ($testExit -ne 0) { exit $testExit }
