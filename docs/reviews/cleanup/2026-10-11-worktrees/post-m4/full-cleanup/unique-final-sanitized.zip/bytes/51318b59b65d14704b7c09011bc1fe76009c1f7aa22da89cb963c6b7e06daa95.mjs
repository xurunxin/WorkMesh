import { readFileSync, writeFileSync } from 'node:fs'
import { createHash } from 'node:crypto'
import { execFileSync } from 'node:child_process'

const root = process.cwd()
const directory = 'docs/reviews/b1-b2/'
const read = path => readFileSync(path)
const json = path => JSON.parse(read(path).toString('utf8'))
const hash = value => createHash('sha256').update(value).digest('hex')
const git = (...args) => execFileSync('git', args, { cwd: root, maxBuffer: 32 * 1024 * 1024 })
const write = (name, value) => writeFileSync(directory + name, JSON.stringify(value, null, 2) + '\n')
const baseline = git('rev-parse', 'HEAD').toString().trim()
const original = json('docs/reviews/r1/test-coverage.json')
const legacy = json('docs/reviews/r1/legacy-requirements.json')
const index = json('docs/plan/activation-task-specs/index.json')
const feature = original.features.find(row => row.seqNum === 5)
const task = index.tasks.find(row => row.seqNum === 5)
const source = json(directory + 'source-snapshot.json')
const inputs = json(directory + 'todo-inputs.json')
const connectorTest = 'apps/connector/src/connect.test.ts'
const nativeTest = 'apps/connector/integration/native-storage.test.ts'
const apiTest = 'apps/api/integration/stage5-agent-connections.integration.test.ts'
const perTest = [
  { modules: ['pending.ts', 'connect.ts'], tests: [connectorTest, apiTest], focus: '持久化后发送前/后强制终止、客户端及服务端重启、丢响应恢复同一 key/body/context 和同一凭据。' },
  { modules: ['pending.ts', 'protocol.ts'], tests: [connectorTest, apiTest], focus: '同 key 异体冲突、新 key 对已消费 code 拒绝；仅持配对码和公开 Connection id 的陌生 claimant 取不到令牌。' },
  { modules: ['platform-security.ts', 'pending.ts'], tests: [connectorTest, nativeTest, apiTest], focus: '窗口外/密文擦除拒绝，真实双进程竞争复用身份，临时文件及 pending 原子性。' },
  { modules: ['protocol.ts'], tests: [apiTest], focus: '原有 replay.body === first.body 断言继续执行，不以新增客户端测试替代。' },
  { modules: ['protocol.ts', 'commit.ts', 'cli.ts'], tests: [connectorTest, apiTest], focus: '同一 connect 命令完成两步流程及完整七项校验，真实 API/MCP 黄金路径。' },
  { modules: ['config.ts', 'protocol.ts'], tests: [connectorTest, apiTest], focus: '逐个破坏指纹、原始 Skill 字节/哈希/签名、Team、principal、Agent/Connection、profile、Skill pin、能力及 authenticated_credential；每项独立拒绝且零正式写入。' },
  { modules: ['protocol.ts', 'commit.ts'], tests: [connectorTest, apiTest], focus: '重放得到历史响应后仍实时验证，已撤销/过期/overlap 凭据不提交新配置。' },
  { modules: ['commit.ts', 'secret-store.ts'], tests: [connectorTest, nativeTest, apiTest], focus: '秘密写入、读回、删除、rename 与各提交阶段被杀；提交点前补偿、提交点后收尾；旧配置原字节和旧引用保持，删除失败阻止新提交。' },
  { modules: ['platform-security.ts', 'secret-store.ts', 'cli.ts'], tests: [connectorTest, nativeTest], focus: '三种 OS 真实秘密存储及禁止降级，POSIX 权限/Windows 实际 ACL 和普通不同用户读取拒绝；stdout/stderr/正式配置/提交记录/工件无明文秘密。' },
  { modules: ['pending.ts', 'commit.ts', 'cli.ts'], tests: [connectorTest, nativeTest, apiTest], focus: '未提交同码复用 pending；并发等待者识别已提交同次配对；成功后同码重跑重新验证并幂等返回；直接输入/扫码保留完整高熵配对码。' },
]
const taskMapping = [
  { checkpoint: '持久化', modules: ['config.ts', 'platform-security.ts', 'pending.ts'], originalTestIds: [1, 2, 3, 9, 10], scope: '发送前独占持久化随机请求身份及敏感配对码；ACL/跨用户边界，崩溃接手和精确重放。' },
  { checkpoint: '完整协议验证', modules: ['protocol.ts'], originalTestIds: [4, 5, 6, 7], scope: '复用公开 discovery/兑换/实时身份契约；Skill 原字节签名、七项校验和当前凭据验证先于正式写入。' },
  { checkpoint: '本地提交与幂等完成', modules: ['secret-store.ts', 'commit.ts', 'connect.ts', 'cli.ts'], originalTestIds: [5, 7, 8, 9, 10], scope: '仅系统秘密存储、自有引用配置；阶段记录/补偿、完成识别和子进程环境注入。' },
  { checkpoint: '验收与交接', modules: ['connect.test.ts'], originalTestIds: [1, 2, 3, 4, 5, 6, 7, 8, 9, 10], scope: '保持冻结原测试与 DoD，新增平台门禁、既有服务端回归、全部适用必需检查和独立复核。' },
]
write('test-coverage.json', {
  todoId: task.todoId,
  plan: 'docs/plan/connector-recovery.md',
  currentPhase: '仅文档前置，待独立方案审查与Chief放行',
  functionalResult: '未运行',
  rule: 'frozenSourceFeatures 和 legacySourceTasks 是完整历史对象；其文字及状态不得改写为本次功能通过。implementationMappings 只说明计划去向，文件待创建不等于实现。',
  nineCategories: original.nineCategories,
  requires: task.requires,
  requiresTodoIds: task.requiresTodoIds,
  acceptanceRequires: task.acceptanceRequires,
  blocks: task.blocks,
  blocksTodoIds: task.blocksTodoIds,
  frozenSourceFeatures: original.features.filter(row => [5, 6, 20].includes(row.seqNum)),
  legacySourceTasks: legacy.tasks.filter(row => ['B1', 'B2', 'B4'].includes(row.task)),
  implementationMappings: taskMapping.map(row => ({ ...row, originalTestIds: row.originalTestIds.map(number => feature.originalTests[number - 1].id), modules: row.modules.map(path => 'apps/connector/src/' + path), result: '未运行' })),
  originalTestMappings: feature.originalTests.map((row, number) => ({ sourceId: row.id, sourceText: row.text, originalCaseName: row.caseName, ...perTest[number], modules: perTest[number].modules.map(path => 'apps/connector/src/' + path), result: '未运行', fileState: '连接器文件待创建；Stage 5 文件现有，扩展待实施' })),
  categoryMappings: feature.matrix.map(row => ({ category: row.category, applicable: row.applicable, reason: row.reason, assertion: row.assertion, originalCaseName: row.caseName, tests: row.applicable ? [...new Set([row.file, ...(row.additionalFiles ?? []).map(file => file.path)])] : [], result: row.applicable ? '未运行' : '不适用' })),
  dod: { source: feature.originalDoD, result: '未运行', checks: ['pnpm lint', 'pnpm typecheck', 'pnpm test', 'pnpm test:integration', 'pnpm test:e2e'], platformAcceptance: { Windows: '未运行', macOS: '未运行', Linux: '未运行' }, zeroMigration: '实施后验证；当前文档前置无迁移改动', independentReview: '待审', chiefConfirmation: null },
  downstream: { seqNum: 20, todoId: 'JfGwKk3prfIie6X2u2J51', owner: 'B-ship 执行者／Chief 裁定发布矩阵', scope: '保留历史 B2 的版本化/无源码设备安装、B4 文档、升级/卸载及外部发布边界；本卡不执行设备安装或发布', result: '未运行' },
})
const inputPaths = [
  'AGENTS.md', 'CONTEXT.md', 'AGENT_PROTOCOL.md', 'OPENAPI.yaml', 'SCHEMA.sql',
  'docs/adr/0043-agent-connection-and-coordination-mcp.md',
  'docs/adr/0046-agent-connection-recovery-and-execution-capacity.md',
  'docs/adr/0075-verifiable-and-simplified-agent-connection-onboarding.md',
  'docs/plan/2026-10-07-activation-onboarding-and-china-ecosystem.md',
  'docs/plan/activation-task-specs/05.md',
  'docs/plan/activation-task-specs/index.json',
  'docs/reviews/r1/execution-inputs.json',
  'docs/reviews/r1/test-coverage.json',
  'docs/reviews/r1/legacy-requirements.json',
]
const pathHashes = inputPaths.map(path => {
  const worktree = read(path)
  const blob = git('show', baseline + ':' + path)
  return { path, worktreeBytes: worktree.length, worktreeSha256: hash(worktree), baseBlobId: git('rev-parse', baseline + ':' + path).toString().trim(), baseBlobBytes: blob.length, baseBlobSha256: hash(blob) }
})
const plan = read('docs/plan/connector-recovery.md')
const prefix = source.todoReadback.split('\nSaved plan:\n')[1].split('\n…(truncated)')[0]
if (!source.planBody.startsWith(prefix)) throw new Error('完整注入正文与工具可读前缀不一致')
const evidenceFiles = ['docs/plan/connector-recovery.md', ...['source-snapshot.json', 'todo-inputs.json', 'test-coverage.json', 'review-guide.md', 'verify-plan.mjs'].map(name => directory + name)]
write('plan-source.json', {
  todoId: task.todoId,
  projectId: 'DzkLDn6UW-IbfoTJzN9Ro',
  currentPlan: { id: source.source.docId, reference: source.source.docReference, version: null, createdAt: null, updatedAt: null, newIdCreated: false, sourceKind: source.source.kind, sourceArtifact: directory + 'source-snapshot.json', sourceBodySha256: hash(Buffer.from(source.planBody, 'utf8')), sourceBodyUtf8Bytes: Buffer.byteLength(source.planBody, 'utf8'), extraction: source.source.extraction, readableFile: 'docs/plan/connector-recovery.md', readableFileSha256: hash(plan), readableFileUtf8Bytes: plan.length, displayTransform: '仅删除空白行上的空格或制表符，并添加文件末尾 LF；不修改文字/段落/代码/链接', displayWhitespaceOnlyLines: source.planBody.split('\n').filter(line => line !== '' && line.trim() === '').length, toolFullReadback: false, toolVisiblePrefixUtf8Bytes: Buffer.byteLength(prefix, 'utf8'), toolVisiblePrefixSha256: hash(Buffer.from(prefix, 'utf8')), toolVisiblePrefixMatches: true },
  toolLimitations: [source.source.toolLimitation, '工具没有提供计划版本及时间字段，均记录 null；不将卡片 updatedAt 当计划版本时间', '任务卡回读不包含最终完整计划的独立 doc 读取回执；完整源来自实际平台注入，二者来源分别标识'],
  authorization: { implementationConfirmedByUser: true, choicesConfirmedByUser: ['系统秘密存储', '本地预期清单', '连接器自有配置'], currentScope: '仅完成文档前置并停review供独立方案审查，尚不开始产品改动', independentPlanReview: '待审', chiefRelease: null, productChanges: [], postImplementationChecks: '未运行；文档前置阶段无需运行全套产品检查', actualControlPlane: 'Todos＋仓库；本批例外，未创建真实WorkMesh Project/WorkItem' },
  repository: { branch: git('branch', '--show-current').toString().trim(), worktreeHead: baseline, latestMain: '1078bbcd527550bfabee73093b7ffd0032d3fd24', mainSource: '本轮 mcp__tds__git fetch origin main 后 rev-parse FETCH_HEAD', mainInputDelta: '对 apps/api、apps/mcp、packages/contracts、当前卡冻结spec、AGENT_PROTOCOL.md、OPENAPI.yaml、SCHEMA.sql 的 HEAD..FETCH_HEAD 文件差异为空；最新主线已增加 D1a，其余未据此冒称已整合到本工作树', integratedMain: false },
  taskSource: { tool: 'mcp__tds__todos', atomicSnapshot: false, current: inputs.entries.find(row => row.id === task.todoId), note: 'rawToolText保留原始截断标记；不以原 frozen specSha256冒充当前全文哈希', entries: inputs.entries.map(row => ({ id: row.id, phase: row.phase, updatedAt: row.updatedAt, toolTruncated: row.toolTruncated, rawToolTextUtf8Sha256: hash(Buffer.from(row.rawToolText, 'utf8')) })) },
  frozenInputHashes: pathHashes,
  files: evidenceFiles.map(path => ({ path, bytes: read(path).length, sha256: hash(read(path)) })),
  hashPolicy: 'SHA-256和bytes是捕获时本工作树原字节；计划原始正文哈希另对source-snapshot.json中planBody解码后的UTF-8计算；Git blob按基点和提交后另核对。plan-source.json不把自身加入files，避免自引用哈希。',
})
console.log('已生成文档来源与完整测试映射；功能验收未运行。')
