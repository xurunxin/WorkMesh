import { createServer } from 'node:http'
import { once } from 'node:events'
import { writeFileSync } from 'node:fs'
import { resolve } from 'node:path'
import { McpServer } from '../../../packages/conformance/node_modules/@modelcontextprotocol/sdk/dist/esm/server/mcp.js'
import { StreamableHTTPServerTransport } from '../../../packages/conformance/node_modules/@modelcontextprotocol/sdk/dist/esm/server/streamableHttp.js'
import { createOpenCodeRuntime } from '../../../packages/conformance/src/joint-clients.drivers.js'
import { createJointModel } from '../../../packages/conformance/src/joint-clients.model.js'
const evidenceRoot = process.env.M5_EVIDENCE_ROOT!
const sentinel = { data: { marker: 'M5_NATIVE_READ_ONLY_PROTOCOL_SMOKE', backendIdentityVerified: false,
  publicPayload: '公开只读协议夹具'.repeat(12000) } }
const requests: unknown[] = [], calls: unknown[] = []
const mcp = createServer(async (request, response) => {
  requests.push({ at: new Date().toISOString(), method: request.method, url: request.url })
  const server = new McpServer({ name: 'm5-read-only-protocol-smoke', version: '1.0.0' })
  server.registerTool('load_agent_facts', { description: 'Read simulated smoke facts; no database, identity, or mutation.', inputSchema: {} }, async args => {
    calls.push({ at: new Date().toISOString(), args }); return { content: [{ type: 'text', text: JSON.stringify(sentinel) }] }
  })
  const transport = new StreamableHTTPServerTransport({ sessionIdGenerator: undefined })
  await server.connect(transport)
  response.on('close', () => { void transport.close(); void server.close() })
  await transport.handleRequest(request, response)
})
mcp.listen(0, '127.0.0.1'); await once(mcp, 'listening')
const model = await createJointModel(async (input, sequence) => {
  if (sequence > 0) return null
  const name = input.tools?.find(item => item.function.name.endsWith('_load_agent_facts'))?.function.name
  if (!name) throw new Error('SMOKE_NATIVE_TOOL_MISSING')
  return { name, arguments: {} }
})
let driver: Awaited<ReturnType<typeof createOpenCodeRuntime>> | undefined
try {
  driver = await createOpenCodeRuntime({ executable: process.env.M5_CLIENT_EXECUTABLE!, evidenceRoot, modelUrl: model.url,
    mcpUrl: `http://127.0.0.1:${(mcp.address() as { port: number }).port}/mcp`, allowedTools: ['load_agent_facts'] })
  const receipt = await driver.run()
  const results = model.captures.at(-1)?.results ?? []
  const passed = calls.length === 1 && results.some(item => typeof item === 'string' && item === JSON.stringify(sentinel))
  writeFileSync(resolve(evidenceRoot, 'roundtrip.json'), JSON.stringify({ scope: 'real native client + controlled model + simulated read-only MCP; no backend identity acceptance',
    passed, publicResponseBytes: Buffer.byteLength(JSON.stringify(sentinel)), receipt, model: model.captures, transport: model.transport, auxiliary: model.auxiliary, requests, calls }, null, 2))
  if (!passed) throw new Error('SMOKE_NATIVE_MODEL_RESULT_NOT_OBSERVED')
  console.log(JSON.stringify({ passed, calls: calls.length, modelRequests: model.captures.length, backendIdentityVerified: false }))
} finally {
  if (driver) await driver.close()
  mcp.closeAllConnections(); await new Promise<void>(done => mcp.close(() => done()))
  await model.close()
}
