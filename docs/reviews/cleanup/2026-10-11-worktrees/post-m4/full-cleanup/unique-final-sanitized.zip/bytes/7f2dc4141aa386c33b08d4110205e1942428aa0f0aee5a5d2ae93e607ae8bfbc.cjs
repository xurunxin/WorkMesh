const cp = require('node:child_process');
const fs = require('node:fs');
const crypto = require('node:crypto');
const paths = process.argv.slice(2);
const sha = (b) => crypto.createHash('sha256').update(b).digest('hex');
const head = cp.execFileSync('git', ['rev-parse', 'HEAD'], { encoding: 'utf8', maxBuffer: 64 * 1024 * 1024 }).trim();
const rows = paths.map((path) => {
  const oid = cp.execFileSync('git', ['rev-parse', `${head}:${path}`], { encoding: 'utf8', maxBuffer: 64 * 1024 * 1024 }).trim();
  const blob = cp.execFileSync('git', ['cat-file', 'blob', oid], { maxBuffer: 64 * 1024 * 1024 });
  const worktree = fs.readFileSync(path);
  const text = worktree.toString('utf8').replace(/^\uFEFF/, '').replace(/\r\n/g, '\n');
  const clean = Buffer.from(text, 'utf8');
  return { path, gitObject: oid, gitBytes: blob.length, gitSha256: sha(blob), worktreeBytes: worktree.length, worktreeSha256: sha(worktree), normalizedEqualsGitBlob: clean.equals(blob), checkoutTransform: clean.equals(blob) ? (worktree.equals(blob) ? 'identical' : 'UTF-8 checkout normalization (BOM/CRLF to LF)') : 'different content' };
});
process.stdout.write(JSON.stringify({ head, rows }, null, 2));
