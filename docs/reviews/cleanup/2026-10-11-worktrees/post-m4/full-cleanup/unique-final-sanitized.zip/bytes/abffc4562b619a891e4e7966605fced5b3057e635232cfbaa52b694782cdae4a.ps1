$ErrorActionPreference='Stop'
$root=(Get-Location).Path
$evidence=Join-Path $root 'docs/reviews/d1a/evidence/reverification-environment-08'
$paths=@('apps/web/e2e/stage0.spec.ts','packages/ui/src/tokens.css','apps/web/features/navigation/theme.test.tsx','apps/web/features/navigation/theme-token-baseline.json','apps/web/e2e/theme-unification.spec.ts')
function SourceState {
  $parts=@("HEAD=$((git rev-parse HEAD).Trim())","TREE=$((git rev-parse 'HEAD^{tree}').Trim())")
  foreach($path in $paths){$oid=(git rev-parse "HEAD:$path").Trim();$sha=(Get-FileHash -LiteralPath $path -Algorithm SHA256).Hash.ToLowerInvariant();$parts+="$path=$oid/$sha"}
  $dirty=@(git status --porcelain -- $paths);$parts+="sourceDirty=$($dirty -join '|')"
  $digest=[Security.Cryptography.SHA256]::HashData([Text.Encoding]::UTF8.GetBytes(($parts -join "`n")))
  [pscustomobject]@{head=(git rev-parse HEAD).Trim();tree=(git rev-parse 'HEAD^{tree}').Trim();fingerprint=([Convert]::ToHexString($digest).ToLowerInvariant());dirty=$dirty}
}
$b=Get-Content (Join-Path $evidence 'run-binding.json') -Raw|ConvertFrom-Json
foreach($id in @('lint','typecheck')){
  $before=SourceState
  $log=Join-Path $evidence "logs/$id.log"
  & pnpm $id 2>&1 | Tee-Object -FilePath $log
  $code=$LASTEXITCODE
  $after=SourceState
  $row=[pscustomobject]@{id=$id;command="pnpm $id";exitCode=$code;log="logs/$id.log";logBytes=(Get-Item $log).Length;logSha256=(Get-FileHash $log -Algorithm SHA256).Hash.ToLowerInvariant();sourceBeforeFingerprint=$before.fingerprint;sourceAfterFingerprint=$after.fingerprint;headBefore=$before.head;headAfter=$after.head;treeBefore=$before.tree;treeAfter=$after.tree;dirtyBefore=$before.dirty;dirtyAfter=$after.dirty}
  $b.checks=@($b.checks)+$row
  if($code -ne 0){throw "pnpm $id failed with exit $code"}
}
$final=SourceState;$b.finalFingerprint=$final.fingerprint
$b|ConvertTo-Json -Depth 30|Set-Content -LiteralPath (Join-Path $evidence 'run-binding.json') -Encoding utf8
