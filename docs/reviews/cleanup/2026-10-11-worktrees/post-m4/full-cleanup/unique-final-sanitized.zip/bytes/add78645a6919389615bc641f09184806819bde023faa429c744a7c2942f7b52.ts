import { expect, test } from '@playwright/test'

test('Project creation and revisioned edit keep Markdown and the selected URL after reload', async ({ page }) => {
  const originalName = `WebPi project ${Date.now()}`
  const updatedName = `${originalName} updated`
  await page.goto('/?view=projects')
  await page.locator('.project-rail header').getByRole('button', { name: /新建项目|New project/ }).click()
  const create = page.getByTestId('create-project')
  await create.locator('input[name="name"]').fill(originalName)
  await create.locator('input[name="summary"]').fill('Project summary')
  await create.locator('textarea[name="description"]').fill('## First revision\n\nReal Markdown description.')
  await create.getByRole('button', { name: /创建项目|Create project/ }).click()
  await expect(page.locator('.wm-page-head h1')).toHaveText(originalName)
  await expect(page).toHaveURL(/view=projects.*project=/)

  const milestoneName = `Milestone ${Date.now()}`
  await page.locator('.project-detail-pane').getByRole('button', { name: /里程碑|Milestones/ }).click()
  const milestones = page.getByTestId('project-milestones')
  await milestones.getByRole('button', { name: /新建里程碑|New milestone/ }).click()
  const milestoneForm = page.getByTestId('milestone-form')
  await milestoneForm.locator('input[name="name"]').fill(milestoneName)
  await milestoneForm.locator('textarea[name="description"]').fill('## First milestone\n\nTracked with the project.')
  await milestoneForm.getByRole('button', { name: /保存里程碑|Save milestone/ }).click()
  await expect(milestones.locator('strong').filter({ hasText: milestoneName })).toBeVisible()
  await milestones.getByRole('button', { name: new RegExp(`(?:编辑|Edit) ${milestoneName}`) }).click()
  await milestoneForm.locator('input[name="targetDate"]').fill('2026-10-15')
  await milestoneForm.getByRole('button', { name: /保存里程碑|Save milestone/ }).click()
  await expect(milestones.getByText('2026-10-15')).toBeVisible()
  await page.keyboard.press('Escape')
  await expect(milestones).toBeHidden()

  await page.locator('.project-detail-pane').getByRole('button', { name: /新建 Issue|New issue/ }).click()
  const issue = page.getByTestId('create-work-item')
  const issueTitle = `Project issue ${Date.now()}`
  await issue.locator('input[name="title"]').fill(issueTitle)
  await issue.locator('textarea[name="description"]').fill('## Project issue\n\nCreated from the selected Project.')
  await expect(issue.locator('select[name="projectId"]')).toHaveValue(new URL(page.url()).searchParams.get('project') ?? '')
  let issueCreateRequests = 0
  page.on('request', request => {
    if (request.method() === 'POST' && new URL(request.url()).pathname === '/api/v1/work-items') issueCreateRequests += 1
  })
  await issue.evaluate(form => {
    const target = form as HTMLFormElement
    target.requestSubmit()
    target.requestSubmit()
  })
  await expect(issue).toBeHidden()
  expect(issueCreateRequests).toBe(1)
  const selectedProjectId = new URL(page.url()).searchParams.get('project')
  await page.getByTestId('project-control-view-work').click()
  // The list renders before the App Router applies its URL. Complete that
  // navigation before opening a sheet that route restoration would clear.
  await expect(page).toHaveURL(url => url.searchParams.get('view') === 'projects'
    && url.searchParams.get('project') === selectedProjectId && url.searchParams.get('tab') === 'list')
  const firstIssue = page.locator('.project-detail-pane').getByRole('button', { name: issueTitle, exact: true })
  await expect(firstIssue).toBeVisible()
  await firstIssue.click()
  let detail = page.locator('.work-item-detail-sheet')
  await detail.getByRole('tab', { name: /详情|Details/ }).click()
  await detail.locator('select[name="milestoneId"]').selectOption({ label: milestoneName })
  await detail.getByRole('button', { name: /保存更改|Save changes/ }).click()
  // The sheet applies a save by round-tripping the projection and re-seeding
  // its draft, so the form only reports no unsaved edits once that lands.
  // Closing a still-dirty sheet answers a native discard prompt instead, which
  // Playwright dismisses, leaving the sheet open.
  await expect(detail.locator('.work-item-detail-actions').getByText(/Unsaved changes|有未保存的更改/)).toHaveCount(0)
  await expect(detail.locator('select[name="milestoneId"]')).toHaveValue(/.+/)
  await detail.getByRole('button', { name: /^(关闭|Close) / }).click()
  await expect(detail).toBeHidden()

  const relatedIssueTitle = `Related issue ${Date.now()}`
  await page.locator('.project-detail-pane').getByRole('button', { name: /新建 Issue|New issue/ }).click()
  const relatedCreate = page.getByTestId('create-work-item')
  await relatedCreate.locator('input[name="title"]').fill(relatedIssueTitle)
  await relatedCreate.getByTestId('create-work-item-submit').click()
  await expect(relatedCreate).toBeHidden()
  await firstIssue.click()
  detail = page.locator('.work-item-detail-sheet')
  await detail.getByRole('tab', { name: /概览|Overview/ }).click()
  const relationships = detail.locator('.relationship-panel')
  const target = relationships.locator('select[name="targetWorkItemId"] option').filter({ hasText: relatedIssueTitle })
  await expect(target).toHaveCount(1)
  await relationships.locator('select[name="targetWorkItemId"]').selectOption(await target.getAttribute('value') ?? '')
  await relationships.getByRole('button', { name: /添加关系|Add relationship/ }).click()
  await expect(relationships.locator('.relation-list')).toContainText(relatedIssueTitle)
  await detail.getByRole('button', { name: /打开完整页面|Open full page/ }).click()
  await expect(page).toHaveURL(/workItem=/)
  await expect(page.locator('.work-item-full-page .relation-list')).toContainText(relatedIssueTitle)
  await page.locator('.work-item-full-page').getByRole('button', { name: /关闭|Close/ }).click()
  await expect(page).not.toHaveURL(/workItem=/)
  await expect(page.locator('.wm-page-head h1')).toHaveText(originalName)

  await page.getByRole('button', { name: /编辑项目|Edit project/ }).click()
  const edit = page.getByTestId('edit-project')
  await edit.locator('input[name="name"]').fill(updatedName)
  await edit.locator('textarea[name="description"]').fill('## Second revision\n\nPersisted after reload.')
  await edit.getByRole('button', { name: /保存更改|Save changes/ }).click()
  await expect(page.locator('.wm-page-head h1')).toHaveText(updatedName)
  await page.locator('.hcp-project-description summary').click()
  await expect(page.locator('.hcp-project-description')).toContainText('Second revision')

  await page.reload()
  await expect(page.locator('.wm-page-head h1')).toHaveText(updatedName)
  await page.locator('.hcp-project-description summary').click()
  await expect(page.locator('.hcp-project-description')).toContainText('Persisted after reload.')

  await page.getByRole('button', { name: /编辑项目|Edit project/ }).click()
  const staleEdit = page.getByTestId('edit-project')
  const other = await page.context().newPage()
  await other.goto(page.url())
  await expect(other.locator('.wm-page-head h1')).toHaveText(updatedName)
  await other.getByRole('button', { name: /编辑项目|Edit project/ }).click()
  const otherEdit = other.getByTestId('edit-project')
  await otherEdit.locator('input[name="name"]').fill(`${updatedName} by another editor`)
  await otherEdit.getByRole('button', { name: /保存更改|Save changes/ }).click()
  await expect(other.locator('.wm-page-head h1')).toHaveText(`${updatedName} by another editor`)
  await other.close()

  const pendingMarkdown = '## Reviewed after conflict\n\nMy draft survives a stale revision.'
  await staleEdit.locator('textarea[name="description"]').fill(pendingMarkdown)
  await staleEdit.getByRole('button', { name: /保存更改|Save changes/ }).click()
  await expect(staleEdit.getByRole('alert')).toBeVisible()
  await expect(staleEdit.locator('textarea[name="description"]')).toHaveValue(pendingMarkdown)
  await staleEdit.getByRole('button', { name: /重新加载最新数据|Reload latest work/ }).click()
  const reconciliation = staleEdit.getByTestId('draft-reconciliation')
  await expect(reconciliation).toBeVisible()
  await reconciliation.getByRole('button', { name: /恢复并检查|Restore for review/ }).click()
  await expect(staleEdit.locator('textarea[name="description"]')).toHaveValue(pendingMarkdown)
  await staleEdit.getByRole('button', { name: /保存更改|Save changes/ }).click()
  await expect(page.locator('.wm-page-head h1')).toHaveText(`${updatedName} by another editor`)
  await expect(page.locator('.hcp-project-description')).toContainText('My draft survives a stale revision.')
})
