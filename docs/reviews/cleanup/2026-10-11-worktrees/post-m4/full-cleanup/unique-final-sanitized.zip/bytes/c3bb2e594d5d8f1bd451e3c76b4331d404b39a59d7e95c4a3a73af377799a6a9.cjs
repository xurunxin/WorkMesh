const fs=require('node:fs');
const p='docs/reviews/d1a/evidence/reverification-index.json';
const d=JSON.parse(fs.readFileSync(p,'utf8'));
const old=d.runs.find(x=>x.id==='reverification-bound-02');
old.serviceSetup=null;
old.serviceSetupStatus='MISSING: no service-setup.json exists in the tested HEAD or current worktree; do not infer this run environment from another run.';
old.environmentReplacementRun='reverification-environment-06';
const b=JSON.parse(fs.readFileSync('docs/reviews/d1a/evidence/reverification-environment-06/run-binding.json','utf8'));
const check=b.checks[0];
d.runs.push({
  id:'reverification-environment-06',
  serviceSetup:'evidence/reverification-environment-06/service-setup.json',
  setupTranscript:'evidence/reverification-environment-06/setup-commands.log',
  cleanup:'evidence/reverification-environment-06/cleanup.json',
  cleanupTranscript:'evidence/reverification-environment-06/cleanup-commands.log',
  head:b.head,tree:b.tree,initialFingerprint:b.initialFingerprint,finalFingerprint:b.finalFingerprint,
  runtime:b.runtime,checks:[{id:check.id,command:check.command,exitCode:check.exitCode,log:check.log,logBytes:check.logBytes,logSha256:check.logSha256,sourceBeforeFingerprint:check.sourceBeforeFingerprint,sourceAfterFingerprint:check.sourceAfterFingerprint,headBefore:check.headBefore,headAfter:check.headAfter,treeBefore:check.treeBefore,treeAfter:check.treeAfter,dirtyBefore:check.dirtyBefore,dirtyAfter:check.dirtyAfter}],
  result:'10/10 passed; this is a new source-bound rerun with captured isolated service setup and cleanup, not recovered bound-02 evidence.'
});
d.attemptNotes += ' Missing bound-02 service setup was not reconstructed; environment-04 and environment-05 setup failures are retained with their actual diagnostics and cleanup evidence where services were created. Environment-06 is the successful independent theme E2E rerun with a complete sanitized service/restore/destroy record.';
fs.writeFileSync(p,JSON.stringify(d,null,2)+'\n');
