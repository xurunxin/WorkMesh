const fs=require('node:fs');const p='docs/reviews/d1a/verification.md';const s=fs.readFileSync(p,'utf8').replace(/(?:\r?\n)*$/,'\n');fs.writeFileSync(p,s);
