'use client'

import {
  createContext,
  useContext,
  memo,
  useCallback,
  useEffect,
  useId,
  useMemo,
  useRef,
  useState,
  type ChangeEvent,
  type CSSProperties,
  type DragEvent,
  type FormEvent,
  type KeyboardEvent,
  type ReactNode,
  type RefObject,
} from 'react'
import type { PointerEvent as ReactPointerEvent } from 'react'
import { CalendarBlankIcon } from '@phosphor-icons/react/dist/csr/CalendarBlank'
import { FolderSimpleIcon } from '@phosphor-icons/react/dist/csr/FolderSimple'
import { FloppyDiskIcon } from '@phosphor-icons/react/dist/csr/FloppyDisk'
import { FunnelXIcon } from '@phosphor-icons/react/dist/csr/FunnelX'
import { GitBranchIcon } from '@phosphor-icons/react/dist/csr/GitBranch'
import { ProhibitIcon } from '@phosphor-icons/react/dist/csr/Prohibit'
import { RobotIcon } from '@phosphor-icons/react/dist/csr/Robot'
import { coordinateDismissalTriggerActivation, useDismissalLayer } from '../internal/overlay.js'
import { Button } from '../primitives/button.js'
import { BudgetChip, type SessionBudgetLimitKind } from './control-plane.js'

/** The share at which a row-sized budget chip starts warning, and the share at
 *  which it reads as spent. Both follow the prototype's dense-row budget bar. */
const BUDGET_WARNING_RATIO = 0.7
const BUDGET_DANGER_RATIO = 0.85

/** Presentation-only work-item data; transport DTOs are mapped by the feature layer. */
export type WorkItemCardData = {
  id: string
  identifier: string
  title: string
  statusId: string
  statusName: string
  statusCategory?: string
  priority?: string
  /** ISO calendar date (YYYY-MM-DD) the Issue is due, or null when unset. */
  dueDate?: string | null
  /** Fractional position the server assigned inside the status column. */
  boardRank?: number | null
  responsibleHuman?: string | null
  responsibleHumanActorId?: string | null
  projectId?: string | null
  projectName?: string | null
  labels?: string[]
  revision?: number
  activeAgent?: string | null
  activeAgentState?: string | null
  activeBudget?: {
    cap: number
    exhausted: boolean
    limit: SessionBudgetLimitKind
    measurable: boolean
    ratio: number | null
    used: number | null
    warning: boolean
  } | null
  blockedByCount?: number
  blockingCount?: number
  subIssueCount?: number
  completedSubIssueCount?: number
}

export type WorkItemCopy = {
  agentExecutionState: (state: string) => string
  allHumans: string
  allMilestones: string
  allPriorities: string
  allProjects: string
  allStatuses: string
  boardColumn: (name: string) => string
  clearFilters: string
  completedSubIssues: (completed: number, total: number) => string
  /**
   * The row's budget figure. `budgetLabel` is the accessible description of a
   * measurable entry and `budgetUnknown` states that the projection could not
   * observe usage - it never reports a zero it did not measure.
   */
  budgetLabel: (limit: string, used: number | null, cap: number) => string
  budgetPercent: (ratio: number) => string
  budgetUnknown: (limit: string, cap: number) => string
  dropWorkHere: string
  /**
   * The due-date chip's visible label. It receives the raw ISO day so each
   * locale owns its own date formatting rather than the card picking one.
   */
  dueChipLabel: (dueDate: string, kind: WorkItemDueKind) => string
  /** Announces how a focused card moves between columns without a pointer. */
  moveCardHint: string
  filterLabel: string
  filterLess: string
  filterMilestone: string
  filterMore: string
  filterPriority: string
  filterProject: string
  filterResponsibleHuman: string
  filterStatus: string
  filtersLabel: string
  labelAddPlaceholder: string
  labelMenuAriaLabel: (title: string) => string
  labelMenuEmpty: string
  labelMenuHeading: string
  labelMenuRemoveAll: string
  labelMenuSuggestions: string
  labelMoreCount: (count: number) => string
  loadMore: string
  loading: string
  moveItem: (title: string) => string
  noActiveAgent: string
  noResponsibleHuman: string
  openProject: (name: string) => string
  priorityName: (priority: string) => string
  boardColumnsLabel: string
  boardLabel: string
  listLabel: string
  savedView: string
  saveView: string
  saveViewName: string
  search: string
  searchPlaceholder: string
  selectProjectFirst: string
}

// Default copy is English. It is the FALLBACK layer for consumers that do
// not provide their own copy via the copy={...} prop. The consuming
// app's LocaleProvider supplies zh-CN-first typed Copy bundles and is
// the primary copy source. Use this default only when the consumer has
// no app-layer LocaleProvider wired in.
const defaultWorkItemCopy: WorkItemCopy = {
  agentExecutionState: state => ({ queued: 'Queued', acknowledged: 'Acknowledged', planning: 'Planning', executing: 'Executing', awaiting_input: 'Awaiting input', awaiting_approval: 'Awaiting approval', blocked: 'Blocked', paused: 'Paused', stopping: 'Stopping', stale: 'Stale', completed: 'Completed', failed: 'Failed', canceled: 'Canceled' }[state] ?? state),
  allHumans: 'All Humans',
  allMilestones: 'All milestones',
  allPriorities: 'All priorities',
  allProjects: 'All projects',
  allStatuses: 'All statuses',
  boardColumn: name => `${name} column`,
  budgetLabel: (limit, used, cap) => `Assigned run budget ${limit}: ${used ?? 'unknown'} of ${cap}`,
  budgetPercent: ratio => `${Math.round(ratio * 100)}%`,
  budgetUnknown: (limit, cap) => `${limit} ?/${cap}`,
  clearFilters: 'Clear filters',
  completedSubIssues: (completed, total) => `Sub-issues ${completed}/${total}`,
  dropWorkHere: 'Drop work here',
  dueChipLabel: (dueDate, kind) => kind === 'overdue' ? `Overdue ${shortDay(dueDate)}` : kind === 'today' ? 'Due today' : `Due ${shortDay(dueDate)}`,
  moveCardHint: 'Hold Control with Left or Right Arrow to move this card to the adjacent column.',
  filterLabel: 'Label',
  filterLess: 'Fewer filters',
  filterMilestone: 'Milestone',
  filterMore: 'More filters',
  filterPriority: 'Priority',
  filterProject: 'Project',
  filterResponsibleHuman: 'Responsible Human',
  filterStatus: 'Status',
  filtersLabel: 'Issue filters',
  labelAddPlaceholder: 'Change or add labels…',
  labelMenuAriaLabel: title => `Labels for ${title}`,
  labelMenuEmpty: 'No labels available yet.',
  labelMenuHeading: 'Labels',
  labelMenuRemoveAll: 'Remove all labels',
  labelMenuSuggestions: 'Suggestions',
  labelMoreCount: count => `+${count} labels`,
  loadMore: 'Load more work items',
  loading: 'Loading…',
  moveItem: title => `Move ${title}`,
  noActiveAgent: 'No active Agent',
  noResponsibleHuman: 'No responsible Human',
  openProject: name => `Open project ${name}`,
  priorityName: priority => ({ none: 'No priority', urgent: 'Urgent', high: 'High', medium: 'Medium', low: 'Low' }[priority] ?? priority),
  boardColumnsLabel: 'Issue board columns',
  boardLabel: 'Issue board',
  listLabel: 'Issue list',
  savedView: 'Saved view',
  saveView: 'Save view',
  saveViewName: 'Saved view name',
  search: 'Search',
  searchPlaceholder: 'Search title or identifier',
  selectProjectFirst: 'Select a project first',
}

function resolveWorkItemCopy(copy?: Partial<WorkItemCopy>): WorkItemCopy {
  return { ...defaultWorkItemCopy, ...copy }
}

export type WorkItemStatusOption = { id: string; name: string; category?: string; color?: string }
export type WorkItemMoveSource = 'pointer' | 'keyboard' | 'explicit-status-selector'
export type WorkItemMoveCallback = (item: WorkItemCardData, targetStatusId: string, source: WorkItemMoveSource, beforeItemId?: string | null) => void | Promise<void>
export type WorkItemLabelChangeCallback = (item: WorkItemCardData, nextLabels: string[]) => void | Promise<void>
export type WorkItemCardDensity = 'compact' | 'comfortable'
export type WorkItemCardProps = {
  item: WorkItemCardData
  layout?: 'list' | 'board' | 'adaptive'
  density?: WorkItemCardDensity
  statusOptions?: WorkItemStatusOption[]
  onOpen?: (item: WorkItemCardData) => void
  onOpenProject?: (projectId: string) => void
  onMove?: WorkItemMoveCallback
  onLabelsChange?: WorkItemLabelChangeCallback
  availableLabels?: string[]
  maxVisibleLabels?: number
  draggable?: boolean
  dragState?: 'idle' | 'dragging' | 'pending'
  className?: string
  onPointerDown?: (event: ReactPointerEvent<HTMLElement>) => void
  copy?: Partial<WorkItemCopy>
  showStatusControl?: boolean
}

function workItemClassNames(...values: Array<string | false | null | undefined>): string { return values.filter(Boolean).join(' ') }

// A native drag can still deliver a click to the element under the pointer when
// it ends, which would open the Issue the Human was trying to move. Recording
// the end lets the card swallow that one activation.
let lastDragEndedAt = 0
const DRAG_CLICK_GUARD_MS = 250
const wasJustDragged = (): boolean => Date.now() - lastDragEndedAt < DRAG_CLICK_GUARD_MS

/**
 * Initials for the card's avatar. The avatar is decorative — the Human's name
 * is always rendered next to it as text — so an unrecognizable name renders a
 * neutral "?" rather than pretending to know the person.
 */
function personInitials(name?: string | null): string {
  const source = (name ?? '').trim()
  if (!source) return '?'
  const parts = source.split(/[\s._\-/]+/).filter(Boolean)
  const first = parts[0]
  if (!first) return '?'
  const last = parts.length > 1 ? parts[parts.length - 1] : undefined
  const head = [...first][0] ?? ''
  const tail = last ? [...last][0] ?? '' : [...first][1] ?? ''
  return `${head}${tail}`.toUpperCase()
}

// Filled-bar count per priority, mirroring the prototype's three-segment glyph.
// The bar count and the text label encode priority independently, so priority
// stays readable when hue is unavailable (design/README.md §3 signature component).
const priorityBarCount: Readonly<Record<string, number>> = { urgent: 3, high: 2, medium: 1, low: 0, none: 0 }

const ISO_DAY = /^\d{4}-\d{2}-\d{2}$/
const padDay = (value: number): string => String(value).padStart(2, '0')

/** M/D from an ISO day. Locale bundles format their own; this is the fallback. */
const shortDay = (isoDay: string): string => {
  const [, month, day] = isoDay.split('-')
  return month && day ? `${Number(month)}/${Number(day)}` : isoDay
}

/**
 * How a due date reads to the Human looking at the card right now.
 *
 * A due date is a calendar day, not an instant, so "overdue" is decided against
 * the viewer's own local day rather than a UTC timestamp — an Issue due today
 * must not read as overdue because the server stored it in another zone. The
 * comparison is a string compare because both sides are already YYYY-MM-DD.
 */
export type WorkItemDueKind = 'overdue' | 'today' | 'upcoming'

export function workItemDueKind(dueDate?: string | null, now: Date = new Date()): WorkItemDueKind | null {
  const day = (dueDate ?? '').slice(0, 10)
  if (!ISO_DAY.test(day)) return null
  const today = `${now.getFullYear()}-${padDay(now.getMonth() + 1)}-${padDay(now.getDate())}`
  if (day < today) return 'overdue'
  return day === today ? 'today' : 'upcoming'
}

function PriorityBars({ priority }: Readonly<{ priority: string }>) {
  const filled = priorityBarCount[priority] ?? 0
  return <span aria-hidden="true" className={workItemClassNames('wm-priority-bars', `priority-${priority}`)} data-filled={filled} data-testid="work-item-priority-bars">
    {[0, 1, 2].map(index => <i className="wm-priority-bar" data-on={index < filled} key={index} />)}
  </span>
}
const WorkItemTokenSurfaceContext = createContext(false)
function workflowStatusStyle(color?: string, semantic = false): CSSProperties {
  return { '--wm-status-color': color || (semantic ? 'var(--wm-ref-text-secondary)' : 'var(--wm-muted)') } as CSSProperties
}
function handlePresentationPromise(callback: (() => void | Promise<void>) | undefined): void {
  if (!callback) return
  try {
    const result = callback()
    if (result && typeof (result as Promise<void>).catch === 'function') void (result as Promise<void>).catch(() => undefined)
  } catch { /* Feature controller owns errors; presentation remains render-safe. */ }
}

const MAX_LABELS_BOARD = 3
const MAX_LABELS_LIST = 4

type WorkItemLabelMenuProps = {
  activeTriggerRef: RefObject<HTMLButtonElement | null>
  align?: 'start' | 'end'
  anchorVersion: number
  availableLabels: string[]
  current: string[]
  hiddenLabels: string[]
  item: WorkItemCardData
  onLabelsChange?: WorkItemLabelChangeCallback
  onOpenChange: (open: boolean) => void
  open: boolean
  panelId: string
  showTrigger: boolean
  text: WorkItemCopy
  title: string
}

function WorkItemLabelMenu({ activeTriggerRef, align = 'start', anchorVersion, availableLabels, current, hiddenLabels, item, onLabelsChange, onOpenChange, open, panelId, showTrigger, text, title }: WorkItemLabelMenuProps) {
  const [query, setQuery] = useState('')
  const [panelPos, setPanelPos] = useState<{ left: number; top: number; width: number; placement: 'start' | 'end' } | null>(null)
  const rootRef = useRef<HTMLDivElement | null>(null)
  const moreTriggerRef = useRef<HTMLButtonElement | null>(null)
  const inputRef = useRef<HTMLInputElement | null>(null)
  const panelPortalRef = useRef<HTMLDivElement | null>(null)
  const toggle = (label: string) => {
    if (!onLabelsChange) return
    const next = current.includes(label) ? current.filter(existing => existing !== label) : [...current, label]
    handlePresentationPromise(() => onLabelsChange(item, next))
  }
  const removeAll = () => {
    if (!onLabelsChange || current.length === 0) return
    handlePresentationPromise(() => onLabelsChange(item, []))
  }
  const addCustom = () => {
    const trimmed = query.trim()
    if (!onLabelsChange || !trimmed || current.includes(trimmed)) return
    handlePresentationPromise(() => onLabelsChange(item, [...current, trimmed]))
    setQuery('')
  }
  useDismissalLayer(open, rootRef, activeTriggerRef, onOpenChange, panelPortalRef)
  useEffect(() => {
    if (open) {
      const handle = window.setTimeout(() => inputRef.current?.focus(), 0)
      const recompute = () => {
        const trigger = activeTriggerRef.current ?? moreTriggerRef.current
        if (!trigger) return
        const rect = trigger.getBoundingClientRect()
        const preferredWidth = Math.min(352, Math.max(256, rect.width + 160))
        const minLeft = 12
        const maxLeft = window.innerWidth - preferredWidth - 12
        const left = align === 'end' ? Math.max(minLeft, Math.min(maxLeft, rect.right - preferredWidth)) : Math.max(minLeft, Math.min(maxLeft, rect.left))
        const top = rect.bottom + 6
        setPanelPos({ left, top, width: preferredWidth, placement: align })
      }
      recompute()
      window.addEventListener('resize', recompute)
      window.addEventListener('scroll', recompute, true)
      return () => {
        window.clearTimeout(handle)
        window.removeEventListener('resize', recompute)
        window.removeEventListener('scroll', recompute, true)
      }
    }
    setPanelPos(null)
    return undefined
  }, [activeTriggerRef, align, anchorVersion, open])
  const currentSet = new Set(current)
  const normalizedQuery = query.trim().toLowerCase()
  const suggestions = availableLabels
    .filter(label => !currentSet.has(label) && (normalizedQuery === '' || label.toLowerCase().includes(normalizedQuery)))
  const matchedCurrent = normalizedQuery === '' ? current : current.filter(label => label.toLowerCase().includes(normalizedQuery))
  const customMatch = normalizedQuery !== '' && !availableLabels.some(label => label.toLowerCase() === normalizedQuery) && !currentSet.has(query.trim())
  const dotsToShow = hiddenLabels.slice(0, 3)
  const extraCount = hiddenLabels.length - dotsToShow.length
  const panel = open && panelPos ? (
    <div
      aria-label={text.labelMenuAriaLabel(title)}
      className={workItemClassNames('wm-work-item-label-menu-panel', `align-${align}`)}
      id={panelId}
      role="dialog"
      onPointerDown={event => event.stopPropagation()}
      ref={panelPortalRef}
      style={{ left: `${panelPos.left}px`, position: 'fixed', top: `${panelPos.top}px`, width: `${panelPos.width}px` }}
    >
      <label className="wm-work-item-label-menu-input">
        <span className="wm-visually-hidden">{text.labelAddPlaceholder}</span>
        <input
          aria-label={text.labelAddPlaceholder}
          onChange={event => setQuery(event.currentTarget.value)}
          onKeyDown={event => { if (event.key === 'Enter') { event.preventDefault(); addCustom() } }}
          placeholder={text.labelAddPlaceholder}
          ref={inputRef}
          type="text"
          value={query}
        />
      </label>
      {suggestions.length > 0 && (
        <section aria-label={text.labelMenuSuggestions} className="wm-work-item-label-menu-section">
          <h4>{text.labelMenuSuggestions}</h4>
          <ul>{suggestions.map(label => <li key={label}><button aria-pressed="false" className={`wm-work-item-label-menu-row wm-label-${workItemLabelTone(label)}`} onClick={() => toggle(label)} type="button"><span aria-hidden="true" className="wm-work-item-label-menu-row-check" /><span className="wm-work-item-label-menu-row-name">{label}</span></button></li>)}</ul>
        </section>
      )}
      {current.length > 0 && (
        <section aria-label={text.labelMenuHeading} className="wm-work-item-label-menu-section">
          <h4>{text.labelMenuHeading}</h4>
          <ul>{matchedCurrent.map(label => <li key={label}><button aria-pressed="true" className={`wm-work-item-label-menu-row is-checked wm-label-${workItemLabelTone(label)}`} onClick={() => toggle(label)} type="button"><span aria-hidden="true" className="wm-work-item-label-menu-row-check">✓</span><span className="wm-work-item-label-menu-row-name">{label}</span></button></li>)}</ul>
          <button className="wm-work-item-label-menu-remove-all" disabled={!onLabelsChange} onClick={removeAll} type="button">{text.labelMenuRemoveAll}</button>
        </section>
      )}
      {current.length === 0 && suggestions.length === 0 && !customMatch && (
        <p className="wm-work-item-label-menu-empty">{text.labelMenuEmpty}</p>
      )}
      {customMatch && (
        <button className="wm-work-item-label-menu-custom" disabled={!onLabelsChange} onClick={addCustom} type="button">{text.labelAddPlaceholder} "{query.trim()}"</button>
      )}
    </div>
  ) : null
  return <div className="wm-work-item-label-menu" ref={rootRef}>
    {showTrigger && <button
      aria-controls={panelId}
      aria-expanded={open}
      aria-haspopup="dialog"
      aria-label={text.labelMenuAriaLabel(title)}
      className="wm-work-item-label-more"
      data-wm-dismissal-trigger="true"
      onClick={event => {
        coordinateDismissalTriggerActivation(event)
        activeTriggerRef.current = event.currentTarget
        onOpenChange(!open)
      }}
      onPointerDown={event => event.stopPropagation()}
      ref={moreTriggerRef}
      type="button"
    >
      <span aria-hidden="true" className="wm-work-item-label-more-dots">
        {dotsToShow.map(label => <span key={label} aria-hidden="true" className={`wm-work-item-label-more-dot wm-label-${workItemLabelTone(label)}`} />)}
      </span>
      {extraCount > 0 && <span className="wm-work-item-label-more-text">+{extraCount}</span>}
    </button>}
    {panel}
  </div>
}

function workItemLabelTone(label: string): string {
  const normalized = label.toLowerCase()
  if (/security|safe|安全|blocker|阻塞/.test(normalized)) return 'danger'
  if (/migration|迁移|risk|风险/.test(normalized)) return 'warning'
  if (/module|模块|admin|管理/.test(normalized)) return 'info'
  if (/coord|协同|done|完成/.test(normalized)) return 'success'
  if (/type|类型|enhancement|增强/.test(normalized)) return 'accent'
  return 'neutral'
}

export function WorkItemCard({ availableLabels, className, copy, density = 'comfortable', draggable = false, dragState = 'idle', item, layout = 'list', maxVisibleLabels, onLabelsChange, onMove, onOpen, onOpenProject, onPointerDown, showStatusControl = true, statusOptions = [] }: WorkItemCardProps) {
  const semanticTokens = useContext(WorkItemTokenSurfaceContext)
  const text = resolveWorkItemCopy(copy)
  const [labelMenuOpen, setLabelMenuOpen] = useState(false)
  const [labelMenuAnchorVersion, setLabelMenuAnchorVersion] = useState(0)
  const labelMenuId = useId()
  const labelMenuTriggerRef = useRef<HTMLButtonElement | null>(null)
  const move = (statusId: string, source: WorkItemMoveSource) => {
    if (!onMove || !statusId || statusId === item.statusId) return
    handlePresentationPromise(() => onMove(item, statusId, source))
  }
  const handleDragStart = (event: DragEvent<HTMLElement>) => {
    if (layout === 'adaptive' && !event.currentTarget.closest('.wm-work-item-adaptive[data-layout="board"]')) {
      event.currentTarget.classList.remove('wm-work-item-card-dragging')
      event.preventDefault()
      return
    }
    if (layout === 'adaptive') event.currentTarget.classList.add('wm-work-item-card-dragging')
    event.dataTransfer.effectAllowed = 'move'
    event.dataTransfer.setData('text/plain', item.id)
  }
  const handleDragEnd = (event: DragEvent<HTMLElement>) => {
    if (layout === 'adaptive') event.currentTarget.classList.remove('wm-work-item-card-dragging')
    // A drag that ends over a card still delivers a click to some browsers.
    // Recording the end lets the next activation be swallowed instead of
    // opening the Issue the Human just moved.
    lastDragEndedAt = Date.now()
  }
  // The board has no visible status selector, so a pointer-less move needs a
  // keyboard path or the card can only ever be moved by dragging. Ctrl (or
  // Cmd on macOS) with Left/Right Arrow steps one column at a time; the move
  // command already restores focus to the same card afterwards.
  const moveByKeyboard = (event: KeyboardEvent<HTMLElement>) => {
    if (!onMove || statusOptions.length === 0) return
    if (!event.ctrlKey && !event.metaKey) return
    if (event.key !== 'ArrowLeft' && event.key !== 'ArrowRight') return
    const index = statusOptions.findIndex(status => status.id === item.statusId)
    if (index < 0) return
    const next = statusOptions[index + (event.key === 'ArrowRight' ? 1 : -1)]
    if (!next) return
    event.preventDefault()
    event.stopPropagation()
    move(next.id, 'keyboard')
  }
  const stopPointer = (event: ReactPointerEvent<HTMLElement>) => event.stopPropagation()
  const hasFacts = Boolean(item.blockedByCount || item.blockingCount || item.subIssueCount)
  // The assigned run's budget is a fact about this row, so it rides the same
  // strip as the other small counts. A card the collection has not yet placed
  // is `adaptive`, not `board`, so it keeps the chip; the collection hides it in
  // board through CSS, because pushing the resolved layout into props would
  // re-render every card on each list/board switch.
  const budget = layout === 'board' ? null : item.activeBudget ?? null
  const hasLabels = Boolean(item.labels && item.labels.length > 0)
  const statusCategory = item.statusCategory ?? 'unknown'
  const statusColor = statusOptions.find(status => status.id === item.statusId)?.color
  const dueKind = workItemDueKind(item.dueDate)
  const subIssueTotal = item.subIssueCount ?? 0
  const subIssueDone = item.completedSubIssueCount ?? 0
  const subIssuePct = subIssueTotal > 0 ? Math.round((subIssueDone / subIssueTotal) * 100) : 0
  const visibleLimit = maxVisibleLabels ?? (layout === 'board' ? MAX_LABELS_BOARD : MAX_LABELS_LIST)
  const labels = item.labels ?? []
  const overflow = Math.max(0, labels.length - visibleLimit)
  const shownLabels = overflow > 0 ? labels.slice(0, visibleLimit) : labels
  const hiddenLabels = overflow > 0 ? labels.slice(visibleLimit) : []
  const canEditLabels = Boolean(onLabelsChange && availableLabels && availableLabels.length > 0)
  const showStableLayoutSlots = layout === 'board' || layout === 'adaptive'
  const showLabelRow = showStableLayoutSlots || hasLabels
  const openLabelMenu = (event: React.MouseEvent<HTMLButtonElement>) => {
    if (!canEditLabels) return
    coordinateDismissalTriggerActivation(event)
    labelMenuTriggerRef.current = event.currentTarget
    setLabelMenuAnchorVersion(version => version + 1)
    setLabelMenuOpen(true)
  }
  return <article aria-busy={dragState === 'pending' || undefined} aria-label={`${item.identifier}: ${item.title}`} className={workItemClassNames('wm-work-item-card', `wm-work-item-card-${layout}`, density === 'compact' && 'wm-work-item-card--compact', `wm-work-item-card-${dragState}`, labelMenuOpen && 'is-label-menu-open', className)} data-status-category={statusCategory} data-density={density} data-work-item-id={item.id} draggable={draggable && dragState !== 'pending'} onDragEnd={draggable ? handleDragEnd : undefined} onDragStart={draggable ? handleDragStart : undefined} onKeyDown={showStatusControl ? moveByKeyboard : undefined} onPointerDown={onPointerDown} style={workflowStatusStyle(statusColor, semanticTokens)}>
    <div className="wm-work-item-card-heading">
      <span className="wm-work-item-identifier">{item.identifier}</span>
      <span className={workItemClassNames('wm-work-item-status-pill', `status-${statusCategory}`)}>{item.statusName}</span>
      {item.priority && <span className={workItemClassNames('wm-work-item-priority', `priority-${item.priority}`)}><PriorityBars priority={item.priority} />{text.priorityName(item.priority)}</span>}
      {dueKind && <span className={workItemClassNames('wm-work-item-due', `is-${dueKind}`)}><CalendarBlankIcon aria-hidden="true" size={13} weight="bold" />{text.dueChipLabel((item.dueDate ?? '').slice(0, 10), dueKind)}</span>}
    </div>
    <button className="wm-work-item-title" onClick={() => { if (wasJustDragged()) return; handlePresentationPromise(onOpen ? () => onOpen(item) : undefined) }} onPointerDown={stopPointer} type="button">{item.title}</button>
    {(showStableLayoutSlots || (item.projectId && item.projectName)) && <div aria-hidden={!item.projectId || !item.projectName || undefined} className={workItemClassNames('wm-work-item-project-slot', (!item.projectId || !item.projectName) && 'is-empty')}>{item.projectId && item.projectName && <button aria-label={text.openProject(item.projectName)} className="wm-work-item-project" onClick={() => handlePresentationPromise(onOpenProject ? () => onOpenProject(item.projectId!) : undefined)} onPointerDown={stopPointer} type="button"><FolderSimpleIcon aria-hidden="true" size={13} weight="bold" /><span>{item.projectName}</span></button>}</div>}
    <div className="wm-work-item-metadata"><span className="wm-work-item-person"><b aria-hidden="true" className="wm-work-item-avatar">{personInitials(item.responsibleHuman)}</b>{item.responsibleHuman ?? text.noResponsibleHuman}</span><span className="wm-work-item-agent"><RobotIcon aria-hidden="true" size={15} weight="duotone" />{item.activeAgent ? `${item.activeAgent}${item.activeAgentState ? ` · ${text.agentExecutionState(item.activeAgentState)}` : ''}` : text.noActiveAgent}</span></div>
    {showLabelRow && <div aria-hidden={!hasLabels || undefined} className={workItemClassNames('wm-work-item-labels', !hasLabels && 'is-empty')}>
      {shownLabels.map(label => canEditLabels
        ? <button aria-controls={labelMenuId} aria-expanded={labelMenuOpen} aria-haspopup="dialog" aria-label={text.labelMenuAriaLabel(item.title)} className={`wm-work-item-label wm-label-${workItemLabelTone(label)}`} key={label} onClick={openLabelMenu} onPointerDown={stopPointer} type="button">{label}</button>
        : <span className={`wm-work-item-label wm-label-${workItemLabelTone(label)}`} key={label}>{label}</span>)}
      {canEditLabels && hasLabels && <WorkItemLabelMenu
        activeTriggerRef={labelMenuTriggerRef}
        align="end"
        anchorVersion={labelMenuAnchorVersion}
        availableLabels={availableLabels ?? []}
        current={labels}
        hiddenLabels={hiddenLabels}
        item={item}
        onLabelsChange={onLabelsChange}
        onOpenChange={setLabelMenuOpen}
        open={labelMenuOpen}
        panelId={labelMenuId}
        showTrigger={overflow > 0}
        text={text}
        title={item.title}
      />}
    </div>}
    {(showStableLayoutSlots || hasFacts || budget) && <div aria-hidden={!hasFacts && !budget || undefined} className={workItemClassNames('wm-work-item-facts', !hasFacts && !budget && 'is-empty')}>{item.blockedByCount ? <span className="wm-fact-blocker" title="被阻塞"><ProhibitIcon aria-hidden="true" size={14} weight="bold" />{item.blockedByCount}</span> : null}{item.blockingCount ? <span className="wm-fact-blocking" title="阻塞下游"><ProhibitIcon aria-hidden="true" size={14} weight="regular" />{item.blockingCount}</span> : null}{subIssueTotal > 0 ? <span className="wm-fact-sub-issue" title="子 Issue 进度"><span className="wm-sub-progress" aria-hidden="true"><span className="wm-sub-progress-fill" style={{ width: `${subIssuePct}%` }} /></span><GitBranchIcon aria-hidden="true" size={14} weight="bold" />{text.completedSubIssues(subIssueDone, subIssueTotal)}</span> : null}
      {/* The prototype states the assigned run's budget on the list row and not on
          the board card, so it is absent from board and from an unresolved card. */}
      {budget && <BudgetChip
        entry={budget}
        exhaustedRatio={BUDGET_DANGER_RATIO}
        label={text.budgetLabel(budget.limit, budget.used, budget.cap)}
        percentLabel={text.budgetPercent}
        unknownLabel={text.budgetUnknown(budget.limit, budget.cap)}
        warningRatio={BUDGET_WARNING_RATIO}
      />}
    </div>}
    {showStatusControl && onMove && statusOptions.length > 0 && <label className="wm-work-item-status-control" onClick={event => event.stopPropagation()} onPointerDown={event => event.stopPropagation()}><span className="wm-visually-hidden">{text.moveItem(item.title)}</span><select aria-label={text.moveItem(item.title)} disabled={dragState === 'pending'} onChange={(event: ChangeEvent<HTMLSelectElement>) => move(event.currentTarget.value, 'explicit-status-selector')} value={item.statusId}>{statusOptions.map(status => <option key={status.id} value={status.id}>{status.name}</option>)}</select></label>}
  </article>
}

export type WorkItemListProps = { items: WorkItemCardData[]; statusOptions?: WorkItemStatusOption[]; density?: WorkItemCardDensity; onOpen?: (item: WorkItemCardData) => void; onOpenProject?: (projectId: string) => void; onMove?: WorkItemMoveCallback; onLabelsChange?: WorkItemLabelChangeCallback; availableLabels?: string[]; maxVisibleLabels?: number; empty?: ReactNode; copy?: Partial<WorkItemCopy> }
export function WorkItemList({ availableLabels, copy, density, empty = 'No work items match this view.', items, maxVisibleLabels, onLabelsChange, onMove, onOpen, onOpenProject, statusOptions = [] }: WorkItemListProps) {
  const text = resolveWorkItemCopy(copy)
  if (items.length === 0) return <section aria-label={text.listLabel} className="wm-work-item-list-empty" data-testid="work-items-empty">{empty}</section>
  return <section aria-label={text.listLabel} className="wm-work-item-list" data-testid="work-list">{items.map(item => <WorkItemCard availableLabels={availableLabels} copy={copy} density={density} item={item} key={item.id} layout="list" maxVisibleLabels={maxVisibleLabels} onLabelsChange={onLabelsChange} onMove={onMove} onOpen={onOpen} onOpenProject={onOpenProject} statusOptions={statusOptions} />)}</section>
}

export type WorkItemBoardProps = { items: WorkItemCardData[]; columns: WorkItemStatusOption[]; density?: WorkItemCardDensity; onOpen?: (item: WorkItemCardData) => void; onOpenProject?: (projectId: string) => void; onMove?: WorkItemMoveCallback; onLabelsChange?: WorkItemLabelChangeCallback; availableLabels?: string[]; maxVisibleLabels?: number; copy?: Partial<WorkItemCopy>; columnWidths?: Record<string, number>; onColumnWidthChange?: (columnId: string, width: number) => void; pannable?: boolean; minColumnWidth?: number; maxColumnWidth?: number }
const DEFAULT_COLUMN_WIDTH = 320
const MIN_COLUMN_WIDTH = 240
const MAX_COLUMN_WIDTH = 600
export function WorkItemBoard({ availableLabels, columnWidths, columns, copy, density, items, maxColumnWidth = MAX_COLUMN_WIDTH, maxVisibleLabels, minColumnWidth = MIN_COLUMN_WIDTH, onColumnWidthChange, onLabelsChange, onMove, onOpen, onOpenProject, pannable = true }: WorkItemBoardProps) {
  const text = resolveWorkItemCopy(copy)
  const draggedItem = useRef<string | null>(null)
  const [pointerItem, setPointerItem] = useState<string | null>(null)
  const [dropColumn, setDropColumn] = useState<string | null>(null)
  const scrollRef = useRef<HTMLDivElement | null>(null)
  const panning = useRef<{ x: number; y: number; left: number; top: number } | null>(null)
  const [isPanning, setIsPanning] = useState(false)
  const itemFor = (id: string | null) => id ? items.find(item => item.id === id) : undefined
  const moveTo = (column: WorkItemStatusOption, source: WorkItemMoveSource, id: string | null) => { const item = itemFor(id); draggedItem.current = null; setPointerItem(null); setDropColumn(null); if (item && item.statusId !== column.id) handlePresentationPromise(onMove ? () => onMove(item, column.id, source) : undefined) }
  const handleDrop = (column: WorkItemStatusOption, event: DragEvent<HTMLDivElement>) => { event.preventDefault(); moveTo(column, 'pointer', event.dataTransfer.getData('text/plain') || draggedItem.current) }
  const startResize = (column: WorkItemStatusOption) => (event: ReactPointerEvent<HTMLDivElement>) => {
    if (!onColumnWidthChange) return
    event.preventDefault()
    event.stopPropagation()
    const startX = event.clientX
    const startWidth = columnWidths?.[column.id] ?? DEFAULT_COLUMN_WIDTH
    const target = event.currentTarget
    target.setPointerCapture(event.pointerId)
    const onMovePointer = (moveEvent: PointerEvent) => {
      const delta = moveEvent.clientX - startX
      const next = Math.min(maxColumnWidth, Math.max(minColumnWidth, Math.round(startWidth + delta)))
      onColumnWidthChange(column.id, next)
    }
    const onUpPointer = () => {
      target.removeEventListener('pointermove', onMovePointer)
      target.removeEventListener('pointerup', onUpPointer)
      target.removeEventListener('pointercancel', onUpPointer)
    }
    target.addEventListener('pointermove', onMovePointer)
    target.addEventListener('pointerup', onUpPointer)
    target.addEventListener('pointercancel', onUpPointer)
  }
  const onPointerDownBoard = (event: ReactPointerEvent<HTMLDivElement>) => {
    if (!pannable) return
    if (event.button !== 0) return
    const target = event.target as HTMLElement
    if (target.closest('.wm-work-item-card') || target.closest('.wm-work-item-status-control') || target.closest('button, select, a, input, textarea')) return
    const scroller = scrollRef.current
    if (!scroller) return
    panning.current = { x: event.clientX, y: event.clientY, left: scroller.scrollLeft, top: scroller.scrollTop }
    setIsPanning(true)
    const target_el = event.currentTarget
    target_el.setPointerCapture(event.pointerId)
    const onMovePointer = (moveEvent: PointerEvent) => {
      if (!panning.current || !scroller) return
      scroller.scrollLeft = panning.current.left - (moveEvent.clientX - panning.current.x)
      scroller.scrollTop = panning.current.top - (moveEvent.clientY - panning.current.y)
    }
    const onUpPointer = () => {
      panning.current = null
      setIsPanning(false)
      target_el.removeEventListener('pointermove', onMovePointer)
      target_el.removeEventListener('pointerup', onUpPointer)
      target_el.removeEventListener('pointercancel', onUpPointer)
    }
    target_el.addEventListener('pointermove', onMovePointer)
    target_el.addEventListener('pointerup', onUpPointer)
    target_el.addEventListener('pointercancel', onUpPointer)
  }
  return <section aria-label={text.boardLabel} className={workItemClassNames('wm-work-item-board', isPanning && 'is-panning')} data-testid="board" tabIndex={0}><div aria-label={text.boardColumnsLabel} className="wm-work-item-board-scroll" onPointerDown={onPointerDownBoard} ref={scrollRef} role="region" tabIndex={0}>{columns.map((column, columnIndex) => { const columnItems = items.filter(item => item.statusId === column.id); const statusCategory = column.category ?? 'unknown'; const width = columnWidths?.[column.id] ?? DEFAULT_COLUMN_WIDTH; return <div aria-label={text.boardColumn(column.name)} className={workItemClassNames('wm-work-item-column', dropColumn === column.id && 'is-drop-target')} data-status-category={statusCategory} data-testid={`column-${column.id}`} data-workflow-state-id={column.id} key={column.id} style={{ ...workflowStatusStyle(column.color), flex: `0 0 ${width}px` }} onDragOver={event => { event.preventDefault(); setDropColumn(column.id) }} onDragLeave={() => setDropColumn(current => current === column.id ? null : current)} onDrop={event => handleDrop(column, event)} onPointerUp={() => moveTo(column, 'pointer', pointerItem ?? draggedItem.current)} onKeyDown={event => { if (event.key !== 'ArrowLeft' && event.key !== 'ArrowRight') return; event.preventDefault(); const next = columns[columnIndex + (event.key === 'ArrowRight' ? 1 : -1)]; if (next) document.querySelector<HTMLElement>(`[data-workflow-state-id="${CSS.escape(next.id)}"]`)?.focus() }} role="group" tabIndex={0}><header><span aria-hidden="true" className="wm-work-item-column-dot" /><h3>{column.name}</h3><span aria-label={`${columnItems.length} items`} className="wm-column-count">{columnItems.length}</span></header><div className="wm-work-item-column-items">{columnItems.map(item => <WorkItemCard availableLabels={availableLabels} copy={copy} density={density} draggable dragState={draggedItem.current === item.id ? 'dragging' : 'idle'} item={item} key={item.id} layout="board" maxVisibleLabels={maxVisibleLabels} onLabelsChange={onLabelsChange} onMove={onMove} onOpen={onOpen} onOpenProject={onOpenProject} onPointerDown={event => { if (event.target instanceof HTMLSelectElement) return; draggedItem.current = item.id; setPointerItem(item.id) }} statusOptions={columns} />)}</div><p className="wm-work-item-drop-hint">{text.dropWorkHere}</p>{onColumnWidthChange ? <div aria-hidden className="wm-work-item-column-resize" onPointerDown={startResize(column)} title="拖动调整列宽"><span className="wm-work-item-column-resize-grip" /></div> : null}</div> })}</div></section>
}

export type WorkItemAdaptiveCollectionProps = WorkItemBoardProps & {
  tokenSurface?: 'board'
  empty?: ReactNode
  layout: 'list' | 'board'
}

type AdaptiveWorkItemCardProps = Pick<WorkItemCardProps,
  | 'availableLabels'
  | 'copy'
  | 'density'
  | 'item'
  | 'maxVisibleLabels'
  | 'onLabelsChange'
  | 'onMove'
  | 'onOpen'
  | 'onOpenProject'
  | 'statusOptions'
> & {
  columnId: string
  onCardDragOver: (columnId: string, itemId: string, event: DragEvent<HTMLDivElement>) => void
  onCardPointerDown: (itemId: string, event: ReactPointerEvent<HTMLElement>) => void
  order: number
}

// The handler is built inside the memo rather than passed as a closure from the
// collection: an inline arrow would change identity on every render and defeat
// the memo that keeps 300 cards from re-rendering when a sibling changes.
const AdaptiveWorkItemCard = memo(function AdaptiveWorkItemCard({ columnId, item, onCardDragOver, onCardPointerDown, order, ...props }: AdaptiveWorkItemCardProps) {
  return <div className="wm-work-item-adaptive-card-slot" onDragOver={event => onCardDragOver(columnId, item.id, event)} style={{ order }}>
    <WorkItemCard {...props} draggable item={item} layout="adaptive" onPointerDown={event => onCardPointerDown(item.id, event)} />
  </div>
})

type AdaptiveColumnProps = {
  cards: ReactNode
  column: WorkItemStatusOption
  columnIndex: number
  count: number
  dropTarget: boolean
  layout: 'list' | 'board'
  onColumnDragLeave: (columnId: string) => void
  onColumnDragOver: (columnId: string, event: DragEvent<HTMLDivElement>) => void
  onColumnDrop: (column: WorkItemStatusOption, event: DragEvent<HTMLDivElement>) => void
  onColumnKeyDown: (columnIndex: number, event: KeyboardEvent<HTMLDivElement>) => void
  onColumnPointerUp: (column: WorkItemStatusOption) => void
  onColumnResize: (column: WorkItemStatusOption, event: ReactPointerEvent<HTMLDivElement>) => void
  showResize: boolean
  text: WorkItemCopy
  width: number
}

const AdaptiveWorkItemColumn = memo(function AdaptiveWorkItemColumn({ cards, column, columnIndex, count, dropTarget, layout, onColumnDragLeave, onColumnDragOver, onColumnDrop, onColumnKeyDown, onColumnPointerUp, onColumnResize, showResize, text, width }: AdaptiveColumnProps) {
  const semanticTokens = useContext(WorkItemTokenSurfaceContext)
  const board = layout === 'board'
  // The keyboard move lives on every card, but describing it on every card
  // would repeat it once per Issue. One description per column keeps the
  // shortcut discoverable without turning board traversal into a wall of text.
  const hintId = useId()
  return <div
    aria-describedby={board ? hintId : undefined}
    aria-label={board ? text.boardColumn(column.name) : undefined}
    className={workItemClassNames('wm-work-item-column', 'wm-work-item-adaptive-column', dropTarget && 'is-drop-target')}
    data-status-category={column.category ?? 'unknown'}
    data-testid={`column-${column.id}`}
    data-workflow-state-id={column.id}
    onDragLeave={board ? () => onColumnDragLeave(column.id) : undefined}
    onDragOver={board ? event => onColumnDragOver(column.id, event) : undefined}
    onDrop={board ? event => onColumnDrop(column, event) : undefined}
    onKeyDown={board ? event => onColumnKeyDown(columnIndex, event) : undefined}
    onPointerUp={board ? () => onColumnPointerUp(column) : undefined}
    role={board ? 'group' : 'presentation'}
    style={{ ...workflowStatusStyle(column.color, semanticTokens), flex: `0 0 ${width}px` }}
    tabIndex={board ? 0 : -1}
  >
    {/* The dot carries the column's status color at the point of use. The
        previous full-width top stripe read as a divider across the panel and
        fought the rounded corner; a small circle keeps the color cue while
        letting the column header stay one left-aligned line. */}
    <header className="wm-work-item-column-header" hidden={!board}><span aria-hidden="true" className="wm-work-item-column-dot" /><h3>{column.name}</h3><span aria-label={`${count} items`} className="wm-column-count">{count}</span></header>
    <span className="wm-visually-hidden" id={hintId}>{text.moveCardHint}</span>
    <div className="wm-work-item-column-items wm-work-item-adaptive-column-items">{cards}</div>
    <p className="wm-work-item-drop-hint" hidden={!board}>{text.dropWorkHere}</p>
    {showResize && <div aria-hidden className="wm-work-item-column-resize" hidden={!board} onPointerDown={event => onColumnResize(column, event)}><span className="wm-work-item-column-resize-grip" /></div>}
  </div>
})

/**
 * Keeps one keyed card tree mounted while the collection changes presentation.
 * The five column containers persist; list mode flattens them with CSS and uses
 * each card's source-order value, while board mode restores the grouped layout.
 */
export function WorkItemAdaptiveCollection({ availableLabels, columnWidths, columns, copy, density, empty = 'No work items match this view.', items, layout, maxColumnWidth = MAX_COLUMN_WIDTH, maxVisibleLabels, minColumnWidth = MIN_COLUMN_WIDTH, onColumnWidthChange, onLabelsChange, onMove, onOpen, onOpenProject, pannable = true, tokenSurface }: WorkItemAdaptiveCollectionProps) {
  const text = useMemo(() => resolveWorkItemCopy(copy), [copy])
  const draggedItem = useRef<string | null>(null)
  const [pointerItem, setPointerItem] = useState<string | null>(null)
  const [dropColumn, setDropColumn] = useState<string | null>(null)
  // Where the dragged card would land inside that column. beforeItemId: null
  // means the end of it. The server resolves this to a rank, so the board only
  // has to say which card to sit above (ADR 0073).
  const [dropBefore, setDropBefore] = useState<string | null>(null)
  const scrollRef = useRef<HTMLDivElement | null>(null)
  const panning = useRef<{ x: number; y: number; left: number; top: number } | null>(null)
  const [isPanning, setIsPanning] = useState(false)

  const effectiveColumns = useMemo(() => {
    if (columns.length > 0) return columns
    const inferred = new Map<string, WorkItemStatusOption>()
    for (const item of items) {
      if (!inferred.has(item.statusId)) inferred.set(item.statusId, { id: item.statusId, name: item.statusName, category: item.statusCategory })
    }
    return [...inferred.values()]
  }, [columns, items])

  const itemById = useMemo(() => new Map(items.map(item => [item.id, item])), [items])
  const columnModels = useMemo(() => {
    const byColumn = new Map(effectiveColumns.map(column => [column.id, [] as Array<{ item: WorkItemCardData; order: number }>]))
    const fallbackColumnId = effectiveColumns[0]?.id
    items.forEach((item, order) => {
      const columnId = byColumn.has(item.statusId) ? item.statusId : fallbackColumnId
      if (columnId) byColumn.get(columnId)?.push({ item, order })
    })
    return effectiveColumns.map(column => {
      const entries = byColumn.get(column.id) ?? []
      // The server assigns board_rank; the board is what presents it. Sorting
      // here rather than in the query is deliberate: the list and the board
      // share one projection, so a layout toggle never re-orders or re-fetches
      // the other view. A column whose rows have no rank keeps the order the
      // server sent, which is the only safe fallback.
      const ranked = entries.every(entry => entry.item.boardRank !== null && entry.item.boardRank !== undefined)
      return {
        column,
        entries: ranked
          ? [...entries].sort((left, right) => left.item.boardRank! - right.item.boardRank! || left.order - right.order)
          : entries,
      }
    })
  }, [effectiveColumns, items])

  const onCardPointerDown = useCallback((itemId: string, event: ReactPointerEvent<HTMLElement>) => {
    if (!event.currentTarget.closest('.wm-work-item-adaptive[data-layout="board"]')) return
    if (event.target instanceof HTMLSelectElement) return
    draggedItem.current = itemId
    setPointerItem(itemId)
  }, [])

  const onColumnDragOver = useCallback((columnId: string, event: DragEvent<HTMLDivElement>) => {
    event.preventDefault()
    setDropColumn(columnId)
    // Over the column's own padding rather than a card: the card lands last.
    if (event.target === event.currentTarget) setDropBefore(null)
  }, [])
  const onCardDragOver = useCallback((columnId: string, itemId: string, event: DragEvent<HTMLDivElement>) => {
    event.preventDefault()
    event.stopPropagation()
    const box = event.currentTarget.getBoundingClientRect()
    // Top half inserts above this card, bottom half below it. That is the rule
    // every board uses, and it is what makes "drop it here" predictable.
    const below = event.clientY - box.top > box.height / 2
    const entries = columnModels.find(entry => entry.column.id === columnId)?.entries ?? []
    const index = entries.findIndex(entry => entry.item.id === itemId)
    const next = entries.slice(index + 1).find(entry => entry.item.id !== draggedItem.current)
    setDropColumn(columnId)
    setDropBefore(below ? (next?.item.id ?? null) : itemId)
  }, [columnModels])

  const cardColumns = useMemo(() => columnModels.map(({ column, entries }) => {
    const inserting = dropColumn === column.id
    const indicator = <div aria-hidden className="wm-work-item-insert" />
    const cards = entries.map(({ item, order }) => <>
      {inserting && dropBefore === item.id && indicator}
      <AdaptiveWorkItemCard
        availableLabels={availableLabels}
        columnId={column.id}
        copy={copy}
        density={density}
        item={item}
        key={item.id}
        maxVisibleLabels={maxVisibleLabels}
        onCardDragOver={onCardDragOver}
        onCardPointerDown={onCardPointerDown}
        onLabelsChange={onLabelsChange}
        onMove={onMove}
        onOpen={onOpen}
        onOpenProject={onOpenProject}
        order={order}
        statusOptions={effectiveColumns}
      />
    </>)
    if (inserting && (dropBefore === null || !entries.some(entry => entry.item.id === dropBefore))) cards.push(<>{indicator}</>)
    return { cards, column, count: entries.length }
  }), [availableLabels, columnModels, copy, density, dropBefore, dropColumn, effectiveColumns, maxVisibleLabels, onCardDragOver, onCardPointerDown, onLabelsChange, onMove, onOpen, onOpenProject])

  const moveTo = useCallback((column: WorkItemStatusOption, source: WorkItemMoveSource, id: string | null, beforeItemId: string | null = null) => {
    const item = id ? itemById.get(id) : undefined
    draggedItem.current = null
    setPointerItem(null)
    setDropColumn(null)
    setDropBefore(null)
    if (!item) return
    const entries = columnModels.find(entry => entry.column.id === column.id)?.entries ?? []
    // Decide by comparing the resulting order against the current one. Index
    // arithmetic on the column minus the dragged card is off by one for every
    // card that is not last, and a wrong "already there" verdict would burn a
    // revision on a drop that changed nothing.
    const currentIds = entries.map(entry => entry.item.id)
    const withoutIds = currentIds.filter(id => id !== item.id)
    const at = beforeItemId === null ? -1 : withoutIds.indexOf(beforeItemId)
    const nextIds = at < 0
      ? [...withoutIds, item.id]
      : [...withoutIds.slice(0, at), item.id, ...withoutIds.slice(at)]
    const unchanged = currentIds.length === nextIds.length
      && currentIds.every((id, index) => id === nextIds[index])
    if (item.statusId === column.id && unchanged) return
    handlePresentationPromise(onMove
      ? () => onMove(item, column.id, source, beforeItemId)
      : undefined)
  }, [columnModels, itemById, onMove])

  const onColumnDragLeave = useCallback((columnId: string) => {
    setDropColumn(current => current === columnId ? null : current)
  }, [])
  const onColumnDrop = useCallback((column: WorkItemStatusOption, event: DragEvent<HTMLDivElement>) => {
    event.preventDefault()
    moveTo(column, 'pointer', event.dataTransfer.getData('text/plain') || draggedItem.current, dropBefore)
  }, [dropBefore, moveTo])
  const onColumnPointerUp = useCallback((column: WorkItemStatusOption) => {
    moveTo(column, 'pointer', pointerItem ?? draggedItem.current, dropBefore)
  }, [dropBefore, moveTo, pointerItem])
  const onColumnKeyDown = useCallback((columnIndex: number, event: KeyboardEvent<HTMLDivElement>) => {
    if (event.key !== 'ArrowLeft' && event.key !== 'ArrowRight') return
    event.preventDefault()
    const next = effectiveColumns[columnIndex + (event.key === 'ArrowRight' ? 1 : -1)]
    if (next) scrollRef.current?.querySelector<HTMLElement>(`[data-workflow-state-id="${CSS.escape(next.id)}"]`)?.focus()
  }, [effectiveColumns])
  const onColumnResize = useCallback((column: WorkItemStatusOption, event: ReactPointerEvent<HTMLDivElement>) => {
    if (!onColumnWidthChange) return
    event.preventDefault()
    event.stopPropagation()
    const startX = event.clientX
    const startWidth = columnWidths?.[column.id] ?? DEFAULT_COLUMN_WIDTH
    const target = event.currentTarget
    target.setPointerCapture(event.pointerId)
    const onMovePointer = (moveEvent: PointerEvent) => {
      const delta = moveEvent.clientX - startX
      onColumnWidthChange(column.id, Math.min(maxColumnWidth, Math.max(minColumnWidth, Math.round(startWidth + delta))))
    }
    const onUpPointer = () => {
      target.removeEventListener('pointermove', onMovePointer)
      target.removeEventListener('pointerup', onUpPointer)
      target.removeEventListener('pointercancel', onUpPointer)
    }
    target.addEventListener('pointermove', onMovePointer)
    target.addEventListener('pointerup', onUpPointer)
    target.addEventListener('pointercancel', onUpPointer)
  }, [columnWidths, maxColumnWidth, minColumnWidth, onColumnWidthChange])
  const onPointerDownBoard = useCallback((event: ReactPointerEvent<HTMLDivElement>) => {
    if (layout !== 'board' || !pannable || event.button !== 0) return
    const target = event.target as HTMLElement
    if (target.closest('.wm-work-item-card') || target.closest('.wm-work-item-status-control') || target.closest('button, select, a, input, textarea')) return
    const scroller = scrollRef.current
    if (!scroller) return
    panning.current = { x: event.clientX, y: event.clientY, left: scroller.scrollLeft, top: scroller.scrollTop }
    setIsPanning(true)
    const pointerTarget = event.currentTarget
    pointerTarget.setPointerCapture(event.pointerId)
    const onMovePointer = (moveEvent: PointerEvent) => {
      if (!panning.current) return
      scroller.scrollLeft = panning.current.left - (moveEvent.clientX - panning.current.x)
      scroller.scrollTop = panning.current.top - (moveEvent.clientY - panning.current.y)
    }
    const onUpPointer = () => {
      panning.current = null
      setIsPanning(false)
      pointerTarget.removeEventListener('pointermove', onMovePointer)
      pointerTarget.removeEventListener('pointerup', onUpPointer)
      pointerTarget.removeEventListener('pointercancel', onUpPointer)
    }
    pointerTarget.addEventListener('pointermove', onMovePointer)
    pointerTarget.addEventListener('pointerup', onUpPointer)
    pointerTarget.addEventListener('pointercancel', onUpPointer)
  }, [layout, pannable])

  if (items.length === 0) return <section aria-label={text.listLabel} className="wm-work-item-list-empty" data-testid="work-items-empty">{empty}</section>
  return <WorkItemTokenSurfaceContext.Provider value={tokenSurface === 'board' && layout === 'board'}><section
    aria-label={layout === 'board' ? text.boardLabel : text.listLabel}
    className={workItemClassNames('wm-work-item-adaptive', isPanning && 'is-panning')}
    data-layout={layout}
    data-testid={layout === 'board' ? 'board' : 'work-list'}
    tabIndex={layout === 'board' ? 0 : undefined}
  >
    <div
      aria-label={layout === 'board' ? text.boardColumnsLabel : undefined}
      className="wm-work-item-board-scroll wm-work-item-adaptive-scroll"
      onPointerDown={onPointerDownBoard}
      ref={scrollRef}
      role={layout === 'board' ? 'region' : undefined}
      tabIndex={layout === 'board' ? 0 : undefined}
    >{cardColumns.map(({ cards, column, count }, columnIndex) => <AdaptiveWorkItemColumn
      cards={cards}
      column={column}
      columnIndex={columnIndex}
      count={count}
      dropTarget={dropColumn === column.id}
      key={column.id}
      layout={layout}
      onColumnDragLeave={onColumnDragLeave}
      onColumnDragOver={onColumnDragOver}
      onColumnDrop={onColumnDrop}
      onColumnKeyDown={onColumnKeyDown}
      onColumnPointerUp={onColumnPointerUp}
      onColumnResize={onColumnResize}
      showResize={Boolean(onColumnWidthChange)}
      text={text}
      width={columnWidths?.[column.id] ?? DEFAULT_COLUMN_WIDTH}
    />)}</div>
  </section></WorkItemTokenSurfaceContext.Provider>
}

export type WorkItemFilterValues = { search?: string; statusId?: string; priority?: string; responsibleHumanActorId?: string; ownerId?: string; projectId?: string; milestoneId?: string; label?: string; statusCategory?: string; mine?: boolean }
export type WorkItemFilterOption = { id: string; label: string; name?: string }
export type WorkItemFiltersProps = { value: WorkItemFilterValues; statuses?: WorkItemFilterOption[]; humans?: WorkItemFilterOption[]; projects?: WorkItemFilterOption[]; milestones?: WorkItemFilterOption[]; savedViews?: Array<{ id: string; name: string }>; onChange: (value: WorkItemFilterValues) => void; onClear?: () => void; onApplySavedView?: (id: string) => void; onCreateSavedView?: (name: string) => void | Promise<void>; copy?: Partial<WorkItemCopy>; compact?: boolean; onCompactChange?: (next: boolean) => void }
export function WorkItemFilters({ compact, humans = [], milestones = [], onApplySavedView, onChange, onClear, onCompactChange, onCreateSavedView, projects = [], savedViews = [], statuses = [], value, copy }: WorkItemFiltersProps) {
  const text = resolveWorkItemCopy(copy)
  const [savedViewName, setSavedViewName] = useState('')
  // In compact mode, Milestone/Label collapse behind a "More filters" toggle.
  // The user-driven state is local to the component so the parent's filter
  // values never change just from expanding the row. When the parent supplies
  // an onCompactChange handler, the toggle also reports the new preference
  // back so the parent can persist it.
  const [advancedExpanded, setAdvancedExpanded] = useState<boolean>(!compact)
  const showAdvanced = !compact || advancedExpanded
  const toggleAdvanced = () => {
    const next = !advancedExpanded
    setAdvancedExpanded(next)
    // Report the parent's view of compact mode (the negation of the local
    // "are the advanced fields visible" state) so it can persist.
    if (onCompactChange) onCompactChange(!next)
  }
  const set = (key: keyof WorkItemFilterValues, next: string | boolean | undefined) => onChange({ ...value, [key]: next || undefined })
  const setResponsibleHuman = (next: string) => onChange({ ...value, responsibleHumanActorId: next || undefined, ownerId: undefined, mine: undefined })
  const setProject = (next: string) => onChange({ ...value, projectId: next || undefined, milestoneId: undefined })
  const submitSavedView = (event: FormEvent<HTMLFormElement>) => { event.preventDefault(); if (!savedViewName.trim() || !onCreateSavedView) return; handlePresentationPromise(() => onCreateSavedView(savedViewName.trim())); setSavedViewName('') }
  return <section aria-label={text.filtersLabel} className="wm-work-item-filters">
    <div className="wm-work-item-filter-row">
      <label>{text.search}<input aria-label={text.search} data-hotkey-filter="true" onChange={event => set('search', event.currentTarget.value)} placeholder={text.searchPlaceholder} value={value.search ?? ''} /></label>
      <label>{text.filterStatus}<select aria-label={text.filterStatus} onChange={event => set('statusId', event.currentTarget.value)} value={value.statusId ?? ''}><option value="">{text.allStatuses}</option>{statuses.map(option => <option key={option.id} value={option.id}>{option.label}</option>)}</select></label>
      <label>{text.filterPriority}<select aria-label={text.filterPriority} onChange={event => set('priority', event.currentTarget.value)} value={value.priority ?? ''}><option value="">{text.allPriorities}</option>{['none', 'urgent', 'high', 'medium', 'low'].map(priority => <option key={priority} value={priority}>{text.priorityName(priority)}</option>)}</select></label>
      <label>{text.filterResponsibleHuman}<select aria-label={text.filterResponsibleHuman} onChange={event => setResponsibleHuman(event.currentTarget.value)} value={value.responsibleHumanActorId ?? value.ownerId ?? ''}><option value="">{text.allHumans}</option>{humans.map(option => <option key={option.id} value={option.id}>{option.label}</option>)}</select></label>
      <label>{text.filterProject}<select aria-label={text.filterProject} onChange={event => setProject(event.currentTarget.value)} value={value.projectId ?? ''}><option value="">{text.allProjects}</option>{projects.map(option => <option key={option.id} value={option.id}>{option.label}</option>)}</select></label>
      {showAdvanced && <label>{text.filterMilestone}<select aria-label={text.filterMilestone} disabled={!value.projectId} onChange={event => set('milestoneId', event.currentTarget.value)} value={value.milestoneId ?? ''}><option value="">{value.projectId ? text.allMilestones : text.selectProjectFirst}</option>{milestones.map(option => <option key={option.id} value={option.id}>{option.label}</option>)}</select></label>}
      {showAdvanced && <label>{text.filterLabel}<input aria-label={text.filterLabel} onChange={event => set('label', event.currentTarget.value)} placeholder={text.filterLabel} value={value.label ?? ''} /></label>}
      {compact && <Button aria-expanded={advancedExpanded} aria-label={advancedExpanded ? text.filterLess : text.filterMore} className="wm-work-item-filters-more" data-testid="work-item-filters-more" onClick={toggleAdvanced} type="button" variant="ghost">{advancedExpanded ? text.filterLess : text.filterMore}</Button>}
      {onClear && <Button icon={<FunnelXIcon size={16} weight="bold" />} onClick={onClear} type="button" variant="ghost">{text.clearFilters}</Button>}
    </div>
    {(savedViews.length > 0 || onCreateSavedView) && <div className="wm-work-item-filter-saved">
      {savedViews.length > 0 && <label className="wm-work-item-saved-views">{text.savedView}<select aria-label={text.savedView} defaultValue="" onChange={event => { if (event.currentTarget.value) onApplySavedView?.(event.currentTarget.value); event.currentTarget.value = '' }}><option value="">{text.savedView}</option>{savedViews.map(view => <option key={view.id} value={view.id}>{view.name}</option>)}</select></label>}
      {onCreateSavedView && <form className="wm-work-item-save-view" onSubmit={submitSavedView}><label className="wm-visually-hidden" htmlFor="wm-save-view-name">{text.saveViewName}</label><input id="wm-save-view-name" onChange={event => setSavedViewName(event.currentTarget.value)} placeholder={text.saveView} required value={savedViewName} /><Button icon={<FloppyDiskIcon size={16} weight="bold" />} type="submit">{text.saveView}</Button></form>}
    </div>}
  </section>
}

export type WorkSurfaceStateKind = 'initial' | 'loading' | 'ready' | 'empty' | 'refreshing' | 'forbidden' | 'conflict' | 'offline' | 'reconnecting' | 'error'
export type WorkSurfaceStateProps = { state: Exclude<WorkSurfaceStateKind, 'ready'>; title: string; description: string; actionLabel?: string; onAction?: () => void }
export function WorkSurfaceState({ actionLabel, description, onAction, state, title }: WorkSurfaceStateProps) { const urgent = state === 'error' || state === 'forbidden' || state === 'conflict'; const busy = state === 'loading' || state === 'refreshing' || state === 'reconnecting'; return <section aria-busy={busy || undefined} aria-live={urgent ? 'assertive' : 'polite'} className={workItemClassNames('wm-work-surface-state', `state-${state}`)} data-testid={`work-surface-state-${state}`} role={urgent ? 'alert' : 'status'}><span aria-hidden="true" className="wm-work-surface-state-marker" /><div><h2>{title}</h2><p>{description}</p></div>{actionLabel && onAction && <Button onClick={onAction} type="button">{actionLabel}</Button>}</section> }
export type WorkSurfacePaginationProps = { nextCursor: string | null; loading?: boolean; onLoadMore?: () => void | Promise<void>; copy?: Partial<Pick<WorkItemCopy, 'loadMore' | 'loading'>> }
export function WorkSurfacePagination({ copy, loading = false, nextCursor, onLoadMore }: WorkSurfacePaginationProps) { const text = resolveWorkItemCopy(copy); if (!nextCursor || !onLoadMore) return null; return <Button className="wm-work-surface-pagination" disabled={loading} onClick={() => handlePresentationPromise(onLoadMore)} type="button">{loading ? text.loading : text.loadMore}</Button> }
