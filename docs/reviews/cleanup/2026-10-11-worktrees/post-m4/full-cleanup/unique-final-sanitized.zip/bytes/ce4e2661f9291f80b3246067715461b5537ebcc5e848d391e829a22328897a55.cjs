const fs = require('node:fs');
const cp = require('node:child_process');
const crypto = require('node:crypto');
const manifestPath = 'docs/reviews/d1a/artifact-manifest.json';
const manifest = JSON.parse(fs.readFileSync(manifestPath, 'utf8'));
const head = cp.execFileSync('git', ['rev-parse', 'HEAD'], {encoding:'utf8'}).trim();
const paths = [...new Set([
  ...manifest.worktreeEvidence.map(x => x.path),
  ...manifest.controlEvidence.map(x => x.path),
])].filter(x => x !== 'docs/reviews/d1a/evidence/git-blob-hashes.json');
const sha = b => crypto.createHash('sha256').update(b).digest('hex');
const rows = [];
for (const path of paths) {
  const oid = cp.execFileSync('git', ['rev-parse', `${head}:${path}`], {encoding:'utf8'}).trim();
  const gitBytes = cp.execFileSync('git', ['cat-file', 'blob', oid], {maxBuffer: 64*1024*1024});
  const worktreeBytes = fs.readFileSync(path);
  const normalized = Buffer.from(worktreeBytes.toString('utf8').replace(/^\uFEFF/, '').replace(/\r\n/g, '\n'), 'utf8');
  const identical = gitBytes.equals(worktreeBytes);
  const lfEqual = gitBytes.equals(normalized);
  rows.push({path, commit: head, gitBlob: oid, gitBytes: gitBytes.length, gitSha256: sha(gitBytes), worktreeBytes: worktreeBytes.length, worktreeSha256: sha(worktreeBytes), checkoutTransform: identical ? 'identical' : lfEqual ? 'UTF-8 BOM/CRLF checkout normalization' : 'different content', normalizedEqualsGitBlob: identical || lfEqual});
}
const pendingPaths=[];
for(const dir of ['docs/reviews/d1a/evidence/reverification-environment-04','docs/reviews/d1a/evidence/reverification-environment-05','docs/reviews/d1a/evidence/reverification-environment-06','docs/reviews/d1a/evidence/reverification-environment-07','docs/reviews/d1a/evidence/reverification-environment-08']){
  const walk=d=>{for(const ent of fs.readdirSync(d,{withFileTypes:true})){const p=`${d}/${ent.name}`;if(ent.isDirectory())walk(p);else pendingPaths.push(p.replaceAll('\\','/'));}};
  if(fs.existsSync(dir))walk(dir);
}
const pending=[];
const utf8Decoder = new TextDecoder('utf-8', {fatal:true});
function projectCheckoutBytes(worktree) {
  try {
    const decoded = utf8Decoder.decode(worktree);
    const roundTrip = Buffer.from(decoded, 'utf8');
    if (!roundTrip.equals(worktree) || worktree.includes(0)) return {bytes:worktree,kind:'binary'};
    return {bytes:Buffer.from(decoded.replace(/^\uFEFF/,'').replace(/\r\n/g,'\n'),'utf8'),kind:'text-utf8'};
  } catch {
    return {bytes:worktree,kind:'binary'};
  }
}
for(const path of [...new Set(pendingPaths)]){
 const worktree=fs.readFileSync(path);
 const {bytes:projected,kind}=projectCheckoutBytes(worktree);
 const oid=cp.execFileSync('git',['hash-object',`--path=${path}`,path],{encoding:'utf8'}).trim();
 const projectedOid=cp.execFileSync('git',['hash-object','--stdin'],{input:projected,encoding:'utf8'}).trim();
 pending.push({path,status:'not present in audited HEAD; prospective Git object only; no commit yet',contentKind:kind,projectedGitBlob:oid,projectedBytesBlob:projectedOid,projectedGitBytes:projected.length,projectedGitSha256:sha(projected),worktreeBytes:worktree.length,worktreeSha256:sha(worktree),conversion:projected.equals(worktree)?(kind==='binary'?'binary bytes identical':'text bytes identical'):'UTF-8 BOM/CRLF clean-filter normalization',normalizedEqualsProjectedGitBlob:oid===projectedOid});
}
const out = {schemaVersion:3, scope:'committed Git bytes come directly from git cat-file blob; worktree bytes are read independently. Pending text bytes are BOM/CRLF normalized; pending binary bytes are preserved raw. Pending Git blob IDs are prospective and are not represented as committed objects.', auditedCommit:head, entries:rows, pendingEvidence:pending, totals:{entries:rows.length,gitBytes:rows.reduce((n,x)=>n+x.gitBytes,0),worktreeBytes:rows.reduce((n,x)=>n+x.worktreeBytes,0),gitBlobMatches:rows.filter(x=>x.normalizedEqualsGitBlob).length,worktreeContentDiffers:rows.filter(x=>!x.normalizedEqualsGitBlob).length,pendingEntries:pending.length,pendingBinaryEntries:pending.filter(x=>x.contentKind==='binary').length,pendingTextEntries:pending.filter(x=>x.contentKind==='text-utf8').length,pendingProjectionMismatches:pending.filter(x=>!x.normalizedEqualsProjectedGitBlob).length}};
fs.writeFileSync('.tmp/d1a-git-evidence-audit.json', JSON.stringify(out,null,2)+'\n');

