import { createOpenCodeRuntime } from '../../../packages/conformance/src/joint-clients.drivers.js'
import { writeFileSync } from 'node:fs'
import { resolve } from 'node:path'
const root = process.env.M5_EVIDENCE_ROOT!
const driver = await createOpenCodeRuntime({ executable: process.env.M5_CLIENT_EXECUTABLE!, evidenceRoot: root })
try {
  const result = await driver.output(['serve', '--stdio', '--hostname', '127.0.0.1', '--port', '0', '--print-logs'], { stopOnReadiness: true })
  writeFileSync(resolve(root, 'direct-stdio-bootstrap.json'), JSON.stringify(result, null, 2))
  if (!result.readiness) throw new Error('M5_OPENCODE_STDIO_READY_NOT_OBSERVED')
  console.log(JSON.stringify({ directStdioReady: true, nativeExit: result.nativeExit, modelRun: false }))
} finally { await driver.close() }
