const fs=require('node:fs');const cp=require('node:child_process');const crypto=require('node:crypto');
const m=JSON.parse(fs.readFileSync('docs/reviews/d1a/artifact-manifest.json','utf8'));
const h=JSON.parse(fs.readFileSync('docs/reviews/d1a/evidence/git-blob-hashes.json','utf8'));
const head=m.evidenceAuditHead;let errors=[];let checked=0;
const sha=b=>crypto.createHash('sha256').update(b).digest('hex');
function check(row,commit,fields){
 const oid=cp.execFileSync('git',['rev-parse',`${commit}:${row.path}`],{encoding:'utf8'}).trim();
 const gb=cp.execFileSync('git',['cat-file','blob',oid],{maxBuffer:64*1024*1024});
 const wb=fs.readFileSync(row.path);const norm=Buffer.from(wb.toString('utf8').replace(/^\uFEFF/,'').replace(/\r\n/g,'\n'),'utf8');
 const expect={gitBlob:oid,gitBytes:gb.length,gitSha256:sha(gb),worktreeBytes:wb.length,worktreeSha256:sha(wb)};
 for(const [k,v] of Object.entries(expect))if(row[k]!==v)errors.push(`${row.path} ${k}: record=${row[k]} actual=${v}`);
 const equal=gb.equals(wb)||gb.equals(norm);const transform=gb.equals(wb)?'identical':gb.equals(norm)?'UTF-8 BOM/CRLF checkout normalization':'different content';
 if(fields){if(row.normalizedEqualsGitBlob!==equal)errors.push(`${row.path} normalizedEqualsGitBlob mismatch`);if(row.checkoutTransform!==transform)errors.push(`${row.path} checkoutTransform mismatch`);}
 checked++;
}
for(const row of m.worktreeEvidence)check(row,head,true);
for(const row of m.controlEvidence)check(row,head,true);
for(const row of h.entries)check(row,head,true);
for(const row of [...m.sourceArtifacts,...m.verificationLogs]){
 const commit=m.testedHead;const oid=cp.execFileSync('git',['rev-parse',`${commit}:${row.path}`],{encoding:'utf8'}).trim();const gb=cp.execFileSync('git',['cat-file','blob',oid],{maxBuffer:64*1024*1024});
 if(row.gitObjectAtHead!==oid||row.gitBytesAtHead!==gb.length||row.gitSha256AtHead!==sha(gb))errors.push(`${row.path} historical tested-head Git record mismatch`);checked++;
 const wb=fs.readFileSync(row.path);const norm=Buffer.from(wb.toString('utf8').replace(/^\uFEFF/,'').replace(/\r\n/g,'\n'),'utf8');const transform=gb.equals(wb)?'identical':gb.equals(norm)?'UTF-8 BOM/CRLF checkout normalization':'different content';if(row.worktreeBytes!==wb.length||row.worktreeSha256!==sha(wb)||row.checkoutTransform!==transform||row.normalizedEqualsGitBlob!==(gb.equals(wb)||gb.equals(norm)))errors.push(`${row.path} historical worktree record mismatch`);
}
const utf8Decoder=new TextDecoder('utf-8',{fatal:true});
function projectCheckoutBytes(wb){try{const decoded=utf8Decoder.decode(wb);const roundTrip=Buffer.from(decoded,'utf8');if(!roundTrip.equals(wb)||wb.includes(0))return{bytes:wb,kind:'binary'};return{bytes:Buffer.from(decoded.replace(/^\uFEFF/,'').replace(/\r\n/g,'\n'),'utf8'),kind:'text-utf8'};}catch{return{bytes:wb,kind:'binary'};}}
for(const row of m.pendingEvidence){const wb=fs.readFileSync(row.path);const {bytes:projected,kind}=projectCheckoutBytes(wb);const oid=cp.execFileSync('git',['hash-object',`--path=${row.path}`,row.path],{encoding:'utf8'}).trim();const projectedOid=cp.execFileSync('git',['hash-object','--stdin'],{input:projected,encoding:'utf8'}).trim();const conversion=projected.equals(wb)?(kind==='binary'?'binary bytes identical':'text bytes identical'):'UTF-8 BOM/CRLF clean-filter normalization';if(sha(wb)!==row.worktreeSha256||wb.length!==row.worktreeBytes||oid!==row.projectedGitBlob||projectedOid!==row.projectedBytesBlob||sha(projected)!==row.projectedGitSha256||projected.length!==row.projectedGitBytes||row.contentKind!==kind||row.conversion!==conversion||row.normalizedEqualsProjectedGitBlob!==(oid===projectedOid))errors.push(`${row.path} pending evidence record mismatch`);checked++;}
const hist=cp.execFileSync('git',['diff','--name-status','9ac1a2015da1ae20b9693ac8a62aac6f49dca8d7','HEAD','--','docs/reviews/r1'],{encoding:'utf8'}).trim();if(hist)errors.push(`R1 history changed: ${hist}`);
const out={auditedHead:head,testedHead:m.testedHead,checkedRows:checked,committedEvidenceRows:m.worktreeEvidence.length+m.controlEvidence.length,blobAuditEntries:h.entries.length,pendingEvidenceRows:m.pendingEvidence.length,blobAuditTotals:h.totals,errors};
fs.writeFileSync('.tmp/d1a-git-record-validation.json',JSON.stringify(out,null,2)+'\n');
if(errors.length){console.error(errors.slice(0,20).join('\n'));process.exit(1)}
console.log(JSON.stringify(out,null,2));
