import hashlib
import json
import re
import zipfile
from pathlib import Path

root = Path('docs/reviews/d1a/evidence/reverification-environment-07')
direct = root / 'e2e-failure-captures/trace-sanitized.zip'
report_zip = root / 'e2e-html-report/data/d69f056ec411e76e5d9f9e4664b013966ee3cc75.zip'
trace_report = json.loads((root / 'e2e-failure-captures/trace-redaction-report.json').read_text(encoding='utf-8'))
expected_renames = trace_report['resourceRenames']
key_pattern = re.compile(r'(csrf|xsrf|authorization|cookie|bootstrap.?token|password|secret|api.?key)', re.I)
zip_crc = {}
remaining_sensitive_fields = []
redacted_sensitive_counts = {}
redacted_serialized_counts = {}
remaining_serialized_fields = []
rekey_targets_present = {}
with zipfile.ZipFile(direct) as archive:
    if archive.testzip() is not None:
        raise SystemExit('direct trace archive CRC failed')
    names = set(archive.namelist())
    for old, new in expected_renames.items():
        rekey_targets_present[new] = new in names
        if old != new and old in names:
            raise SystemExit(f'old content-hash resource still present: {old}')
    for name in names:
        data = archive.read(name)
        if name.endswith(('.trace', '.network')):
            try:
                lines = data.decode('utf-8').splitlines()
            except UnicodeDecodeError:
                continue
            def inspect_serialized(node):
                if isinstance(node, dict):
                    key = node.get('k')
                    child = node.get('v')
                    if isinstance(key, str) and key_pattern.search(key):
                        marker = isinstance(child, dict) and child.get('s') == '[REDACTED]'
                        if marker:
                            redacted_serialized_counts[key] = redacted_serialized_counts.get(key, 0) + 1
                        elif isinstance(child, dict) and any(isinstance(v, str) and v not in ('', '[REDACTED]') for v in child.values()):
                            remaining_serialized_fields.append(f'{name}:{key}')
                    for child_value in node.values():
                        inspect_serialized(child_value)
                elif isinstance(node, list):
                    for child_value in node:
                        inspect_serialized(child_value)
            for line in lines:
                try:
                    inspect_serialized(json.loads(line))
                except json.JSONDecodeError:
                    continue
            continue
        if not name.startswith('resources/') or not name.endswith('.json'):
            continue
        try:
            value = json.loads(data.decode('utf-8'))
        except (UnicodeDecodeError, json.JSONDecodeError):
            continue
        def inspect(node, at=''):
            if isinstance(node, dict):
                for key, child in node.items():
                    if key_pattern.search(str(key)) and child == '[REDACTED]':
                        redacted_sensitive_counts[str(key)] = redacted_sensitive_counts.get(str(key), 0) + 1
                    if key_pattern.search(str(key)) and child not in (None, '', '[REDACTED]'):
                        remaining_sensitive_fields.append(f'{name}:{at}/{key}')
                    inspect(child, f'{at}/{key}')
            elif isinstance(node, list):
                for index, child in enumerate(node):
                    inspect(child, f'{at}/{index}')
        inspect(value)
    if remaining_sensitive_fields:
        raise SystemExit('sensitive JSON fields remain')
    if remaining_serialized_fields:
        raise SystemExit('sensitive Playwright serialized values remain')
    for field, minimum in {'csrfToken': 1, 'csrf_token': 1, 'password': 1}.items():
        if redacted_sensitive_counts.get(field, 0) < minimum:
            raise SystemExit(f'expected at least {minimum} redacted {field} fields')
    for field, minimum in {'csrfToken': 1, 'csrf_token': 1}.items():
        if redacted_serialized_counts.get(field, 0) < minimum:
            raise SystemExit(f'expected at least {minimum} redacted serialized {field} fields')
    zip_crc['directTrace'] = {'crcVerified': True, 'entries': len(names), 'bytes': direct.stat().st_size}
with zipfile.ZipFile(report_zip) as archive:
    if archive.testzip() is not None:
        raise SystemExit('HTML report attachment ZIP CRC failed')
    zip_crc['htmlReportAttachment'] = {'crcVerified': True, 'entries': len(archive.namelist()), 'bytes': report_zip.stat().st_size}
if direct.read_bytes() != report_zip.read_bytes():
    raise SystemExit('direct and HTML report trace ZIP copies differ')
archive_sha256 = hashlib.sha256(direct.read_bytes()).hexdigest()
if trace_report.get('sourceArchiveSha256') != archive_sha256 or trace_report.get('archiveBytes') != direct.stat().st_size:
    raise SystemExit('trace redaction report does not match the archived ZIP bytes')
if not all(rekey_targets_present.values()):
    raise SystemExit('one or more renamed resource references are missing')

trace_dir = root / 'e2e-html-report/trace'
ui_mode = (trace_dir / 'uiMode.Ut8wwJNp.js').read_text(encoding='utf-8')
imports = sorted(set(re.findall(r'import\(["\'](\./[^"\']+)["\']\)', ui_mode)))
local_imports = {}
for specifier in imports:
    target = (trace_dir / 'uiMode.Ut8wwJNp.js').parent / specifier
    local_imports[specifier] = target.is_file()
if not all(local_imports.values()):
    raise SystemExit('a UI Mode dynamic import is unresolved')

sha = lambda path: hashlib.sha256(path.read_bytes()).hexdigest()
module = trace_dir / 'assets/xtermModule-CsJ4vdCR.js'
summary = {
    'sourceRun': 'reverification-environment-07',
    'traceRedactionReport': 'e2e-failure-captures/trace-redaction-report.json',
    'redactedFieldCountsByName': trace_report['redactedFieldCountsByName'],
    'verifiedRedactedFieldCountsByName': redacted_sensitive_counts,
    'verifiedRedactedSerializedFieldCountsByName': redacted_serialized_counts,
    'renamedResourceTargetsPresent': rekey_targets_present,
    'remainingSensitiveJsonFields': 0,
    'remainingSensitiveSerializedFields': 0,
    'originalSensitiveValuesRemaining': trace_report['originalSensitiveValuesRemaining'],
    'zipCopiesIdentical': True,
    'traceArchiveSha256': archive_sha256,
    'zipChecks': zip_crc,
    'dynamicImports': {key: value for key, value in local_imports.items()},
    'playwrightModuleSource': 'node_modules/.pnpm/playwright-core@1.61.1/node_modules/playwright-core/lib/vite/traceViewer/assets/xtermModule-CsJ4vdCR.js',
    'includedModule': 'e2e-html-report/trace/assets/xtermModule-CsJ4vdCR.js',
    'includedModuleBytes': module.stat().st_size,
    'includedModuleSha256': sha(module),
}
(root / 'evidence-repair-validation.json').write_text(json.dumps(summary, indent=2) + '\n', encoding='utf-8')
print(json.dumps(summary, indent=2))
