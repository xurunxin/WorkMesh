import { createJointClientsFixture } from '../../../packages/conformance/src/joint-clients.fixture.js'
import { createExternalConsumer } from '../../../packages/conformance/src/joint-clients.external.js'
import { saveJointEvidence } from '../../../packages/conformance/src/joint-clients.reporter.js'
const f = await createJointClientsFixture()
let external: Awaited<ReturnType<typeof createExternalConsumer>> | undefined
try {
  const connection = await f.pairClient('opencode')
  const expected = (await f.db.query<{ agent_actor_id: string; principal_human_actor_id: string; team_id: string }>(
    'SELECT agent_actor_id, principal_human_actor_id, team_id FROM agent_connections WHERE id=$1 AND agent_id=$2', [connection.connectionId, connection.agentId])).rows[0]!
  external = await createExternalConsumer({ baseUrl: f.baseUrl, installationToken: connection.token, allowedTools: ['verify_connection'] })
  const verified = await external.invoke<{ connectionIdentity: { connection: { id: string; agent_actor_id: string; principal_human_actor_id: string; client_type: string } }; bootstrap: { verified: boolean } }>('verify_connection', {})
  const actual = verified.connectionIdentity.connection
  const passed = verified.bootstrap.verified && actual.id === connection.connectionId && actual.agent_actor_id === expected.agent_actor_id
    && actual.principal_human_actor_id === expected.principal_human_actor_id && actual.client_type === 'opencode'
  saveJointEvidence('opencode-actual-identity.json', { passed, expected: { connectionId: connection.connectionId, agentDefinitionId: connection.agentId, ...expected },
    verified, actualModelRun: true, toolResults: external.model.captures.at(-1)?.results, fullAcceptance: 'not_run' })
  if (!passed) throw new Error('M5_NATIVE_IDENTITY_EXACT_BINDING_MISMATCH')
  console.log(JSON.stringify({ actualIdentityRoundTrip: passed, nativeModelToolResult: true, fullAcceptance: 'not_run' }))
} finally { await external?.close(); await f.close() }
