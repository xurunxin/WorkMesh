const fs = require('node:fs');
const path = require('node:path');
const root = path.resolve('.tmp/d1a-stage0-trace-env07-2');
const secrets = new Set();
const parseLine = (line) => { try { return JSON.parse(line); } catch { return null; } };
for (const name of fs.readdirSync(root)) {
  if (!name.endsWith('.trace')) continue;
  for (const line of fs.readFileSync(path.join(root, name), 'utf8').split(/\r?\n/)) {
    const row = parseLine(line);
    if (!row || row.type !== 'before' || !row.params) continue;
    const selector = String(row.params.selector || '').toLowerCase();
    if ((selector.includes('bootstrap token') || selector.includes('password')) && typeof row.params.value === 'string') secrets.add(row.params.value);
  }
}
const sensitive = /authorization|cookie|csrf|bootstrap.?token|password|secret/i;
const visit = (value, key = '') => {
  if (sensitive.test(key)) return '[REDACTED]';
  if (Array.isArray(value)) return value.map(item => {
    if (item && typeof item === 'object' && typeof item.name === 'string' && sensitive.test(item.name)) return { ...item, value: '[REDACTED]' };
    return visit(item, key);
  });
  if (!value || typeof value !== 'object') {
    if (typeof value === 'string') { for (const secret of secrets) value = value.split(secret).join('[REDACTED]'); }
    return value;
  }
  const out = {};
  for (const [childKey, child] of Object.entries(value)) out[childKey] = visit(child, childKey);
  return out;
};
let files = 0;
for (const name of fs.readdirSync(root)) {
  const file = path.join(root, name);
  if (!fs.statSync(file).isFile()) continue;
  const ext = path.extname(name);
  if (!['.trace', '.network', '.stacks'].includes(ext)) continue;
  const lines = fs.readFileSync(file, 'utf8').split(/\r?\n/).filter(Boolean);
  const sanitized = lines.map(line => { const row = parseLine(line); return row ? JSON.stringify(visit(row)) : line; }).join('\n') + '\n';
  fs.writeFileSync(file, sanitized);
  files++;
}
console.log(JSON.stringify({ redactedCredentialFields: true, detectedFilledSecrets: secrets.size, sanitizedTraceFiles: files }));
