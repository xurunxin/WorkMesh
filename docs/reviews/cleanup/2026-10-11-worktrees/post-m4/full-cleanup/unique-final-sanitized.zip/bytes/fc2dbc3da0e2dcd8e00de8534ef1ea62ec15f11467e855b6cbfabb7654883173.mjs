import { execFileSync, spawnSync } from 'node:child_process';
import { writeFileSync, readFileSync } from 'node:fs';
import { planForEvent, readWorkspaces } from '../scripts/ci-policy.mjs';
const base='9ac1a2015da1ae20b9693ac8a62aac6f49dca8d7';
const candidateIndex='.tmp/ci385-final-candidate.index';
const env={...process.env,GIT_INDEX_FILE:candidateIndex};
for(const args of [['read-tree',base],['add','-A']]) { const r=spawnSync('git',args,{env,stdio:'ignore'}); if(r.status!==0) throw new Error(`git ${args[0]} failed: ${r.status}`); }
const tree=execFileSync('git',['write-tree'],{env,encoding:'utf8'}).trim();
const diff=spawnSync('git',['diff','--check',base,tree],{encoding:null,maxBuffer:64*1024*1024});
writeFileSync('.tmp/ci385-candidate-diff-check.log',diff.stdout||Buffer.alloc(0));
if(diff.status!==0) throw new Error(`candidate diff check failed: ${diff.status}`);
const git=args=> args[0]==='merge-base' ? `${base}\n` : execFileSync('git',args,{encoding:'utf8',maxBuffer:64*1024*1024});
const plan=planForEvent('pull_request',{pull_request:{base:{sha:base},head:{sha:tree}}},readWorkspaces(),git);
writeFileSync('.tmp/ci385-candidate-selection.json',JSON.stringify({base,candidateTree:tree,selection:plan},null,2)+'\n');
console.log(JSON.stringify({candidateTree:tree,diffCheckExitCode:diff.status,diffCheckOutputBytes:(diff.stdout||Buffer.alloc(0)).length,mode:plan.mode,affectedPackages:plan.packages.length,testPackages:plan.testPackages.length,checks:plan.checks},null,2));

