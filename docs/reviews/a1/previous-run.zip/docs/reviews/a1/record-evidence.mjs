import { createHash } from 'node:crypto'
import { execFileSync } from 'node:child_process'
import { readFileSync, writeFileSync, readdirSync } from 'node:fs'
import { join } from 'node:path'

// 只汇总实际日志，不将历史 CI、skip 或尚未执行的项目标成通过。
const root = process.cwd()
const directory = join(root, 'docs/reviews/a1')
const hash = bytes => createHash('sha256').update(bytes).digest('hex')
const decode = bytes => bytes[0] === 0xff && bytes[1] === 0xfe
  ? bytes.subarray(2).toString('utf16le') : bytes.toString('utf8').replace(/^\uFEFF/, '')
const json = path => JSON.parse(decode(readFileSync(join(root, path))))
const git = args => execFileSync('git', args, { cwd: root, windowsHide: true })
const write = (name, value) => writeFileSync(join(directory, name), JSON.stringify(value, null, 2) + '\n')
const source = json('docs/plan/a1-configuration-readiness/source.json')
const r1 = json('docs/reviews/r1/test-coverage.json').features.find(feature => feature.seqNum === 8)
const testFile = 'apps/api/integration/configuration-readiness.integration.test.ts'
const testSource = readFileSync(join(root, testFile), 'utf8')
const checks = Object.fromEntries(readdirSync(join(directory, 'evidence')).filter(name => name.endsWith('.result.json')).map(name => {
  const result = json(`docs/reviews/a1/evidence/${name}`)
  return [name.replace('.result.json', ''), result]
}))
const passed = checks.targeted?.exitCode === 0
for (const entry of source.testMapping.originalTests)
  if (!testSource.includes(entry.caseName)) throw new Error(`Missing original case: ${entry.caseName}`)
for (const entry of source.testMapping.nineCategories.filter(entry => entry.applicable))
  if (!testSource.includes(entry.caseName)) throw new Error(`Missing applicable case: ${entry.caseName}`)
write('test-coverage.json', {
  source: 'docs/reviews/r1/test-coverage.json', todoId: source.todoId,
  owner: '本会话 A1 执行者',
  originalTests: r1.originalTests.map(entry => ({ ...entry,
    testFile, caseName: source.testMapping.originalTests.find(test => test.id === entry.id).caseName,
    status: passed ? '本轮定向集成实际通过' : '本轮尚未通过', evidence: 'evidence/targeted.log' })),
  nineCategories: source.testMapping.nineCategories.map(entry => ({ ...entry,
    result: entry.applicable ? passed ? '本轮定向集成实际通过' : '本轮尚未通过' : '不适用，未冒称通过',
    supplementalCase: ['transaction failure', 'duplicate idempotency key', 'stale revision', 'server restart/outbox recovery'].includes(entry.category)
      ? source.testMapping.originalTests[5].caseName : null,
    evidence: entry.applicable ? 'evidence/targeted.log' : null })),
  originalDoD: r1.originalDoD,
  currentDoD: {
    projection: passed ? '定向集成通过' : '待验证',
    isolationAndStates: passed ? '定向集成通过' : '待验证',
    zeroSchemaChange: git(['diff', '1078bbcd527550bfabee73093b7ffd0032d3fd24', '--', 'SCHEMA.sql', 'packages/db/src/schema.ts', 'packages/db/migrations']).length === 0,
    requiredChecks: checks,
    independentReview: '待本提交独立复核', chiefConfirmation: '待本提交 Chief 最终确认',
  },
  auditException: '鉴权拒绝仅允许既有 authorization_denials；成功、重复、参数错误和查询故障全部 public 表行数与内容摘要不变。',
  nonApplicableSupplement: '六类写协议/恢复测试不适用；原验收6另覆盖重复并行 GET、失败 SELECT、无业务持久化副作用，不冒称执行了事务或恢复测试。',
})
const rawRead = json('docs/reviews/a1/platform-readback.json').todo.value.content[0].text
const originalSpec = rawRead.split('\nSpec:\n')[1].split('\nSaved plan:\n')[0]
const body = git(['show', '98175411cb0b1f3d52c661d71e3e75c489a05e6b:docs/plan/a1-configuration-readiness.md'])
if (hash(body) !== source.contentSha256) throw new Error('Saved plan archive hash mismatch')
const savedPrefix = rawRead.split('\nSaved plan:\n')[1].split('\n…(truncated)')[0]
if (!body.toString('utf8').startsWith(savedPrefix)) throw new Error('Current saved-plan prefix mismatch')
write('implementation-inputs.json', {
  todoId: source.todoId, projectId: source.projectId, phase: 'building',
  executorAgentId: rawRead.match(/Assigned agent: ([^ ]+)/)[1],
  executorSource: '本轮 todos 实读 Assigned agent；不冒称任命其他阶段 owner。',
  authorization: '用户本轮明确要求 Now carry out this plan. Make all the file changes it calls for.',
  authority: '用户已确认 workKind、指定上下文与 authorization_denials 例外；Todos 编排与仓库证据替代真实 WorkMesh 双轨。',
  savedPlan: { path: source.snapshotPath, currentID: source.currentID, version: null,
    contentSha256: hash(body), byteKind: 'git-blob', contentBytes: body.length, sourceCommit: '98175411cb0b1f3d52c661d71e3e75c489a05e6b',
    source: source.savedPlanSource, fullBackendDocumentRead: false, historyPreserved: true,
    currentToolPrefixMatches: true },
  currentSpec: { path: 'docs/reviews/a1/current-spec.md', source: 'mcp__tds__todos(id) 完整 Spec 段',
    updatedAt: '2026-10-08T07:46:54.320Z', exactToolSpecUtf8Sha256: hash(Buffer.from(originalSpec)),
    snapshotWorktreeSha256: hash(readFileSync(join(directory, 'current-spec.md'))),
    note: '工具 Spec 原字符串与落盘文件边界换行分开核验；历史源 SHA 不改写。' },
  upstreamMain: '1078bbcd527550bfabee73093b7ffd0032d3fd24',
  integrationBase: '901e040',
  dependencyRecord: { required: [1, 2, 18, 3], source: 'docs/plan/activation-task-specs/index.json',
    note: '开工实读相关前置任务为 done；本轮不宣告这些历史任务重新验收。' },
  upstreamDifference: '合入 D1a 主题变量与 E2E 修正及证据；本卡依赖的鉴权、模型、Agent、仓库、schema 接口未变。',
  implementationAdjustments: [
    'apps/api/src/authz/authorize.ts 为该操作跳过预先查询 Team 存在性的 resolveTeam；Human-only 身份策略保留，同一最终 SELECT 重验实时权限并将隐藏/不存在统一 NOT_FOUND，既有拒绝审计不改。',
    'packages/contracts/src/route-policy.test.ts 的显式路由数量更新为新增 GET 后的实际数量。',
    'docs/plan/activation-task-specs/08.md 增加当前口径，保留历史正文、测试、DoD 与源 SHA；获批计划精确快照不修改。',
  ],
  verificationCommitBinding: '实施提交由平台回合结束生成；本记录用实施前基点与 source-manifest.json 文件哈希绑定，不预填未来 commit SHA。',
})
const paths = git(['diff', '--name-only', '1078bbcd527550bfabee73093b7ffd0032d3fd24']).toString().trim().split(/\r?\n/)
const untracked = git(['ls-files', '--others', '--exclude-standard']).toString().trim().split(/\r?\n/)
write('source-manifest.json', {
  base: '1078bbcd527550bfabee73093b7ffd0032d3fd24',
  note: '哈希对应本轮工作树原字节；Windows CRLF、PowerShell UTF-16 日志不等同 Git LF 文本。清单不哈希自身。未来提交 SHA 由提交历史读回。',
  files: [...new Set([...paths, ...untracked])].filter(path => path && path !== 'docs/reviews/a1/source-manifest.json').sort().map(path => {
    const bytes = readFileSync(join(root, path))
    return { path, bytes: bytes.length, sha256: hash(bytes) }
  }),
})
console.log(JSON.stringify({ originalTests: r1.originalTests.length, categories: source.testMapping.nineCategories.length, checks, savedPlanMatches: true }))
