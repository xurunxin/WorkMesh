# A1 实施与验证记录

## 交付范围

新增 Human-only `GET /api/v1/workbench/configuration-readiness`，operationId
`getConfigurationReadiness`。必填 `teamId` 与显式 `workKind`，可选 Project/WorkItem
上下文；模型、Agent、仓库、Runner 固定四项投影，无总体运行许可。缺少或不可见配置
统一 `blocked/unmet`，Runner 恒 `unknown/not_observable`；仓库不适用是
`applicability=not_applicable`、`state=null`，不是第四种就绪状态。

同一参数化 SELECT 重验 Human、会话、Team 权限并读取当前配置，不缓存投影。
指定资源只看当前上下文，未指定才看 Team 的 Project；非仓库请求也校验指定资源。
不返回隐藏资源的名称、数量、ID；不可见/不存在/删除/越界资源统一 NOT_FOUND。
数据库故障返回结构化错误。成功、重复、参数错误、查询故障所有 public 表行数和
实际行内容摘要不变；鉴权拒绝仅允许既有 `authorization_denials` 安全审计增加。

共享 Zod/OpenAPI 契约、REST 清单、操作绑定与 Human-only 策略均同步；
`docs/route-policy-matrix.md` 和 OpenAPI 策略扩展由 `pnpm generate:route-policy`
生成，未手改矩阵。`SCHEMA.sql`、`packages/db/src/schema.ts`、migrations 无变更，
无新增事件或写端点，无 Session、receipt、event、outbox 副作用。

实现位于 `apps/api/src/configuration-readiness.ts`，由 `server.ts` 注册。额外调整
`authz/authorize.ts`：该 GET 跳过粗粒度 Team 存在性读取，由最终 SELECT 统一校验；
全局身份、Human-only 和拒绝审计机制保持。路由数量断言随新增 GET 增加一项。
相关产品说明写入 CONTEXT、AGENT_PROTOCOL、ADR 0074 与本卡仓库规格；ADR 状态
仍是 Proposed，没有自行宣布验收。获批计划及 R1、G1 历史归档保持。

## 输入、授权与提交绑定

精确获批计划：`docs/plan/a1-configuration-readiness.md`；来源/currentID/null 版本/
正文哈希沿用同名目录 `source.json`，不为自引用另存平台版本。本轮用户明确要求实施，
工具实读任务为 building，依赖四卡为 done，读回见 `platform-readback.json` 与
`dependencies-readback.json`。本轮 Spec 完整段另存 `current-spec.md`；历史源 SHA
不冒充当前正文 SHA。没有创建真实 WorkMesh Session 或冒充真实控制面。

开工实读远端 main 为 `1078bbcd527550bfabee73093b7ffd0032d3fd24`，当前会话分支
正常合入为 `901e040`，保留原归档提交。D1a 主线增量没有改动 A1 依赖的权限、模型、
Agent、仓库或 schema 契约。`implementation-inputs.json` 记录当前输入与差异，
`source-manifest.json` 将实施文件及原始日志绑定到工作树字节和实施基点；平台在回合
结束生成实施提交，本文不虚构未来 commit SHA。Windows CRLF 与 PowerShell UTF-16
日志的原始字节和 Git LF 文本需分别核验。

## 验收映射与实际检查

原七条用例名及三条适用 R1 用例均在
`apps/api/integration/configuration-readiness.integration.test.ts`，契约另有四项测试。
`test-coverage.json` 完整保存原测试、原 DoD、九类适用性及本轮结果。写协议与恢复类
不适用没有被标成通过；重复/失败 GET 的副作用另由原验收6覆盖。

每条命令的原始输出及退出码见
`evidence/*.log`、`evidence/*.result.json`。运行入口 `run-checks.ps1` 只配置本轮
回环地址上的公开测试夹具，随机 bootstrap token 仅传入进程环境，不写证据。

已完成的顺序单元回归：`pnpm test` 29/29 任务成功，1661 项通过，2 项 retention
soak 可选用例跳过；跳过未计通过。`pnpm ci:source build` 18/18 任务成功。
`pnpm lint`、`pnpm typecheck` 均成功；路由、WorkMesh Skill、Runner Skill 的生成
一致性检查成功，`pnpm ci:validate` 和 `pnpm ci:test` 成功（后者 12 项）。
Agent smoke 成功，conformance 为 6/6 adapter/fixture 运行成功。独立开启
`RUN_RECOVERY_INTEGRATION=1` 的真实备份、断点恢复、状态核验用例为 1/1 通过；
不把根集成入口默认跳过的 recovery 误计通过。原始结果以对应 result.json 为准。

`pnpm test:integration` 最终成功：数据库 77/77、API 165 项通过及 1 项真实模型
测试跳过、Worker 78 项通过及 1 项可选 retention upgrade 测试跳过。根入口
recovery 默认 1 项跳过，另以独立开启的 recovery 运行证明实际恢复成功。
合计 320 项通过、3 项跳过，跳过不计通过。API 这轮包含新增 11 项定向断言。

conformance 原始 report、JUnit、transcript 从日志所示生成目录原字节归档到
`evidence/conformance-results/`，没有改写原始输出。

失败记录保留：bootstrap 格式、Windows PowerShell 无 BOM 中文注释吞掉下一行环境
变量、夹具数据库约束/membership/capability、旧路由数量断言，以及单元测试服务
加载超过既有 hook 时限。修复夹具/路由计数后重新运行，没有放宽产品校验或测试超时。
全量集成首轮另有既有 Runner 子进程超时（与完整构建重叠）；独立重跑用例成功。
这是运行相关性记录，不推定根因，也不以局部重跑代替全量集成的最终结果。

## 演示与交接

用已有 Human session 调用：

```text
GET /api/v1/workbench/configuration-readiness?teamId=<TEAM>&workKind=repository&projectId=<PROJECT>
GET /api/v1/workbench/configuration-readiness?teamId=<TEAM>&workKind=non_repository&projectId=<PROJECT>
```

前者检查该 Project，其他项目不补足；后者仓库项不适用。禁用可见模型、撤销 Team
membership/Agent grant 后再次读取，结果即时变化；重复 GET 不持久化投影。
无 assignment、旧 heartbeat、executing Session 都不改变 Runner unknown。
隐藏 Team/Project 与不存在资源的错误只因 correlationId 区分请求，不泄露资源事实。

A2 页面、setup shell、Runner 活性事实与激活许可不在此次交付内。最终提交的远端
required CI、独立复核与 Chief 最终确认须分别实读，不能用本地检查或历史 CI 替代。
本记录交给复核方，不冒称最终 DoD 已由 Chief 验收。
