﻿param([Parameter(Mandatory=$true)][string]$Check)
$ErrorActionPreference = 'Stop'
# 本轮独立、仅回环可达的公开测试夹具；不得用于生产部署。
$env:RUN_INTEGRATION = '1'
$env:DATABASE_URL = 'postgres://workmesh:workmesh-ci-postgres@127.0.0.1:35432/workmesh_a1_test'
$env:REDIS_URL = 'redis://127.0.0.1:36379'
$env:SESSION_SECRET = 'workmesh-ci-session-secret-api-00000001'
$env:WORKMESH_MASTER_KEY = '0123456789abcdef0123456789abcdef0123456789abcdef0123456789abcdef'
$env:WORKMESH_BOOTSTRAP_TOKEN = node -e "process.stdout.write(require('node:crypto').randomBytes(32).toString('base64url'))"
$env:WORKMESH_RUNNER_SERVICE_TOKEN = 'workmesh-ci-runner-service-token-00000001'
$env:AUTH_RATE_LIMIT_ENDPOINT_BURST = '10000'
$env:AUTH_RATE_LIMIT_SOCKET_BURST = '10000'
$env:AUTH_RATE_LIMIT_CLIENT_IP_BURST = '10000'
$env:AUTH_RATE_LIMIT_SUBJECT_BURST = '1000'
$env:AUTH_RATE_LIMIT_INSTALL_BURST = '100'
$env:S3_ENDPOINT = 'http://127.0.0.1:39000'
$env:S3_BUCKET = 'workmesh-artifacts'
$env:S3_REGION = 'us-east-1'
$env:S3_ACCESS_KEY_ID = 'workmesh'
$env:S3_SECRET_ACCESS_KEY = 'workmesh-ci-minio-password'
$env:S3_FORCE_PATH_STYLE = 'true'
$env:WORKMESH_BETA_GITEA = 'false'
$env:WORKMESH_PLAYWRIGHT_RUN_DIR = Join-Path $env:TEMP 'workmesh-a1-01a1187a-playwright'
$commands = @{
  contracts = @('--filter','@workmesh/contracts','exec','vitest','run','src/configuration-readiness-contracts.test.ts')
  targeted = @('--filter','@workmesh/api','exec','vitest','run','--config','../../vitest.integration.config.ts','integration/configuration-readiness.integration.test.ts')
  apiTypecheck = @('--filter','@workmesh/api','typecheck')
  lint = @('lint')
  typecheck = @('typecheck')
  unit = @('test')
  integration = @('test:integration')
  e2e = @('test:e2e')
  ci = @('ci:validate')
  route = @('check:route-policy')
  build = @('ci:source','build')
  workmeshSkill = @('check:workmesh-skill')
  runnerSkill = @('check:runner-skill')
  agentSmoke = @('smoke:agents:ci')
  conformance = @('test:conformance')
  ciPolicy = @('ci:test')
  rateLimitUnit = @('--filter','@workmesh/api','exec','vitest','run','src/auth-rate-limit/server-rate-limit.test.ts','--fileParallelism=false')
  recovery = @('--filter','@workmesh/recovery','test:integration')
  runnerIntegration = @('--filter','@workmesh/api','exec','vitest','run','--config','../../vitest.integration.config.ts','integration/workbench-runner.integration.test.ts')
}
if (!$commands.ContainsKey($Check)) { throw "Unknown check: $Check" }
if ($Check -eq 'recovery') {
  $env:RUN_RECOVERY_INTEGRATION = '1'
  $env:RECOVERY_SOURCE_DATABASE_URL = 'postgres://workmesh:workmesh-ci-postgres@127.0.0.1:35432/workmesh_a1_recovery_source_test'
  $env:RECOVERY_TARGET_DATABASE_URL = 'postgres://workmesh:workmesh-ci-postgres@127.0.0.1:35432/workmesh_a1_recovery_target_test'
  $env:RECOVERY_TEST_S3_ENDPOINT = $env:S3_ENDPOINT
  $env:RECOVERY_TEST_S3_ACCESS_KEY_ID = $env:S3_ACCESS_KEY_ID
  $env:RECOVERY_TEST_S3_SECRET_ACCESS_KEY = $env:S3_SECRET_ACCESS_KEY
  $env:WORKMESH_POSTGRES_TOOL_CONTAINER = 'wm-a1-01a1187a-pg'
  $env:WORKMESH_POSTGRES_TOOL_HOST = '127.0.0.1'
  $env:WORKMESH_POSTGRES_TOOL_PORT = '5432'
}
$arguments = $commands[$Check]
$log = Join-Path $PSScriptRoot "evidence/$Check.log"
node -e "console.log({run:process.env.RUN_INTEGRATION,database:new URL(process.env.DATABASE_URL).pathname})"
$ErrorActionPreference = 'Continue'
& pnpm.cmd @arguments *> $log
$result = $LASTEXITCODE
$ErrorActionPreference = 'Stop'
@{ command = "pnpm $($arguments -join ' ')"; exitCode = $result } |
  ConvertTo-Json | Set-Content -Encoding utf8 (Join-Path $PSScriptRoot "evidence/$Check.result.json")
Get-Content -LiteralPath $log -Tail 24
exit $result
