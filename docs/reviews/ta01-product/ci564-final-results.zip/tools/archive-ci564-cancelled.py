import hashlib
import json
from pathlib import Path
import re
import subprocess
import zipfile

head = '5371f16e24db94415155228dfc8ac149523573a0'
root = Path('.tmp/ta01-resumption')
out = Path('docs/reviews/ta01-product')
sha = lambda data: hashlib.sha256(data).hexdigest()
producer = json.loads((root / 'ci564-producer-projection.json').read_bytes())
for arch, profile, job, artifact in [('amd64', 'personal', 116800972564, 12025527706),
        ('arm64', 'personal', 116800972501, 12024994988), ('arm64', 'team', 116800972574, 12025184756),
        ('arm64', 'enterprise', 116800972535, 12026012155)]:
    raw = root / f'ci564-{arch}-{profile}-raw.zip'
    with zipfile.ZipFile(raw) as archive:
        members = {name: archive.read(name) for name in archive.namelist() if name.startswith('server-install/')}
    assert len(members) == 10 and 'server-install/result.json' not in members
    source = members['server-install/source.txt'].decode().split()
    assert source[0] == head and source[1] == producer[arch]['tree']
    assert members['server-install/source-after.txt'].decode().split() == source
    manifest = json.loads(members['server-install/manifest.json'])
    received_producer = json.loads(members['server-install/producer.json'])
    assert manifest['source']['commit'] == head and manifest['arch'] == arch
    assert sha(members['server-install/manifest.json']) == received_producer['manifestSha256'] == producer[arch]['manifestSha256']
    assert str(received_producer['artifactId']) == str(producer[arch]['candidateArtifact'])
    scripts = {}
    for checksum, name in re.findall(r'^([a-f0-9]{64})  (scripts/server-distribution/[^\s]+)$', members['server-install/input-sha256.txt'].decode(), re.M):
        assert '..' not in name and sha(subprocess.check_output(['git', 'show', head + ':' + name])) == checksum
        scripts[name] = checksum
    assert len([name for name in scripts if name.endswith('.py')]) == 6
    records, serial = [], members['server-install/serial.log'].decode(errors='replace')
    for match in re.finditer(r'\{"tag": "ta01-(?:install-action|progress|installer-phase|failure)"', serial):
        value, _ = json.JSONDecoder().raw_decode(serial, match.start())
        records.append(value)
    for data in members.values():
        assert not re.search(rb'wm[ips]_[A-Za-z0-9_-]{43}', data)
    jobs = json.loads(subprocess.check_output(['gh', 'api', f'repos/xurunxin/WorkMesh/actions/jobs/{job}']))
    assert jobs['status'] == 'completed' and jobs['conclusion'] == 'cancelled'
    value = {'说明': '平台checkpoint推送后作业取消；没有result，不能补造最终失败/成功、完整重启、回执或资源收尾。只保实际原件、准确源码及串口已记录事实。',
        'sourceHead': head, 'sourceTree': source[1], 'scriptsMatchGit': True, 'scripts': scripts,
        'runId': 38846561914, 'jobId': job, 'artifactId': artifact, 'arch': arch, 'profile': profile,
        'jobConclusion': jobs['conclusion'], 'resultPresent': False, 'producer': received_producer,
        'artifactZipSha256': sha(raw.read_bytes()), 'records': records,
        'members': {name: {'bytes': len(data), 'sha256': sha(data)} for name, data in members.items()}}
    stem = out / f'ci564-{arch}-{profile}-cancelled'
    with zipfile.ZipFile(stem.with_suffix('.zip'), 'x', compression=zipfile.ZIP_DEFLATED) as archive:
        for name, data in members.items():
            archive.writestr(name, data)
    value['selectedZipSha256'] = sha(stem.with_suffix('.zip').read_bytes())
    with stem.with_suffix('.json').open('x', encoding='utf8', newline='\n') as output:
        json.dump(value, output, ensure_ascii=False, indent=2)
        output.write('\n')
    actions = [row for row in records if row.get('tag') == 'ta01-install-action']
    print(json.dumps({'arch': arch, 'profile': profile, 'members': len(members), 'resultPresent': False,
        'inputFilesMatch': len(scripts), 'lastActions': actions[-3:]}))
