from datetime import datetime, timezone
import hashlib
import json
from pathlib import Path
import subprocess
import zipfile

root = Path('.tmp/ta01-resumption')
out = Path('docs/reviews/ta01-product')
head = '5371f16e24db94415155228dfc8ac149523573a0'
sha = lambda data: hashlib.sha256(data).hexdigest()
def api(path):
    result = subprocess.run(['gh', 'api', 'repos/xurunxin/WorkMesh/' + path], capture_output=True, timeout=30)
    assert result.returncode == 0, 'GitHub query failed; stderr withheld'
    return json.loads(result.stdout)
run = api('actions/runs/38846561914')
jobs = api('actions/runs/38846561914/jobs?per_page=100')['jobs']
assert run['head_sha'] == head and run['status'] == 'completed' and run['conclusion'] == 'cancelled'
assert all(job['status'] == 'completed' for job in jobs)
producers = json.loads((root / 'ci564-producer-projection.json').read_bytes())
members = {'producers.json': (root / 'ci564-producer-projection.json').read_bytes()}
for arch, producer in producers.items():
    raw = root / f'ci564-build-{arch}-raw.zip'
    assert sha(raw.read_bytes()) == producer['rawZipSha256']
    with zipfile.ZipFile(raw) as archive:
        members.update({arch + '/' + name: archive.read(name) for name in archive.namelist() if name.startswith('server-build/')})
guests = []
for job in jobs:
    if not job['name'].startswith('Server full installation ('):
        continue
    arch, profile = job['name'].removesuffix(')').split('(')[1].split(', ')
    suffix = {'success': 'full-guest-pass', 'failure': 'first-failure', 'cancelled': 'cancelled'}[job['conclusion']]
    path = out / f'ci564-{arch}-{profile}-{suffix}.json'
    value = json.loads(path.read_bytes())
    assert value['sourceHead'] == head and value['jobId'] == job['id'] and value['scriptsMatchGit']
    assert sha(path.with_suffix('.zip').read_bytes()) == value['selectedZipSha256']
    assert value['producer']['manifestSha256'] == producers[arch]['manifestSha256']
    assert str(value['producer']['artifactId']) == str(producers[arch]['candidateArtifact'])
    guests.append({'arch': arch, 'profile': profile, 'jobId': job['id'], 'conclusion': job['conclusion'],
        'index': path.name, 'indexSha256': sha(path.read_bytes()), 'selectedZipSha256': value['selectedZipSha256'],
        'artifactId': value['artifactId'], 'artifactZipSha256': value['artifactZipSha256'],
        'resultPresent': value.get('resultPresent', True), 'totalSeconds': value.get('totalSeconds')})
assert len(guests) == 6
checkpoint = 'ac0a4d21deba15a23c8c7b40f671b59c41f30f37'
next_run = api('actions/runs/38852474436')
assert next_run['head_sha'] == checkpoint and next_run['event'] == 'pull_request'
summary = {'说明': 'CI564全部作业已终态，但运行cancelled；一组成功、一组真实失败、四组取消且没有result，不能写自然结束或补通过。后续CI565为平台checkpoint自动触发，不代原故障闭合。',
    'sourceHead': head, 'run': {key: run[key] for key in ['id', 'status', 'conclusion', 'head_sha', 'created_at', 'updated_at']},
    'jobs': [{key: job[key] for key in ['id', 'name', 'status', 'conclusion', 'started_at', 'completed_at']} for job in jobs],
    'guests': guests, 'producers': producers,
    'checkpoint': {'head': checkpoint, 'parent': subprocess.check_output(['git', 'rev-parse', checkpoint + '^']).decode().strip(),
        'tree': subprocess.check_output(['git', 'rev-parse', checkpoint + '^{tree}']).decode().strip(),
        'subject': subprocess.check_output(['git', 'show', '-s', '--format=%s', checkpoint]).decode().strip()},
    'ci565Snapshot': {key: next_run[key] for key in ['id', 'status', 'conclusion', 'head_sha', 'created_at', 'updated_at']},
    'cancellationAttribution': '执行者未调用cancel/rerun。平台checkpoint后四job取消，与本仓库ci-pull_request-228并发规则一致；GitHub接口未给独立取消发起者，因果归属为规则和时序推断。',
    'observedAt': datetime.now(timezone.utc).isoformat()}
members['summary.json'] = (json.dumps(summary, ensure_ascii=False, indent=2) + '\n').encode()
members['checkpoint-commit.txt'] = subprocess.check_output(['git', 'show', '-s', '--format=raw', checkpoint])
members['checkpoint-ci.yml'] = subprocess.check_output(['git', 'show', checkpoint + ':.github/workflows/ci.yml'])
for name in ['archive-ci564-cancelled.py', 'archive-ci564-final.py', 'inspect-ci564-producers.py']:
    members['tools/' + name] = (root / name).read_bytes()
stem = out / 'ci564-final-results'
with zipfile.ZipFile(stem.with_suffix('.zip'), 'x', compression=zipfile.ZIP_DEFLATED) as archive:
    for name, data in members.items():
        archive.writestr(name, data)
summary['selectedZipSha256'] = sha(stem.with_suffix('.zip').read_bytes())
summary['members'] = {name: {'bytes': len(data), 'sha256': sha(data)} for name, data in members.items()}
with stem.with_suffix('.json').open('x', encoding='utf8', newline='\n') as output:
    json.dump(summary, output, ensure_ascii=False, indent=2)
    output.write('\n')
print(json.dumps({'runConclusion': run['conclusion'], 'guestConclusions': [row['conclusion'] for row in guests],
    'required': next(job['conclusion'] for job in jobs if job['name'] == 'Required CI'), 'members': len(members)}))
