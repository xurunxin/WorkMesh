from pathlib import Path
from datetime import datetime, timezone
import hashlib, json, re, subprocess, zipfile

BASE = Path('.tmp/ta01-resumption')
OUT = Path('docs/reviews/ta01-product')
HEAD = 'c7cf68aaf279f771a2022d37d69b5651cdb66ace'
RUN = 39169353227
sha = lambda b: hashlib.sha256(b).hexdigest()
def gh(*args):
    return json.loads(subprocess.check_output(['gh', *args]))
def git(*args):
    return subprocess.check_output(['git', *args])
def write_json(path, value):
    assert not path.exists(), str(path)
    path.write_text(json.dumps(value, ensure_ascii=False, indent=2)+'\n', encoding='utf8', newline='\n')
def safe(members):
    for name, data in members.items():
        assert not re.search(rb'wm[ips]_[A-Za-z0-9_-]{43}|-----BEGIN (?:RSA |EC |OPENSSH )?PRIVATE KEY-----', data), name
def bundle(stem, members, index):
    safe(members)
    target = OUT/(stem+'.zip')
    with zipfile.ZipFile(target, 'x', zipfile.ZIP_DEFLATED) as z:
        for name, data in members.items():
            z.writestr(name, data)
    index.update(selectedZipSha256=sha(target.read_bytes()), members={n:{'bytes':len(b),'sha256':sha(b)} for n,b in members.items()})
    write_json(OUT/(stem+'.json'), index)
def verify_inputs(members, prefix):
    assert members[prefix+'source-commit.txt'] == git('cat-file','commit',HEAD)
    source = HEAD+' '+git('rev-parse',HEAD+'^{tree}').decode().strip()
    assert members[prefix+'source.txt'].decode().strip() == source
    assert members[prefix+'source-after.txt'].decode().strip() == source
    inputs = []
    for line in members[prefix+'input-sha256.txt'].decode().splitlines():
        checksum, path = line.split(None,1); path=path.strip()
        assert sha(git('show',HEAD+':'+path)) == checksum, path
        inputs.append({'path':path,'sha256':checksum,'gitBlob':git('rev-parse',HEAD+':'+path).decode().strip()})
    assert len(inputs) == 23
    return inputs

run=gh('run','view',str(RUN),'--repo','xurunxin/WorkMesh','--json','databaseId,number,headSha,status,conclusion,jobs,url,event')
assert run['headSha']==HEAD and run['status']=='completed' and run['conclusion']=='success'
assert len(run['jobs'])==17 and all(j['conclusion']=='success' and j['status']=='completed' for j in run['jobs'])
artifacts=gh('api',f'repos/xurunxin/WorkMesh/actions/runs/{RUN}/artifacts')['artifacts']
meta={a['id']:{k:a[k] for k in ['id','name','digest','size_in_bytes','expired','created_at']} for a in artifacts}
def raw_members(path, artifact, predicate):
    assert sha(path.read_bytes())==meta[artifact]['digest'].split(':')[1]
    assert path.stat().st_size==meta[artifact]['size_in_bytes']
    with zipfile.ZipFile(path) as z:
        assert z.testzip() is None
        return {n:z.read(n) for n in z.namelist() if predicate(n)}

producer_members=raw_members(BASE/'ci570/producer-raw.zip',12152047803,lambda n:n.startswith('server-build/') and not n.endswith('/source-install.log'))
inputs=verify_inputs(producer_members,'server-build/')
manifest_bytes=producer_members['server-build/manifest.json']
manifest=json.loads(manifest_bytes);digest=sha(manifest_bytes)
assert manifest['source']['commit']==HEAD and manifest['source']['tree']==git('rev-parse',HEAD+'^{tree}').decode().strip()
assert producer_members['server-build/manifest-sha256.txt'].decode().strip().split()[0]==digest
assert '# pass 18' in producer_members['server-build/unit.log'].decode() and '# fail 0' in producer_members['server-build/unit.log'].decode()
bundle('ci570-amd64-producer',producer_members,{
    'sourceHead':HEAD,'sourceTree':manifest['source']['tree'],'runId':RUN,'jobId':117799150808,
    'artifact':meta[12152047803],'rawZipSha256':meta[12152047803]['digest'].split(':')[1],
    'candidateArtifact':meta[12152451241],'manifestSha256':digest,'inputPathsMatchGit':inputs,
    'sourceCommitMatchesGit':True,'tools':manifest['tools'],
    'scope':'生产者原始安全成员；省略依赖安装日志，不下载巨大候选副本。三画像原件另列，不关闭历史139。'})
assertions=['withdrawnCandidateCommitRejected','restartedInstallerRejectsWithdrawnCandidate','explicitReupgradeRevalidates']
proofs=[]
for profile, artifact, job in [('personal',12154815070,117801087468),('team',12154590857,117801087401),('enterprise',12152749057,117801087484)]:
    members=raw_members(BASE/f'ci570-{profile}-raw.zip',artifact,lambda n:n.startswith('server-install/'))
    verified=verify_inputs(members,'server-install/')
    r=json.loads(members['server-install/result.json'])
    index=json.loads((BASE/'guest-evidence'/f'ci570-amd64-{profile}-full-guest-pass.json').read_text(encoding='utf8'))
    assert r['status']=='passed' and r['sourceHead']==HEAD and not r['nativeDiagnostic']
    assert r['sourceTree']==manifest['source']['tree'] and members['server-install/manifest.json']==manifest_bytes
    assert r['manifestSha256']==digest and index['producer']['artifactId']=='12152451241'
    assert r['guestVcpus']==4 and r['guestRamMiB']==4096 and r['totalSeconds']<9000 and r['accelerator']=='tcg'
    assert r['qemuVersion']=='QEMU emulator version 8.2.2 (Debian 1:8.2.2+ds-0ubuntu1.18)'
    assert r['imageSha256']=='6a81c37564db9b1ee84e141922625e1d7c5b389b99bb3c572e0243607d5bb4d2'
    before,after=r['receipts'];checks=before['profiles'][0]['checks']
    assert set(assertions)<=set(checks)
    assert set(['upgradeKeepsOriginalVolumes','compatibleProgramRollback','completeEncryptedBackup','partialMigrationStopsIncompatibleRollback','restoreIntoEmptyTargetKeepsOriginal','failedHealthStopsIncompatibleRuntimeAndKeepsVolumes'])<=set(checks)
    assert len(members)==11 and r['qemuExitCode']==0
    proof={'profile':profile,'jobId':job,'status':'passed','totalSeconds':r['totalSeconds'],'rebootSeconds':r['rebootSeconds'],
       'rawArtifact':meta[artifact],'rawZipSha256':meta[artifact]['digest'].split(':')[1],
       'manifestSha256':digest,'candidateArtifactId':12152451241,'newAssertions':assertions,
       'bootBefore':before['bootId'],'bootAfter':after['bootId'],'businessAfterReboot':after['checks'][0]['checks']}
    index.update(artifact=meta[artifact],inputPathsMatchGit=verified,sourceCommitMatchesGit=True,qemuVersion=r['qemuVersion'],imageSha256=r['imageSha256'],
       qemuCommand=r['qemuCommand'],accelerator=r['accelerator'],archiveSha256=r['archiveSha256'],
       newAssertions=assertions,
       evidenceBoundary='新增断言来自准确Git源码guest.py执行后的安全receipt；两次commit各为全新安装器进程，不是整机重启拒绝断言。完整系统重启另有两boot与四项恢复证明。未导出私有journal、配置、数据库或密钥。')
    bundle(f'ci570-amd64-{profile}-full-guest-pass',members,index)
    proofs.append(proof)

required_members=raw_members(BASE/'ci570/required-raw.zip',12154482391,lambda n:n=='required-ci.log')
assert all(line.endswith(': success') for line in required_members['required-ci.log'].decode().splitlines())
source_members=raw_members(BASE/'ci570/source-gates-raw.zip',12152441975,lambda n:n in ['lint.log','typecheck.log','test.log'])
assert len(source_members)==3
bundle('ci570-required-source-gates',dict(required_members,**source_members),{
  'sourceHead':HEAD,'runId':RUN,'requiredJobId':117818842379,'sourceGatesJobId':117799150852,
  'rawArtifacts':[meta[12154482391],meta[12152441975]],
  'scope':'终态聚合与源码门禁安全日志；job结论来自GitHub。日志无独立checkout SHA，不把PR合成checkout冒作候选原始commit；三guest与生产者另核准确源码。'})
source_paths=['scripts/server-distribution/install.mjs','scripts/server-distribution/journal.mjs','scripts/server-distribution/guest.py']
snapshot={
 'observedAt':datetime.now(timezone.utc).isoformat(),'source':'执行者本轮GitHub CLI/API读取与原件字节核验，非正式独审结论',
 'runId':RUN,'runNumber':570,'sourceHead':HEAD,'sourceTree':manifest['source']['tree'],
 'status':'completed','conclusion':'success','url':run['url'],
 'jobs':[{k:j[k] for k in ['databaseId','name','status','conclusion','startedAt','completedAt']} for j in run['jobs']],
 'manifestSha256':digest,'candidateArtifact':meta[12152451241],'guestProofs':proofs,
 'assertionSource':{p:{'gitBlob':git('rev-parse',HEAD+':'+p).decode().strip(),'sha256':sha(git('show',HEAD+':'+p))} for p in source_paths},
 'p1Status':{'restoredCandidate':'实现、控制流与本候选三画像真实断言已验证；正式P1复审未完成',
              'historic139':'API139/MCP139仍未闭；问题q-E6FuFFokBxxs6UpR6K9vC未答复，未批准或执行新诊断VM'},
 'thisTurn':'仅取回归档和更新资料；无产品改动，无rerun/cancel，无新矩阵或诊断VM',
 'meaning':'只绑定c7cf68a受测候选；后续资料skip-ci head无自身成功Required，不能合入或发布',
 'commands':['gh run view 39169353227 --repo xurunxin/WorkMesh --json databaseId,number,headSha,status,conclusion,jobs,url,event',
             'gh api repos/xurunxin/WorkMesh/actions/runs/39169353227/artifacts',
             'gh api repos/xurunxin/WorkMesh/actions/artifacts/<immutable-id>/zip',
             'git cat-file commit c7cf68aaf279f771a2022d37d69b5651cdb66ace',
             'git show c7cf68aaf279f771a2022d37d69b5651cdb66ace:<input-path>']}
write_json(OUT/'ci570-observed-status.json',snapshot)
print(json.dumps({'manifestSha256':digest,'sourceTree':manifest['source']['tree'],'jobs':len(run['jobs']),'guests':[{k:p[k] for k in ['profile','totalSeconds','rebootSeconds','newAssertions']} for p in proofs]}))
