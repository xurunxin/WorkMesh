from pathlib import Path
from datetime import datetime,timezone
import hashlib,json,re,subprocess,zipfile
r=Path('.tmp/ta01-resumption/api-auth-pg-arm-1800');out=Path('docs/reviews/ta01-product/resumption-api-auth-pg-arm-1800-once')
assert not out.with_suffix('.json').exists() and not out.with_suffix('.zip').exists()
sha=lambda b:hashlib.sha256(b).hexdigest();members={}
for p in sorted(r.iterdir()):
 if not p.is_file() or p.name.startswith('live-') or p.name in {'pr-body.md'}:continue
 assert p.stat().st_size<2*1024*1024;members['measurement/'+p.name]=p.read_bytes()
tool=Path('docs/reviews/ta01-product/tools/api-auth-pg-path-probe.mjs').read_bytes();inputs=json.loads((r/'used-inputs.json').read_bytes())
assert sha(tool)==inputs['measurement.mjs']['sha256'];members['tools/api-auth-pg-path-probe.mjs']=tool
prior=json.loads(Path('docs/reviews/ta01-product/resumption-api-auth-pg-path-comparison.json').read_bytes())
sources={}
for name in ['packages/db/src/events.ts','packages/db/src/human-attention-sources.ts','docs/adr/0076-china-ecosystem-ingress-channel-delivery-contract-and-model-presets.md']:
 data=subprocess.check_output(['git','show','541f6ba64841915801a1ccb123f9adb7f61ebe17:'+name])
 assert data==subprocess.check_output(['git','show','HEAD:'+name]);members['product-source/'+name]=data
 sources[name]={'sha256':sha(data),'blob':subprocess.check_output(['git','rev-parse','HEAD:'+name]).decode().strip()}
summary={'说明':'用户21:48单次1800秒ARM诊断例外：本组件样本完成单对真实配对身份GET，不代个人Lite、CI完整矩阵或旧139/超时根因闭合。',
 'startingDeliveryHead':'9bf8d3a2dd12d5a8eb06001413d42b74d5131d4a','productSourceHead':'541f6ba64841915801a1ccb123f9adb7f61ebe17',
 'productSourceFiles':prior['productSourceFiles'],'additionalSourceFiles':sources,'measurementSha256':sha(tool),
 'inputs':inputs,'result':json.loads((r/'result.json').read_bytes()),'analysis':json.loads((r/'analysis.json').read_bytes()),
 'publicRoleInputOrigins':json.loads((r/'role-source.json').read_bytes()),
 'resources':json.loads((r/'resources.json').read_bytes()),'ci567Snapshot':json.loads((r/'ci567-snapshot.json').read_bytes()),
 'priorIncompleteEvidence':['resumption-api-auth-pg-path-comparison.json','resumption-api-auth-pg-arm-preexpanded.json'],
 'officialInterpretationReferences':['https://nodejs.org/download/release/v22.19.0/docs/api/process.html#processcpuusagepreviousvalue','https://www.postgresql.org/docs/16/monitoring-stats.html'],
 'observedAt':datetime.now(timezone.utc).isoformat(),'fullProductAcceptance':False,'productCodeChanged':False,'workflowChanged':False}
members['summary.json']=(json.dumps(summary,ensure_ascii=False,indent=2)+'\n').encode()
for name,data in members.items():assert not re.search(rb'wm[ips]_[A-Za-z0-9_-]{43}',data),name
with zipfile.ZipFile(out.with_suffix('.zip'),'x',compression=zipfile.ZIP_DEFLATED) as z:
 for name,data in members.items():z.writestr(name,data)
summary['selectedZipSha256']=sha(out.with_suffix('.zip').read_bytes())
summary['members']={name:{'bytes':len(data),'sha256':sha(data)} for name,data in members.items()}
out.with_suffix('.json').write_text(json.dumps(summary,ensure_ascii=False,indent=2)+'\n',encoding='utf8',newline='\n')
print(json.dumps({'members':len(members),'zipBytes':out.with_suffix('.zip').stat().st_size,'zipSha256':summary['selectedZipSha256']}))
