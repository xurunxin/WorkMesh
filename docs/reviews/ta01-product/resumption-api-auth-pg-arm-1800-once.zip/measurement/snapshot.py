from pathlib import Path
from datetime import datetime,timezone
import json,subprocess
r=Path('.tmp/ta01-resumption/api-auth-pg-arm-1800'); l=json.loads((r/'resources.json').read_bytes()); i=l['containers'][0]['id']
def call(args): return subprocess.run(['docker',*args],capture_output=True,timeout=30)
x=json.loads(call(['inspect',i]).stdout)[0]; c=x['HostConfig']
assert x['Image']==l['imageId'] and x['Config']['Labels']['io.workmesh.ta01.probe.owner']==l['owner']
assert not x['Mounts'] and not c['Devices'] and not c['Binds'] and not c['PortBindings'] and not c['Privileged']
assert c['NanoCpus']==4000000000 and c['Memory']==c['MemorySwap']==4294967296
proof={'at':datetime.now(timezone.utc).isoformat(),'containerId':i,'owner':l['owner'],'cpus':4,'ramMiB':4096,'mounts':0,'devices':0,'ports':0,'privileged':False,'running':x['State']['Running']}
(r/'isolation.json').write_text(json.dumps(proof,indent=2)+'\n',encoding='utf8')
for name in ['progress.jsonl','serial.log','qemu-stderr.log']:
    v=call(['exec',i,'cat','/opt/arm-once-1800/guest/'+name])
    if v.returncode==0: (r/('live-'+name)).write_bytes(v.stdout)
events=[]
p=r/'live-progress.jsonl'
if p.exists(): events=[json.loads(line) for line in p.read_text(encoding='utf8').splitlines()]
print(json.dumps({'at':proof['at'],'safeReceipts':len(events),'last':[v for v in events[-2:]]},ensure_ascii=True))
