from pathlib import Path
from datetime import datetime,timezone
import hashlib,json,subprocess
r=Path('.tmp/ta01-resumption/api-auth-pg-arm-1800');a=json.loads((r/'analysis.json').read_bytes())
assert a['status']=='component-measured' and a['actualTargetGetCount']==2 and not a['vmDeadlineReached']
assert not a['hostTermObserved'] and a['qemuExitCode']==0 and a['nodeExitCode']==0 and a['childExitCodes']=={'node':0,'redis':0,'postgres':0}
assert len(a['finalRuns'])==2 and all(v['status']==200 and v['wallMs']<=30000 for v in a['finalRuns'])
states=[]
for trace in a['observedTraces']:
 rows=[v for sample in trace['samples'] for v in sample['rows']]
 assert not any(v['wait_event_type']=='Lock' for v in rows)
 states.append({'label':trace['label'],'samples':len(trace['samples']),
  'waitStates':sorted(set((v['state'],str(v['wait_event_type']),str(v['wait_event'])) for v in rows)),
  'poolMaxMs':max(v['wallMs'] for v in trace['acquires']),
  'maxClientSql':max(trace['queries'],key=lambda v:v['wallMs']),
  'observedLock':False,'interpretation':'本次采样未见Lock，不排除间隙等待；active/空wait不当CPU证明'})
a['sampleStates']=states
a['hypotheses']=[
 {'id':'H1','claim':'本样本主要耗于秒级连接取得排队','verdict':'本样本不支持','evidence':'最大24.95/4.97ms，对应两次读取12.18/3.03秒；不推旧CI连接耗尽与否'},
 {'id':'H2','claim':'本样本主要耗于行锁等待','verdict':'未观测到证据，不能排除间隙等待','evidence':'27/11次等待采样未见Lock；原生阳性行锁仅校准方法'},
 {'id':'H3','claim':'实时身份初始化及handler尾段都有可见成本','verdict':'支持本样本存在这些成本','evidence':'首次45SQL/身份COMMIT7.45s/handler尾4.03s；工作项17SQL/COMMIT0.96s/尾41.39ms。尾段含验证/生成/序列化/公共onSend，未独拆纯函数'},
 {'id':'H4','claim':'这些数字证明原CI的CPU、PG或TCG根因','verdict':'不成立','evidence':'角色/ISO/观察/竞争负载不同；process CPU含多核，PG执行含等待，原CI无同一关联内部段'},
 {'id':'H5','claim':'监测连接在本轮一直未完成','verdict':'已排除于本次供应过程','evidence':'monitor-connected已保存，分界1.41秒；空库迁移随后完成，非业务GET时间'}]
a['nextAction']='本轮例外已用，不追加第五轮。先核首个资格身份事务中appendEvent通知快照大模板的调用/计划及资格handler纯计算边界；保持ADR0076事务内来源快照和实时权限。不凭样本省略SQL、缓存资格或触发新整轮。原CI仍缺同一请求内部关联/调度证据，暂无准确产品修复。'
a['notificationSourceQuery']={'templateSha256':'410bd0b8398dc57e5e1db8e8f58892fceb0782fba85bd6aad8371797c15d66b3',
 'maxClientWallMs':2245.872800000012,'source':'packages/db/src/events.ts:appendEvent',
 'contract':'docs/adr/0076-china-ecosystem-ingress-channel-delivery-contract-and-model-presets.md:C1',
 'meaning':'业务事务内捕获notification_sources来源revision；不能为提速跳过。PG归一化模板SHA不同，未把整库最大计划值强配给单次客户端查询。'}
(r/'analysis.json').write_text(json.dumps(a,ensure_ascii=False,indent=2)+'\n',encoding='utf8')
l=json.loads((r/'resources.json').read_bytes());l['scopeCorrectionHistory']=[l['scopeCorrection']]
l['scopeCorrection']='本次经原安装/配对形成真实隔离work:read身份，原实时资格和逐请求授权保留；8个供应请求及2个目标GET。Node/PG/Redis/QEMU均0，无宿主TERM；密钥/私有日志/磁盘不归档。'
(r/'resources.json').write_text(json.dumps(l,ensure_ascii=False,indent=2)+'\n',encoding='utf8')
v=subprocess.run(['gh','run','view','38893305755','--repo','xurunxin/WorkMesh','--json','headSha,status,conclusion,jobs'],capture_output=True,timeout=45);assert v.returncode==0
w=json.loads(v.stdout);assert w['status']=='completed' and w['conclusion']=='failure'
snapshot={'at':datetime.now(timezone.utc).isoformat(),'runId':38893305755,'headSha':w['headSha'],'status':w['status'],'conclusion':w['conclusion'],
 'jobs':[{k:j[k] for k in ['databaseId','name','status','conclusion']} for j in w['jobs']]}
(r/'ci567-snapshot.json').write_text(json.dumps(snapshot,indent=2)+'\n',encoding='utf8')
print(json.dumps({'status':a['status'],'targetGets':2,'setupRequests':8,'nodeEvents':a['capturedNodeEvents'],
 'progressEvents':a['capturedHttpProgress'],'ci567':'failure','resourcesClosed':l['containers'][0]['removedAndAbsent']}))
