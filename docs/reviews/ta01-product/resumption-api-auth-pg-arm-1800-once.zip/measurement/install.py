from pathlib import Path
import json,subprocess
base=Path('.tmp/ta01-resumption/api-auth-pg-arm-1800');ledger=json.loads((base/'resources.json').read_bytes());identifier=ledger['containers'][0]['id']
assert ledger['exactQemuPackageAvailable']
packages=['qemu-system-arm=1:8.2.2+ds-0ubuntu1.18','qemu-utils=1:8.2.2+ds-0ubuntu1.18','qemu-efi-aarch64=2024.02-2ubuntu0.10','ipxe-qemu=1.21.1+git-20220113.fbbdc3926-0ubuntu2','ipxe-qemu-256k-compat-efi-roms=1.0.0+git-20150424.a25a16d-0ubuntu5','genisoimage','python3','ca-certificates']
with (base/'apt-install.stdout').open('xb') as out,(base/'apt-install.stderr').open('xb') as err:
 value=subprocess.run(['docker','exec',identifier,'apt-get','install','-y','--no-install-recommends',*packages],stdout=out,stderr=err,timeout=300)
ledger['aptInstallExitCode']=value.returncode;ledger['installedPackageRequests']=packages
(base/'resources.json').write_text(json.dumps(ledger,ensure_ascii=False,indent=2)+'\n',encoding='utf8',newline='\n')
assert value.returncode==0, 'exact tool installation failed; no fallback version'
for name,args in [('qemu-version',['qemu-system-aarch64','--version']),('firmware-sha256',['sha256sum','/usr/share/AAVMF/AAVMF_CODE.fd']),('rom-sha256',['sha256sum','/usr/lib/ipxe/qemu/efi-virtio.rom'])]:
 value=subprocess.run(['docker','exec',identifier,*args],capture_output=True,timeout=30)
 (base/(name+'.stdout')).write_bytes(value.stdout);(base/(name+'.stderr')).write_bytes(value.stderr)
 assert value.returncode==0,name+' unavailable; stop before VM'
assert (base/'qemu-version.stdout').read_text().splitlines()[0]=='QEMU emulator version 8.2.2 (Debian 1:8.2.2+ds-0ubuntu1.18)'
assert (base/'firmware-sha256.stdout').read_text().split()[0]=='545e2eda871a00dba51c0df48a34829fe3b0de6ec10ea760c75f1fc1c6a29dc5'
assert (base/'rom-sha256.stdout').read_text().split()[0]=='606518e1cfa5afd4ceac95ea309a7e385d60fb17ae0b684cee948d73ab255dfc'
print('exact ARM QEMU, firmware and ROM checked before guest')
