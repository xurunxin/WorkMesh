from pathlib import Path
import json,re
r=Path('.tmp/ta01-resumption/api-auth-pg-arm-1800')
result=json.loads((r/'result.json').read_bytes());progress=[json.loads(v) for v in (r/'progress.jsonl').read_text(encoding='utf8').splitlines()]
serial=(r/'serial.log').read_text(encoding='utf8',errors='replace');decoder=json.JSONDecoder();nodes=[]
for match in re.finditer(r'\{"tag": "ta01-api-auth-node-progress"',serial):
 value,_=decoder.raw_decode(serial,match.start());nodes.append({k:v for k,v in value.items() if k!='tag'})
ordinals=[v['eventOrdinal'] for v in nodes];continuous=ordinals==list(range(len(nodes)))
for event in progress:
 if 'node' in event:assert event['node'] in nodes
starts=[v for v in nodes if v['name']=='request-started'];returned=[v for v in nodes if v['name']=='request-returned']
receipts=result['receipts'];assert len(receipts)<=1
final=receipts[0] if receipts else {};probe=final.get('probe');complete=bool(probe) and continuous
observed=[v['trace'] for v in nodes if v['name']=='request-observed']
recorded=[v['trace'] for v in nodes if v['name']=='request-recorded'];runs=probe.get('runs',[]) if probe else []
summary={'authorization':{'approvedAtMinute':'2026-10-16 21:48 Asia/Shanghai','source':'用户本次反馈：单次延长诊断窗（推荐）',
 'singleUseException':True,'previousVmLimitSeconds':1200,'vmLimitSeconds':1800,'additionalVmSeconds':600,
 'nodeLimitSeconds':600,'getLimitSeconds':30,'productLimitsChanged':False,
 'precision':'runner approvedAt将分钟编码为:00；不冒秒级批准事件'},
 'status':result['status'],'elapsedSeconds':result['elapsedSeconds'],'vmDeadlineReached':result.get('deadlineReached',False),
 'qemuExitCode':result.get('qemuExitCode'),'hostTermObserved':'terminating on signal 15' in (r/'qemu-stderr.log').read_text(encoding='utf8'),
 'guestStages':[v['guest'] for v in progress if 'guest' in v],
 'capturedHttpProgress':sum(v['phase']=='component-progress' for v in progress),'capturedNodeEvents':len(nodes),
 'continuousNodeEventOrdinals':continuous,'finalReceipts':len(receipts),'nodeExitCode':final.get('nodeExitCode'),
 'nodeDeadlineReached':final.get('nodeDeadlineReached',False),'childExitCodes':final.get('childExitCodes'),
 'actualTargetGetCount':len(starts) if complete else None,
 'observedTargetGetStarts':len(starts),'observedTargetGetReturns':len(returned),
 'completeNodeReport':bool(probe),'requestStarts':starts,'requestReturns':returned,
 'observedTraces':observed,'recordedTraces':recorded,'finalRuns':runs,
 'lastNodeEvent':nodes[-1] if nodes else None,'probeErrorType':probe.get('errorType') if probe else None,
 'probeErrorCode':probe.get('errorCode') if probe else None,'setupRequestCount':8 if starts else None,
 'setupRequestCountBasis':'源码在所有8次供应请求状态断言后才进入目标读取；3个供应GET、5个供应POST，与目标一对分开',
 'actualCountBasis':'仅完整Node最终报告及连续事件时按已保存request-started计数；缺件不补零，也不倒填前三次',
 'correlations':[],'fullProductAcceptance':False,
 'scopeLimits':['独立API而非个人Lite；Fastify inject并非网络MCP/TLS，实时身份/权限路径与PG/Redis不替换',
 '只读ISO9660供代码，原guest私有盘供数据；布局/观察开销不等生产，资格未缓存',
 'PG20连接/64MB/额外观测，不等个人Lite；CPU含Node多线程，SQL客户端wall含编解码/调度，PG执行含等待',
 '有界负样本不排除原故障；API139/MCP139及原ARM首败未因此闭合；不追加第五轮']}
for trace in observed:
 assert trace['correlationSha256'] in [v['correlationSha256'] for v in starts]
 matched=[]; counts={}
 for q in trace['queries']:counts[q['textSha256']]=counts.get(q['textSha256'],0)+1
 full=next((v for v in recorded if v['correlationSha256']==trace['correlationSha256']),{})
 for q in trace['queries']:
  for pg in full.get('serverStatements',[]):
   if q['textSha256']==pg['textSha256'] and counts[q['textSha256']]==1 and int(pg['calls'])==1:
    matched.append({'phase':q['phase'],'templateSha256':q['textSha256'],'backendPid':q['backendPid'],
     'clientWallMs':q.get('wallMs'),'pgTotalExecMs':pg['total_exec_time'],'pgTotalPlanMs':pg['total_plan_time']})
 summary['correlations'].append({'label':trace['label'],'correlationSha256':trace['correlationSha256'],
  'wallMs':trace['wallMs'],'nodeCpu':trace['nodeCpu'],'identityCommittedMs':trace.get('identityCommittedMs'),
  'authorizedMs':trace.get('authorizedMs'),'handlerTail':trace.get('handlerTail'),
  'sqlCount':len(trace['queries']),'acquires':trace['acquires'],'waitSamples':trace['samples'],
  'exactSingleCallPgMatches':matched,
  'interpretation':'匹配仅说明本隔离库单模板单次调用统计，PG执行不是CPU，不推旧CI相同等待或调度。'})
(r/'analysis.json').write_text(json.dumps(summary,ensure_ascii=False,indent=2)+'\n',encoding='utf8')
(r/'node-progress.json').write_text(json.dumps(nodes,ensure_ascii=False,indent=2)+'\n',encoding='utf8')
print(json.dumps({k:summary[k] for k in ['status','elapsedSeconds','capturedHttpProgress','capturedNodeEvents','actualTargetGetCount','observedTargetGetStarts','observedTargetGetReturns','nodeExitCode','nodeDeadlineReached','probeErrorType']}))
