"""固定隔离 guest 内真实 API/PG 路径测量，不是完整支持验收。"""
import hashlib,json,os,resource,shutil,subprocess,time,urllib.request
from pathlib import Path

def sha(p):
    with p.open('rb') as f: return hashlib.file_digest(f,'sha256').hexdigest()

def main():
    base=Path('/opt/ta01-component-micro'); expected=json.loads((base/'expected.json').read_bytes())
    assert Path('/sys/class/dmi/id/sys_vendor').read_text().strip()=='QEMU'
    assert os.uname().nodename=='ta01-micro-'+expected['nonce'][:8] and os.uname().machine=='aarch64' and os.geteuid()==0
    began=time.monotonic(); processes=[]; handles=[]
    receipt={'phase':'component-measurement','nonce':expected['nonce'],'kernel':os.uname().release,
        'bootId':Path('/proc/sys/kernel/random/boot_id').read_text().strip(),'cpuCount':os.cpu_count(),
        'accelerator':'tcg','fullProductAcceptance':False,'stages':[]}
    def post(value):
        payload=json.dumps(value).encode(); assert len(payload)<1024*1024
        req=urllib.request.Request('http://10.0.2.2:18080/receipt',payload,{'content-type':'application/json'})
        with urllib.request.urlopen(req,timeout=10) as response: assert response.status==200
    def stage(name):
        value={'name':name,'elapsedSeconds':time.monotonic()-began}
        receipt['stages'].append(value)
        print(json.dumps({'tag':'ta01-api-auth-probe-stage',**value}),flush=True)
        post({'phase':'component-progress','nonce':expected['nonce'],'guest':value})
    def run(args,timeout=120):
        v=subprocess.run(args,capture_output=True,timeout=timeout)
        if v.returncode:
            receipt['failedCommand']={'name':args[-1].rsplit('/',1)[-1] if len(args)==1 else args[0],
                'exitCode':v.returncode,'stderrSha256':hashlib.sha256(v.stderr).hexdigest(),'stderrBytes':len(v.stderr)}
            raise RuntimeError('isolated subprocess failed')
        return v
    try:
        resource.setrlimit(resource.RLIMIT_CORE,(0,0)); Path('/proc/sys/kernel/core_pattern').write_text('|/bin/false\n')
        stage('guest-identity-verified')
        seed=Path('/dev/disk/by-label/cidata'); assert seed.is_block_device()
        seed_root=base/'seed-inputs'; seed_root.mkdir(exist_ok=False)
        run(['mount','-o','ro,nodev,nosuid',str(seed),str(seed_root)])
        assert sha(seed_root/'measurement.mjs')==expected['inputs']['measurement.mjs']
        run(['ip','route','del','default']); assert b'default' not in subprocess.check_output(['ip','route'])
        stage('preexpanded-inputs-mounted-and-egress-removed')
        roots={}
        for role in ['api','postgres','redis']:
            root=seed_root/'roles'/role; roots[role]=root
            for name,meta in expected['keyFiles'][role].items():
                assert sha(root/name)==meta['sha256']
            private=base/(role+'-private'); private.mkdir(exist_ok=False)
            for name,mode in [('tmp',0o1777),('dev/shm',0o1777)]+([('data',0o755)] if role=='redis' else []):
                target=private/name; target.mkdir(parents=True,exist_ok=False); target.chmod(mode)
                run(['mount','--bind',str(target),str(root/name)])
            run(['mount','-t','proc','-o','nosuid,nodev,noexec','proc',str(root/'proc')])
            run(['mount','--bind','/dev/null',str(root/'dev/null')])
        assert sha(roots['api']/'usr/local/bin/node')==expected['nodeSha256']
        stage('exact-role-readonly-rootfs-ready')
        pg=roots['postgres']; data=pg/'tmp/probe-data'; data.mkdir(); os.chown(data,70,70); data.chmod(0o700)
        run(['chroot','--userspec=70:70',str(pg),'/usr/local/bin/initdb','-D','/tmp/probe-data','-A','trust','-U','postgres','--no-locale'])
        log=(base/'postgres.private.log').open('wb'); handles.append(log)
        process=subprocess.Popen(['chroot','--userspec=70:70',str(pg),'/usr/local/bin/postgres','-D','/tmp/probe-data',
            '-c','listen_addresses=127.0.0.1','-c','port=5432','-c','unix_socket_directories=/tmp',
            '-c','max_connections=20','-c','shared_buffers=64MB','-c','shared_preload_libraries=pg_stat_statements',
            '-c','pg_stat_statements.track=all','-c','pg_stat_statements.track_planning=on','-c','track_io_timing=on',
            '-c','track_activities=on','-c','log_statement=none','-c','log_min_error_statement=panic',
            '-c','log_parameter_max_length=0','-c','log_parameter_max_length_on_error=0'],stdout=log,stderr=log)
        processes.append(('postgres',process))
        # 服务就绪探测仅用于独有数据库供应，不重试任何业务请求。
        for _ in range(60):
            ready=subprocess.run(['chroot',str(pg),'/usr/local/bin/pg_isready','-h','127.0.0.1','-U','postgres'],capture_output=True,timeout=5)
            if ready.returncode==0: break
            assert process.poll() is None
            time.sleep(1)
        assert ready.returncode==0
        run(['chroot','--userspec=70:70',str(pg),'/usr/local/bin/createdb','-h','127.0.0.1','-U','postgres','ta01_auth_path_test'])
        redis=roots['redis']; redisdata=redis/'data'; redisdata.mkdir(exist_ok=True); os.chown(redisdata,999,999)
        log=(base/'redis.private.log').open('wb'); handles.append(log)
        process=subprocess.Popen(['chroot','--userspec=999:999',str(redis),'/usr/local/bin/redis-server','--bind','127.0.0.1',
            '--port','6379','--dir','/data','--appendonly','yes'],stdout=log,stderr=log)
        processes.append(('redis',process))
        for _ in range(30):
            ready=subprocess.run(['chroot',str(redis),'/usr/local/bin/redis-cli','ping'],capture_output=True,timeout=5)
            if ready.returncode==0 and ready.stdout.strip()==b'PONG': break
            assert process.poll() is None
            time.sleep(1)
        assert ready.returncode==0 and ready.stdout.strip()==b'PONG'
        stage('isolated-pg-and-redis-ready')
        api=roots['api']; (api/'tmp/measurement.mjs').write_bytes((seed_root/'measurement.mjs').read_bytes())
        nodeBegan=time.monotonic()
        import selectors
        error_path=base/'node.private.stderr'
        safe_output=[]; output_bytes=0; pending=b''
        with error_path.open('wb') as err:
            node=subprocess.Popen(['chroot','--userspec=10001:10001',str(api),'/usr/local/bin/node',
                '/tmp/measurement.mjs','/app','--single-pair'],stdout=subprocess.PIPE,stderr=err,bufsize=0)
            processes.append(('node',node))
            selector=selectors.DefaultSelector(); selector.register(node.stdout,selectors.EVENT_READ)
            while True:
                if time.monotonic()-nodeBegan>=600:
                    receipt['nodeDeadlineReached']=True
                    node.terminate(); break
                if not selector.select(timeout=0.5): continue
                block=os.read(node.stdout.fileno(),65536)
                if not block:
                    assert not pending, 'partial JSON line at EOF'
                    break
                output_bytes+=len(block); assert output_bytes<2*1024*1024
                pending+=block
                while b'\n' in pending:
                    line,pending=pending.split(b'\n',1)
                    value=json.loads(line); safe_output.append(value)
                    if value.get('kind')=='progress':
                        print(json.dumps({'tag':'ta01-api-auth-node-progress',**value}),flush=True)
                        if value['name'] in {'module-started','product-import-started','product-import-finished',
                            'migrations-started','monitor-connected','migrations-finished','installation-finished','work-item-fixture-created',
                            'real-work-read-pairing-finished','request-started','identity-committed','authorized','on-send',
                            'request-observed','request-returned','request-recorded','request-deadline'}:
                            post({'phase':'component-progress','nonce':expected['nonce'],'node':value})
                    else:
                        receipt['probe']=value
            selector.close()
            try: code=node.wait(timeout=15)
            except subprocess.TimeoutExpired: node.kill(); code=node.wait(timeout=5)
        receipt.update(nodeExitCode=code,nodeSeconds=time.monotonic()-nodeBegan,
            streamedRecords=len(safe_output),stdoutBytes=output_bytes,
            stderrBytes=error_path.stat().st_size,stderrSha256=sha(error_path))
        if receipt.get('probe'):
            assert receipt['probe']['executableSha256']==expected['nodeSha256']
        if code!=0: receipt['errorType']='ProbeProcessFailed'
        stage('node-finished')
    except Exception as error:
        receipt['errorType']=type(error).__name__
        receipt['errorStage']=receipt['stages'][-1]['name'] if receipt['stages'] else 'before-inputs-ready'
    finally:
        receipt['childExitCodes']={}
        for name,p in reversed(processes):
            if p.poll() is None: p.terminate()
            try: code=p.wait(timeout=15)
            except subprocess.TimeoutExpired: p.kill(); code=p.wait(timeout=5)
            receipt['childExitCodes'][name]=code
        for h in handles: h.close()
        receipt['totalSeconds']=time.monotonic()-began
        payload=json.dumps(receipt).encode(); assert len(payload)<1024*1024
        try:
            req=urllib.request.Request('http://10.0.2.2:18080/receipt',payload,{'content-type':'application/json'})
            with urllib.request.urlopen(req,timeout=10) as response: assert response.status==200
        finally:
            print(json.dumps({'tag':'ta01-api-auth-path-finished','nodeExitCode':receipt.get('nodeExitCode'),'errorType':receipt.get('errorType')}),flush=True)
            subprocess.run(['systemctl','--no-block','poweroff'],check=True)

if __name__=='__main__': main()
