from pathlib import Path
import hashlib,json,subprocess,sys,zipfile
profile,raw_digest=sys.argv[1:];assert profile in {'personal','team'}
r=Path('.tmp/ta01-resumption');stem=r/('guest-evidence/ci567-arm64-'+profile+'-first-failure')
x=json.loads(stem.with_suffix('.json').read_bytes());head=x['sourceHead'];sha=lambda b:hashlib.sha256(b).hexdigest()
assert head=='e2763da4dfdf25f7fc5c28c34a9619d4788f4541'
raw=r/('ci567-arm-'+profile+'-raw.zip');assert sha(raw.read_bytes())==raw_digest
with zipfile.ZipFile(raw) as z:
 assert z.read('server-install/source.txt')==z.read('server-install/source-after.txt')
 assert z.read('server-install/source.txt').decode().split()==[head,x['sourceTree']]
 inputs={}
 for line in z.read('server-install/input-sha256.txt').decode().splitlines():
  digest,path=line.split('  ',1);assert not path.startswith('/') and '..' not in path.split('/')
  assert sha(subprocess.check_output(['git','show',head+':'+path]))==digest;inputs[path]=digest
 assert len(inputs)==22
 result=json.loads(z.read('server-install/result.json'));manifest=json.loads(z.read('server-install/manifest.json'))
 assert result['arch']==manifest['arch']=='arm64' and result['profilesRequested']==[profile]
 assert result['sourceTree']==manifest['source']['tree']==x['sourceTree']
 assert result['guestVcpus']==4 and result['guestRamMiB']==4096 and result['accelerator']=='tcg'
 assert result['qemuVersion']=='QEMU emulator version 8.2.2 (Debian 1:8.2.2+ds-0ubuntu1.18)'
 assert result['imageSha256']=='1d6bffe64b848468ac97f821d369a4846d983de1800ccf6b5ec8853e85cefc55'
assert x['producer']['artifactId']=='12043116531'
assert x['status']=='failed' and x['errorType']=='TimeoutError' and x['receipts']==[]
last_action=[v for v in x['records'] if v['tag']=='ta01-install-action'][-1]
x.update(allSourceInputsMatchGit=True,allSourceInputCount=22,guestShapeMatchesJob=True,architecture='arm64',
 lastObservedAction=last_action,actualFailureBoundary='原9000秒总窗截止；无最终回执，不推该动作内部阶段或恢复完成。')
stem.with_suffix('.json').write_text(json.dumps(x,ensure_ascii=False,indent=2)+'\n',encoding='utf8',newline='\n')
target=Path('docs/reviews/ta01-product')/stem.name
for ext in ['.json','.zip']:
 assert not target.with_suffix(ext).exists();target.with_suffix(ext).write_bytes(stem.with_suffix(ext).read_bytes())
print(json.dumps({'profile':profile,'status':x['status'],'errorType':x['errorType'],'totalSeconds':x['totalSeconds'],
 'receipts':0,'lastAction':last_action,'sourceInputs':22,'scripts':6}))
