import json,os,selectors,subprocess,sys,time
child="import sys,time;sys.stdout.write('{\"n\":1}\\n{\"n\":2}\\n');sys.stdout.flush();time.sleep(.5);sys.stdout.write('{\"n\":');sys.stdout.flush();time.sleep(.1);sys.stdout.write('3}\\n');sys.stdout.flush()"
p=subprocess.Popen([sys.executable,'-c',child],stdout=subprocess.PIPE,bufsize=0)
s=selectors.DefaultSelector();s.register(p.stdout,selectors.EVENT_READ);pending=b'';rows=[];before_eof=[]
while True:
 assert s.select(timeout=2)
 data=os.read(p.stdout.fileno(),65536)
 if not data:break
 pending+=data
 while b'\n' in pending:
  line,pending=pending.split(b'\n',1);rows.append(json.loads(line));before_eof.append(p.poll() is None)
assert rows==[{'n':1},{'n':2},{'n':3}] and not pending and before_eof[:2]==[True,True]
assert p.wait(timeout=2)==0;s.close()
print(json.dumps({'rows':rows,'firstTwoSavedBeforeEof':True,'splitLineHandled':True,'childExitCode':0}))
