from pathlib import Path
from datetime import datetime,timezone
import json,subprocess
r=Path('.tmp/ta01-resumption/api-auth-pg-arm-1800'); l=json.loads((r/'resources.json').read_bytes()); i=l['containers'][0]['id']
def call(args):return subprocess.run(['docker',*args],capture_output=True,timeout=45)
def save():(r/'resources.json').write_text(json.dumps(l,ensure_ascii=False,indent=2)+'\n',encoding='utf8')
x=json.loads(call(['inspect',i]).stdout)[0]; c=x['HostConfig']
assert x['Image']==l['imageId'] and x['Config']['Labels']['io.workmesh.ta01.probe.owner']==l['owner']
assert not x['Mounts'] and not c['Devices'] and not c['Binds'] and not c['PortBindings'] and not c['Privileged']
assert c['NanoCpus']==4000000000 and c['Memory']==c['MemorySwap']==4294967296
code='''from pathlib import Path
import json
rows=[]
for p in Path('/proc').iterdir():
 if not p.name.isdigit() or not (p/'comm').exists():continue
 name=(p/'comm').read_text().strip()
 if name.startswith(('qemu-system','postgres','redis-server','node')):
  text=(p/'stat').read_text();state=text[text.rfind(')')+2:].split()[0]
  rows.append({'pid':int(p.name),'name':name,'state':state})
print(json.dumps({'matchingProcesses':rows,'active':sum(v['state']!='Z' for v in rows)}))
'''
v=call(['exec',i,'python3','-c',code]); assert v.returncode==0
proof=json.loads(v.stdout); assert proof['active']==0
(r/'before-stop-processes.json').write_bytes(v.stdout)
shared={}
for ref in ['ubuntu:24.04','node:22.19.0-alpine3.21','postgres:16.9-alpine','redis:7.4.5-alpine']:
 v=call(['image','inspect',ref])
 if v.returncode==0: shared[ref]=json.loads(v.stdout)[0]['Id']
l['beforeStopProcessProof']=proof
l['scopeCorrection']='无已有或生产凭据；独有测试身份是否生成及实际请求数未知，Node最终报告缺失；不保存私有日志/数据/磁盘。'
save(); v=call(['stop','--time','10',i]); l['stopExitCode']=v.returncode;save();assert v.returncode==0
x=json.loads(call(['inspect',i]).stdout)[0]; assert not x['State']['Running'] and not x['State']['OOMKilled']
l['containers'][0].update(exitCode=x['State']['ExitCode'],oom=False,activeRelevantProcessesBeforeStop=0)
save();assert call(['rm',i]).returncode==0
v=call(['inspect',i]);assert v.returncode and b'no such object' in v.stderr.lower()
l['containers'][0]['removedAndAbsent']=True
for ref,expected in shared.items():assert json.loads(call(['image','inspect',ref]).stdout)[0]['Id']==expected
l['sharedReferencesStillSame']=shared;l['closedAt']=datetime.now(timezone.utc).isoformat();save()
print(json.dumps({'removedAndAbsent':True,'controllerExitCode':l['containers'][0]['exitCode'],'sharedReferencesKept':len(shared)}))
