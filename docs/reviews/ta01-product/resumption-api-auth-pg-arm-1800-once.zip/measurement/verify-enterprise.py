from pathlib import Path
import hashlib,json,subprocess,zipfile
r=Path('.tmp/ta01-resumption');stem=r/'guest-evidence/ci567-arm64-enterprise-first-failure'
x=json.loads(stem.with_suffix('.json').read_bytes());head=x['sourceHead'];sha=lambda b:hashlib.sha256(b).hexdigest()
assert head=='e2763da4dfdf25f7fc5c28c34a9619d4788f4541'
assert sha((r/'ci567-arm-enterprise-raw.zip').read_bytes())=='4e530949fc667eb7ffcc15389bcfbd07d4b4a5087755f41a5538aed280d9d5f7'
with zipfile.ZipFile(r/'ci567-arm-enterprise-raw.zip') as z:
 assert z.read('server-install/source.txt')==z.read('server-install/source-after.txt')
 assert z.read('server-install/source.txt').decode().split()==[head,x['sourceTree']]
 inputs={}
 for line in z.read('server-install/input-sha256.txt').decode().splitlines():
  digest,path=line.split('  ',1);assert not path.startswith('/') and '..' not in path.split('/')
  assert sha(subprocess.check_output(['git','show',head+':'+path]))==digest;inputs[path]=digest
 assert len(inputs)==22
 result=json.loads(z.read('server-install/result.json'));manifest=json.loads(z.read('server-install/manifest.json'))
 assert result['arch']==manifest['arch']=='arm64' and result['profilesRequested']==['enterprise']
 assert result['sourceTree']==manifest['source']['tree']==x['sourceTree']
 assert result['guestVcpus']==4 and result['guestRamMiB']==4096 and result['accelerator']=='tcg'
 assert result['qemuVersion']=='QEMU emulator version 8.2.2 (Debian 1:8.2.2+ds-0ubuntu1.18)'
 assert result['imageSha256']=='1d6bffe64b848468ac97f821d369a4846d983de1800ccf6b5ec8853e85cefc55'
assert x['producer']['artifactId']=='12043116531'
value=subprocess.run(['gh','api','repos/xurunxin/WorkMesh/actions/artifacts/12043116531'],capture_output=True,timeout=30);assert value.returncode==0
a=json.loads(value.stdout)
x.update(allSourceInputsMatchGit=True,allSourceInputCount=22,guestShapeMatchesJob=True,architecture='arm64',
 candidateArtifactMetadata={k:a[k] for k in ['id','name','digest','size_in_bytes','expired']})
diag=x['receipts'][-1]['diagnostics'];pending=x['receipts'][0]
projection=diag.get('apiReadTimings')
summary={'firstFailedAction':next(v for v in x['records'] if v.get('state')=='failed'),
 'installerRead':diag['installer'],'journal':diag['journal'],'apiReadTimings':projection,
 'pendingToFinalHostSeconds':x['receipts'][-1]['hostElapsed']-pending['hostElapsed'],
 'codes':diag['codes'],'containerEvents':diag.get('containerEvents'),'databaseBudget':diag.get('databaseBudget'),
 'scope':'本候选企业升级后的正常commit（序号16）读取30秒失败；序号14/15是恢复输入拒绝夹具，非成功recover-old。晚200不补成功，投影非统一请求分解，不推旧139或数据库根因。'}
x['firstFailureSummary']=summary
stem.with_suffix('.json').write_text(json.dumps(x,ensure_ascii=False,indent=2)+'\n',encoding='utf8',newline='\n')
target=Path('docs/reviews/ta01-product')/stem.name
for ext in ['.json','.zip']:
 assert not target.with_suffix(ext).exists();target.with_suffix(ext).write_bytes(stem.with_suffix(ext).read_bytes())
print(json.dumps({'sourceInputs':22,'scripts':6,'status':x['status'],'summary':summary},ensure_ascii=True))
