from pathlib import Path
import ast,hashlib,json,subprocess,uuid,time
from datetime import datetime,timezone
root=Path('.tmp/ta01-resumption/real-api-mcp-native')
ast.parse((root/'native.py').read_text(encoding='utf-8'))
paths={name:Path(value) for name,value in json.loads((root/'host-input-paths.json').read_text()).items()}
expected=json.loads((root/'inputs.json').read_text())
for name,p in paths.items():assert hashlib.file_digest(p.open('rb'),'sha256').hexdigest()==expected[name],name
image='sha256:534baea6a22c03a63003dbc8dbe78fe34bc0d7e595d9a9dc9834884ff530eb55'
owner=str(uuid.uuid4());label='io.workmesh.ta01.real-api-mcp.owner'
ledger={'owner':owner,'imageId':image,'beganAt':datetime.now(timezone.utc).isoformat(),
 'purpose':'一次amd64原生真实API/MCP联动预检；旧准确角色/固定Node，无VM或产品修改',
 'limits':{'cpus':4,'memoryBytes':4294967296,'swapTotalBytes':4294967296,'nodeSeconds':600,'businessMs':30000},
 'inputSha256':expected,'newVm':False,'hostInstall':False,'containers':[]}
def save():(root/'resources.json').write_text(json.dumps(ledger,ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
def call(args,timeout=60,**kw):return subprocess.run(['docker',*args],capture_output=True,timeout=timeout,**kw)
save()
created=call(['create','--pull','never','--cpus','4','--memory','4g','--memory-swap','4g','--pids-limit','512',
 '--security-opt','no-new-privileges:true','--label',label+'='+owner,'--entrypoint','/bin/sleep',image,'infinity'])
assert created.returncode==0,'create failed; output withheld'
cid=created.stdout.decode().strip();assert len(cid)==64 and all(c in '0123456789abcdef' for c in cid)
ledger['containers'].append({'id':cid});save()
try:
 d=json.loads(call(['inspect',cid]).stdout)[0]
 assert d['Id']==cid and d['Image']==image and d['Config']['Labels'][label]==owner
 assert not d['HostConfig'].get('Binds') and not d['HostConfig'].get('Devices') and not d['HostConfig']['Privileged']
 assert not d['HostConfig'].get('PortBindings') and not d['Mounts']
 assert d['HostConfig']['NanoCpus']==4_000_000_000 and d['HostConfig']['Memory']==d['HostConfig']['MemorySwap']==4294967296
 ledger['boundaryVerified']=True;save()
 assert call(['start',cid]).returncode==0
 for phase,args in [('apt-update',['apt-get','update']),('python',['apt-get','install','-y','--no-install-recommends','python3'])]:
  v=call(['exec',cid,*args],timeout=300)
  (root/(phase+'.stdout')).write_bytes(v.stdout);(root/(phase+'.stderr')).write_bytes(v.stderr)
  ledger[phase]={'exitCode':v.returncode,'stdoutSha256':hashlib.sha256(v.stdout).hexdigest(),'stderrSha256':hashlib.sha256(v.stderr).hexdigest()};save()
  assert v.returncode==0,'container tool supply failed; output withheld'
 assert call(['network','disconnect','bridge',cid]).returncode==0
 assert not json.loads(call(['inspect',cid]).stdout)[0]['NetworkSettings']['Networks']
 ledger['externalNetworkDisconnectedBeforeBusiness']=True;save()
 assert call(['exec',cid,'mkdir','/opt/real-api-mcp']).returncode==0
 for name,p in {**paths,'inputs.json':root/'inputs.json'}.items():
  assert call(['cp',str(p),cid+':/opt/real-api-mcp/'+name],timeout=180).returncode==0,'input copy failed'
 began=time.monotonic()
 v=call(['exec',cid,'python3','/opt/real-api-mcp/native.py'],timeout=650)
 (root/'runner.stdout').write_bytes(v.stdout);(root/'runner.stderr').write_bytes(v.stderr)
 ledger['runnerExitCode']=v.returncode;ledger['runnerSeconds']=time.monotonic()-began;save()
 # 仅取固定安全报告；服务日志、数据库和运行密钥随容器定向收尾。
 for name in ['result.json','node.stdout','node.stderr','setup-failure.stdout','setup-failure.stderr']:
  result=call(['exec',cid,'cat','/opt/real-api-mcp/'+name])
  if result.returncode==0:(root/name).write_bytes(result.stdout)
 result=json.loads((root/'result.json').read_text(encoding='utf-8'))
 print(json.dumps({'nodeExitCode':result.get('nodeExitCode'),'errorType':result.get('errorType'),
  'probeStatus':result.get('probe',{}).get('status'),'samples':len(result.get('probe',{}).get('samples',[])),
  'apiCounts':result.get('probe',{}).get('apiCounts'),'seconds':result.get('elapsedSeconds')}))
finally:
 final=call(['inspect',cid]);assert final.returncode==0
 d=json.loads(final.stdout)[0];assert d['Id']==cid and d['Config']['Labels'][label]==owner
 ledger['beforeStop']={k:d['State'][k] for k in ['Status','Running','ExitCode','OOMKilled']};save()
 if d['State']['Running']:
  assert call(['stop','--time','10',cid]).returncode==0
 assert call(['rm',cid]).returncode==0
 absent=call(['inspect',cid]);assert absent.returncode!=0 and b'no such object' in absent.stderr.lower()
 ledger['removedAndAbsent']=True;save()
