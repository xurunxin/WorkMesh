from pathlib import Path
import hashlib,json,subprocess,time
from datetime import datetime,timezone
root=Path('.tmp/ta01-resumption/real-api-mcp-tcg-568-once')
ledger=json.loads((root/'resources.json').read_text(encoding='utf8'));cid=ledger['containers'][0]['id']
assert not ledger['vmStarted'] and not (root/'attempt-started.json').exists()
def save():(root/'resources.json').write_text(json.dumps(ledger,ensure_ascii=False,indent=2)+'\n',encoding='utf8')
def call(args,timeout=60):return subprocess.run(['docker',*args],capture_output=True,timeout=timeout)
def sha(p):
 with p.open('rb') as f:return hashlib.file_digest(f,'sha256').hexdigest()
paths={k:Path(v) for k,v in json.loads((root/'host-input-paths.json').read_text()).items()}
inputs=json.loads((root/'inputs.json').read_text())
image=Path('.tmp/ta01-resumption/local-guest-image-cache/amd64-6a81c375.img')
assert sha(image)=='6a81c37564db9b1ee84e141922625e1d7c5b389b99bb3c572e0243607d5bb4d2'
for name,file in paths.items():assert sha(file)==inputs[name],name
d=json.loads(call(['inspect',cid]).stdout)[0]
assert d['Id']==cid and d['Config']['Labels']['io.workmesh.ta01.real-api-mcp.owner']==ledger['owner']
try:
 assert call(['exec',cid,'mkdir','/opt/real-api-mcp']).returncode==0
 for name,file in {**paths,'inputs.json':root/'inputs.json','guest.py':root/'guest.py','run-guest.py':root/'run-guest.py','amd64.img':image}.items():
  assert call(['cp',str(file),cid+':/opt/real-api-mcp/'+name],180).returncode==0,'copy failed: '+name
 assert call(['network','disconnect','bridge',cid]).returncode==0
 assert not json.loads(call(['inspect',cid]).stdout)[0]['NetworkSettings']['Networks']
 ledger['externalNetworkDisconnectedBeforeVm']=True
 ledger['vmStarted']=True;ledger['vmCommand']=['docker','exec',cid,'python3','/opt/real-api-mcp/run-guest.py']
 ledger['vmStartedAt']=datetime.now(timezone.utc).isoformat();save()
 (root/'attempt-started.json').write_text(json.dumps({'startedAt':ledger['vmStartedAt'],'maximumSeconds':1200,'noRetry':True})+'\n')
 began=time.monotonic()
 try:
  v=call(['exec',cid,'python3','/opt/real-api-mcp/run-guest.py'],1240)
  ledger['runnerExitCode']=v.returncode
  (root/'runner.stdout').write_bytes(v.stdout);(root/'runner.stderr').write_bytes(v.stderr)
 except subprocess.TimeoutExpired:
  ledger['hostRunnerDeadlineReached']=True
 ledger['runnerSeconds']=time.monotonic()-began;save()
finally:
 # 只取既定安全文件；数据库、密钥、服务日志、磁盘随独有容器收尾。
 for name in ['result.json','started.json','receipts.ndjson','serial.log','qemu-stderr.log']:
  v=call(['exec',cid,'cat','/opt/real-api-mcp/guest/'+name])
  if v.returncode==0:(root/name).write_bytes(v.stdout)
 v=call(['exec',cid,'sh','-c','ps -eo comm | sort | uniq -c'])
 if v.returncode==0:(root/'process-names-before-stop.txt').write_bytes(v.stdout)
 d=json.loads(call(['inspect',cid]).stdout)[0]
 assert d['Id']==cid and d['Config']['Labels']['io.workmesh.ta01.real-api-mcp.owner']==ledger['owner']
 ledger['beforeStop']={k:d['State'][k] for k in ['Status','Running','ExitCode','OOMKilled']};save()
 if d['State']['Running']:assert call(['stop','--time','10',cid]).returncode==0
 assert call(['rm',cid]).returncode==0
 absent=call(['inspect',cid]);assert absent.returncode!=0 and b'no such object' in absent.stderr.lower()
 ledger['removedAndAbsent']=True;save()
 print(json.dumps({'runnerExitCode':ledger.get('runnerExitCode'),'runnerSeconds':ledger.get('runnerSeconds'),
  'resultAvailable':(root/'result.json').exists(),'removedAndAbsent':ledger['removedAndAbsent']}))
