from pathlib import Path
import ast,hashlib,json
root=Path('.tmp/ta01-resumption/real-api-mcp-tcg-568-once')
baseline=Path('.tmp/ta01-resumption/real-api-mcp-native')
source=(baseline/'native.py').read_text(encoding='utf8')
source=source.replace("'mode':'native-api-auth-pg-path'","'mode':'tcg-real-api-mcp-path'")
source=source.replace('def stage(name):stages.append({\'name\':name,\'elapsedSeconds\':time.monotonic()-began})',
 '''def stage(name):
    row={'name':name,'elapsedSeconds':time.monotonic()-began};stages.append(row)
    with (base/'progress.ndjson').open('a',encoding='utf8') as out:
        out.write(json.dumps(row)+'\\n');out.flush();os.fsync(out.fileno())''')
source=source.replace("    started=time.monotonic()\n", "    stage('node-starting')\n    started=time.monotonic()\n")
ast.parse(source)
(root/'native.py').write_text(source,encoding='utf8',newline='\n')
(root/'measurement.mjs').write_bytes((baseline/'measurement.mjs').read_bytes())
paths=json.loads((baseline/'host-input-paths.json').read_text())
paths.update({'native.py':str(root/'native.py'),'measurement.mjs':str(root/'measurement.mjs')})
expected={k:hashlib.file_digest(Path(v).open('rb'),'sha256').hexdigest() for k,v in paths.items()}
old=json.loads((baseline/'inputs.json').read_text())
for k in expected:
 if k!='native.py':assert expected[k]==old[k],k
(root/'inputs.json').write_text(json.dumps(expected,indent=2)+'\n',encoding='utf8')
(root/'host-input-paths.json').write_text(json.dumps(paths,indent=2)+'\n',encoding='utf8')
print(json.dumps({'unchangedMeasurement':expected['measurement.mjs']==old['measurement.mjs'],'inputs':len(expected)}))
