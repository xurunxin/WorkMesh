from pathlib import Path
import hashlib,json,subprocess,uuid
from datetime import datetime,timezone
root=Path('.tmp/ta01-resumption/real-api-mcp-tcg-568-once')
root.mkdir(exist_ok=False)
owner=str(uuid.uuid4()); image='sha256:534baea6a22c03a63003dbc8dbe78fe34bc0d7e595d9a9dc9834884ff530eb55'
label='io.workmesh.ta01.real-api-mcp.owner'
ledger={'owner':owner,'imageId':image,'beganAt':datetime.now(timezone.utc).isoformat(),
 'limits':{'vmSeconds':1200,'nodeSeconds':600,'businessMs':30000,'cpus':4,'memoryBytes':4294967296},
 'vmStarted':False,'containers':[],'hostInstall':False}
def save():(root/'resources.json').write_text(json.dumps(ledger,ensure_ascii=False,indent=2)+'\n',encoding='utf8')
def call(args,timeout=60):return subprocess.run(['docker',*args],capture_output=True,timeout=timeout)
save()
v=call(['create','--pull','never','--cpus','4','--memory','4g','--memory-swap','4g','--pids-limit','512',
 '--security-opt','no-new-privileges:true','--label',label+'='+owner,'--entrypoint','/bin/sleep',image,'infinity'])
assert v.returncode==0,'create failed; output withheld'
cid=v.stdout.decode().strip();assert len(cid)==64
ledger['containers'].append({'id':cid});save()
d=json.loads(call(['inspect',cid]).stdout)[0]
assert d['Id']==cid and d['Image']==image and d['Config']['Labels'][label]==owner
assert not d['Mounts'] and not d['HostConfig'].get('Devices') and not d['HostConfig']['Privileged'] and not d['HostConfig'].get('PortBindings')
assert d['HostConfig']['NanoCpus']==4000000000 and d['HostConfig']['Memory']==d['HostConfig']['MemorySwap']==4294967296
ledger['boundaryVerified']=True;save()
assert call(['start',cid]).returncode==0
for phase,command in [('apt-update',['apt-get','update']),('qemu-policy',['apt-cache','policy','qemu-system-x86'])]:
 v=call(['exec',cid,*command],300)
 (root/(phase+'.stdout')).write_bytes(v.stdout);(root/(phase+'.stderr')).write_bytes(v.stderr)
 ledger[phase]={'exitCode':v.returncode,'stdoutSha256':hashlib.sha256(v.stdout).hexdigest()};save()
 assert v.returncode==0,phase+' failed; output withheld'
ledger['exactQemuPackageAvailable']=b'1:8.2.2+ds-0ubuntu1.18' in (root/'qemu-policy.stdout').read_bytes();save()
print(json.dumps({'containerId':cid,'exactQemuPackageAvailable':ledger['exactQemuPackageAvailable']}))
