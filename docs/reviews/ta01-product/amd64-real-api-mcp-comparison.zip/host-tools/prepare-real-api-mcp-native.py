from pathlib import Path
import hashlib,json,ast,subprocess
root=Path('.tmp/ta01-resumption/real-api-mcp-native');root.mkdir(exist_ok=False)
original=Path('docs/reviews/ta01-product/tools/api-auth-pg-path-probe.mjs').read_bytes()
assert hashlib.sha256(original).hexdigest()=='df8ee36d0900d90bd8ef61b93e69c04290cfcf0eb6060f772f2c4077ff0efb76'
source=original.decode()
environment=source[source.index("process.env.NODE_ENV = 'test';"):source.index('const app = buildApp')]
setup=source[source.index('  const install = await app.inject'):source.index('  const lag = monitorEventLoopDelay')]
prefix='''// 隔离原生联动预检：真实API与独立MCP进程；不是完整安装或139修复证明。
import assert from 'node:assert/strict';
import { createHash, randomBytes, randomUUID } from 'node:crypto';
import { readFileSync } from 'node:fs';
import { createRequire } from 'node:module';
import { pathToFileURL } from 'node:url';
import { performance } from 'node:perf_hooks';
import { spawn } from 'node:child_process';
const appRoot='/app', requireApp=createRequire('/app/package.json');
const sha=x=>createHash('sha256').update(x).digest('hex');
const began=performance.now(), stages=[];
const progress=(name,fields={})=>stages.push({name,elapsedMs:performance.now()-began,...fields});
const report={mode:'real-api-mcp-native',fullProductAcceptance:false,nodeVersion:process.version,
 nodeSha256:sha(readFileSync(process.execPath)),stages,samples:[],apiCounts:{qualified:0,workItem:0},
 fixtureSetup:'原真实安装/配对路由inject，目标MCP和API通过独立进程的真实回环HTTP连接',
 plannedRounds:32,requestsDeadlineMs:30000};
'''
middle='''
report.importsMs=importsMs;
const app=buildApp({logger:false});
app.addHook('onRequest',(request,_reply,done)=>{
 const url=new URL(request.url,'http://127.0.0.1:3001');
 if(url.pathname==='/api/v1/agent-capabilities'&&url.searchParams.get('discovery')==='qualified')report.apiCounts.qualified++;
 if(/^\\/api\\/v1\\/work-items\\/[^/]+$/.test(url.pathname)&&request.method==='GET')report.apiCounts.workItem++;
 done();
});
const setupDb=dbModule.createDb();
let cookie='',csrf='',mcp,childExit;
const human=async(method,url,payload)=>app.inject({method,url,payload,headers:{cookie,'x-csrf-token':csrf,'idempotency-key':randomUUID()}});
const expectStatus=(response,status)=>assert.equal(response.statusCode,status,'unexpected status; body withheld');
const childOut=createHash('sha256'),childErr=createHash('sha256');let childOutBytes=0,childErrBytes=0;
try{
 await dbModule.applyMigrations(setupDb);
'''
tail='''
 await app.listen({host:'127.0.0.1',port:3001});
 mcp=spawn(process.execPath,['/opt/mcp/app/dist/http.js'],{cwd:'/opt/mcp/app',
  env:{PATH:'/usr/local/bin:/usr/bin:/bin',HOME:'/tmp',NODE_ENV:'production',
   WORKMESH_API_URL:'http://127.0.0.1:3001',WORKMESH_BETA_COORDINATION_MCP:'true',HOST:'127.0.0.1',PORT:'3002'},
  stdio:['ignore','pipe','pipe']});
 childExit=new Promise(resolve=>mcp.once('exit',(code,signal)=>resolve({code,signal})));
 mcp.stdout.on('data',b=>{childOutBytes+=b.length;childOut.update(b)});
 mcp.stderr.on('data',b=>{childErrBytes+=b.length;childErr.update(b)});
 let live=false;report.startupHealthRequests=0;
 for(let i=0;i<90;i++){
  assert.equal(mcp.exitCode,null,'MCP exited before liveness');
  try{report.startupHealthRequests++;const r=await fetch('http://127.0.0.1:3002/livez',{signal:AbortSignal.timeout(2000)});await r.text();live=r.status===200;}catch{}
  if(live)break;await new Promise(resolve=>setTimeout(resolve,1000));
 }
 assert.ok(live,'MCP did not become live');progress('real-http-servers-live');
 async function rpc(method,id,params){
  const start=performance.now(),controller=new AbortController();
  const timer=setTimeout(()=>controller.abort(),30000);
  try{
   const r=await fetch('http://127.0.0.1:3002/mcp',{method:'POST',signal:controller.signal,
    headers:{'content-type':'application/json',accept:'application/json, text/event-stream','x-workmesh-installation-token':token},
    body:JSON.stringify({jsonrpc:'2.0',id,method,params})});
   const body=await r.text(),wallMs=performance.now()-start;
   report.samples.push({method,status:r.status,wallMs,bytes:Buffer.byteLength(body),bodySha256:sha(body)});
   assert.ok(wallMs<=30000,'original request deadline exceeded');assert.equal(r.status,200);
   const messages=r.headers.get('content-type')?.includes('text/event-stream')
    ?body.split(/\\r?\\n/).filter(l=>l.startsWith('data:')).map(l=>JSON.parse(l.slice(5))):[JSON.parse(body)];
   const replies=messages.filter(x=>x.id===id);assert.equal(replies.length,1);assert.equal(replies[0].error,undefined);
   return replies[0].result;
  }finally{clearTimeout(timer)}
 }
 for(let round=0;round<32;round++){
  const before=report.apiCounts.qualified;
  await rpc('initialize',1,{protocolVersion:'2024-11-05',capabilities:{},clientInfo:{name:'ta01-real-api-native',version:'1.0.0'}});
  assert.equal(report.apiCounts.qualified,before,'initialize unexpectedly read qualification');
  const reply=await rpc('tools/call',2,{name:'get_work_item',arguments:{workItemId:item.json().id}});
  assert.notEqual(reply.isError,true);
  const body=reply.structuredContent?.data??JSON.parse(reply.content.find(x=>x.type==='text').text);
  assert.equal(body.id,item.json().id);
  assert.equal(report.apiCounts.qualified,round+1);assert.equal(report.apiCounts.workItem,round+1);
 }
 report.completedRounds=32;
 const detail=await human('GET',`/api/v1/agent-connections/${created.json().connection.id}`);expectStatus(detail,200);
 const revoked=await app.inject({method:'DELETE',url:`/api/v1/agent-connections/${created.json().connection.id}`,
  headers:{cookie,'x-csrf-token':csrf,'idempotency-key':randomUUID(),'if-match':detail.headers.etag}});expectStatus(revoked,204);
 const rejected=await rpc('tools/call',2,{name:'get_work_item',arguments:{workItemId:item.json().id}});
 assert.equal(rejected.isError,true);assert.equal(report.apiCounts.qualified,33);assert.equal(report.apiCounts.workItem,32);
 report.revocationRejected=true;report.status='sample-completed';
}catch(error){report.status='failed';report.errorType=error.name;report.errorCode=error.code??null;
 report.errorMessageSha256=sha(String(error.message));process.exitCode=1;
}finally{
 if(mcp){
  if(mcp.exitCode===null&&mcp.signalCode===null)mcp.kill('SIGTERM');
  let timer;try{report.mcpExit=await Promise.race([childExit,new Promise((_,reject)=>{timer=setTimeout(()=>reject(new Error('MCP cleanup deadline')),35000)})]);}
  catch(error){report.cleanupError=error.name;process.exitCode=1;}finally{clearTimeout(timer)}
 }
 report.mcpStdout={bytes:childOutBytes,sha256:childOut.digest('hex')};report.mcpStderr={bytes:childErrBytes,sha256:childErr.digest('hex')};
 await app.close();await setupDb.end();report.elapsedMs=performance.now()-began;
 console.log(JSON.stringify(report));setTimeout(()=>process.exit(process.exitCode??0),50);
}
'''
(root/'measurement.mjs').write_text(prefix+environment+middle+setup+tail,encoding='utf-8',newline='\n')
old=Path('.tmp/ta01-resumption/api-auth-pg-native-567/native.py').read_text(encoding='utf-8')
old=old.replace("Path('/opt/native')","Path('/opt/real-api-mcp')")
marker="    stage('exact-native-roles-ready')"
extra="""    mcp_root=base/'mcp';mcp_root.mkdir(exist_ok=False)
    run(['tar','-xzf',str(base/'mcp-rootfs.tar.gz'),'-C',str(mcp_root)])
    destination=roots['api']/'opt/mcp';destination.mkdir(parents=True,exist_ok=False)
    os.rename(mcp_root/'app',destination/'app')
    assert sha(roots['api']/'usr/local/bin/node')==sha(mcp_root/'usr/local/bin/node')=='638c77326270093b1251a5e72b4335c94c74856a210460341c73d6f3da647328'
"""
assert marker in old
old=old.replace(marker,extra+marker)
ast.parse(old)
(root/'native.py').write_text(old,encoding='utf-8',newline='\n')
subprocess.run(['D:/Cache/TEMP/workmesh-ta00-nf20n0st/node-v22.19.0-win-x64/node.exe','--check',str(root/'measurement.mjs')],check=True)
paths={name:Path('.tmp/ta01-resumption/api-auth-pg-native-567')/name for name in ['api-rootfs.tar.gz','postgres-rootfs.tar.gz','redis-rootfs.tar.gz']}
paths['mcp-rootfs.tar.gz']=Path('.tmp/ta01-resumption/exact-mcp-9c8/node-rootfs.tar.gz')
paths.update({name:root/name for name in ['measurement.mjs','native.py']})
digests={name:hashlib.file_digest(p.open('rb'),'sha256').hexdigest() for name,p in paths.items()}
previous=json.loads(Path('.tmp/ta01-resumption/api-auth-pg-native-567/inputs.json').read_text())
for name in ['api-rootfs.tar.gz','postgres-rootfs.tar.gz','redis-rootfs.tar.gz']:assert digests[name]==previous[name]
assert digests['mcp-rootfs.tar.gz']=='7f5c28b98d3df88b571135fd6ce0c53e4ca589155373430654a090baab419a9f'
(root/'inputs.json').write_text(json.dumps(digests,indent=2)+'\n',encoding='utf-8')
(root/'host-input-paths.json').write_text(json.dumps({name:str(p) for name,p in paths.items()},indent=2)+'\n',encoding='utf-8')
print(json.dumps({'prepared':True,'nodeRequestsDeadlineMs':30000,'nodeLimitSeconds':600,'newVm':False,'plannedRounds':32}))
