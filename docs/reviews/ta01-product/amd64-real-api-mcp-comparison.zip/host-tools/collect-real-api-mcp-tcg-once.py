from pathlib import Path
import json,subprocess
root=Path('.tmp/ta01-resumption/real-api-mcp-tcg-568-once')
ledger=json.loads((root/'resources.json').read_text(encoding='utf8'))
if ledger.get('removedAndAbsent'):
 print(json.dumps({'removedAndAbsent':True,'finalReport':(root/'result.json').exists()}));raise SystemExit(0)
cid=ledger['containers'][0]['id']
v=subprocess.run(['docker','exec',cid,'cat','/opt/real-api-mcp/guest/receipts.ndjson'],capture_output=True,timeout=15)
if v.returncode==0:
 complete=v.stdout[:v.stdout.rfind(b'\n')+1]
 rows=[json.loads(x) for x in complete.splitlines()]
 (root/'receipts-live.ndjson').write_bytes(complete)
 print(json.dumps({'receipts':len(rows),'last':{k:rows[-1].get(k) for k in ['kind','hostVmSeconds']},
  'lastStage':rows[-1].get('value',{}).get('name'),'hasFinal':any(x['kind']=='final' for x in rows)}))
else:print(json.dumps({'receiptsAvailable':False,'vmStarted':ledger.get('vmStarted')}))
