"""固定输入单次1200秒VM，阶段先落盘；不重试、不扩窗。"""
import base64,hashlib,json,os,subprocess,threading,time,uuid
from pathlib import Path
from http.server import BaseHTTPRequestHandler,ThreadingHTTPServer
base=Path('/opt/real-api-mcp');run=base/'guest';run.mkdir(exist_ok=False)
def sha(p):
 with p.open('rb') as f:return hashlib.file_digest(f,'sha256').hexdigest()
version=subprocess.check_output(['qemu-system-x86_64','--version']).decode().splitlines()[0]
assert version=='QEMU emulator version 8.2.2 (Debian 1:8.2.2+ds-0ubuntu1.18)'
assert sha(Path('/usr/bin/qemu-system-x86_64'))=='8a35ccba41582fc6c38b9df85fc9e35fa1d42f414d2d7d8090ee9b2f5e7c0854'
image=base/'amd64.img';assert sha(image)=='6a81c37564db9b1ee84e141922625e1d7c5b389b99bb3c572e0243607d5bb4d2'
inputs=json.loads((base/'inputs.json').read_bytes())
for name,digest in inputs.items():assert sha(base/name)==digest
nonce=uuid.uuid4().hex;expected={'nonce':nonce,'inputs':inputs};receipts=[];lock=threading.Lock()
class Handler(BaseHTTPRequestHandler):
 def do_GET(self):
  name=self.path[1:]
  if name not in inputs:self.send_error(404);return
  file=base/name;self.send_response(200);self.send_header('Content-Length',str(file.stat().st_size));self.end_headers()
  with file.open('rb') as source:
   while block:=source.read(1048576):self.wfile.write(block)
 def do_POST(self):
  size=int(self.headers.get('Content-Length','0'))
  if self.path!='/receipt' or not 0<size<1048576:self.send_error(400);return
  value=json.loads(self.rfile.read(size))
  if value.get('nonce')!=nonce or value.get('kind') not in {'stage','final','failure'}:self.send_error(400);return
  value['hostVmSeconds']=time.monotonic()-began
  with lock:
   receipts.append(value)
   with (run/'receipts.ndjson').open('a',encoding='utf8') as out:
    out.write(json.dumps(value)+'\n');out.flush();os.fsync(out.fileno())
  self.send_response(200);self.end_headers()
 def log_message(self,*_):pass
server=ThreadingHTTPServer(('127.0.0.1',18080),Handler)
threading.Thread(target=server.serve_forever,daemon=True).start()
cloud='#cloud-config\nwrite_files:\n'
for name,data in [('guest.py',(base/'guest.py').read_bytes()),('expected.json',json.dumps(expected).encode())]:
 cloud+='  - path: /opt/real-api-mcp/'+name+'\n    permissions: "0644"\n    encoding: b64\n    content: '+base64.b64encode(data).decode()+'\n'
cloud+='runcmd:\n  - [python3, /opt/real-api-mcp/guest.py]\n'
(run/'user-data').write_text(cloud);(run/'meta-data').write_text('instance-id: ta01-real-'+nonce+'\nlocal-hostname: ta01-real-'+nonce[:8]+'\n')
subprocess.run(['genisoimage','-quiet','-output',str(run/'seed.iso'),'-volid','cidata','-joliet','-rock',str(run/'user-data'),str(run/'meta-data')],check=True,capture_output=True)
subprocess.run(['qemu-img','create','-f','qcow2','-F','qcow2','-b',str(image),str(run/'root.qcow2'),'40G'],check=True,capture_output=True)
args=['qemu-system-x86_64','-accel','tcg','-m','4096','-smp','4','-display','none','-serial','file:'+str(run/'serial.log'),
 '-netdev','user,id=net0','-device','virtio-net-pci,netdev=net0','-drive','if=virtio,format=qcow2,file='+str(run/'root.qcow2'),
 '-drive','if=virtio,format=raw,readonly=on,file='+str(run/'seed.iso')]
report={'qemuVersion':version,'qemuBinarySha256':sha(Path('/usr/bin/qemu-system-x86_64')),'guestSha256':sha(image),
 'command':args,'vmSecondsLimit':1200,'nodeSecondsLimit':600,'businessMsLimit':30000,'fullProductAcceptance':False,'inputs':inputs}
(run/'started.json').write_text(json.dumps(report,indent=2)+'\n')
began=time.monotonic();process=None
try:
 with (run/'qemu-stderr.log').open('wb') as error:
  process=subprocess.Popen(args,stdout=subprocess.DEVNULL,stderr=error)
  try:report['qemuExitCode']=process.wait(timeout=1200)
  except subprocess.TimeoutExpired:
   report['deadlineReached']=True;process.terminate();report['qemuExitCode']=process.wait(timeout=15)
finally:
 if process and process.poll() is None:process.terminate();process.wait(timeout=15)
 report['elapsedSeconds']=time.monotonic()-began;report['receipts']=receipts
 finals=[x['value'] for x in receipts if x['kind']=='final']
 report['status']='sample-completed' if not report.get('deadlineReached') and report.get('qemuExitCode')==0 and len(finals)==1 and finals[0].get('nodeExitCode')==0 and finals[0].get('probe',{}).get('status')=='sample-completed' else 'incomplete-or-failed'
 (run/'result.json').write_text(json.dumps(report,indent=2)+'\n');server.shutdown();server.server_close()
print(json.dumps({k:report.get(k) for k in ['status','elapsedSeconds','qemuExitCode','deadlineReached']}))
