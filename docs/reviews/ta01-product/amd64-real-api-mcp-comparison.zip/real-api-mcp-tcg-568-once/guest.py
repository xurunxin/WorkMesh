"""单次固定amd64 guest对照：只传安全阶段与最终投影，不重试业务。"""
import hashlib,json,os,resource,subprocess,time,urllib.request
from pathlib import Path
base=Path('/opt/real-api-mcp');expected=json.loads((base/'expected.json').read_bytes())
nonce=expected['nonce'];began=time.monotonic()
def send(kind,value):
 payload=json.dumps({'nonce':nonce,'kind':kind,'value':value}).encode()
 assert len(payload)<1048576
 req=urllib.request.Request('http://10.0.2.2:18080/receipt',payload,{'content-type':'application/json'})
 with urllib.request.urlopen(req,timeout=10) as response:assert response.status==200
def stage(name):send('stage',{'name':name,'guestSeconds':time.monotonic()-began})
try:
 assert os.geteuid()==0 and os.uname().machine=='x86_64' and os.cpu_count()==4
 assert Path('/sys/class/dmi/id/sys_vendor').read_text().strip()=='QEMU'
 assert os.uname().nodename=='ta01-real-'+nonce[:8]
 assert os.uname().release=='6.8.0-142-generic'
 resource.setrlimit(resource.RLIMIT_CORE,(0,0));Path('/proc/sys/kernel/core_pattern').write_text('|/bin/false\n')
 send('stage',{'name':'fixed-guest-verified','kernel':os.uname().release,'cpus':os.cpu_count(),
  'bootId':Path('/proc/sys/kernel/random/boot_id').read_text().strip()})
 for name,digest in expected['inputs'].items():
  assert name in {'api-rootfs.tar.gz','postgres-rootfs.tar.gz','redis-rootfs.tar.gz','mcp-rootfs.tar.gz','measurement.mjs','native.py'}
  target=base/name
  with urllib.request.urlopen('http://10.0.2.2:18080/'+name,timeout=60) as response,target.open('xb') as out:
   while block:=response.read(1048576):out.write(block)
  with target.open('rb') as f:assert hashlib.file_digest(f,'sha256').hexdigest()==digest
  stage('input-verified:'+name)
 (base/'inputs.json').write_text(json.dumps(expected['inputs']),encoding='utf8')
 subprocess.run(['ip','route','del','default'],check=True,capture_output=True)
 assert b'default' not in subprocess.check_output(['ip','route'])
 stage('inputs-ready-external-route-removed')
 with (base/'harness.stdout').open('wb') as out,(base/'harness.stderr').open('wb') as err:
  proc=subprocess.Popen(['python3',str(base/'native.py')],stdout=out,stderr=err)
  cursor=0
  while True:
   file=base/'progress.ndjson'
   if file.exists():
    with file.open(encoding='utf8') as source:
     source.seek(cursor)
     for line in source:send('stage',{'name':'harness:'+json.loads(line)['name'],'harnessSeconds':json.loads(line)['elapsedSeconds']})
     cursor=source.tell()
   if proc.poll() is not None:break
   time.sleep(0.5)
 report=json.loads((base/'result.json').read_bytes())
 report['harnessExitCode']=proc.returncode
 send('final',report)
except Exception as error:
 send('failure',{'errorType':type(error).__name__,'actualBusinessRequests':None,'guestSeconds':time.monotonic()-began})
finally:
 print(json.dumps({'tag':'ta01-real-api-mcp-guest-finished'}),flush=True)
 subprocess.run(['systemctl','--no-block','poweroff'],check=True)
