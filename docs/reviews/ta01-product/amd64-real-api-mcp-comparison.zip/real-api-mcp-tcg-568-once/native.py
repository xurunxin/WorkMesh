"""准确AMD候选的原生小范围预检；仍不是支持验收。"""
from pathlib import Path
import hashlib,json,os,resource,subprocess,time

base=Path('/opt/real-api-mcp'); began=time.monotonic(); stages=[]; processes=[]; handles=[]
report={'mode':'tcg-real-api-mcp-path','hostKernel':os.uname().release,'machine':os.uname().machine,
    'fullProductAcceptance':False,'stages':stages}
def sha(p):
    with p.open('rb') as f:return hashlib.file_digest(f,'sha256').hexdigest()
def stage(name):
    row={'name':name,'elapsedSeconds':time.monotonic()-began};stages.append(row)
    with (base/'progress.ndjson').open('a',encoding='utf8') as out:
        out.write(json.dumps(row)+'\n');out.flush();os.fsync(out.fileno())
def run(args,timeout=120):
    v=subprocess.run(args,capture_output=True,timeout=timeout)
    if v.returncode:
        report['failedSetupCommand']={'executable':args[0],'exitCode':v.returncode,'stdoutSha256':hashlib.sha256(v.stdout).hexdigest(),
            'stderrSha256':hashlib.sha256(v.stderr).hexdigest(),'stderrBytes':len(v.stderr)}
        # 这里只运行无凭据的供应命令；Node/业务输出另取安全投影。
        (base/'setup-failure.stdout').write_bytes(v.stdout); (base/'setup-failure.stderr').write_bytes(v.stderr)
        raise RuntimeError('isolated setup command failed')
    return v
try:
    resource.setrlimit(resource.RLIMIT_CORE,(0,0))
    assert os.uname().machine=='x86_64' and os.geteuid()==0
    assert not any((p/'comm').read_text().startswith('qemu-system') for p in Path('/proc').iterdir() if p.name.isdigit() and (p/'comm').exists())
    expected=json.loads((base/'inputs.json').read_bytes()); roots={}
    for name,digest in expected.items():assert sha(base/name)==digest
    for role in ['api','postgres','redis']:
        root=base/role; root.mkdir(exist_ok=False); roots[role]=root
        run(['tar','-xzf',str(base/(role+'-rootfs.tar.gz')),'-C',str(root)])
        null=root/'dev/null'
        if not null.exists():run(['mknod','-m','666',str(null),'c','1','3'])
        shm=root/'dev/shm'; shm.mkdir(exist_ok=True); shm.chmod(0o1777)
    mcp_root=base/'mcp';mcp_root.mkdir(exist_ok=False)
    run(['tar','-xzf',str(base/'mcp-rootfs.tar.gz'),'-C',str(mcp_root)])
    destination=roots['api']/'opt/mcp';destination.mkdir(parents=True,exist_ok=False)
    os.rename(mcp_root/'app',destination/'app')
    assert sha(roots['api']/'usr/local/bin/node')==sha(mcp_root/'usr/local/bin/node')=='638c77326270093b1251a5e72b4335c94c74856a210460341c73d6f3da647328'
    stage('exact-native-roles-ready')
    pg=roots['postgres']; data=pg/'tmp/probe-data'; data.mkdir(); os.chown(data,70,70); data.chmod(0o700)
    run(['chroot','--userspec=70:70',str(pg),'/usr/local/bin/initdb','-D','/tmp/probe-data','-A','trust','-U','postgres','--no-locale'])
    log=(base/'postgres.private.log').open('wb');handles.append(log)
    p=subprocess.Popen(['chroot','--userspec=70:70',str(pg),'/usr/local/bin/postgres','-D','/tmp/probe-data',
        '-c','listen_addresses=127.0.0.1','-c','port=5432','-c','unix_socket_directories=/tmp','-c','max_connections=20',
        '-c','shared_buffers=64MB','-c','shared_preload_libraries=pg_stat_statements','-c','pg_stat_statements.track=all',
        '-c','pg_stat_statements.track_planning=on','-c','track_io_timing=on','-c','track_activities=on','-c','log_statement=none',
        '-c','log_min_error_statement=panic','-c','log_parameter_max_length=0','-c','log_parameter_max_length_on_error=0'],stdout=log,stderr=log)
    processes.append(('postgres',p))
    for _ in range(60):
        ready=subprocess.run(['chroot',str(pg),'/usr/local/bin/pg_isready','-h','127.0.0.1','-U','postgres'],capture_output=True,timeout=5)
        if ready.returncode==0:break
        assert p.poll() is None;time.sleep(1)
    assert ready.returncode==0
    run(['chroot','--userspec=70:70',str(pg),'/usr/local/bin/createdb','-h','127.0.0.1','-U','postgres','ta01_auth_path_test'])
    redis=roots['redis']; d=redis/'data';d.mkdir(exist_ok=True);os.chown(d,999,999)
    log=(base/'redis.private.log').open('wb');handles.append(log)
    p=subprocess.Popen(['chroot','--userspec=999:999',str(redis),'/usr/local/bin/redis-server','--bind','127.0.0.1',
        '--port','6379','--dir','/data','--appendonly','yes'],stdout=log,stderr=log);processes.append(('redis',p))
    for _ in range(30):
        ready=subprocess.run(['chroot',str(redis),'/usr/local/bin/redis-cli','ping'],capture_output=True,timeout=5)
        if ready.returncode==0 and ready.stdout.strip()==b'PONG':break
        assert p.poll() is None;time.sleep(1)
    assert ready.returncode==0 and ready.stdout.strip()==b'PONG'
    stage('native-pg-redis-ready')
    api=roots['api'];(api/'tmp/measurement.mjs').write_bytes((base/'measurement.mjs').read_bytes())
    stage('node-starting')
    started=time.monotonic()
    v=subprocess.run(['chroot','--userspec=10001:10001',str(api),'/usr/local/bin/node','/tmp/measurement.mjs','/app'],capture_output=True,timeout=600)
    report.update(nodeExitCode=v.returncode,nodeSeconds=time.monotonic()-started,stdoutBytes=len(v.stdout),
        stdoutSha256=hashlib.sha256(v.stdout).hexdigest(),stderrBytes=len(v.stderr),stderrSha256=hashlib.sha256(v.stderr).hexdigest())
    (base/'node.stdout').write_bytes(v.stdout);(base/'node.stderr').write_bytes(v.stderr)
    if v.stdout:report['probe']=json.loads(v.stdout)
    stage('native-node-finished')
except Exception as error:
    report['errorType']=type(error).__name__
finally:
    report['childExitCodes']={}
    for name,p in reversed(processes):
        if p.poll() is None:p.terminate()
        try:code=p.wait(timeout=15)
        except subprocess.TimeoutExpired:p.kill();code=p.wait(timeout=5)
        report['childExitCodes'][name]=code
    for h in handles:h.close()
    report['elapsedSeconds']=time.monotonic()-began
    (base/'result.json').write_text(json.dumps(report,indent=2)+'\n',encoding='utf8')
    print(json.dumps({k:report.get(k) for k in ['nodeExitCode','errorType','elapsedSeconds']}))
