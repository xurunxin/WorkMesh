// 隔离原生联动预检：真实API与独立MCP进程；不是完整安装或139修复证明。
import assert from 'node:assert/strict';
import { createHash, randomBytes, randomUUID } from 'node:crypto';
import { readFileSync } from 'node:fs';
import { createRequire } from 'node:module';
import { pathToFileURL } from 'node:url';
import { performance } from 'node:perf_hooks';
import { spawn } from 'node:child_process';
const appRoot='/app', requireApp=createRequire('/app/package.json');
const sha=x=>createHash('sha256').update(x).digest('hex');
const began=performance.now(), stages=[];
const progress=(name,fields={})=>stages.push({name,elapsedMs:performance.now()-began,...fields});
const report={mode:'real-api-mcp-native',fullProductAcceptance:false,nodeVersion:process.version,
 nodeSha256:sha(readFileSync(process.execPath)),stages,samples:[],apiCounts:{qualified:0,workItem:0},
 fixtureSetup:'原真实安装/配对路由inject，目标MCP和API通过独立进程的真实回环HTTP连接',
 plannedRounds:32,requestsDeadlineMs:30000};
process.env.NODE_ENV = 'test';
process.env.DATABASE_URL = 'postgresql://postgres@127.0.0.1:5432/ta01_auth_path_test?application_name=ta01-api-auth-path';
process.env.REDIS_URL = 'redis://127.0.0.1:6379';
process.env.SESSION_SECRET = randomBytes(48).toString('base64url');
process.env.WORKMESH_MASTER_KEY = randomBytes(32).toString('hex');
process.env.AUTH_RATE_LIMIT_HMAC_KEY = randomBytes(48).toString('base64url');
process.env.WORKMESH_BOOTSTRAP_TOKEN = randomBytes(48).toString('base64url');
process.env.WORKMESH_BOOTSTRAP_ALLOW_LOOPBACK = 'true';
process.env.WORKMESH_BETA_COORDINATION_MCP = 'true';
process.env.WORKMESH_BETA_GITEA = 'true';
process.env.WEB_ORIGIN = 'http://127.0.0.1:3001';
const importsStarted = performance.now();
progress('product-import-started');
const dbModule = await import(pathToFileURL(requireApp.resolve('@workmesh/db')));
const { buildApp } = await import(pathToFileURL(`${appRoot}/dist/server.js`));
process.env.NODE_ENV = 'production';
const importsMs = performance.now() - importsStarted;
progress('product-import-finished', { importsMs });

report.importsMs=importsMs;
const app=buildApp({logger:false});
app.addHook('onRequest',(request,_reply,done)=>{
 const url=new URL(request.url,'http://127.0.0.1:3001');
 if(url.pathname==='/api/v1/agent-capabilities'&&url.searchParams.get('discovery')==='qualified')report.apiCounts.qualified++;
 if(/^\/api\/v1\/work-items\/[^/]+$/.test(url.pathname)&&request.method==='GET')report.apiCounts.workItem++;
 done();
});
const setupDb=dbModule.createDb();
let cookie='',csrf='',mcp,childExit;
const human=async(method,url,payload)=>app.inject({method,url,payload,headers:{cookie,'x-csrf-token':csrf,'idempotency-key':randomUUID()}});
const expectStatus=(response,status)=>assert.equal(response.statusCode,status,'unexpected status; body withheld');
const childOut=createHash('sha256'),childErr=createHash('sha256');let childOutBytes=0,childErrBytes=0;
try{
 await dbModule.applyMigrations(setupDb);
  const install = await app.inject({ method: 'POST', url: '/api/v1/auth/install',
    headers: { 'idempotency-key': randomUUID(), 'x-workmesh-bootstrap-token': process.env.WORKMESH_BOOTSTRAP_TOKEN },
    payload: { name: 'TA01 isolated auth path', slug: 'ta01-auth-path', adminName: 'Probe',
      email: 'probe@example.test', password: randomBytes(24).toString('base64url') } });
  expectStatus(install, 200);
  progress('installation-finished');
  const setCookie = install.headers['set-cookie'];
  cookie = (Array.isArray(setCookie) ? setCookie[0] : setCookie).split(';')[0];
  csrf = install.json().csrfToken;
  const me = await human('GET', '/api/v1/auth/me'); expectStatus(me, 200);
  const teams = await human('GET', '/api/v1/teams'); expectStatus(teams, 200);
  const team = teams.json().items[0];
  const states = await human('GET', `/api/v1/teams/${team.id}/states`); expectStatus(states, 200);
  const project = await human('POST', '/api/v1/projects', { name: 'TA01 probe project', teamId: team.id });
  expectStatus(project, 200);
  const item = await human('POST', '/api/v1/work-items', { teamId: team.id, projectId: project.json().id,
    statusId: states.json().items[0].id, responsibleHumanActorId: me.json().actor.id, title: 'TA01 auth path' });
  expectStatus(item, 200);
  progress('work-item-fixture-created');
  const created = await human('POST', '/api/v1/agent-connections', { name: 'TA01 path probe',
    agentSlug: 'ta01-path-probe', clientType: 'codex', teamId: team.id,
    principalHumanActorId: me.json().actor.id, requestedCapabilities: ['work:read'], grantAgentDelegate: false });
  expectStatus(created, 201);
  const redeemed = await app.inject({ method: 'POST', url: '/api/v1/agent-connections/redeem',
    headers: { 'idempotency-key': randomUUID() }, payload: {
      pairingCode: new URL(created.json().connect_url).hash.slice(1), agentSlug: 'ta01-path-probe',
      client: { type: 'codex', version: '1.1.0' } } });
  expectStatus(redeemed, 200);
  progress('real-work-read-pairing-finished');
  const token = redeemed.json().installation_token;
  report.fixture = { capabilities: ['work:read'], realPairing: true, realCredential: true,
    isolatedFreshDatabase: true, changedProductionAuthority: false };

 await app.listen({host:'127.0.0.1',port:3001});
 mcp=spawn(process.execPath,['/opt/mcp/app/dist/http.js'],{cwd:'/opt/mcp/app',
  env:{PATH:'/usr/local/bin:/usr/bin:/bin',HOME:'/tmp',NODE_ENV:'production',
   WORKMESH_API_URL:'http://127.0.0.1:3001',WORKMESH_BETA_COORDINATION_MCP:'true',HOST:'127.0.0.1',PORT:'3002'},
  stdio:['ignore','pipe','pipe']});
 childExit=new Promise(resolve=>mcp.once('exit',(code,signal)=>resolve({code,signal})));
 mcp.stdout.on('data',b=>{childOutBytes+=b.length;childOut.update(b)});
 mcp.stderr.on('data',b=>{childErrBytes+=b.length;childErr.update(b)});
 let live=false;const healthBegan=performance.now();report.startupHealthRequests=0;
 for(let i=0;i<90;i++){
  assert.ok(performance.now()-healthBegan<180000,'original health deadline exceeded');
  assert.equal(mcp.exitCode,null,'MCP exited before liveness');
  try{report.startupHealthRequests++;const r=await fetch('http://127.0.0.1:3002/livez',{signal:AbortSignal.timeout(2000)});await r.text();live=r.status===200;}catch{}
  if(live)break;await new Promise(resolve=>setTimeout(resolve,1000));
 }
 assert.ok(live&&performance.now()-healthBegan<=180000,'MCP did not become live within original health deadline');progress('real-http-servers-live');
 async function rpc(method,id,params){
  const start=performance.now(),controller=new AbortController();
  const timer=setTimeout(()=>controller.abort(),30000);
  try{
   const r=await fetch('http://127.0.0.1:3002/mcp',{method:'POST',signal:controller.signal,
    headers:{'content-type':'application/json',accept:'application/json, text/event-stream','x-workmesh-installation-token':token},
    body:JSON.stringify({jsonrpc:'2.0',id,method,params})});
   const body=await r.text(),wallMs=performance.now()-start;
   report.samples.push({method,status:r.status,wallMs,bytes:Buffer.byteLength(body),bodySha256:sha(body)});
   assert.ok(wallMs<=30000,'original request deadline exceeded');assert.equal(r.status,200);
   const messages=r.headers.get('content-type')?.includes('text/event-stream')
    ?body.split(/\r?\n/).filter(l=>l.startsWith('data:')).map(l=>JSON.parse(l.slice(5))):[JSON.parse(body)];
   const replies=messages.filter(x=>x.id===id);assert.equal(replies.length,1);assert.equal(replies[0].error,undefined);
   return replies[0].result;
  }finally{clearTimeout(timer)}
 }
 for(let round=0;round<32;round++){
  const before=report.apiCounts.qualified;
  await rpc('initialize',1,{protocolVersion:'2024-11-05',capabilities:{},clientInfo:{name:'ta01-real-api-native',version:'1.0.0'}});
  assert.equal(report.apiCounts.qualified,before,'initialize unexpectedly read qualification');
  const reply=await rpc('tools/call',2,{name:'get_work_item',arguments:{workItemId:item.json().id}});
  assert.notEqual(reply.isError,true);
  const body=reply.structuredContent?.data??JSON.parse(reply.content.find(x=>x.type==='text').text);
  assert.equal(body.id,item.json().id);
  assert.equal(report.apiCounts.qualified,round+1);assert.equal(report.apiCounts.workItem,round+1);
 }
 report.completedRounds=32;
 const detail=await human('GET',`/api/v1/agent-connections/${created.json().connection.id}`);expectStatus(detail,200);
 const revoked=await app.inject({method:'DELETE',url:`/api/v1/agent-connections/${created.json().connection.id}`,
  headers:{cookie,'x-csrf-token':csrf,'idempotency-key':randomUUID(),'if-match':detail.headers.etag}});expectStatus(revoked,204);
 const rejected=await rpc('tools/call',2,{name:'get_work_item',arguments:{workItemId:item.json().id}});
 assert.equal(rejected.isError,true);assert.equal(report.apiCounts.qualified,33);assert.equal(report.apiCounts.workItem,32);
 report.revocationRejected=true;report.status='sample-completed';
}catch(error){report.status='failed';report.errorType=error.name;report.errorCode=error.code??null;
 report.errorMessageSha256=sha(String(error.message));process.exitCode=1;
}finally{
 if(mcp){
  if(mcp.exitCode===null&&mcp.signalCode===null)mcp.kill('SIGTERM');
  let timer;try{report.mcpExit=await Promise.race([childExit,new Promise((_,reject)=>{timer=setTimeout(()=>reject(new Error('MCP cleanup deadline')),35000)})]);}
  catch(error){report.cleanupError=error.name;process.exitCode=1;}finally{clearTimeout(timer)}
 }
 report.mcpStdout={bytes:childOutBytes,sha256:childOut.digest('hex')};report.mcpStderr={bytes:childErrBytes,sha256:childErr.digest('hex')};
 await app.close();await setupDb.end();report.elapsedMs=performance.now()-began;
 console.log(JSON.stringify(report));setTimeout(()=>process.exit(process.exitCode??0),50);
}
