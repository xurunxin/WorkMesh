$ErrorActionPreference = 'Stop'
$taskWorkspace = (Get-Location).Path
$taskRoot = Join-Path $taskWorkspace '.tmp/ta01-resumption/api-auth-pg-567'
$taskNativeRoot = Join-Path $taskWorkspace '.tmp/ta01-resumption/api-auth-pg-native-567'
$taskRows = @()
foreach ($taskBase in @($taskRoot, $taskNativeRoot)) {
    $taskBaseItem = Get-Item -LiteralPath $taskBase
    if (($taskBaseItem.Attributes -band [IO.FileAttributes]::ReparsePoint) -ne 0) { throw 'owned base became reparse point' }
    if (-not $taskBaseItem.FullName.StartsWith($taskWorkspace + [IO.Path]::DirectorySeparatorChar, [StringComparison]::OrdinalIgnoreCase)) { throw 'target outside workspace' }
    $taskArtifact = Get-Content -LiteralPath (Join-Path $taskBase 'artifact.json') -Raw | ConvertFrom-Json
    $taskExtraction = Get-Content -LiteralPath (Join-Path $taskBase 'extraction.json') -Raw | ConvertFrom-Json
    foreach ($taskFile in @('candidate.zip', 'selected.tar')) {
        $taskTarget = Join-Path $taskBase $taskFile
        $taskItem = Get-Item -LiteralPath $taskTarget
        if ($taskItem.PSIsContainer -or (($taskItem.Attributes -band [IO.FileAttributes]::ReparsePoint) -ne 0)) { throw 'not a regular owned input' }
        if ($taskItem.Directory.FullName -ne $taskBaseItem.FullName) { throw 'unexpected target parent' }
        if ($taskFile -eq 'candidate.zip') { $taskExpected = $taskArtifact.digest.Replace('sha256:', ''); $taskExpectedBytes = $taskArtifact.size_in_bytes }
        else { $taskExpected = $taskExtraction.selectedTarSha256; $taskExpectedBytes = $taskExtraction.selectedTarBytes }
        $taskActual = (Get-FileHash -LiteralPath $taskTarget -Algorithm SHA256).Hash.ToLowerInvariant()
        if ($taskActual -ne $taskExpected -or $taskItem.Length -ne $taskExpectedBytes) { throw 'input identity mismatch; no deletion' }
        $taskRow = [ordered]@{ path = [IO.Path]::GetRelativePath($taskWorkspace, $taskTarget); bytes = $taskItem.Length; sha256 = $taskActual; state = 'intent-verified' }
        $taskRows += $taskRow
        $taskRows | ConvertTo-Json -Depth 5 | Set-Content -LiteralPath (Join-Path $taskRoot 'deleted-inputs.json') -Encoding utf8
        Remove-Item -LiteralPath $taskTarget
        if (Test-Path -LiteralPath $taskTarget) { throw 'input removal not confirmed' }
        $taskRow.state = 'removed-and-absent'
        $taskRows | ConvertTo-Json -Depth 5 | Set-Content -LiteralPath (Join-Path $taskRoot 'deleted-inputs.json') -Encoding utf8
    }
}
Write-Output ('removed_owned_duplicate_inputs=' + $taskRows.Count)
