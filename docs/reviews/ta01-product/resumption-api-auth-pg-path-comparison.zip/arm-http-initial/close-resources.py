from datetime import datetime,timezone
from pathlib import Path
import json,subprocess
r=Path('.tmp/ta01-resumption/api-auth-pg-567');n=Path('.tmp/ta01-resumption/api-auth-pg-native-567')
ledger=json.loads((r/'resources.json').read_bytes());i=ledger['containers'][0]['id']
def call(args):return subprocess.run(['docker',*args],capture_output=True,timeout=45)
def save():(r/'resources.json').write_text(json.dumps(ledger,ensure_ascii=False,indent=2)+'\n',encoding='utf8',newline='\n')
for base in [n,n/'context-2',n/'lock-control']:
    x=json.loads((base/'result.json').read_bytes())
    assert x['nodeExitCode']==0 and x['childExitCodes']=={'redis':0,'postgres':0}
for base in [r,r/'arm-seed-2']:
    x=json.loads((base/'result.json').read_bytes());assert x['deadlineReached'] and x['status']=='incomplete' and x['receipts']==[]
x=json.loads(call(['inspect',i]).stdout)[0];c=x['HostConfig']
assert x['Image']==ledger['imageId'] and x['Config']['Labels']['io.workmesh.ta01.probe.owner']==ledger['owner']
assert not x['Mounts'] and not c['Devices'] and not c['Binds'] and not c['PortBindings'] and not c['Privileged']
assert c['NanoCpus']==4000000000 and c['Memory']==c['MemorySwap']==4294967296
code="""
from pathlib import Path
import json
rows=[]
for p in Path('/proc').iterdir():
    if not p.name.isdigit() or not (p/'comm').exists():continue
    name=(p/'comm').read_text().strip()
    if name.startswith(('qemu-system','postgres','redis-server','node')):
        stat=(p/'stat').read_text();state=stat[stat.rfind(')')+2:].split()[0]
        rows.append({'pid':int(p.name),'name':name,'state':state})
print(json.dumps({'matchingProcesses':rows,'active':sum(row['state']!='Z' for row in rows)}))
"""
v=call(['exec',i,'python3','-c',code]);assert v.returncode==0
proof=json.loads(v.stdout);assert proof['active']==0
(r/'before-stop-processes.json').write_bytes(v.stdout)
shared={}
for ref in ['ubuntu:24.04','node:22.19.0-alpine3.21','postgres:16.9-alpine','redis:7.4.5-alpine']:
    v=call(['image','inspect',ref])
    if v.returncode==0:shared[ref]=json.loads(v.stdout)[0]['Id']
ledger['scopeCorrection']={'oldGenericScope':ledger['scope'],'observedAt':datetime.now(timezone.utc).isoformat(),
    'correction':'未注入已有或生产凭据；三次原生过程中生成真实隔离测试身份并走原配对/授权路径。两次ARM实际请求数未知。所有测试密钥与数据仅留独有消费者，未归档磁盘或私有日志。'}
ledger['beforeStopProcessProof']=proof;save()
v=call(['stop','--time','10',i]);ledger['stopExitCode']=v.returncode;save();assert v.returncode==0
x=json.loads(call(['inspect',i]).stdout)[0];assert not x['State']['Running'] and not x['State']['OOMKilled']
ledger['containers'][0].update(exitCode=x['State']['ExitCode'],oom=False,activeRelevantProcessesBeforeStop=0)
save();assert call(['rm',i]).returncode==0
v=call(['inspect',i]);assert v.returncode and b'no such object' in v.stderr.lower()
ledger['containers'][0]['removedAndAbsent']=True;save()
imageClosure=[]
for base in [r,n]:
    images=json.loads((base/'image-resources.json').read_bytes())
    assert all(c['removedAndAbsent'] for c in images['containers'])
    for role,row in images['roles'].items():
        tag=row['tag'];assert not row['preexistingTag']
        x=json.loads(call(['image','inspect',tag]).stdout)[0];assert x['Id']==row['actualImageId']
        consumers=call(['ps','-aq','--no-trunc','--filter','ancestor='+x['Id']]);assert consumers.returncode==0
        if consumers.stdout.strip():
            row['derivedTagRemoval']='retained: active or stopped consumer exists'
        else:
            v=call(['image','rm',tag]);row['removeTagExitCode']=v.returncode
            if v.returncode:row['derivedTagRemoval']='failed; no retry or alternative deletion'
            else:
                v=call(['image','inspect',tag]);assert v.returncode and b'no such image' in v.stderr.lower()
                row['derivedTagRemoval']='removed-and-absent'
        imageClosure.append({'role':role,'tag':tag,'outcome':row['derivedTagRemoval']})
    (base/'image-resources.json').write_text(json.dumps(images,indent=2)+'\n',encoding='utf8')
for ref,expected in shared.items():assert json.loads(call(['image','inspect',ref]).stdout)[0]['Id']==expected
ledger['sharedReferencesStillSame']=shared;ledger['derivedTagClosure']=imageClosure;ledger['closedAt']=datetime.now(timezone.utc).isoformat();save()
print(json.dumps({'controllerRemoved':True,'pid1ExitCode':ledger['containers'][0]['exitCode'],'sharedReferencesKept':len(shared),'derivedTags':imageClosure}))
