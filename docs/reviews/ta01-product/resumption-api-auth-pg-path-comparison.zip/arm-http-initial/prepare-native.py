from pathlib import Path
import ast
r=Path('.tmp/ta01-resumption/api-auth-pg-native-567'); r.mkdir(exist_ok=False)
old=Path('.tmp/ta01-resumption/api-auth-pg-567')
for name in ['fetch-select.py','export.py']:
    s=(old/name).read_text(encoding='utf8').replace('api-auth-pg-567','api-auth-pg-native-567')
    s=s.replace('12032934001','12033760634')
    s=s.replace('391bd59c041d4a7d87a15573d2f03ff07edfddcf6b1233b6f092b75639fd29b4','1e8cb5c8e3eacc3e1de2be0f4bffbbf17e02beffa0b72cd0abe260f4c246c8c5')
    s=s.replace("'arm64'","'amd64'").replace('linux/arm64','linux/amd64').replace('ci566-auth-pg-owned','ci566-auth-pg-amd-owned')
    ast.parse(s); (r/name).write_text(s,encoding='utf8',newline='\n')
