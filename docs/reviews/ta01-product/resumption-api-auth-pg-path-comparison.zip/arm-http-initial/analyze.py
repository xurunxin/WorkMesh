from pathlib import Path
import json
r=Path('.tmp/ta01-resumption/api-auth-pg-567');native=Path('.tmp/ta01-resumption/api-auth-pg-native-567')
def analyze(probe):
    rows=[]
    for t in probe.get('runs',[]):
        queries=t.get('queries',[])
        complete=bool(queries) and t.get('identityCommittedMs') is not None and t.get('authorizedMs') is not None
        byPhase={}
        for q in queries:
            p=byPhase.setdefault(q['phase'],{'queries':0,'clientSqlWallSumMs':0.0})
            p['queries']+=1;p['clientSqlWallSumMs']+=q.get('wallMs',0)
        ordered=sorted(queries,key=lambda q:q['startedMs'])
        nonoverlap=all('wallMs' in a and a['startedMs']+a['wallMs']<=b['startedMs']+0.001 for a,b in zip(ordered,ordered[1:]))
        rows.append({'repeat':t['repeat'],'label':t['label'],'status':t.get('status'),
            'wallMs':t.get('wallMs'),'identityCommittedMs':t.get('identityCommittedMs'),
            'authorizedMs':t.get('authorizedMs'),'handlerTail':t.get('handlerTail'),
            'nodeCpu':t.get('nodeCpu'),'responseBytes':t.get('responseBytes'),
            'control':t.get('control'),
            'instrumentationComplete':complete,'requestWithinOriginal30s':t.get('wallMs',float('inf'))<=30000,
            'queryCount':len(queries),'backendPids':sorted({q['backendPid'] for q in queries}),
            'unfinishedQueries':sum('wallMs' not in q for q in queries),
            'perPhase':byPhase,'clientQueryIntervalsNonoverlapping':nonoverlap,
            'maxAcquireMs':max([q['wallMs'] for q in t.get('acquires',[])],default=None),
            'waitSamples':len(t.get('samples',[])),
            'observedWaitTypes':sorted({row['wait_event_type'] or 'none' for s in t.get('samples',[]) for row in s['rows']}),
            'maxObservedBlockers':max([row['max_blockers'] for s in t.get('samples',[]) for row in s['rows']],default=None),
            'largestStatementExecMs':max([float(x['total_exec_time']) for x in t.get('serverStatements',[])],default=None),
            'largestStatementPlanMs':max([float(x['total_plan_time']) for x in t.get('serverStatements',[])],default=None)})
    return {'rows':rows,'revokedReadStatus':probe.get('revokedReadStatus'),'nodeVersion':probe.get('nodeVersion'),
        'executableSha256':probe.get('executableSha256'),'importsMs':probe.get('importsMs'),
        'postgresSettings':probe.get('postgresSettings'),
        'limits':['SQL wall includes protocol encoding/decoding and callback scheduling; not pure DB wait',
            'pg_stat_statements is isolated whole-database aggregate, may include nested/background work; do not subtract from request wall',
            '250ms sampled waits can miss gaps; zero samples is unavailable, not proof of no lock',
            'handler tail includes validation/serialization/common onSend; process CPU includes V8 threads and monitoring, not a CPU ratio',
            'Node timer is cooperative; external wall check still rejects responses above30000ms',
            'native x86_64 results do not estimate ARM TCG or original CI workload']}
summary={'nativeInitial':analyze(json.loads((native/'result.json').read_bytes()).get('probe',{})),
    'nativeContextFixed':analyze(json.loads((native/'context-2/result.json').read_bytes()).get('probe',{})),
    'armInitial':{'deadlineReached':True,'receipts':0,'actualRequestCount':'unknown','internalStage':'unknown'}}
control=native/'lock-control/result.json'
if control.exists():summary['nativeLockControl']=analyze(json.loads(control.read_bytes()).get('probe',{}))
arm=r/'arm-seed-2/result.json'
if arm.exists():
    a=json.loads(arm.read_bytes());summary['armSeed2']={'result':{k:a.get(k) for k in ['status','qemuExitCode','deadlineReached','elapsedSeconds']},
        'receipts':len(a['receipts'])}
    if a['receipts'] and a['receipts'][0].get('probe'):
        summary['armSeed2']['probe']=analyze(a['receipts'][0]['probe'])
(r/'analysis.json').write_text(json.dumps(summary,indent=2)+'\n',encoding='utf8')
print(json.dumps({'nativeRequests':len(summary['nativeContextFixed']['rows']),
    'nativeCompleteTraces':sum(row['instrumentationComplete'] for row in summary['nativeContextFixed']['rows']),
    'armSeed2':summary.get('armSeed2',{}).get('result')}))
