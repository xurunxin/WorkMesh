from pathlib import Path
import hashlib,json,subprocess,zipfile
r=Path('.tmp/ta01-resumption');name='ci567-amd64-enterprise-full-guest-pass';stem=r/'guest-evidence'/name
x=json.loads(stem.with_suffix('.json').read_bytes());head=x['sourceHead'];assert head=='e2763da4dfdf25f7fc5c28c34a9619d4788f4541'
sha=lambda b:hashlib.sha256(b).hexdigest()
with zipfile.ZipFile(r/'ci567-amd64-enterprise-raw.zip') as z:
    assert z.read('server-install/source.txt')==z.read('server-install/source-after.txt')
    assert z.read('server-install/source.txt').decode().split()==[head,x['sourceTree']]
    inputs={}
    for line in z.read('server-install/input-sha256.txt').decode().splitlines():
        digest,path=line.split('  ',1);assert not path.startswith('/') and '..' not in path.split('/')
        assert sha(subprocess.check_output(['git','show',head+':'+path]))==digest;inputs[path]=digest
    assert len(inputs)==22
    result=json.loads(z.read('server-install/result.json'));manifest=json.loads(z.read('server-install/manifest.json'))
    assert result['arch']==manifest['arch']=='amd64' and result['profilesRequested']==['enterprise']
    assert result['sourceTree']==manifest['source']['tree']==x['sourceTree']
    assert result['guestVcpus']==4 and result['guestRamMiB']==4096 and result['accelerator']=='tcg'
    assert result['qemuVersion']=='QEMU emulator version 8.2.2 (Debian 1:8.2.2+ds-0ubuntu1.18)'
    assert result['imageSha256']=='6a81c37564db9b1ee84e141922625e1d7c5b389b99bb3c572e0243607d5bb4d2'
assert x['producer']['artifactId']=='12042658945'
v=subprocess.run(['gh','api','repos/xurunxin/WorkMesh/actions/artifacts/12042658945'],capture_output=True,timeout=30);assert v.returncode==0
a=json.loads(v.stdout);assert a['digest']=='sha256:d54d6fbd1377769d164ccf95fe83e8cfb987ff7ccc54759d8ce5465dd8e912ac'
x.update(allSourceInputsMatchGit=True,allSourceInputCount=22,guestShapeMatchesJob=True,architecture='amd64',
    candidateArtifactMetadata={k:a[k] for k in ['id','name','digest','size_in_bytes','expired']})
stem.with_suffix('.json').write_text(json.dumps(x,ensure_ascii=False,indent=2)+'\n',encoding='utf8',newline='\n')
target=Path('docs/reviews/ta01-product')/name
for ext in ['.json','.zip']:
    assert not target.with_suffix(ext).exists();target.with_suffix(ext).write_bytes(stem.with_suffix(ext).read_bytes())
print(json.dumps({'sourceInputs':22,'scripts':6,'status':x['status'],'producerArtifact':x['producer']['artifactId'],'members':len(x['members'])}))
