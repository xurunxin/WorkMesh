from pathlib import Path
import json,subprocess
r=Path('.tmp/ta01-resumption/api-auth-pg-567'); l=json.loads((r/'resources.json').read_bytes()); i=l['containers'][0]['id']
v=subprocess.run(['docker','inspect',i],capture_output=True,timeout=30); assert v.returncode==0
x=json.loads(v.stdout)[0]; c=x['HostConfig']
assert x['Config']['Labels']['io.workmesh.ta01.probe.owner']==l['owner'] and x['Image']==l['imageId']
assert c['NanoCpus']==4000000000 and c['Memory']==c['MemorySwap']==4294967296
assert not c['Privileged'] and not c['Devices'] and not c['Binds'] and not c['PortBindings'] and not x['Mounts']
controls={k:c[k] for k in ['NanoCpus','Memory','MemorySwap','Privileged','Devices','Binds','PortBindings','SecurityOpt','PidsLimit']}
(r/'outer-controls.json').write_text(json.dumps(controls,indent=2)+'\n',encoding='utf8')
code="from pathlib import Path;import json; names=[(p/'comm').read_text().strip() for p in Path('/proc').iterdir() if p.name.isdigit() and (p/'comm').exists()];print(json.dumps({'qemuCount':sum(x.startswith('qemu-system') for x in names),'nodeCount':sum(x=='node' for x in names),'hostKernel':__import__('os').uname().release,'hostMachine':__import__('os').uname().machine}))"
v=subprocess.run(['docker','exec',i,'python3','-c',code],capture_output=True,timeout=30); assert v.returncode==0
(r/'outer-metadata.json').write_bytes(v.stdout)
for name,args in [('qemu-sha256',['sha256sum','/usr/bin/qemu-system-aarch64']),('qemu-packages',['dpkg-query','-W','qemu-system-arm','qemu-utils','qemu-efi-aarch64','ipxe-qemu','ipxe-qemu-256k-compat-efi-roms'])]:
    v=subprocess.run(['docker','exec',i,*args],capture_output=True,timeout=30); assert v.returncode==0
    (r/(name+'.stdout')).write_bytes(v.stdout); (r/(name+'.stderr')).write_bytes(v.stderr)
print(json.dumps({'controlsValidated':True,**json.loads((r/'outer-metadata.json').read_bytes())}))
