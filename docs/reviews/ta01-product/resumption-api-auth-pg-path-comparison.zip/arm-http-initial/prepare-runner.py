from pathlib import Path
import ast,json
r=Path('.tmp/ta01-resumption/api-auth-pg-567')
s=Path('.tmp/ta01-resumption/api-manifest-arm-566/used-run-component-tcg.py').read_text(encoding='utf8')
old="names = ['node-rootfs.tar.gz', *([] if exact_role else ['runtime.tar']), 'startup.mjs' if startup else 'measurement.mjs']"
assert s.count(old)==1
s=s.replace(old,"names = ['api-rootfs.tar.gz', 'postgres-rootfs.tar.gz', 'redis-rootfs.tar.gz', 'measurement.mjs']")
s=s.replace("'api-manifest-pure-cost'","'api-auth-pg-path'")
ast.parse(s)
(r/'run-guest.py').write_text(s,encoding='utf8',newline='\n')
(r/'node-sha256.txt').write_text('da2abd2c48f19561e35478d51583b068ab410f888a09f363bd131ab611392cb7\n',encoding='utf8')
(r/'prelaunch-errors.json').write_text(json.dumps({'firstFailure':'PowerShell ParserError in inline runner generation; no Python or VM started',
    'secondFailure':'start-run.py AST preflight missing run-guest.py; no inputs copied or VM started',
    'correction':'standalone UTF-8 runner generation with exact one-match replacement and AST check; no product retry'},indent=2)+'\n',encoding='utf8')
