import hashlib
import json
from pathlib import Path
import re
import subprocess
import sys
import zipfile

raw_name, stem_name, run, job, artifact = sys.argv[1:]
head = 'e2763da4dfdf25f7fc5c28c34a9619d4788f4541'
sha = lambda data: hashlib.sha256(data).hexdigest()
raw = Path('.tmp/ta01-resumption') / raw_name
if not raw.exists():
    with raw.open('xb') as output:
        fetched = subprocess.run(['gh', 'api', f'repos/xurunxin/WorkMesh/actions/artifacts/{int(artifact)}/zip'], stdout=output, stderr=subprocess.PIPE)
    assert fetched.returncode == 0, 'artifact download failed; stderr withheld'
with zipfile.ZipFile(raw) as archive:
    members = {name: archive.read(name) for name in archive.namelist() if name.startswith('server-install/')}
result = json.loads(members['server-install/result.json'])
assert result['sourceHead'] == head
assert len(result['scripts']) == 6
for name, expected in result['scripts'].items():
    assert name.endswith('.py') and '/' not in name and '\\' not in name
    assert sha(subprocess.check_output(['git', 'show', head + ':scripts/server-distribution/' + name])) == expected
producer = json.loads(members['server-install/producer.json'])
assert sha(members['server-install/manifest.json']) == producer['manifestSha256'] == result['manifestSha256']
assert json.loads(members['server-install/manifest.json'])['source']['commit'] == head
if result['status'] == 'passed':
    before, after = result['receipts']
    profiles = result['profilesRequested']
    assert len(profiles) == 1 and result['scope'] == 'single-configuration'
    assert before['phase'] == 'before-reboot' and after['phase'] == 'after-reboot'
    assert before['profilesRequested'] == after['profilesRequested'] == profiles
    assert before['bootId'] != after['bootId'] and before['kernel'] and after['kernel']
    assert [entry['profile'] for entry in before['profiles']] == after['restartedProfiles'] == profiles
    assert all(entry['status'] == 'passed' for entry in before['profiles'])
    assert {entry['event'] for entry in result['qmpEvents']} >= {'RESET', 'SHUTDOWN'}
    assert result['qemuExitCode'] == 0
    assert len(after['checks']) == 1 and after['checks'][0]['profile'] == profiles[0]
    assert set(after['checks'][0]['checks']) >= {'authenticatedApiAfterReboot', 'authenticatedMcpAfterReboot',
        'artifactBytesAfterReboot', 'newOutboxDeliveredAfterReboot'}
records, decoder = [], json.JSONDecoder()
serial = members['server-install/serial.log'].decode('utf8', errors='replace')
for match in re.finditer(r'\{"tag": "ta01-(?:install-action|progress|installer-phase|failure|api-read-timings)"', serial):
    value, _ = decoder.raw_decode(serial, match.start())
    records.append(value)
for data in members.values():
    assert not re.search(rb'wm[ips]_[A-Za-z0-9_-]{43}', data)
index = {key: result.get(key) for key in ['sourceHead', 'sourceTree', 'status', 'errorType', 'totalSeconds',
    'guestVcpus', 'guestRamMiB', 'manifestSha256', 'scripts', 'nativeDiagnostic', 'profilesRequested',
    'scope', 'qemuExitCode', 'qmpEvents', 'rebootSeconds'] if key in result}
index.update({'说明': '原始完整guest结果；single-configuration只证明其准确画像与架构，不代六组合。诊断模式非支持验收；真实故障、未知和通过分别保留，不推旧故障已修复。',
    'runId': int(run), 'jobId': int(job), 'artifactId': int(artifact), 'scriptsMatchGit': True,
    'producer': producer, 'receipts': result['receipts'], 'records': records,
    'artifactZipSha256': sha(raw.read_bytes()),
    'members': {name: {'bytes': len(data), 'sha256': sha(data)} for name, data in members.items()}})
stem = Path('.tmp/ta01-resumption/guest-evidence') / stem_name
with zipfile.ZipFile(stem.with_suffix('.zip'), 'x', compression=zipfile.ZIP_DEFLATED) as archive:
    for name, data in members.items():
        archive.writestr(name, data)
index['selectedZipSha256'] = sha(stem.with_suffix('.zip').read_bytes())
with stem.with_suffix('.json').open('x', encoding='utf8', newline='\n') as output:
    json.dump(index, output, ensure_ascii=False, indent=2)
    output.write('\n')
brief = {key: index.get(key) for key in ['status', 'errorType', 'totalSeconds', 'scope', 'profilesRequested', 'producer', 'qemuExitCode', 'rebootSeconds']}
brief['members'] = len(members)
brief['receipts'] = []
for receipt in result['receipts']:
    diag = receipt.get('diagnostics', {})
    brief['receipts'].append({'phase': receipt['phase'], 'profiles': receipt.get('profiles'),
        'restartedProfiles': receipt.get('restartedProfiles'), 'checks': receipt.get('checks'),
        'bootId': receipt.get('bootId'), 'nativeTrace': diag.get('nativeTrace', receipt.get('nativeTrace')),
        'proxy': diag.get('mcpProxyProgress'), 'databaseBudget': diag.get('databaseBudget'),
        'events': diag.get('containerEvents'),
        'reads': [{key: value for key, value in row.items() if key != 'containers'} for row in diag.get('installer', [])]})
print(json.dumps(brief, indent=2))
