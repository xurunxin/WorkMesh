from pathlib import Path
import hashlib,json,subprocess,sys,zipfile
r=Path('.tmp/ta01-resumption');work=r/'api-auth-pg-567';head='e2763da4dfdf25f7fc5c28c34a9619d4788f4541'
v=subprocess.run(['gh','api','repos/xurunxin/WorkMesh/actions/runs/38893305755/artifacts?per_page=100'],capture_output=True,timeout=30);assert v.returncode==0
artifacts=json.loads(v.stdout)['artifacts']; rows=[]
for profile,job in [('personal',116950873995),('team',116950873839)]:
    a=next(a for a in artifacts if a['name']==f'server-install-raw-amd64-{profile}-38893305755-1')
    name=f'ci567-amd64-{profile}-full-guest-pass';raw_name=f'ci567-amd64-{profile}-raw.zip'
    v=subprocess.run([sys.executable,str(work/'inspect-ci567-guest.py'),raw_name,name,'38893305755',str(job),str(a['id'])],capture_output=True,timeout=120)
    (work/f'ci567-{profile}-inspection.stdout').write_bytes(v.stdout);(work/f'ci567-{profile}-inspection.stderr').write_bytes(v.stderr)
    assert v.returncode==0
    raw=r/raw_name;assert 'sha256:'+hashlib.file_digest(raw.open('rb'),'sha256').hexdigest()==a['digest']
    stem=r/'guest-evidence'/name;x=json.loads(stem.with_suffix('.json').read_bytes());assert x['status']=='passed'
    with zipfile.ZipFile(raw) as z:
        assert z.read('server-install/source.txt')==z.read('server-install/source-after.txt')
        assert z.read('server-install/source.txt').decode().split()==[head,x['sourceTree']]
        for line in z.read('server-install/input-sha256.txt').decode().splitlines():
            digest,path=line.split('  ',1); assert hashlib.sha256(subprocess.check_output(['git','show',head+':'+path])).hexdigest()==digest
        assert len(z.read('server-install/input-sha256.txt').decode().splitlines())==22
        result=json.loads(z.read('server-install/result.json'))
        assert result['arch']=='amd64' and result['profilesRequested']==[profile] and result['scope']=='single-configuration'
        assert result['guestVcpus']==4 and result['guestRamMiB']==4096 and result['accelerator']=='tcg'
        assert result['qemuVersion']=='QEMU emulator version 8.2.2 (Debian 1:8.2.2+ds-0ubuntu1.18)'
        assert result['imageSha256']=='6a81c37564db9b1ee84e141922625e1d7c5b389b99bb3c572e0243607d5bb4d2'
    assert x['producer']=={'artifactId':'12042658945','manifestSha256':'75aaf2410024455f35c06274cc63f9b818795c8e2a830b28161079e4eaf1f28e'}
    x.update(allSourceInputsMatchGit=True,allSourceInputCount=22,guestShapeMatchesJob=True,architecture='amd64')
    stem.with_suffix('.json').write_text(json.dumps(x,ensure_ascii=False,indent=2)+'\n',encoding='utf8',newline='\n')
    target=Path('docs/reviews/ta01-product')/name
    for ext in ['.json','.zip']:
        assert not target.with_suffix(ext).exists();target.with_suffix(ext).write_bytes(stem.with_suffix(ext).read_bytes())
    rows.append({'profile':profile,'artifactId':a['id'],'rawZipSha256':a['digest'],'seconds':x['totalSeconds'],'rebootSeconds':x['rebootSeconds']})
(work/'ci567-amd-remaining.json').write_text(json.dumps(rows,indent=2)+'\n',encoding='utf8')
print(json.dumps(rows))
