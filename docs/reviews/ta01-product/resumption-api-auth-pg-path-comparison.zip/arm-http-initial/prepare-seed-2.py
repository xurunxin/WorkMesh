from pathlib import Path
import ast,json
old=Path('.tmp/ta01-resumption/api-auth-pg-567');r=old/'arm-seed-2';r.mkdir(exist_ok=False)
s=(old/'guest.py').read_text(encoding='utf8')
s=s.replace('import hashlib,json,os,resource,subprocess,time,urllib.request','import hashlib,json,os,resource,shutil,subprocess,time,urllib.request')
s=s.replace("def stage(name): receipt['stages'].append({'name':name,'elapsedSeconds':time.monotonic()-began})", "def stage(name):\n        value={'name':name,'elapsedSeconds':time.monotonic()-began}\n        receipt['stages'].append(value)\n        print(json.dumps({'tag':'ta01-api-auth-probe-stage',**value}),flush=True)")
oldblock="""        for name,digest in expected['inputs'].items():
            assert name in {'api-rootfs.tar.gz','postgres-rootfs.tar.gz','redis-rootfs.tar.gz','measurement.mjs'}
            target=base/name
            with urllib.request.urlopen('http://10.0.2.2:18080/'+name,timeout=60) as response,target.open('xb') as out:
                while b:=response.read(1024*1024): out.write(b)
            assert sha(target)==digest
"""
newblock="""        stage('guest-identity-verified')
        seed=Path('/dev/disk/by-label/cidata'); assert seed.is_block_device()
        seed_root=base/'seed-inputs'; seed_root.mkdir(exist_ok=False)
        run(['mount','-o','ro,nodev,nosuid,noexec',str(seed),str(seed_root)])
        for name,digest in expected['inputs'].items():
            assert name in {'api-rootfs.tar.gz','postgres-rootfs.tar.gz','redis-rootfs.tar.gz','measurement.mjs'}
            target=base/name; assert not target.exists() and (seed_root/name).is_file()
            shutil.copyfile(seed_root/name,target)
            assert sha(target)==digest
        run(['umount',str(seed_root)])
"""
assert s.count(oldblock)==1;s=s.replace(oldblock,newblock)
s=s.replace("            null=root/'dev/null'", "            shm=root/'dev/shm'; shm.mkdir(exist_ok=True); shm.chmod(0o1777)\n            null=root/'dev/null'")
ast.parse(s);(r/'guest.py').write_text(s,encoding='utf8',newline='\n')
s=(old/'run-guest.py').read_text(encoding='utf8').replace("root = Path('/opt/micro')","root = Path('/opt/arm-seed-2')")
oldline="str(run / 'user-data'), str(run / 'meta-data')],"
assert s.count(oldline)==1
s=s.replace(oldline,"str(run / 'user-data'), str(run / 'meta-data'), *[str(root / name) for name in names]],")
ast.parse(s);(r/'run-guest.py').write_text(s,encoding='utf8',newline='\n')
s=(old/'start-run.py').read_text(encoding='utf8').replace("r=Path('.tmp/ta01-resumption/api-auth-pg-567')","r=Path('.tmp/ta01-resumption/api-auth-pg-567/arm-seed-2')")
s=s.replace("(r/'resources.json')","(r.parent/'resources.json')")
s=s.replace("inputs={name:r/name for name in ['api-rootfs.tar.gz','postgres-rootfs.tar.gz','redis-rootfs.tar.gz','node-sha256.txt']}","inputs={name:r.parent/name for name in ['api-rootfs.tar.gz','postgres-rootfs.tar.gz','redis-rootfs.tar.gz','node-sha256.txt']}")
s=s.replace('/opt/micro','/opt/arm-seed-2')
ast.parse(s);(r/'start-run.py').write_text(s,encoding='utf8',newline='\n')
(r/'changes.json').write_text(json.dumps({'firstAttempt':'1200s deadlineReached, host SIGTERM, QEMU0, no receipts; stage and actual request count unknown',
    'nativePreflight':'exact CI566 AMD roles, corrected request context, six real reads and post-revocation401; not ARM evidence',
    'fixtureChanges':['same existing read-only cidata drive supplies identical hash-bound public role inputs; no added virtual device',
        'restore private /dev/shm directory mode1777 as in native preflight; exported directory was0755',
        'bounded provisioning stage tags; original first attempt stage remains unknown'],
    'budgets':{'vcpus':4,'ramMiB':4096,'vmSeconds':1200,'nodeSeconds':600,'requestMs':30000},
    'claimsFirstFailureRootCause':False,'productChanges':False},indent=2)+'\n',encoding='utf8')
