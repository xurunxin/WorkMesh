from pathlib import Path
import hashlib,json,subprocess,sys,zipfile
r=Path('.tmp/ta01-resumption');out=r/'api-auth-pg-567'
source=(r/'inspect-ci566-guest.py').read_text(encoding='utf8').replace('541f6ba64841915801a1ccb123f9adb7f61ebe17','e2763da4dfdf25f7fc5c28c34a9619d4788f4541')
(out/'inspect-ci567-guest.py').write_text(source,encoding='utf8')
args=[sys.executable,str(out/'inspect-ci567-guest.py'),'ci567-amd64-enterprise-raw.zip','ci567-amd64-enterprise-full-guest-pass','38893305755','116950873944','12045015440']
v=subprocess.run(args,capture_output=True,timeout=120)
(out/'ci567-enterprise-inspection.stdout').write_bytes(v.stdout);(out/'ci567-enterprise-inspection.stderr').write_bytes(v.stderr)
assert v.returncode==0,'guest verification failed; log retained'
raw=r/'ci567-amd64-enterprise-raw.zip'
assert hashlib.file_digest(raw.open('rb'),'sha256').hexdigest()=='0c6a7d0c1c7591d40f5cc5954c962cf0b1bc68bed23d62eb4f12a8fdeaadbf24'
x=json.loads((r/'guest-evidence/ci567-amd64-enterprise-full-guest-pass.json').read_bytes())
print(json.dumps({k:x[k] for k in ['status','sourceHead','totalSeconds','rebootSeconds','manifestSha256']}))
