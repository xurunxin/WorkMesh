from pathlib import Path
import json,subprocess
r=Path('.tmp/ta01-resumption/api-auth-pg-567'); i=json.loads((r/'resources.json').read_bytes())['containers'][0]['id']
code="""
from pathlib import Path
import json
rows=[]
allowed={'/opt/micro/api-rootfs.tar.gz','/opt/micro/postgres-rootfs.tar.gz','/opt/micro/redis-rootfs.tar.gz'}
for p in Path('/proc').iterdir():
    if not p.name.isdigit(): continue
    try:
        for f in (p/'fd').iterdir():
            try:
                path=str(f.resolve())
                if path in allowed:
                    pos=next(x.split()[1] for x in (p/'fdinfo'/f.name).read_text().splitlines() if x.startswith('pos:'))
                    rows.append({'input':Path(path).name,'readPosition':int(pos),'bytes':Path(path).stat().st_size})
            except (OSError,StopIteration): pass
    except OSError: pass
print(json.dumps({'openExpectedInputFiles':rows}))
"""
v=subprocess.run(['docker','exec',i,'python3','-c',code],capture_output=True,timeout=30); assert v.returncode==0
(r/'input-progress.json').write_bytes(v.stdout)
print(v.stdout.decode())
