from datetime import datetime,timezone
from pathlib import Path
import hashlib,json
r=Path('.tmp/ta01-resumption/api-auth-pg-567');n=Path('.tmp/ta01-resumption/api-auth-pg-native-567')
l=json.loads((r/'resources.json').read_bytes());assert l['containers'][0]['removedAndAbsent']
l['containers'][0]['creationPurpose']=l['containers'][0]['purpose']
l['containers'][0]['purpose']='2 fixed-budget ARM component guests plus 3 native isolated API/PG/Redis probes; all relevant processes stopped before removal'
l['scope']=l['scopeCorrection']['correction'];l['metadataUpdatedAt']=datetime.now(timezone.utc).isoformat()
(r/'resources.json').write_text(json.dumps(l,ensure_ascii=False,indent=2)+'\n',encoding='utf8',newline='\n')
p=json.loads((n/'lock-control/result.json').read_bytes())['probe'];trace=p['runs'][-1]
query=max(trace['queries'],key=lambda q:q['wallMs']);matches=[s for s in trace['serverStatements'] if s['textSha256']==query['textSha256']]
assert len(matches)==1 and p['sqlTemplates'][query['textSha256']].startswith('SELECT connection.*')
assert query['phase']=='identity' and trace['control']['requestedHoldSeconds']==1 and len(trace['samples'])==4
assert all(any(row['wait_event_type']=='Lock' and row['wait_event']=='transactionid' and row['max_blockers']==1 for row in sample['rows']) for sample in trace['samples'])
proof={'description':'仅原生独有凭据行锁的阳性对照；不推原CI发生同类等待。相同SQL模板SHA精确匹配客户端与PG统计；锁等待源由独有事务明确控制。',
    'clientQuery':query,'serverStatement':matches[0],'control':trace['control'],'requestWallMs':trace['wallMs'],
    'maxAcquireMs':max(row['wallMs'] for row in trace['acquires']),'samples':trace['samples'],
    'serverExecutionTimeIsCpuTime':False,'provesOriginalCiLockWait':False}
(r/'controlled-lock-proof.json').write_text(json.dumps(proof,ensure_ascii=False,indent=2)+'\n',encoding='utf8')
# 同版本的原始工具快照和各次实际输入分别核字节，后续代码不倒填。
for path,expected in [
    (r/'used-first-measurement.mjs',json.loads((r/'used-inputs.json').read_bytes())['measurement.mjs']['sha256']),
    (r/'used-context-measurement.mjs',json.loads((r/'arm-seed-2/used-inputs.json').read_bytes())['measurement.mjs']['sha256']),
    (n/'context-2/used-measurement.mjs',json.loads((n/'context-2/inputs.json').read_bytes())['measurement.mjs']),
    (Path('docs/reviews/ta01-product/tools/api-auth-pg-path-probe.mjs'),json.loads((n/'lock-control/inputs.json').read_bytes())['measurement.mjs'])]:
    assert hashlib.sha256(path.read_bytes()).hexdigest()==expected
print(json.dumps({'controlledStatementMatched':True,'waitSamples':4,'actualToolSnapshotsMatched':4,'controllerRemoved':True}))
