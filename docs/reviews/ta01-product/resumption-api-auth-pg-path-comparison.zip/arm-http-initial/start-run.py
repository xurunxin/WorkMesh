from pathlib import Path
import ast,hashlib,json,subprocess
r=Path('.tmp/ta01-resumption/api-auth-pg-567'); l=json.loads((r/'resources.json').read_bytes()); i=l['containers'][0]['id']
assert l['exactQemuPackageAvailable'] and l['aptInstallExitCode']==0
for p in [r/'guest.py',r/'run-guest.py',r/'start-run.py']:
    ast.parse(p.read_text(encoding='utf8'))
inputs={name:r/name for name in ['api-rootfs.tar.gz','postgres-rootfs.tar.gz','redis-rootfs.tar.gz','node-sha256.txt']}
inputs.update({'component-tcg-guest.py':r/'guest.py','run-component-tcg.py':r/'run-guest.py',
    'measurement.mjs':Path('docs/reviews/ta01-product/tools/api-auth-pg-path-probe.mjs'),
    'arm64.img':Path('.tmp/ta01-resumption/local-guest-image-cache/arm64-1d6bffe6.img')})
node='D:/Cache/TEMP/workmesh-ta00-nf20n0st/node-v22.19.0-win-x64/node.exe'
assert subprocess.run([node,'--check',str(inputs['measurement.mjs'])],capture_output=True,timeout=30).returncode==0
meta={}
for name,path in inputs.items():
    with path.open('rb') as f: checksum=hashlib.file_digest(f,'sha256').hexdigest()
    meta[name]={'bytes':path.stat().st_size,'sha256':checksum}
assert meta['arm64.img']['sha256']=='1d6bffe64b848468ac97f821d369a4846d983de1800ccf6b5ec8853e85cefc55'
(r/'used-inputs.json').write_text(json.dumps(meta,indent=2)+'\n',encoding='utf8')
assert subprocess.run(['docker','exec',i,'mkdir','/opt/micro'],capture_output=True,timeout=30).returncode==0
for name,path in inputs.items():
    v=subprocess.run(['docker','cp',str(path),i+':/opt/micro/'+name],capture_output=True,timeout=180)
    assert v.returncode==0,'input copy failed; no VM launched'
with (r/'runner.stdout').open('xb') as out,(r/'runner.stderr').open('xb') as err:
    v=subprocess.run(['docker','exec',i,'python3','/opt/micro/run-component-tcg.py','--exact-mcp-role','--arm64'],stdout=out,stderr=err,timeout=1250)
(r/'runner-exit.json').write_text(json.dumps({'runnerExitCode':v.returncode})+'\n',encoding='utf8')
for remote,name in [('guest/result.json','result.json'),('guest/serial.log','serial.log'),('guest/qemu-stderr.log','qemu-stderr.log')]:
    with (r/name).open('xb') as out:
        z=subprocess.run(['docker','exec',i,'cat','/opt/micro/'+remote],stdout=out,stderr=subprocess.PIPE,timeout=30)
    assert z.returncode==0
result=json.loads((r/'result.json').read_bytes())
print(json.dumps({'runnerExitCode':v.returncode,'status':result['status'],'qemuExitCode':result.get('qemuExitCode'),'elapsedSeconds':result['elapsedSeconds'],'receipts':len(result['receipts'])}))
