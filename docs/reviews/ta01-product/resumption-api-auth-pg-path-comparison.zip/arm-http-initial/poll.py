from pathlib import Path
import json,subprocess
r=Path('.tmp/ta01-resumption/api-auth-pg-567'); i=json.loads((r/'resources.json').read_bytes())['containers'][0]['id']
v=subprocess.run(['docker','exec',i,'sh','-c','tail -c 900 /opt/micro/guest/serial.log'],capture_output=True,timeout=15)
print(v.stdout.decode('utf8','replace'))
