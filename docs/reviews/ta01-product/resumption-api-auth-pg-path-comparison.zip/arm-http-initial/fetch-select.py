from pathlib import Path
import hashlib, json, subprocess, zipfile, io, tarfile

r=Path('.tmp/ta01-resumption/api-auth-pg-567')
artifact=json.loads(subprocess.check_output(['gh','api','repos/xurunxin/WorkMesh/actions/artifacts/12032934001']))
assert artifact['id']==12032934001 and not artifact['expired']
(r/'artifact.json').write_text(json.dumps({k:artifact[k] for k in ['id','name','digest','size_in_bytes','expired']},indent=2)+'\n',encoding='utf8')
with (r/'candidate.zip').open('xb') as out:
    v=subprocess.run(['gh','api','repos/xurunxin/WorkMesh/actions/artifacts/12032934001/zip'],stdout=out,stderr=subprocess.PIPE,timeout=180)
assert v.returncode==0
assert (r/'candidate.zip').stat().st_size==artifact['size_in_bytes']
assert 'sha256:'+hashlib.file_digest((r/'candidate.zip').open('rb'),'sha256').hexdigest()==artifact['digest']
with zipfile.ZipFile(r/'candidate.zip') as z:
    raw=z.read('manifest.json'); (r/'manifest.json').write_bytes(raw); m=json.loads(raw)
assert hashlib.sha256(raw).hexdigest()=='391bd59c041d4a7d87a15573d2f03ff07edfddcf6b1233b6f092b75639fd29b4'
assert m['source']['commit']=='541f6ba64841915801a1ccb123f9adb7f61ebe17'

class Parts(io.RawIOBase):
    def __init__(self,z): self.z=z; self.i=0; self.f=None; self.h=None; self.n=0
    def readable(self): return True
    def read(self,n=-1):
        assert n>=0
        out=bytearray()
        while len(out)<n:
            if self.f is None:
                if self.i==len(m['chunks']): break
                self.f=self.z.open(m['chunks'][self.i]['path']); self.h=hashlib.sha256(); self.n=0
            b=self.f.read(n-len(out))
            if b: self.h.update(b); self.n+=len(b); out+=b
            else:
                row=m['chunks'][self.i]
                assert self.h.hexdigest()==row['sha256'] and self.n==row['bytes']
                self.f.close(); self.f=None; self.i+=1
        return bytes(out)

def walk(visitor):
    with zipfile.ZipFile(r/'candidate.zip') as z:
        p=Parts(z)
        with tarfile.open(fileobj=p,mode='r|') as t:
            for x in t:
                assert x.isfile() or x.isdir()
                if x.isfile(): visitor(x,t.extractfile(x))
        while p.read(1024*1024): pass
        assert p.i==len(m['chunks'])

small={}; inventory={}
def first(x,f):
    h=hashlib.sha256(); b=bytearray(); size=0
    while v:=f.read(1024*1024):
        h.update(v); size+=len(v)
        if x.size<=1024*1024: b+=v
    assert size==x.size and x.name not in inventory
    digest=h.hexdigest()
    if x.name.startswith('blobs/sha256/'): assert x.name.split('/')[-1]==digest
    inventory[x.name]={'bytes':size,'sha256':digest}
    if x.size<=1024*1024: small[x.name]=bytes(b)
walk(first)
roles={}; needed=set(); index=json.loads(small['index.json'])
for role in ['api','postgres','redis']:
    image=m['images'][role]; md=image['archiveId'].split(':')[1]; cd=image['id'].split(':')[1]
    manifest=json.loads(small['blobs/sha256/'+md]); assert manifest['config']['digest']=='sha256:'+cd
    config=json.loads(small['blobs/sha256/'+cd]); assert config['architecture']=='arm64'
    if role=='api': assert config['config']['Labels']['org.opencontainers.image.revision']==m['source']['commit']
    descs=[x for x in index['manifests'] if x['digest']==image['archiveId']]; assert len(descs)==1
    files={'blobs/sha256/'+md,'blobs/sha256/'+cd}|{'blobs/sha256/'+x['digest'].split(':')[1] for x in manifest['layers']}
    for row in [manifest['config'],*manifest['layers']]: assert inventory['blobs/sha256/'+row['digest'].split(':')[1]]['bytes']==row['size']
    tag='workmesh-ta01-diagnostic/'+role+':ci566-auth-pg-owned'
    desc=dict(descs[0]); desc['annotations']={'io.containerd.image.name':'docker.io/'+tag,'org.opencontainers.image.ref.name':tag}
    roles[role]={'image':image,'tag':tag,'manifest':manifest,'config':config,'descriptor':desc,'files':sorted(files)}
    needed|=files
newindex=json.dumps({'schemaVersion':2,'manifests':[v['descriptor'] for v in roles.values()]},separators=(',',':')).encode()
classic=json.dumps([{'Config':'blobs/sha256/'+v['image']['id'].split(':')[1],'RepoTags':[v['tag']],'Layers':['blobs/sha256/'+x['digest'].split(':')[1] for x in v['manifest']['layers']]} for v in roles.values()],separators=(',',':')).encode()
with (r/'selected.tar').open('xb') as out,tarfile.open(fileobj=out,mode='w|') as t:
    for name,data in [('oci-layout',small['oci-layout']),('index.json',newindex),('manifest.json',classic)]:
        info=tarfile.TarInfo(name); info.size=len(data); t.addfile(info,io.BytesIO(data))
    copied=set()
    def second(x,f):
        if x.name in needed: t.addfile(x,f); copied.add(x.name)
    walk(second); assert copied==needed
report={'source':m['source'],'sourceArtifact':artifact['id'],'manifestSha256':hashlib.sha256(raw).hexdigest(),'roles':roles,'allApplicationChunksVerifiedTwice':True,'selectedBlobs':{k:inventory[k] for k in sorted(needed)},'selectedTarBytes':(r/'selected.tar').stat().st_size,'selectedTarSha256':hashlib.file_digest((r/'selected.tar').open('rb'),'sha256').hexdigest()}
(r/'extraction.json').write_text(json.dumps(report,indent=2)+'\n',encoding='utf8')
print(json.dumps({'sourceVerified':True,'roles':list(roles),'subsetBytes':report['selectedTarBytes']}))
