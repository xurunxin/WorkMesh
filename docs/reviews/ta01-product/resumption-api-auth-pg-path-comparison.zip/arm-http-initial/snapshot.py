from datetime import datetime,timezone
from pathlib import Path
import json,subprocess
r=Path('.tmp/ta01-resumption/api-auth-pg-567')
def api(path):
    v=subprocess.run(['gh','api','repos/xurunxin/WorkMesh/'+path],capture_output=True,timeout=30)
    assert v.returncode==0
    return json.loads(v.stdout)
run=api('actions/runs/38893305755'); jobs=api('actions/runs/38893305755/jobs?per_page=100')['jobs']
pr=api('pulls/228'); main=api('git/ref/heads/main')
projection={'observedAt':datetime.now(timezone.utc).isoformat(),
    'run':{k:run[k] for k in ['id','run_number','head_sha','status','conclusion','created_at','updated_at']},
    'jobs':[{k:j[k] for k in ['id','name','status','conclusion','started_at','completed_at']} for j in jobs],
    'pr':{'number':pr['number'],'draft':pr['draft'],'state':pr['state'],'merged':pr['merged'],'head':pr['head']['sha']},
    'main':{'ref':main['ref'],'sha':main['object']['sha']},'executorCancelledOrRerun':False}
target=r/'ci567-snapshot.json'
target.write_text(json.dumps(projection,indent=2)+'\n',encoding='utf8')
print(json.dumps({'observedAt':projection['observedAt'],'head':pr['head']['sha'],'runStatus':run['status'],
    'guests':[{k:j[k] for k in ['id','name','status','conclusion']} for j in jobs if j['name'].startswith('Server full')]}))
