from pathlib import Path
import re
p=Path('docs/plan/ta01-self-hosted-deployment/current-delivery.md')
s=p.read_text(encoding='utf8')
for a,b in [('max_connections20','`max_connections=20`'),('shared_buffers64MB','`shared_buffers=64MB`'),
    ('Node22.19.0','Node 22.19.0'),('QEMU8.2.2','QEMU 8.2.2'),('Node0','Node 退出0'),('QEMU0','QEMU 退出0'),
    ('VM1,200','VM 1,200'),('Node600','Node 600'),('Client90','Client 90'),('guest4','guest 4'),('job210','job 210')]:s=s.replace(a,b)
parts=re.split(r'(`[^`]*`|\]\([^)]*\))',s)
for i in range(0,len(parts),2):
    text=parts[i]
    text=re.sub(r'(?<=[\u4e00-\u9fff])(?=[A-Za-z0-9])|(?<=[A-Za-z0-9])(?=[\u4e00-\u9fff])',' ',text)
    text=re.sub(r'\b(\d+(?:,\d{3})*(?:\.\d+)?)(ms|bytes|MB|GiB|s)\b',r'\1 \2',text)
    parts[i]=text
p.write_text(''.join(parts),encoding='utf8',newline='\n')
p=Path('docs/integration/server-installation.md');s=p.read_text(encoding='utf8')
s=s.replace('本轮真实受测为 `541f6ba`／CI566。','已归档的 CI566 受测为 `541f6ba`。',1)
marker='## 当前状态\n\n'
assert s.count(marker)==1
s=s.replace(marker,marker+'最新观测为 CI567／run38893305755，绑定 `e2763da`：三组 AMD 已核完整重启通过，三组 ARM 仍在运行，Required 尚未齐备。新通过不关闭旧 API／MCP139。独立 API 角色的真实配对／PG 原生测量及行锁阳性对照已完成；两次 ARM 组件过程达原 1,200 秒、无请求回执，不冒个人 Lite 镜像复现或完整验收。准确来源与缺口见[当前报告](../plan/ta01-self-hosted-deployment/current-delivery.md)。本次资料提交使用 `[skip ci]` 保留在途原运行，不能作为可合入候选。\n\n',1)
p.write_text(s,encoding='utf8',newline='\n')
p=Path('docs/plan/ta01-self-hosted-deployment/acceptance-matrix.md');s=p.read_text(encoding='utf8')
at=s.index('\n## ')
section='''
## CI567 在途观测与本轮组件测量

CI567／run38893305755 绑定 `e2763da4dfdf25f7fc5c28c34a9619d4788f4541`。执行者 2026-10-16 12:43:17 UTC 核三组 AMD 完整重启通过，三组 ARM 仍在运行；Required 尚未齐备。下列 CI566 及更早章节继续保留各自历史来源，不套用新 head。

| 画像 | AMD64 原件 | ARM64 当前状态 |
| --- | --- | --- |
| 个人 | [通过](../../reviews/ta01-product/ci567-amd64-personal-full-guest-pass.json)，job116950873995 | job116950873965，in_progress |
| 团队 | [通过](../../reviews/ta01-product/ci567-amd64-team-full-guest-pass.json)，job116950873839 | job116950873874，in_progress |
| 企业 | [通过](../../reviews/ta01-product/ci567-amd64-enterprise-full-guest-pass.json)，job116950873944 | job116950874189，in_progress |

三份原件各核 22 输入、六脚本、准确生产者与 manifest，以及不同 boot_id／两次 kernel／QMP RESET 和 SHUTDOWN／QEMU 退出 0／重启后四项证明。只证明本候选本组合，同程序夹具和单轮通过不关闭历史 API／MCP139。

本轮[原生真实身份与 PG 测量](../../reviews/ta01-product/resumption-api-auth-pg-path-comparison.json)有六份完整阶段记录及三份含受控行锁的记录。首次原生六个 HTTP 成功但 ALS 未传入，不能算内部测量成功。受控凭据 SELECT 与 PG 同模板统计及四份 Lock 采样对应，仅证明校准有效，不推原 CI 根因。两次固定 ARM 组件过程均达原 1,200 秒、无请求回执，实际请求数未知；供料和服务准备不冒 API 时间。独立 API 角色、inject、观测开销及个人 Lite 镜像差异见[当前报告](current-delivery.md)。

产品代码、CI、原期限和支持矩阵均未改；资料提交用 `[skip ci]` 保留 CI567，不获得本 head 的 Required 成功结论。原根因、完整验收、仅 P0/P1 正式产品审及最新 Required 未齐，不进入合入。
'''
s=s[:at]+ '\n'+section+s[at:];p.write_text(s,encoding='utf8',newline='\n')
