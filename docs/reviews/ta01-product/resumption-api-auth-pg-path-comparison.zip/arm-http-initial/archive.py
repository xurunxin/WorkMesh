from datetime import datetime,timezone
from pathlib import Path
import hashlib,json,re,subprocess,zipfile

r=Path('.tmp/ta01-resumption/api-auth-pg-567');n=Path('.tmp/ta01-resumption/api-auth-pg-native-567')
out=Path('docs/reviews/ta01-product/resumption-api-auth-pg-path-comparison')
assert not out.with_suffix('.json').exists() and not out.with_suffix('.zip').exists()
sha=lambda b:hashlib.sha256(b).hexdigest()
assert subprocess.run(['git','diff','--quiet','541f6ba64841915801a1ccb123f9adb7f61ebe17','HEAD','--','apps','packages','infra/docker','scripts/server-distribution','pnpm-lock.yaml','OPENAPI.yaml','SCHEMA.sql']).returncode==0
members={}
for prefix,base in [('arm-http-initial',r),('native-initial',n),('native-context-fixed',n/'context-2'),('native-lock-control',n/'lock-control'),('arm-seed-2',r/'arm-seed-2')]:
    for p in sorted(base.iterdir()):
        if not p.is_file() or p.name in {'candidate.zip','selected.tar'} or p.suffix in {'.gz','.img'}:continue
        assert p.stat().st_size<2*1024*1024
        if p.name=='analysis.json':continue
        members[prefix+'/'+p.name]=p.read_bytes()
measurement=Path('docs/reviews/ta01-product/tools/api-auth-pg-path-probe.mjs').read_bytes()
members['tools/api-auth-pg-path-probe.mjs']=measurement
sources=['apps/api/src/server.ts','apps/api/src/agent-connections.ts','apps/api/src/authz/authorize.ts',
    'apps/api/src/client-profile.ts','apps/api/src/work-item-executors.ts','packages/db/src/index.ts',
    'packages/contracts/src/agent-discovery.ts','packages/config/src/index.ts','docker-compose.lite.yml']
sourceFiles={}
for file in sources:
    data=subprocess.check_output(['git','show','541f6ba64841915801a1ccb123f9adb7f61ebe17:'+file])
    assert data==subprocess.check_output(['git','show','HEAD:'+file])
    members['product-source/'+file]=data;sourceFiles[file]={'sha256':sha(data),
        'blob':subprocess.check_output(['git','rev-parse','541f6ba64841915801a1ccb123f9adb7f61ebe17:'+file]).decode().strip()}
analysis=json.loads((r/'analysis.json').read_bytes())
members['analysis.json']=(r/'analysis.json').read_bytes()
resources=json.loads((r/'resources.json').read_bytes());images={'arm64':json.loads((r/'image-resources.json').read_bytes()),'amd64':json.loads((n/'image-resources.json').read_bytes())}
summary={'说明':'执行者直接测量：准确CI566独立API/PG/Redis角色与真实隔离配对凭据；不是个人Lite完整镜像、已安装组合、原CI内部时延分解或原生139根因证明。空上下文、首个ARM截止及后续修正分别保留。',
    'startingDeliveryHead':'e2763da4dfdf25f7fc5c28c34a9619d4788f4541',
    'productCandidateHead':'541f6ba64841915801a1ccb123f9adb7f61ebe17',
    'productCandidateTree':'9d330d4aca890e4d1147315923e6c3f5f61b68f2',
    'productSourceUnchangedThroughStartingDelivery':True,'productSourceFiles':sourceFiles,
    'measurementFinalSha256':sha(measurement),
    'actualMeasurementVersions':{'armInitialExpected':json.loads((r/'used-inputs.json').read_bytes())['measurement.mjs']['sha256'],
        'nativeInitial':json.loads((n/'inputs.json').read_bytes())['measurement.mjs'],
        'nativeContextFixed':json.loads((n/'context-2/inputs.json').read_bytes())['measurement.mjs'],
        'armSeed2Expected':json.loads((r/'arm-seed-2/used-inputs.json').read_bytes())['measurement.mjs']['sha256'],
        'nativeLockControl':json.loads((n/'lock-control/inputs.json').read_bytes())['measurement.mjs']},
    'analysis':analysis,'resources':resources,'images':images,
    'ci567Snapshot':json.loads((r/'ci567-snapshot.json').read_bytes()),
    'originalEvidence':'ci566-arm64-personal-first-failure.json',
    'scopeLimits':['独立API角色，不是个人Lite完整镜像；跳过entrypoint，NODE_ENV=test仅禁止server导入自动listen，构造app前恢复production',
        '原路由/身份/授权/真实PG/Redis；Fastify inject，无MCP/TLS/代理/Worker/S3/真实竞争负载，未控制物理宿主',
        '本次PG max_connections20/shared_buffers64MB；原个人Lite为32MB及track_activities off；小测观测额外开销明确',
        '250ms等待采样可能缺失，PG统计为整库聚合；handler尾段不等于单个纯函数，process CPU含V8多线程；禁止相减推旧SQL/CPU成本',
        '原业务30秒、健康180秒、安装1800秒、完整guest150分钟不变；本轮另有有界组件开销，不宣称总开销不变',
        'AMD139/API139/MCP139分别未闭；有限未复现不排除；完整验收/正式P0P1产品审/最新Required未齐不可合入'],
    'fullProductAcceptance':False,'productCodeChanged':False,'workflowChanged':False,'observedAt':datetime.now(timezone.utc).isoformat()}
members['summary.json']=(json.dumps(summary,ensure_ascii=False,indent=2)+'\n').encode()
for name,data in members.items():
    assert not re.search(rb'wm[ips]_[A-Za-z0-9_-]{43}',data),name
with zipfile.ZipFile(out.with_suffix('.zip'),'x',compression=zipfile.ZIP_DEFLATED) as z:
    for name,data in members.items():z.writestr(name,data)
summary['selectedZipSha256']=sha(out.with_suffix('.zip').read_bytes())
summary['members']={name:{'bytes':len(data),'sha256':sha(data)} for name,data in members.items()}
out.with_suffix('.json').write_text(json.dumps(summary,ensure_ascii=False,indent=2)+'\n',encoding='utf8',newline='\n')
print(json.dumps({'members':len(members),'zipBytes':out.with_suffix('.zip').stat().st_size,'zipSha256':summary['selectedZipSha256']}))
