from pathlib import Path
import ast,hashlib,json,subprocess
r=Path('.tmp/ta01-resumption/api-auth-pg-native-567');old=Path('.tmp/ta01-resumption/api-auth-pg-567')
l=json.loads((old/'resources.json').read_bytes());i=l['containers'][0]['id']
assert json.loads((old/'result.json').read_bytes())['deadlineReached']
ast.parse((r/'native.py').read_text(encoding='utf8'))
paths={n:r/n for n in ['api-rootfs.tar.gz','postgres-rootfs.tar.gz','redis-rootfs.tar.gz','native.py']}
paths['measurement.mjs']=Path('docs/reviews/ta01-product/tools/api-auth-pg-path-probe.mjs')
hashes={n:hashlib.file_digest(p.open('rb'),'sha256').hexdigest() for n,p in paths.items()}
(r/'inputs.json').write_text(json.dumps(hashes,indent=2)+'\n',encoding='utf8')
paths['inputs.json']=r/'inputs.json'
assert subprocess.run(['docker','exec',i,'mkdir','/opt/native'],capture_output=True,timeout=30).returncode==0
for n,p in paths.items():assert subprocess.run(['docker','cp',str(p),i+':/opt/native/'+n],capture_output=True,timeout=180).returncode==0
with (r/'runner.stdout').open('xb') as out,(r/'runner.stderr').open('xb') as err:
    v=subprocess.run(['docker','exec',i,'python3','/opt/native/native.py'],stdout=out,stderr=err,timeout=650)
(r/'runner-exit.json').write_text(json.dumps({'exitCode':v.returncode})+'\n',encoding='utf8')
for n in ['result.json','node.stdout','node.stderr','setup-failure.stdout','setup-failure.stderr']:
    v=subprocess.run(['docker','exec',i,'cat','/opt/native/'+n],capture_output=True,timeout=30)
    if v.returncode==0:(r/n).write_bytes(v.stdout)
result=json.loads((r/'result.json').read_bytes());p=result.get('probe',{})
print(json.dumps({'nodeExitCode':result.get('nodeExitCode'),'errorType':result.get('errorType'),
    'nodeErrorType':p.get('errorType'),'nodeErrorCode':p.get('errorCode'),'completedRequests':len(p.get('runs',[])),
    'elapsedSeconds':result['elapsedSeconds']}))
