from pathlib import Path
import ast
parent=Path('.tmp/ta01-resumption/api-auth-pg-native-567');r=parent/'context-2';r.mkdir(exist_ok=False)
s=(parent/'native.py').read_text(encoding='utf8').replace("base=Path('/opt/native')","base=Path('/opt/native-2')")
ast.parse(s);(r/'native.py').write_text(s,encoding='utf8',newline='\n')
s=(parent/'start-native.py').read_text(encoding='utf8').replace("r=Path('.tmp/ta01-resumption/api-auth-pg-native-567')","r=Path('.tmp/ta01-resumption/api-auth-pg-native-567/context-2')")
s=s.replace("paths={n:r/n for n in ['api-rootfs.tar.gz','postgres-rootfs.tar.gz','redis-rootfs.tar.gz','native.py']}","paths={n:r.parent/n for n in ['api-rootfs.tar.gz','postgres-rootfs.tar.gz','redis-rootfs.tar.gz']}; paths['native.py']=r/'native.py'")
s=s.replace('/opt/native','/opt/native-2')
ast.parse(s);(r/'start-native.py').write_text(s,encoding='utf8',newline='\n')
