from pathlib import Path
import subprocess,json,hashlib,gzip,uuid,tarfile
r=Path('.tmp/ta01-resumption/api-auth-pg-native-567'); x=json.loads((r/'extraction.json').read_bytes())
owner=str(uuid.uuid4()); ledger={'owner':owner,'roles':{},'containers':[]}
def call(a,timeout=30): return subprocess.run(['docker',*a],capture_output=True,timeout=timeout)
def save(): (r/'image-resources.json').write_text(json.dumps(ledger,indent=2)+'\n',encoding='utf8')
assert not (r/'image-resources.json').exists()
for role,v in x['roles'].items():
    pre=call(['image','inspect',v['tag']]); assert pre.returncode and b'no such image' in pre.stderr.lower()
    ledger['roles'][role]={'tag':v['tag'],'preexistingTag':False,'image':v['image']}
save()
v=call(['load','--input',str(r/'selected.tar')],180); ledger['loadExitCode']=v.returncode; save(); assert v.returncode==0
for role,v in x['roles'].items():
    info=json.loads(call(['image','inspect',v['tag']]).stdout)[0]
    assert info['Architecture']=='amd64' and info['Id'] in {v['image']['id'],v['image']['archiveId']}
    ledger['roles'][role]['actualImageId']=info['Id']; save()
    args=['create','--platform','linux/amd64','--pull','never','--network','none','--label','io.workmesh.ta01.probe.owner='+owner,'--entrypoint','/bin/false']
    for name in (info['Config'].get('Volumes') or {}): args+=['--tmpfs',name]
    out=call([*args,info['Id']]); assert out.returncode==0
    i=out.stdout.decode().strip(); assert len(i)==64
    ledger['containers'].append({'id':i,'role':role,'purpose':'export only; never started'}); save()
    state=json.loads(call(['inspect',i]).stdout)[0]
    assert not state['State']['Running'] and state['Image']==info['Id'] and state['Config']['Labels']['io.workmesh.ta01.probe.owner']==owner
    assert not state['Mounts'] or all(a['Type']=='tmpfs' for a in state['Mounts'])
    p=subprocess.Popen(['docker','export',i],stdout=subprocess.PIPE,stderr=subprocess.PIPE); h=hashlib.sha256(); n=0
    file=r/(role+'-rootfs.tar.gz')
    with file.open('xb') as out,gzip.GzipFile(fileobj=out,mode='wb',mtime=0) as z:
        while b:=p.stdout.read(1024*1024): z.write(b); h.update(b); n+=len(b)
    assert p.wait(timeout=60)==0
    ledger['roles'][role]['rootfs']={'bytes':file.stat().st_size,'sha256':hashlib.file_digest(file.open('rb'),'sha256').hexdigest(),'rawBytes':n,'rawSha256':h.hexdigest()}
    save()
    with tarfile.open(file,mode='r|gz') as t:
        wanted={'api':['usr/local/bin/node','app/dist/server.js','app/package.json','app/node_modules/@workmesh/db/migrations/v1/0001_v1_baseline.sql'],
            'postgres':['usr/local/bin/postgres','usr/local/lib/postgresql/pg_stat_statements.so'],
            'redis':['usr/local/bin/redis-server']}[role]
        found={}
        for member in t:
            if member.name in wanted:
                f=t.extractfile(member); found[member.name]={'bytes':member.size,'sha256':hashlib.file_digest(f,'sha256').hexdigest()}
        ledger['roles'][role]['keyFiles']=found; save()
    assert call(['rm',i]).returncode==0
    out=call(['inspect',i]); assert out.returncode and b'no such object' in out.stderr.lower()
    ledger['containers'][-1]['removedAndAbsent']=True; save()
print(json.dumps({k:{'rootfsBytes':v['rootfs']['bytes'],'keyFiles':list(v['keyFiles'])} for k,v in ledger['roles'].items()}))
