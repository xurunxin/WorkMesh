from pathlib import Path
from datetime import datetime,timezone
import hashlib,json,re,subprocess,zipfile
r=Path('.tmp/ta01-resumption/api-auth-pg-arm-preexpanded'); out=Path('docs/reviews/ta01-product/resumption-api-auth-pg-arm-preexpanded')
assert not out.with_suffix('.zip').exists() and not out.with_suffix('.json').exists()
sha=lambda data:hashlib.sha256(data).hexdigest()
members={}
for p in sorted(r.iterdir()):
    if not p.is_file() or p.name.startswith('live-') or p.name in {'pr-body.md'}:continue
    assert p.stat().st_size<2*1024*1024
    members['measurement/'+p.name]=p.read_bytes()
tool=Path('docs/reviews/ta01-product/tools/api-auth-pg-path-probe.mjs').read_bytes()
used=json.loads((r/'used-inputs.json').read_bytes())
assert sha(tool)==used['measurement.mjs']['sha256']
members['tools/api-auth-pg-path-probe.mjs']=tool
prior=json.loads(Path('docs/reviews/ta01-product/resumption-api-auth-pg-path-comparison.json').read_bytes())
result=json.loads((r/'result.json').read_bytes())
summary={'说明':'预展开已核公开CI566独立API/PG/Redis角色，固定ARM小组件单对真实GET；不是个人Lite同镜像复现、原CI根因或完整支持验收。',
    'startingDeliveryHead':subprocess.check_output(['git','rev-parse','HEAD']).decode().strip(),
    'testedProductSource':'541f6ba64841915801a1ccb123f9adb7f61ebe17',
    'measurementSha256':sha(tool),'publicInputs':used,'productSourceFiles':prior['productSourceFiles'],
    'result':result,'analysis':json.loads((r/'analysis.json').read_bytes()),
    'resources':json.loads((r/'resources.json').read_bytes()),
    'ci567Snapshot':json.loads((r/'ci567-snapshot.json').read_bytes()),
    'unchangedOriginalLimits':{'vcpus':4,'ramMiB':4096,'vmSeconds':1200,'nodeSeconds':600,'getSeconds':30},
    'priorArmAttempts':'两个旧ARM均到期且无最终回执，实际GET数未知；本次不倒填。',
    'scopeLimits':['独立API而非个人Lite；Fastify inject、真实PG/Redis/配对，未覆盖MCP/TLS/Worker/S3/竞争负载',
        '公开rootfs在原控制容器内预展开并核gzip和rawTarSHA；现有seed盘供应只读代码，临时目录绑原guest私有根盘，无新设备/宿主依赖/权限',
        'PG20连接/64MB/额外观测，不等个人Lite；事件输出/采样开销未配对量化',
        'process CPU含Node多线程；SQL客户端wall包含调度，PG执行含等待；不同钟不相减',
        'API139/MCP139、原ARM迟响应未闭，未放宽任何产品期限、授权或保证；未具备正式成果审或合入条件'],
    'fullProductAcceptance':False,'productCodeChanged':False,'workflowChanged':False,
    'observedAt':datetime.now(timezone.utc).isoformat()}
members['summary.json']=(json.dumps(summary,ensure_ascii=False,indent=2)+'\n').encode()
for name,data in members.items(): assert not re.search(rb'wm[ips]_[A-Za-z0-9_-]{43}',data),name
with zipfile.ZipFile(out.with_suffix('.zip'),'x',compression=zipfile.ZIP_DEFLATED) as z:
    for name,data in members.items():z.writestr(name,data)
summary['selectedZipSha256']=sha(out.with_suffix('.zip').read_bytes())
summary['members']={name:{'bytes':len(data),'sha256':sha(data)} for name,data in members.items()}
out.with_suffix('.json').write_text(json.dumps(summary,ensure_ascii=False,indent=2)+'\n',encoding='utf8',newline='\n')
print(json.dumps({'members':len(members),'zipBytes':out.with_suffix('.zip').stat().st_size,'zipSha256':summary['selectedZipSha256']}))
