from pathlib import Path
from datetime import datetime,timezone
import hashlib,json,subprocess
r=Path('.tmp/ta01-resumption/api-auth-pg-arm-preexpanded')
result=json.loads((r/'result.json').read_bytes()); events=[json.loads(v) for v in (r/'progress.jsonl').read_text(encoding='utf8').splitlines()]
assert result['deadlineReached'] and result['status']=='incomplete' and result['receipts']==[]
assert result['qemuExitCode']==0 and b'terminating on signal 15' in (r/'qemu-stderr.log').read_bytes()
guest=[v['guest'] for v in events if 'guest' in v]; node=[v['node'] for v in events if 'node' in v]
assert len(events)==8 and [v['eventOrdinal'] for v in node]==list(range(4))
assert not any(v['name'].startswith('request-') for v in node)
analysis={'capturedProgressEvents':len(events),'guestStages':guest,'nodeStages':node,
    'observedTargetGetStartCount':0,'observedTargetGetReturnCount':0,'actualTargetGetCount':None,
    'actualTargetGetCountReason':'缺Node最终回执；零已保存目标回执不证明实际零请求，不倒填前两次ARM。',
    'earliestProvenFailure':'VM原1200秒宿主截止；未观察到业务断言失败或139。',
    'lastObservedBoundary':'migrations-started在monitor.connect之前；不能区分该连接建立与applyMigrations。',
    'notInference':['模块导入60.29秒在目标GET前，不解释旧资格21.62秒。',
        '目标SQL/连接取得/锁等待/handler生成/调度未测；不推DB或CPU根因，也不把缺回执当排除。',
        'QEMU0但宿主TERM且deadlineReached，非正常关机；Node/PG/Redis最终退出与实际请求数未知。'],
    'hypotheses':[
        {'id':'H1','claim':'本次ARM目标GET主要等待连接或行锁','verdict':'未知','missing':'无目标trace、SQL或等待样本；原生校准不外推'},
        {'id':'H2','claim':'资格生成/序列化解释原21.62秒','verdict':'未知','missing':'本次未收handler阶段；模块导入是前置成本，不能扣减'},
        {'id':'H3','claim':'调度或观测开销解释迟响应','verdict':'未知','missing':'无目标CPU/wall/PG关联；ISO只读布局及流式观测未量化'},
        {'id':'H4','claim':'这次预展开足以在1200秒内取得单对完整回执','verdict':'不成立于本次执行','evidence':'准备阶段有回执，目标回执和最终报告仍缺；未证明固定环境下一定不可完成'}],
    'nextAuthorizedAction':'保留CI567，待三ARM原件可得后核准确result/serial/journal；不追加第四次组件或整轮试跑。',
    'unapprovedOption':{'proposal':'若仍要一次同固定guest单对测量，单独裁定VM总窗1800秒（比原上限增加600秒），Node600秒/GET30秒及4CPU4GiB不变；不改产品或正式验收期限。',
        'status':'仅选项，未批准/未执行；增窗也不保证得到样本或闭合原根因。'},
    'fullProductAcceptance':False}
(r/'analysis.json').write_text(json.dumps(analysis,ensure_ascii=False,indent=2)+'\n',encoding='utf8')
for name,args in [('qemu-binary',['docker','exec',json.loads((r/'resources.json').read_bytes())['containers'][0]['id'],'sha256sum','/usr/bin/qemu-system-aarch64']),
    ('qemu-packages',['docker','exec',json.loads((r/'resources.json').read_bytes())['containers'][0]['id'],'dpkg-query','-W','qemu-system-arm','qemu-utils','qemu-efi-aarch64','ipxe-qemu','ipxe-qemu-256k-compat-efi-roms'])]:
    value=subprocess.run(args,capture_output=True,timeout=30); assert value.returncode==0
    (r/(name+'.stdout')).write_bytes(value.stdout)
value=subprocess.run(['gh','run','view','38893305755','--repo','xurunxin/WorkMesh','--json','headSha,status,conclusion,jobs'],capture_output=True,timeout=45)
assert value.returncode==0
workflow=json.loads(value.stdout)
snapshot={'at':datetime.now(timezone.utc).isoformat(),'runId':38893305755,'headSha':workflow['headSha'],
    'status':workflow['status'],'conclusion':workflow['conclusion'],'jobs':[{k:job[k] for k in ['databaseId','name','status','conclusion']} for job in workflow['jobs']]}
(r/'ci567-snapshot.json').write_text(json.dumps(snapshot,indent=2)+'\n',encoding='utf8')
print(json.dumps({'progress':len(events),'status':result['status'],'elapsedSeconds':result['elapsedSeconds'],'actualTargetGetCount':None,'ciStatus':snapshot['status']}))
