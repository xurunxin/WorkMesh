from pathlib import Path
import ast,hashlib,json,subprocess
r=Path('.tmp/ta01-resumption/api-auth-pg-arm-preexpanded'); old=Path('.tmp/ta01-resumption/api-auth-pg-567')
ledger=json.loads((r/'resources.json').read_bytes()); i=ledger['containers'][0]['id']
assert ledger['exactQemuPackageAvailable'] and ledger['aptInstallExitCode']==0
for p in r.glob('*.py'): ast.parse(p.read_text(encoding='utf8'))
source=json.loads((old/'image-resources.json').read_bytes())
source['keyFiles']={name:value['keyFiles'] for name,value in source['roles'].items()}
(r/'role-source.json').write_text(json.dumps(source,indent=2)+'\n',encoding='utf8')
inputs={name:old/name for name in ['api-rootfs.tar.gz','postgres-rootfs.tar.gz','redis-rootfs.tar.gz','node-sha256.txt']}
inputs.update({'role-source.json':r/'role-source.json','component-tcg-guest.py':r/'guest.py','run-component-tcg.py':r/'run-guest.py',
    'expand.py':r/'expand.py','measurement.mjs':Path('docs/reviews/ta01-product/tools/api-auth-pg-path-probe.mjs'),
    'arm64.img':Path('.tmp/ta01-resumption/local-guest-image-cache/arm64-1d6bffe6.img')})
metadata={}
for name,p in inputs.items():
    with p.open('rb') as f: digest=hashlib.file_digest(f,'sha256').hexdigest()
    metadata[name]={'bytes':p.stat().st_size,'sha256':digest}
assert metadata['arm64.img']['sha256']=='1d6bffe64b848468ac97f821d369a4846d983de1800ccf6b5ec8853e85cefc55'
(r/'used-inputs.json').write_text(json.dumps(metadata,indent=2)+'\n',encoding='utf8')
subprocess.run(['docker','exec',i,'mkdir','/opt/arm-preexpanded'],check=True,capture_output=True,timeout=30)
for name,p in inputs.items(): subprocess.run(['docker','cp',str(p),i+':/opt/arm-preexpanded/'+name],check=True,capture_output=True,timeout=180)
with (r/'expand.stdout').open('xb') as out,(r/'expand.stderr').open('xb') as err:
    z=subprocess.run(['docker','exec',i,'python3','/opt/arm-preexpanded/expand.py'],stdout=out,stderr=err,timeout=180)
assert z.returncode==0,'public pre-expansion failed; no VM launched'
subprocess.run(['docker','cp',i+':/opt/arm-preexpanded/preexpanded.json',str(r/'preexpanded.json')],check=True,capture_output=True,timeout=30)
with (r/'runner.stdout').open('xb') as out,(r/'runner.stderr').open('xb') as err:
    z=subprocess.run(['docker','exec',i,'python3','/opt/arm-preexpanded/run-component-tcg.py','--exact-mcp-role','--arm64'],stdout=out,stderr=err,timeout=1250)
(r/'runner-exit.json').write_text(json.dumps({'runnerExitCode':z.returncode})+'\n',encoding='utf8')
for name in ['result.json','serial.log','qemu-stderr.log','progress.jsonl']:
    with (r/name).open('xb') as out:
        z=subprocess.run(['docker','exec',i,'cat','/opt/arm-preexpanded/guest/'+name],stdout=out,stderr=subprocess.PIPE,timeout=30)
    assert z.returncode==0
print('bounded ARM measurement finished; inspect result and incremental receipts')
