from pathlib import Path
import gzip,hashlib,json,subprocess,time
r=Path('/opt/arm-preexpanded'); before=time.monotonic()
metadata=json.loads((r/'role-source.json').read_bytes()); roots=r/'roles'; roots.mkdir(exist_ok=False)
record={'roles':{},'preexpandedBy':'native x86_64 tar, public input only','runtimeChanges':False}
def sha(p):
    with p.open('rb') as f: return hashlib.file_digest(f,'sha256').hexdigest()
for role,source in metadata['roles'].items():
    archive=r/(role+'-rootfs.tar.gz'); assert sha(archive)==source['rootfs']['sha256']
    raw=hashlib.sha256(); size=0
    with gzip.open(archive,'rb') as f:
        while data:=f.read(1024*1024): raw.update(data); size+=len(data)
    assert size==source['rootfs']['rawBytes'] and raw.hexdigest()==source['rootfs']['rawSha256']
    dest=roots/role; dest.mkdir()
    subprocess.run(['tar','-xzf',str(archive),'-C',str(dest)],check=True,capture_output=True)
    for name,key in source['keyFiles'].items(): assert sha(dest/name)==key['sha256']
    added=[]
    for name in ['proc','dev','dev/shm','tmp']+(['data'] if role=='redis' else []):
        p=dest/name
        if not p.exists(): p.mkdir(parents=True); added.append(name)
    null=dest/'dev/null'
    if not null.exists(): null.touch(); added.append('dev/null mount placeholder')
    record['roles'][role]={'gzipSha256':sha(archive),'rawTarSha256':raw.hexdigest(),
        'rawTarBytes':size,'keyFiles':source['keyFiles'],'addedMountpoints':added}
record['elapsedSeconds']=time.monotonic()-before
(r/'preexpanded.json').write_text(json.dumps(record,indent=2)+'\n',encoding='utf8')
print(json.dumps({'preexpandedSeconds':record['elapsedSeconds'],'roles':list(record['roles'])}))
