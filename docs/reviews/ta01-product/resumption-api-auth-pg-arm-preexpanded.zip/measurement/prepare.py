from pathlib import Path
import ast,json
r=Path('.tmp/ta01-resumption/api-auth-pg-arm-preexpanded')
old=Path('.tmp/ta01-resumption/api-auth-pg-567/arm-seed-2')
s=(old/'guest.py').read_text(encoding='utf8')
start=s.index("        for name,digest in expected['inputs'].items():")
end=s.index("        pg=roots['postgres'];", start)
s=s[:start]+'''        assert sha(seed_root/'measurement.mjs')==expected['inputs']['measurement.mjs']
        run(['ip','route','del','default']); assert b'default' not in subprocess.check_output(['ip','route'])
        stage('preexpanded-inputs-mounted-and-egress-removed')
        roots={}
        for role in ['api','postgres','redis']:
            root=seed_root/'roles'/role; roots[role]=root
            for name,meta in expected['keyFiles'][role].items():
                assert sha(root/name)==meta['sha256']
            private=base/(role+'-private'); private.mkdir(exist_ok=False)
            for name,mode in [('tmp',0o1777),('dev/shm',0o1777)]+([('data',0o755)] if role=='redis' else []):
                target=private/name; target.mkdir(parents=True,exist_ok=False); target.chmod(mode)
                run(['mount','--bind',str(target),str(root/name)])
            run(['mount','-t','proc','-o','nosuid,nodev,noexec','proc',str(root/'proc')])
            run(['mount','--bind','/dev/null',str(root/'dev/null')])
        assert sha(roots['api']/'usr/local/bin/node')==expected['nodeSha256']
        stage('exact-role-readonly-rootfs-ready')
''' +s[end:]
s=s.replace("'ro,nodev,nosuid,noexec'","'ro,nodev,nosuid'")
s=s.replace("(base/'measurement.mjs').read_bytes()","(seed_root/'measurement.mjs').read_bytes()")
start=s.index("        result=subprocess.run(['chroot','--userspec=10001:10001'")
end=s.index("        stage('node-finished')",start)
s=s[:start]+'''        import selectors
        error_path=base/'node.private.stderr'
        safe_output=[]; output_bytes=0
        with error_path.open('wb') as err:
            node=subprocess.Popen(['chroot','--userspec=10001:10001',str(api),'/usr/local/bin/node',
                '/tmp/measurement.mjs','/app','--single-pair'],stdout=subprocess.PIPE,stderr=err)
            processes.append(('node',node))
            selector=selectors.DefaultSelector(); selector.register(node.stdout,selectors.EVENT_READ)
            while True:
                if time.monotonic()-nodeBegan>=600:
                    receipt['nodeDeadlineReached']=True
                    node.terminate(); break
                if not selector.select(timeout=0.5): continue
                line=node.stdout.readline(1024*1024)
                if not line: break
                output_bytes+=len(line); assert output_bytes<2*1024*1024
                value=json.loads(line); safe_output.append(value)
                if value.get('kind')=='progress':
                    print(json.dumps({'tag':'ta01-api-auth-node-progress',**value}),flush=True)
                    if value['name'] in {'module-started','product-import-started','product-import-finished',
                        'migrations-started','migrations-finished','installation-finished','work-item-fixture-created',
                        'real-work-read-pairing-finished','request-started','request-returned','request-recorded','request-deadline'}:
                        post({'phase':'component-progress','nonce':expected['nonce'],'node':value})
                else:
                    receipt['probe']=value
            selector.close()
            try: code=node.wait(timeout=15)
            except subprocess.TimeoutExpired: node.kill(); code=node.wait(timeout=5)
        receipt.update(nodeExitCode=code,nodeSeconds=time.monotonic()-nodeBegan,
            streamedRecords=len(safe_output),stdoutBytes=output_bytes,
            stderrBytes=error_path.stat().st_size,stderrSha256=sha(error_path))
        if receipt.get('probe'):
            assert receipt['probe']['executableSha256']==expected['nodeSha256']
        if code!=0: receipt['errorType']='ProbeProcessFailed'
''' +s[end:]
point=s.index('    def stage(name):')
s=s[:point]+'''    def post(value):
        payload=json.dumps(value).encode(); assert len(payload)<1024*1024
        req=urllib.request.Request('http://10.0.2.2:18080/receipt',payload,{'content-type':'application/json'})
        with urllib.request.urlopen(req,timeout=10) as response: assert response.status==200
''' +s[point:]
s=s.replace("        print(json.dumps({'tag':'ta01-api-auth-probe-stage',**value}),flush=True)","        print(json.dumps({'tag':'ta01-api-auth-probe-stage',**value}),flush=True)\n        post({'phase':'component-progress','nonce':expected['nonce'],'guest':value})")
ast.parse(s); (r/'guest.py').write_text(s,encoding='utf8',newline='\n')
s=(old/'run-guest.py').read_text(encoding='utf8').replace('/opt/arm-seed-2','/opt/arm-preexpanded')
s=s.replace("'inputs': {name: sha(root / name) for name in names},", "'inputs': {'measurement.mjs': sha(root/'measurement.mjs')},\n                'keyFiles': json.loads((root/'role-source.json').read_bytes())['keyFiles'],")
s=s.replace("if value.get('nonce') != nonce or value.get('phase') != 'component-measurement':", "if value.get('nonce') != nonce or value.get('phase') not in {'component-measurement','component-progress'}:")
s=s.replace("            receipts.append(value)","            with (run/'progress.jsonl').open('a',encoding='utf8') as log:\n                log.write(json.dumps(value)+'\\n'); log.flush()\n            if value['phase']=='component-measurement': receipts.append(value)")
start=s.index("    subprocess.run(['genisoimage'")
end=s.index("    subprocess.run(['qemu-img'",start)
s=s[:start]+'''    seed=root/'seed-public'; seed.mkdir(exist_ok=False)
    import shutil
    for name in ['user-data','meta-data']: shutil.copyfile(run/name,seed/name)
    shutil.copyfile(root/'measurement.mjs',seed/'measurement.mjs')
    (seed/'roles').symlink_to(root/'roles',target_is_directory=True)
    subprocess.run(['genisoimage','-quiet','-follow-links','-output',str(run/'seed.iso'),
        '-volid','cidata','-joliet','-rock',str(seed)],check=True,capture_output=True)
''' +s[end:]
# -follow-links would follow all runtime symlinks: use the already expanded real directory instead.
s=s.replace("    (seed/'roles').symlink_to(root/'roles',target_is_directory=True)","    (root/'roles').rename(seed/'roles')")
s=s.replace("'genisoimage','-quiet','-follow-links'","'genisoimage','-quiet'")
ast.parse(s); (r/'run-guest.py').write_text(s,encoding='utf8',newline='\n')
print('derived guest and runner AST passed; no VM launched')
