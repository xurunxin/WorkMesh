from pathlib import Path
import hashlib, json, subprocess, shutil, zipfile
from datetime import datetime, timezone

OLD = Path('C:/Users/xurx/.tds/workspaces/01a138ab-2566-7f87-9d06-5b16bebd86c2')
OUT = Path('.tmp/ta01-recovery')
SOURCE = OLD / '.tmp/ta01-resumption/api-crash-window-a-6g-once'
DEST = Path('.tmp/ta01-resumption/api-crash-window-a-6g-once')
assert not DEST.exists()
assert subprocess.check_output(['git', '-C', str(OLD), 'status', '--porcelain']) == b''
rows = []
for root in [OLD / '.tmp', OLD / 'docs/plan/ta01-self-hosted-deployment']:
    for p in sorted(root.rglob('*')):
        if not p.is_file(): continue
        with p.open('rb') as f: digest = hashlib.file_digest(f, 'sha256').hexdigest()
        rows.append({'path':p.relative_to(OLD).as_posix(), 'bytes':p.stat().st_size, 'sha256':digest})
(OUT/'old-file-inventory.json').write_text(json.dumps({'observedAt':datetime.now(timezone.utc).isoformat(), 'oldWorktree':str(OLD), 'head':subprocess.check_output(['git','-C',str(OLD),'rev-parse','HEAD']).decode().strip(),'files':rows},ensure_ascii=False,indent=2)+'\n',encoding='utf8')
shutil.copytree(SOURCE, DEST)
for p in SOURCE.rglob('*'):
    if p.is_file(): assert p.read_bytes() == (DEST/p.relative_to(SOURCE)).read_bytes()
print(json.dumps({'inventoryFiles':len(rows),'inventoryBytes':sum(x['bytes'] for x in rows),'copiedAttemptFiles':sum(p.is_file() for p in SOURCE.rglob('*')),'destination':str(DEST)}))
