from pathlib import Path
from datetime import datetime, timezone
import hashlib, json, subprocess

OUT=Path('.tmp/ta01-recovery')
OLD=Path('C:/Users/xurx/.tds/workspaces/01a138ab-2566-7f87-9d06-5b16bebd86c2')
ROOT=OLD/'.tmp/ta01-resumption/api-crash-window-a-6g-once'
ledger=json.loads((ROOT/'resources.json').read_bytes()); cid=ledger['containers'][0]['id']
def call(args):
    return subprocess.run(['docker',*args],capture_output=True,timeout=60,check=True).stdout
info=json.loads(call(['inspect',cid]))[0]
assert info['Id']==cid and info['Config']['Labels'][ledger['label']]==ledger['owner']
assert info['Image']==ledger['imageId'] and not info['Mounts']
assert not info['HostConfig']['Privileged'] and not info['HostConfig']['Devices'] and not info['HostConfig']['PortBindings']
now=datetime.now(timezone.utc).isoformat()
events=[json.loads(line) for line in call(['events','--since',ledger['createdAt'],'--until',now,'--filter','container='+cid,'--format','{{json .}}']).splitlines()]
projection=[{'id':e.get('id',e.get('Actor',{}).get('ID')),'action':e.get('Action',e.get('status')),'timeNano':e.get('timeNano')} for e in events]
top=call(['top',cid,'-eo','pid,ppid,comm']).decode()
assert 'qemu' not in top and 'python' not in top
assert subprocess.run(['docker','exec',cid,'test','!','-d','/opt/api-window/guest']).returncode==0
assert not ledger['vmStarted'] and not (ROOT/'attempt-started.json').exists()
source=[]
for name,digest in json.loads((ROOT/'input-preflight.json').read_bytes())['scripts'].items():
    original=subprocess.check_output(['git','show','9c8bbff749c1d2a52a3e6489dcec02d2d7c859af:scripts/server-distribution/'+name])
    actual=call(['exec',cid,'cat','/opt/api-window/source/'+name])
    assert original==actual==(ROOT/'source'/name).read_bytes()
    assert hashlib.sha256(actual).hexdigest()==digest
    source.append({'path':'scripts/server-distribution/'+name,'gitBlob':subprocess.check_output(['git','rev-parse','9c8bbff749c1d2a52a3e6489dcec02d2d7c859af:scripts/server-distribution/'+name]).decode().strip(),'sha256':digest})
for name in ['run_window.py','diagnostic_guest.py','api_identity.py']:
    assert call(['exec',cid,'cat','/opt/api-window/'+name])==(ROOT/name).read_bytes()
value={'observedAt':now,'containerId':cid,'owner':ledger['owner'],'state':{k:info['State'][k] for k in ['Running','StartedAt','FinishedAt','ExitCode','OOMKilled','Pid']},'imageId':info['Image'],'hostConfig':{k:info['HostConfig'][k] for k in ['Memory','MemorySwap','NanoCpus','Privileged','Devices','PortBindings']},'mounts':info['Mounts'],'processes':top,'guestDirectoryAbsent':True,'attemptMarkerAbsent':True,'events':projection,'eventHistoryBoundary':'Docker保留的事件窗口，不保证覆盖容器创建以来全部exec历史；结合实时进程、目录和旧账本判断','memory':call(['exec',cid,'cat','/proc/meminfo']).decode(),'cgroupEvents':call(['exec',cid,'cat','/sys/fs/cgroup/memory.events']).decode(),'sourceBindings':source,'instrumentationEqualToOldPreparation':True}
(OUT/'prelaunch-audit.json').write_text(json.dumps(value,ensure_ascii=False,indent=2)+'\n',encoding='utf8')
print(json.dumps({'containerId':cid,'guestDirectoryAbsent':True,'attemptMarkerAbsent':True,'sourcesVerified':len(source),'retainedEvents':len(projection)}))
