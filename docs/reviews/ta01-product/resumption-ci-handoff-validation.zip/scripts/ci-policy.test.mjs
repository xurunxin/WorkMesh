import assert from 'node:assert/strict'
import { test } from 'node:test'
import { checkIds, classifyChanges, evaluateResults, planForEvent, readWorkspaces, validateCiBootstrap, validateMcpConformanceEntrypoints, validateDevelopmentImageEntrypoint, validateBackendLiteEntrypoint, validateConnectorInstallEntrypoint } from './ci-policy.mjs'
import { readFileSync, mkdtempSync, mkdirSync, writeFileSync } from 'node:fs'
import { execFileSync, spawnSync } from 'node:child_process'
import { tmpdir } from 'node:os'
import { join } from 'node:path'
import { fileURLToPath } from 'node:url'
import { validateServerInstallEntrypoint } from './ci-policy.mjs'
import { parse } from './ci-bootstrap/yaml.mjs'

const workspaces = readWorkspaces()
const classify = (paths, options) => classifyChanges(paths, workspaces, options)
const results = plan => Object.fromEntries(['changes', ...checkIds].map(id => [id, { result: id === 'changes' || plan.checks[id] ? 'success' : 'skipped' }]))

test('实际CI校验入口消费完整生产者与guest图及固定工件下载', () => {
  const result = spawnSync(process.execPath, [fileURLToPath(new URL('./validate-ci.mjs', import.meta.url))], { encoding: 'utf8' })
  assert.equal(result.status, 0, result.stderr || result.stdout)
  assert.match(result.stdout, /\[ci:validate\] OK: 12 jobs/)
})

test('双架构候选只构建一次，六个画像 guest 全部必需且摘要交接不能绕过', () => {
  const jobs = parse(readFileSync(new URL('../.github/workflows/ci.yml', import.meta.url), 'utf8')).jobs
  const original = { job: jobs['server-install'], build: jobs['server-build'] }
  assert.deepEqual(validateServerInstallEntrypoint(original.job, original.build), [])
  assert.ok(jobs['required-ci'].needs.includes('server-build'))
  for (const mutate of [
    value => { value.build.strategy.matrix.include.pop() },
    value => { value.job.strategy.matrix.arch.pop() },
    value => { value.job.strategy.matrix.profile = value.job.strategy.matrix.profile.replace(',"enterprise"', '') },
    value => { value.job.strategy.matrix.exclude = [{ arch: 'arm64', profile: 'team' }] },
    value => { delete value.build.env.PYTHONDONTWRITEBYTECODE },
    value => { delete value.job.env.PYTHONDONTWRITEBYTECODE },
    value => { value.job.steps = value.job.steps.filter(step => step.name !== 'Execute installed configuration in full guest') },
    value => { value.job.steps.find(step => step.name === 'Execute installed configuration in full guest').if = 'false' },
    value => { const step = value.job.steps.find(step => step.name === 'Execute installed configuration in full guest'); step.run = step.run.replace("'${{ inputs.native-diagnostic }}' = true", "true = true") },
    value => { value.build.steps.find(step => step.name === 'Build immutable offline candidate')['continue-on-error'] = true },
    value => { value.job.steps.find(step => step.name === 'Verify producer manifest digest').if = 'false' },
    value => { value.job.steps.find(step => step.name === 'Download immutable architecture candidate').with['artifact-ids'] = 'other-artifact' },
    value => { value.job.env.CANDIDATE_SHA = 'unbound' },
    value => { value.build.outputs['digest-amd64'] = value.build.outputs['digest-arm64'] },
    value => { value.job.needs = ['changes'] },
    value => { value.job.steps.find(step => step.name === 'Execute installed configuration in full guest').run += ' --profile personal' },
    value => { const steps = value.job.steps; const left = steps.findIndex(step => step.name === 'Verify producer manifest digest'); const right = steps.findIndex(step => step.name === 'Execute installed configuration in full guest'); [steps[left], steps[right]] = [steps[right], steps[left]] },
  ]) {
    const invalid = structuredClone(original); mutate(invalid)
    assert.ok(validateServerInstallEntrypoint(invalid.job, invalid.build).length)
  }
  for (const input of ['scripts/server-distribution/install.mjs', 'packages/config/src/deployment-profile.ts', 'apps/api/src/server.ts']) {
    const plan = classify([input])
    for (const id of ['server-build', 'server-install']) {
      assert.equal(plan.checks[id], true)
      for (const result of ['failure', 'skipped', 'cancelled']) {
        const needs = results(plan); needs[id].result = result; assert.ok(evaluateResults(plan, needs).length)
      }
    }
  }
})

test('自包含双架构完整安装不可丢 leg、跳过或吞失败', () => {
  const job = parse(readFileSync(new URL('../.github/workflows/ci.yml', import.meta.url), 'utf8')).jobs['connector-install']
  assert.deepEqual(validateConnectorInstallEntrypoint(job), [])
  for (const mutate of [
    value => { value.strategy.matrix.include.pop() },
    value => { value.strategy.matrix.include[1].runner = 'ubuntu-24.04' },
    value => { value.steps = value.steps.filter(step => step.name !== 'Execute full no-source product guest') },
    value => { value.steps.find(step => step.name === 'Execute full no-source product guest').if = 'false' },
    value => { value.steps.find(step => step.name === 'Run installed entry integrity checks')['continue-on-error'] = true },
  ]) {
    const candidate = structuredClone(job); mutate(candidate)
    assert.ok(validateConnectorInstallEntrypoint(candidate).length > 0)
  }
  for (const path of ['apps/connector/scripts/install-entry.ts', 'apps/api/src/auth-idempotency.ts', 'apps/mcp/src/http.ts', 'packages/contracts/src/index.ts']) {
    const plan = classify([path]); assert.equal(plan.checks['connector-install'], true)
    for (const result of ['failure', 'skipped', 'cancelled']) {
      const needs = results(plan); needs['connector-install'].result = result
      assert.ok(evaluateResults(plan, needs).length > 0)
    }
  }
})

test('纯后端 Lite 部署验收不能删除、条件跳过或吞掉失败', () => {
  const job = parse(readFileSync(new URL('../.github/workflows/ci.yml', import.meta.url), 'utf8')).jobs['source-gates']
  assert.deepEqual(validateBackendLiteEntrypoint(job), [])
  const name = 'Verify backend Lite installation and signed Skill'
  for (const mutate of [
    value => { value.steps = value.steps.filter(step => step.name !== name) },
    value => { value.steps.find(step => step.name === name).if = 'false' },
    value => { value.steps.find(step => step.name === name)['continue-on-error'] = true },
    value => { value.steps.find(step => step.name === name).run += ' || true' },
    value => { delete value.steps.find(step => step.name === name).env.WORKMESH_VALIDATION_OUTPUT },
  ]) {
    const candidate = structuredClone(job); mutate(candidate)
    assert.ok(validateBackendLiteEntrypoint(candidate).length > 0)
  }
  for (const path of ['scripts/verify-a2-backend-lite-api.mjs', 'scripts/verify-a2-backend-lite.mjs', 'scripts/verify-backend-skill.mjs', 'apps/api/assets/skills/workmesh-1.1.0.md'])
    assert.equal(classify([path]).checks['source-gates'], true)
})

test('开发镜像构建接线不能被删除、跳过或吞掉失败', () => {
  const job = parse(readFileSync(new URL('../.github/workflows/ci.yml', import.meta.url), 'utf8')).jobs['source-gates']
  assert.deepEqual(validateDevelopmentImageEntrypoint(job), [])
  for (const mutate of [
    value => { value.steps = value.steps.filter(step => step.name !== 'Build all development images with normal lifecycle hooks') },
    value => { value.steps.find(step => step.name === 'Build all development images with normal lifecycle hooks').if = 'false' },
    value => { value.steps.find(step => step.name === 'Build all development images with normal lifecycle hooks')['continue-on-error'] = true },
    value => { value.steps.find(step => step.name === 'Build all development images with normal lifecycle hooks').run += ' --help' },
  ]) {
    const candidate = structuredClone(job)
    mutate(candidate)
    assert.ok(validateDevelopmentImageEntrypoint(candidate).length > 0)
  }
  for (const path of ['infra/docker/api.Dockerfile', 'infra/docker/web.Dockerfile', 'infra/docker/worker.Dockerfile', 'infra/docker/mcp.Dockerfile', 'apps/connector/scripts/prepare-native.mjs', 'scripts/validate-development-images.py'])
    assert.equal(classify([path]).checks['source-gates'], true)
})

test('classification bootstrap locks only YAML and cannot bypass policy or evidence', () => {
  const input = {
    job: parse(readFileSync(new URL('../.github/workflows/ci.yml', import.meta.url), 'utf8')).jobs.changes,
    manifest: JSON.parse(readFileSync(new URL('./ci-bootstrap/package.json', import.meta.url), 'utf8')),
    lock: JSON.parse(readFileSync(new URL('./ci-bootstrap/package-lock.json', import.meta.url), 'utf8')),
    yamlVersion: parse(readFileSync(new URL('../pnpm-lock.yaml', import.meta.url), 'utf8')).importers['.'].devDependencies.yaml.version,
  }
  assert.deepEqual(validateCiBootstrap(input), [])
  for (const mutate of [
    value => { value.job.steps.find(step => step.name === 'Validate selection and required-result safety').run = 'node --test scripts/ci-policy.test.mjs' },
    value => { value.job.steps.find(step => step.name === 'Validate selection and required-result safety').run = value.job.steps.find(step => step.name === 'Validate selection and required-result safety').run.replace('node scripts/check-integration-docs.mjs 2>&1 | tee ci-logs/integration-docs.log', '') },
    value => { value.job.steps.find(step => step.name === 'Validate selection and required-result safety').run = value.job.steps.find(step => step.name === 'Validate selection and required-result safety').run.replace('set -o pipefail', '') },
    value => { value.job.steps.find(step => step.name === 'Validate selection and required-result safety')['continue-on-error'] = true },
    value => { value.job.steps.find(step => step.name === 'Validate selection and required-result safety').if = 'false' },
    value => { value.job.steps = value.job.steps.filter(step => step.name !== 'Set up exact Node') },
    value => { value.job.steps = value.job.steps.filter(step => step.id !== 'scope') },
    value => { value.job.steps = value.job.steps.filter(step => !step.uses?.startsWith('actions/upload-artifact@')) },
    value => { value.manifest.dependencies.yaml = '^2.9.0' },
    value => { value.lock.packages['node_modules/yaml'].integrity = '' },
    value => { value.lock.packages['node_modules/extra'] = { version: '1.0.0' } },
  ]) {
    const candidate = structuredClone(input)
    mutate(candidate)
    assert.ok(validateCiBootstrap(candidate).length > 0)
  }
})

test('YAML semantics preserve flow maps, aliases and literal command bodies', () => {
  const document = parse('run: &command |\n  set -o pipefail\n  echo "# literal: yes"\nsteps: [{run: *command, continue-on-error: false}]\n')
  assert.equal(document.steps[0].run, 'set -o pipefail\necho "# literal: yes"\n')
  assert.equal(document.steps[0]['continue-on-error'], false)
  assert.throws(() => parse('steps: []\nsteps: []\n'), /unique/)
})

test('连接器改动必须实际运行平台矩阵，失败/跳过不能放行', () => {
  const plan = classify(['apps/connector/src/connect.ts'])
  assert.equal(plan.checks['connector-platform'], true)
  assert.equal(plan.checks['api-integration'], true)
  for (const result of ['skipped', 'failure', 'cancelled']) {
    const needs = results(plan)
    needs['connector-platform'].result = result
    assert.ok(evaluateResults(plan, needs).length > 0)
  }
})

test('known prose on PR and main avoids every install/service/test job', () => {
  for (const options of [{}, { mainPush: true }]) {
    const plan = classify(['docs/adr/0078-review.md', 'docs/plan/design.md', 'README.md', 'AGENTS.md'], options)
    assert.equal(plan.mode, 'docs')
    assert.deepEqual(plan.packages, [])
    assert.ok(Object.values(plan.checks).every(value => value === false))
    assert.deepEqual(evaluateResults(plan, results(plan)), [])
  }
})

test('retired workspace paths fail closed to full without a browser check', () => {
  for (const path of ['apps/web/app/page.tsx', 'packages/ui/src/button.tsx']) {
    const plan = classify([path])
    assert.equal(plan.mode, 'full')
    assert.ok(Object.values(plan.checks).every(Boolean))
    assert.equal('e2e' in plan.checks, false)
  }
})

test('backend assets and fake-agent changes require API checks', () => {
  for (const path of ['apps/api/assets/skills/workmesh-1.1.0.md', 'apps/fake-agent/src/index.ts']) {
    assert.equal(classify([path]).checks['api-integration'], true)
  }
})

test('API and worker changes retain destructive recovery and real backend integration', () => {
  for (const name of ['api', 'worker']) {
    const plan = classify([`apps/${name}/src/index.ts`])
    assert.equal(plan.checks[`${name}-integration`], true)
    assert.equal(plan.checks['recovery-integration'], true)
      assert.equal(plan.checks['api-integration'], true)
  }
})

test('cross-workspace lock audits are selected without inventing runtime dependency cycles', () => {
  for (const name of ['api', 'worker']) {
    const plan = classify([`apps/${name}/src/agent/commands.ts`])
    const consumers = name === 'api' ? ['@workmesh/conformance'] : []
    assert.deepEqual(plan.packages, [`@workmesh/${name}`, ...consumers].sort())
    assert.deepEqual(plan.testPackages, [`@workmesh/${name}`, '@workmesh/db', ...consumers].sort())
    assert.equal(plan.checks['db-integration'], false)
    assert.equal(plan.checks['worker-integration'], name === 'worker')
  }
  assert.ok(classify(['apps/web/app/page.tsx']).testPackages.includes('@workmesh/api'))
  assert.deepEqual(classify(['README.md']).testPackages, [])
})

test('upstream contracts/domain/db/config changes include transitive consumers', () => {
  for (const name of ['contracts', 'domain', 'db', 'config']) {
    const plan = classify([`packages/${name}/src/index.ts`])
    assert.ok(plan.packages.includes('@workmesh/api'))
    assert.ok(plan.packages.includes('@workmesh/worker'))
    assert.equal(plan.checks['api-integration'], true)
    assert.equal(plan.checks['worker-integration'], true)
    assert.equal(plan.checks['recovery-integration'], true)
  }
  const plan = classify(['packages/contracts/src/index.ts'])
  assert.ok(Object.values(plan.checks).every(Boolean))
})

test('protocol changes retain SDK consumers, conformance and direct backend imports', () => {
  const plan = classify(['packages/agent-sdk/src/index.ts'])
  for (const name of ['agent-sdk', 'mcp', 'fake-agent', 'conformance']) assert.ok(plan.packages.includes(`@workmesh/${name}`))
  assert.equal(plan.checks['agent-smoke'], true)
})

test('root config, unknown/deleted workspaces and executable-looking docs fail closed to full', () => {
  for (const path of ['pnpm-lock.yaml', '.github/workflows/ci.yml', 'OPENAPI.yaml', 'SCHEMA.sql', 'AGENT_PROTOCOL.md',
    'docs/route-policy-matrix.md', 'docs/V1_RELEASE_POLICY.md', 'docs/VERSION_POLICY.md', 'docs/operations/releases.md',
    'docs/adr/0043-agent-connection-and-coordination-mcp.md', 'docs/plans/agent-first-coordination-mcp.md',
    'docs/releases/v1.0.0.md', 'docs/example.ts',
    'skills/workmesh/SKILL.md', 'packages/deleted/src/index.ts', 'scripts/runner.mjs']) {
    const plan = classify(['README.md', path])
    assert.equal(plan.mode, 'full', path)
    assert.ok(Object.values(plan.checks).every(Boolean), path)
  }
})

test('main code changes, empty diff, manual/scheduled/reusable CI and merge queues always run full', () => {
  assert.equal(classify(['apps/web/app/page.tsx'], { mainPush: true }).mode, 'full')
  assert.equal(classify([]).mode, 'full')
  for (const eventName of ['workflow_dispatch', 'workflow_call', 'schedule', 'merge_group']) {
    assert.equal(planForEvent(eventName, {}, workspaces, () => { throw new Error('Must not inspect diff') }).mode, 'full')
  }
  assert.equal(planForEvent('push', { ref: 'refs/tags/v1.0.0-rc.1' }, workspaces).mode, 'full')
})

test('PR uses merge-base, main push uses before/after, renames include both paths, missing history runs full', () => {
  const base = 'a'.repeat(40), head = 'b'.repeat(40), mergeBase = 'c'.repeat(40)
  const calls = []
  const git = args => { calls.push(args); return args[0] === 'merge-base' ? mergeBase : 'README.md\0docs/adr/new.md\0' }
  assert.equal(planForEvent('pull_request', { pull_request: { base: { sha: base }, head: { sha: head } } }, workspaces, git).mode, 'docs')
  assert.deepEqual(calls[1], ['diff', '--no-renames', '--name-only', '-z', mergeBase, head])
  calls.length = 0
  assert.equal(planForEvent('push', { ref: 'refs/heads/main', before: base, after: head }, workspaces, git).mode, 'docs')
  assert.deepEqual(calls[0], ['diff', '--no-renames', '--name-only', '-z', base, head])
  const event = { pull_request: { base: { sha: base }, head: { sha: head } } }
  assert.equal(planForEvent('pull_request', event, workspaces, () => { throw new Error('Missing object') }).mode, 'full')
  assert.equal(planForEvent('pull_request', {}, workspaces).mode, 'full')
  assert.throws(() => planForEvent('pull_request', event, workspaces, args => {
    if (args.includes('--check')) throw new Error('Invalid whitespace')
    return args[0] === 'merge-base' ? mergeBase : 'README.md\0'
  }), /Invalid whitespace/)
  assert.equal(classify(['docs/old.md', 'apps/api/src/new.ts']).checks['api-integration'], true)
})

test('aggregate rejects failure, cancellation and accidental skips for every required job', () => {
  const plan = classify([], { forceFull: true })
  for (const id of ['changes', ...checkIds]) {
    for (const result of ['failure', 'cancelled', 'skipped']) {
      const needs = results(plan); needs[id].result = result
      assert.ok(evaluateResults(plan, needs).some(failure => failure.startsWith(`${id}=`)))
    }
  }
})

test('aggregate only accepts planned skips and rejects incomplete/malformed decisions', () => {
  const plan = classify(['apps/connector/src/connect.ts'])
  assert.deepEqual(evaluateResults(plan, results(plan)), [])
  for (const result of ['success', 'failure', 'cancelled']) {
    const needs = results(plan); needs['db-integration'].result = result
    assert.ok(evaluateResults(plan, needs).length > 0)
  }
  assert.throws(() => evaluateResults(null, {}))
  assert.throws(() => evaluateResults(plan, {}))
  assert.throws(() => evaluateResults({ ...plan, checks: {} }, results(plan)))
})

// 真实MCP/Pi链不得因只改adapter或Runner而漏过必需API job。
test('MCP discovery consumers require real conformance and propagate failed or skipped job', () => {
  for (const path of ['apps/mcp/src/index.ts', 'apps/agent-runner/src/workmesh-tools.ts', 'packages/agent-sdk/src/index.ts', 'packages/conformance/src/index.ts']) {
    const plan = classify([path])
    assert.equal(plan.checks['api-integration'], true)
    for (const result of ['failure', 'cancelled', 'skipped']) {
      const actual = results(plan)
      actual['api-integration'] = { result }
      assert.ok(evaluateResults(plan, actual).some(failure => failure.startsWith('api-integration=')))
    }
  }
})

test('real workflow semantic mutations cannot silently omit MCP conformance', () => {
  const input = {
    job: parse(readFileSync(new URL('../.github/workflows/ci.yml', import.meta.url), 'utf8')).jobs['api-integration'],
    rootScripts: JSON.parse(readFileSync(new URL('../package.json', import.meta.url))).scripts,
    packageScripts: JSON.parse(readFileSync(new URL('../packages/conformance/package.json', import.meta.url))).scripts,
    integrationConfig: readFileSync(new URL('../packages/conformance/vitest.integration.config.ts', import.meta.url), 'utf8'),
    unitConfig: readFileSync(new URL('../vitest.config.ts', import.meta.url), 'utf8'),
  }
  assert.deepEqual(validateMcpConformanceEntrypoints(input), [])
  for (const mutate of [
    value => { value.job.steps = value.job.steps.filter(step => step.name !== 'Run real MCP and Pi conformance') },
    value => { value.rootScripts['test:integration'] = 'pnpm test:integration:api' },
    value => { value.rootScripts['test:conformance:integration'] = 'pnpm --filter @workmesh/conformance test:integration' },
    value => { value.packageScripts['test:integration'] = 'vitest run' },
    value => { delete value.rootScripts['test:acceptance:m4'] },
    value => { delete value.packageScripts['acceptance:optional'] },
    value => { value.integrationConfig += "'src/optional-domains.acceptance.ts'" },
    value => { value.job.steps.find(step => step.name === 'Run real MCP and Pi conformance').run += '\npnpm test:acceptance:m4' },
    ...['src/mcp-coverage.conformance.test.ts', 'src/execution-recovery.conformance.test.ts', 'src/planning-collaboration.conformance.test.ts', 'src/delivery-recovery.conformance.test.ts', 'src/joint-clients.conformance.test.ts', 'src/optional-domains.conformance.test.ts'].map(suite => value => {
      assert.ok(value.integrationConfig.includes(suite), 'Mutation must remove an existing suite')
      value.integrationConfig = value.integrationConfig.replace(suite, 'deleted-suite.test.ts')
    }),
    value => { value.unitConfig = value.unitConfig.replace('**/optional-domains.conformance.test.ts', '**/deleted-suite.test.ts') },
    value => { value.integrationConfig = value.integrationConfig.replace('passWithNoTests: false', 'passWithNoTests: true') },
    value => { value.job.steps.find(step => step.name === 'Run real MCP and Pi conformance').run = 'pnpm test:conformance:integration' },
    value => { value.job.steps.find(step => step.name === 'Run real MCP and Pi conformance')['continue-on-error'] = true },
    value => { value.job.steps = value.job.steps.filter(step => !step.uses?.startsWith('actions/upload-artifact@')) },
  ]) {
    const candidate = structuredClone(input)
    mutate(candidate)
    assert.ok(validateMcpConformanceEntrypoints(candidate).length > 0)
  }
})

test('controlled CRLF evidence preserves bytes and all other whitespace gates', () => {
  // 仅本次新建的 Git 夹具；不删除或修改任何已有资源。
  const directory = mkdtempSync(join(tmpdir(), 'workmesh-evidence-whitespace-'))
  const git = args => execFileSync('git', ['-c', 'core.autocrlf=false', '-c', 'core.whitespace=blank-at-eol,blank-at-eof,space-before-tab', ...args], { cwd: directory })
  git(['init', '--quiet'])
  const evidence = join(directory, 'docs/plan/agent-mcp-m4/execution')
  mkdirSync(evidence, { recursive: true })
  const attrs = readFileSync(new URL('../docs/plan/agent-mcp-m4/execution/.gitattributes', import.meta.url))
  writeFileSync(join(evidence, '.gitattributes'), attrs)
  const path = 'docs/plan/agent-mcp-m4/execution/probe.json'
  const exact = Buffer.from('{"actual":true}\r\n')
  writeFileSync(join(directory, path), exact)
  git(['add', '.'])
  git(['diff', '--cached', '--check'])
  assert.deepEqual(git(['show', `:${path}`]), exact)
  for (const bytes of ['bad \r\n', ' \tbad\r\n', 'bad\r\n\r\n']) {
    writeFileSync(join(directory, path), bytes)
    git(['add', path])
    assert.notEqual(spawnSync('git', ['diff', '--cached', '--check'], { cwd: directory }).status, 0)
  }
  writeFileSync(join(directory, path), exact)
  writeFileSync(join(directory, 'outside.json'), exact)
  git(['add', '.'])
  assert.notEqual(spawnSync('git', ['-c', 'core.whitespace=blank-at-eol,blank-at-eof,space-before-tab', 'diff', '--cached', '--check'], { cwd: directory }).status, 0)
})
