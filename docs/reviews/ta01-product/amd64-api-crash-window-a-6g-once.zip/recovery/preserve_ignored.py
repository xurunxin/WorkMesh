from pathlib import Path
import hashlib, json, zipfile

OLD=Path('C:/Users/xurx/.tds/workspaces/01a138ab-2566-7f87-9d06-5b16bebd86c2')
ROOT=OLD/'ci-logs/execution-recovery'
OUT=Path('.tmp/ta01-recovery')
rows=[]
archive=OUT/'retained-private-execution-recovery.zip'
with zipfile.ZipFile(archive,'x',zipfile.ZIP_DEFLATED) as z:
    for p in sorted(ROOT.rglob('*')):
        if not p.is_file():continue
        data=p.read_bytes();name=p.relative_to(OLD).as_posix()
        rows.append({'path':name,'bytes':len(data),'sha256':hashlib.sha256(data).hexdigest()})
        z.writestr(name,data)
with zipfile.ZipFile(archive) as z:
    assert z.testzip() is None
    for entry in rows:assert hashlib.sha256(z.read(entry['path'])).hexdigest()==entry['sha256']
value={'source':'旧树忽略项补查：构建产物、依赖及缓存原地保留；另保全既有执行恢复日志。',
       'files':rows,'count':len(rows),'bytes':sum(x['bytes'] for x in rows),
       'privateArchiveLocalPath':str(archive),'privateArchiveSha256':hashlib.sha256(archive.read_bytes()).hexdigest(),
       'privateRawBytesCommitted':False,'oldTreePreserved':True}
(OUT/'ignored-evidence-inventory.json').write_text(json.dumps(value,ensure_ascii=False,indent=2)+'\n',encoding='utf8')
print(json.dumps({'files':value['count'],'bytes':value['bytes'],'privateArchiveSha256':value['privateArchiveSha256']}))
