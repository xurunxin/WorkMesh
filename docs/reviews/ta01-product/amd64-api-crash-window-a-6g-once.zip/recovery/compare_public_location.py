from pathlib import Path
import hashlib, json, subprocess

ROOT=Path('.tmp/ta01-resumption/api-crash-window-a-6g-once')
OLD=Path('C:/Users/xurx/.tds/workspaces/01a138ab-2566-7f87-9d06-5b16bebd86c2/.tmp/ta01-resumption/public-node-symbols')
result=json.loads((ROOT/'result.json').read_bytes())
trace=result['final']['nativeTrace'];location=trace['location']
with (OLD/'node').open('rb') as f:binary_sha=hashlib.file_digest(f,'sha256').hexdigest()
assert binary_sha==trace['targetBinarySha256']=='638c77326270093b1251a5e72b4335c94c74856a210460341c73d6f3da647328'
raw=(OLD/'symbol-index.json').read_bytes();index_sha=hashlib.sha256(raw).hexdigest()
assert index_sha=='0e360d773217d9bd4a55ea5bbe4ebdbc05326ec017d2cdcf78606a6f42302399'
symbols=json.loads(raw);assert symbols['binarySha256']==binary_sha
positions=[location['nodeElfAddress'],*[v['lookupNodeElfAddress'] for v in location['publicFrameChain']['frames']]]
mapped=[]
for address in positions:
    matches=[{'symbol':name,'elfAddress':start,'bytes':size,'offsetInFunction':address-start}
             for start,size,name in symbols['symbols'] if start<=address<start+size]
    assert matches
    mapped.append({'nodeElfAddress':address,'matches':matches})
path='docs/reviews/ta01-product/resumption-ci559-public-location.json'
old_bytes=subprocess.check_output(['git','show','1a2e562f1d5df8680ff5cf71362d148e447d8e58:'+path])
old=json.loads(old_bytes)
with (OLD/'node').open('rb') as f:
    f.seek(location['nodeFileOffset']);instruction=f.read(4).hex()
assert location['nodeElfAddress']==old['faultInstruction']['address'] and instruction==old['faultInstruction']['bytes']
value={'source':'仅对本次已有安全core元数据和旧缓存的公开Node二进制做静态匹配；没有新VM、core读取、GDB运行或业务请求。',
       'targetBinarySha256':binary_sha,'publicIndexSha256':index_sha,'captureId':trace['captureId'],
       'publicLocations':mapped,'faultInstruction':{'nodeFileOffset':location['nodeFileOffset'],'bytes':instruction,
           'instructionFromExistingVerifiedDisassembly':old['faultInstruction']['instruction']},
       'previousEvidence':{'path':path,'gitBlob':subprocess.check_output(['git','rev-parse','1a2e562f1d5df8680ff5cf71362d148e447d8e58:'+path]).decode().strip(),
                           'sha256':hashlib.sha256(old_bytes).hexdigest(),'sameNodeBinaryAndPublicFaultPosition':True},
       'limits':'IC::UpdateState+128和有限公开帧不能区分产品输入、运行依赖或TCG；没有JS调用点、寄存器操作数或完整栈。signalCode=-6保留原值，不仅据此推发送方或根因。',
       'debugger':'原GDB到after-binary后超时；coreCaptured=true但captured=false，不能宣称完整调试成功。'}
(ROOT/'public-location-comparison.json').write_text(json.dumps(value,ensure_ascii=False,indent=2)+'\n',encoding='utf8')
print(json.dumps({'faultLocation':mapped[0],'publicFrameCount':len(mapped)-1,'samePriorPublicPosition':True}))
