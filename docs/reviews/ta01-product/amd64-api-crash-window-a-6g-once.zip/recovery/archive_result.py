from pathlib import Path
from datetime import datetime, timezone
import hashlib, json, re, subprocess, zipfile

ROOT=Path('.tmp/ta01-resumption/api-crash-window-a-6g-once')
REC=Path('.tmp/ta01-recovery')
OUT=Path('docs/reviews/ta01-product/amd64-api-crash-window-a-6g-once')
sha=lambda b:hashlib.sha256(b).hexdigest()
ledger=json.loads((ROOT/'resources.json').read_bytes());cid=ledger['containers'][0]['id']
result=json.loads((ROOT/'result.json').read_bytes())
assert ledger['removedAndAbsent'] and ledger['vmStarted']
assert result['maximumSeconds']==9000 and result['oneVmOnly']
assert result['sourceHead']=='9c8bbff749c1d2a52a3e6489dcec02d2d7c859af'
assert result['manifestSha256']=='c34733df5e9d45ac6fddbc504a45540779e252071d55fe22eb9bfbee2744028b'
assert result['qemuBinarySha256']=='8a35ccba41582fc6c38b9df85fc9e35fa1d42f414d2d7d8090ee9b2f5e7c0854'
assert result['guestSha256']=='6a81c37564db9b1ee84e141922625e1d7c5b389b99bb3c572e0243607d5bb4d2'
assert result['actualTargetAttempts'] in [0,1,'unknown']
for name,digest in ledger['diagnosticSourceSha256'].items():
    assert sha((ROOT/name).read_bytes())==digest==sha((ROOT/('actual-'+name)).read_bytes())
absence=subprocess.run(['docker','inspect',cid],capture_output=True,timeout=30)
assert absence.returncode!=0 and b'no such object' in absence.stderr.lower()
stop=datetime.now(timezone.utc).isoformat()
events=subprocess.check_output(['docker','events','--since',ledger['createdAt'],'--until',stop,
                               '--filter','container='+cid,'--format','{{json .}}'],timeout=30)
safe=[]
for raw in events.splitlines():
    event=json.loads(raw);assert event.get('id',event.get('Actor',{}).get('ID'))==cid
    item={'id':cid,'action':event.get('Action',event.get('status')),'timeNano':event.get('timeNano')}
    if 'exitCode' in event.get('Actor',{}).get('Attributes',{}):item['exitCode']=event['Actor']['Attributes']['exitCode']
    safe.append(item)
(ROOT/'outer-events-after-stop.json').write_text(json.dumps(safe,indent=2)+'\n',encoding='utf8')
(ROOT/'cleanup-verification.json').write_text(json.dumps({'at':stop,'containerId':cid,'inspectExitCode':absence.returncode,
    'safeError':'no such object','stderrSha256':sha(absence.stderr),'noOtherResourceRemoved':True},ensure_ascii=False,indent=2)+'\n',encoding='utf8')
members={}
for p in sorted(ROOT.iterdir()):
    if p.is_file() and not p.name.startswith('live-'):members[p.name]=p.read_bytes()
for p in sorted((ROOT/'source').glob('*.py')):
    original=subprocess.check_output(['git','show',result['sourceHead']+':scripts/server-distribution/'+p.name])
    assert p.read_bytes()==original;members['original-source/'+p.name]=original
for name in ['prelaunch-audit.json','ignored-evidence-inventory.json','preserve_ignored.py','snapshot.py','archive_result.py','compare_public_location.py']:
    members['recovery/'+name]=(REC/name).read_bytes()
for name,data in members.items():
    assert not re.search(rb'wm[ips]_[A-Za-z0-9_-]{43}|-----BEGIN (?:RSA |EC |OPENSSH )?PRIVATE KEY-----',data),name
with zipfile.ZipFile(OUT.with_suffix('.zip'),'x',zipfile.ZIP_DEFLATED) as z:
    for name,data in members.items():z.writestr(name,data)
with zipfile.ZipFile(OUT.with_suffix('.zip')) as z:
    assert z.testzip() is None
    for name,data in members.items():assert z.read(name)==data
index={'source':'本次唯一获批6GiB外层API窗口的原始安全回执、执行输入、资源及停止证明。不是完整产品验收或历史139闭合。',
       'branch':'tds/conv-01a1572a-7aeb-7b6d-b7e8-83e89c2b723d','recoveredHead':'1a2e562f1d5df8680ff5cf71362d148e447d8e58',
       'productSourceHead':result['sourceHead'],'authorization':json.loads((ROOT/'authorization.json').read_bytes()),
       'newSessionAuthorization':'用户2026-10-20 10:34批准新会话接续，先核旧树及同次资源；不增加次数或重置已运行期限。',
       'result':result,'outer':{'containerId':cid,'owner':ledger['owner'],'memoryBytes':6442450944,
          'memorySwapTotalBytes':6442450944,'cpuQuota':4,'capacityBeforeLaunch':json.loads((ROOT/'capacity-before-launch.json').read_bytes()),
          'lifetimeMemoryPeakBytes':int((ROOT/'outer-memory.peak.txt').read_text()) if (ROOT/'outer-memory.peak.txt').exists() else None,
          'memoryEvents':(ROOT/'outer-memory.events.txt').read_text() if (ROOT/'outer-memory.events.txt').exists() else None,
          'beforeStop':ledger['beforeStop'],'runnerExitCode':ledger['runnerExitCode'],
          'events':safe,'eventHistoryBoundary':'Docker事件保留窗口；cgroup峰值从容器创建累计，含准备及本次执行，不是纯QEMU RSS。'},
       'cleanup':json.loads((ROOT/'cleanup-verification.json').read_bytes()),
       'p1State':{'restoredCandidate':'正式复审已闭合','historicApi139':'未闭；只评本次样本','historicMcp139':'未闭；本次不执行MCP业务窗口，原安装健康前缀保持'},
       'noRetryOrAdditionalWindow':True,'privateDataOrCoreOrDiskArchived':False,
       'selectedZipSha256':sha(OUT.with_suffix('.zip').read_bytes()),
       'members':{name:{'bytes':len(data),'sha256':sha(data)} for name,data in members.items()}}
OUT.with_suffix('.json').write_text(json.dumps(index,ensure_ascii=False,indent=2)+'\n',encoding='utf8')
print(json.dumps({'status':result['status'],'seconds':result['totalSeconds'],'targetAttempts':result['actualTargetAttempts'],
                  'members':len(members),'zipSha256':index['selectedZipSha256']}))
