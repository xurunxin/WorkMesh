from pathlib import Path
from datetime import datetime,timezone
import ast,hashlib,json,subprocess,time

ROOT=Path('.tmp/ta01-resumption/api-crash-window-a')
ledger=json.loads((ROOT/'resources.json').read_text(encoding='utf8'))
cid=ledger['containers'][0]['id']
assert not ledger['vmStarted'] and not (ROOT/'attempt-started.json').exists()
def save():(ROOT/'resources.json').write_text(json.dumps(ledger,ensure_ascii=False,indent=2)+'\n',encoding='utf8')
def call(args,timeout=60):return subprocess.run(['docker',*args],capture_output=True,timeout=timeout)
for name in ['run_window.py','diagnostic_guest.py','api_identity.py']:ast.parse((ROOT/name).read_text(encoding='utf8'))
value=json.loads(call(['inspect',cid]).stdout)[0]
assert value['Id']==cid and value['Config']['Labels'][ledger['label']]==ledger['owner'] and not value['Mounts']
assert not value['HostConfig']['Privileged'] and not value['HostConfig'].get('Devices') and not value['HostConfig'].get('PortBindings')
ledger.update(vmLaunchCommandInvoked=True,launchUtc=datetime.now(timezone.utc).isoformat(),
              command=['docker','exec',cid,'python3','/opt/api-window/run_window.py'],
              externalNetwork='仅原guest准备从Ubuntu源获取Docker/固定GDB；原程序下载候选后删除默认路由，业务不联网拉镜像',
              diagnosticSourceSha256={n:hashlib.sha256((ROOT/n).read_bytes()).hexdigest() for n in ['run_window.py','diagnostic_guest.py','api_identity.py']})
save()
with (ROOT/'attempt-started.json').open('x',encoding='utf8') as out:
    out.write(json.dumps({'at':ledger['launchUtc'],'maximumSeconds':9000,'oneVmOnly':True,'noRetry':True,'window':'A'})+'\n')
start=time.monotonic()
try:
    try:
        value=call(['exec',cid,'python3','/opt/api-window/run_window.py'],9030)
        ledger['runnerExitCode']=value.returncode
        (ROOT/'runner.stdout').write_bytes(value.stdout);(ROOT/'runner.stderr').write_bytes(value.stderr)
    except subprocess.TimeoutExpired:
        ledger['outerCleanupBackstopReached']=True
finally:
    ledger['runnerSeconds']=time.monotonic()-start;save()
    for name in ['result.json','started.json','receipts.ndjson','serial.log','qemu-stderr.log']:
        value=call(['exec',cid,'cat','/opt/api-window/guest/'+name],30)
        if value.returncode==0:(ROOT/name).write_bytes(value.stdout)
    ledger['vmStarted']=(ROOT/'started.json').exists()
    if (ROOT/'result.json').exists():
        result=json.loads((ROOT/'result.json').read_text());ledger['vmResult']={k:result.get(k) for k in ['status','totalSeconds','qemuExitCode','deadlineReached','actualTargetAttempts']}
    value=call(['exec',cid,'sh','-c','ps -eo comm | sort | uniq -c'])
    if value.returncode==0:(ROOT/'process-names-before-stop.txt').write_bytes(value.stdout)
    value=json.loads(call(['inspect',cid]).stdout)[0]
    assert value['Id']==cid and value['Config']['Labels'][ledger['label']]==ledger['owner'] and not value['Mounts']
    ledger['beforeStop']={k:value['State'][k] for k in ['Running','ExitCode','OOMKilled']};save()
    if value['State']['Running']:assert call(['stop','--time','10',cid]).returncode==0
    assert call(['rm',cid]).returncode==0
    absent=call(['inspect',cid]);assert absent.returncode!=0 and b'no such object' in absent.stderr.lower()
    ledger['removedAndAbsent']=True;save()
print(json.dumps({'runnerExitCode':ledger.get('runnerExitCode'),'vm':ledger.get('vmResult'),'removedAndAbsent':ledger.get('removedAndAbsent')}))
