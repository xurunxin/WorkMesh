import copy, hashlib, unittest
from api_identity import select_api


class Identity(unittest.TestCase):
    def setUp(self):
        self.identity = {'id': 'owned-id', 'project': 'ta01-enterprise'}
        self.manifest = {'images': {'api': {'id': 'sha256:config', 'archiveId': 'sha256:archive'}}}
        self.info = {'Config': {'Labels': {'com.docker.compose.service': 'api',
            'com.docker.compose.project': 'ta01-enterprise', 'io.workmesh.installation': 'owned-id',
            'io.workmesh.installation-root': hashlib.sha256(b'/root/server-install/enterprise').hexdigest()}},
            'Image': 'sha256:config', 'HostConfig': {'ReadonlyRootfs': True},
            'State': {'Running': True, 'Pid': 100}}

    def select(self, values):
        return select_api(values, self.identity, '/root/server-install/enterprise', self.manifest)

    def test_exact_and_archive_identity(self):
        self.assertIs(self.select([self.info]), self.info)
        self.info['Image'] = 'sha256:archive'
        self.assertIs(self.select([self.info]), self.info)

    def test_mcp_or_other_installation_or_root_rejected(self):
        for key, value in [('com.docker.compose.service', 'mcp'), ('io.workmesh.installation', 'other'),
                           ('io.workmesh.installation-root', 'other'), ('com.docker.compose.project', 'other')]:
            info = copy.deepcopy(self.info); info['Config']['Labels'][key] = value
            with self.assertRaises(ValueError): self.select([info])

    def test_wrong_image_or_writable_or_stopped_rejected(self):
        for section, key, value in [(None, 'Image', 'sha256:unknown'), ('HostConfig','ReadonlyRootfs',False),
                                    ('State','Running',False), ('State','Pid',0)]:
            info = copy.deepcopy(self.info)
            (info if section is None else info[section])[key] = value
            with self.assertRaises(ValueError): self.select([info])

    def test_ambiguous_rejected(self):
        with self.assertRaises(ValueError): self.select([self.info, copy.deepcopy(self.info)])


if __name__ == '__main__': unittest.main()
