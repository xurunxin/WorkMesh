from pathlib import Path
import base64, hashlib, json, subprocess, time, uuid
from datetime import datetime, timezone

root = Path('.tmp/ta01-resumption/ci568/bootstrap-platform-probe')
root.mkdir(exist_ok=False)
owner = str(uuid.uuid4())
image = 'sha256:df972be33b984b13cdcf49f5fe132db249f779fb476be751ac6032ef3b1c55ff'
head = '8ff1f8bf87b1593ff4833b1ab1358e71f8a23a8b'
old_head = '1de9bf3d777901796247af916139d4bfa36e6811'
label = 'io.workmesh.ta01.platform-probe.owner'
def call(args, **kw):
    return subprocess.run(['docker', *args], capture_output=True, timeout=45, **kw)
scripts = {name: subprocess.check_output(['git', 'show', ref + ':scripts/server-distribution/install.sh'])
           for name, ref in [('old', old_head), ('new', head)]}
for name, data in scripts.items():
    (root / (name + '-install.sh')).write_bytes(data)
script = 'set -eu\numask 077\nwork=$(mktemp -d)\n'
for name, data in scripts.items():
    script += "printf '%s' '" + base64.b64encode(data).decode() + "' | base64 -d > \"$work/" + name + '.sh"\n'
script += '''
test ! -e "$work/prefix"
test -z "$(command -v docker || true)"
mkdir "$work/bundle"
measure() {
  name=$1; arch=$2; entry=$3
  printf '{\n  "arch": "%s",\n  "fixture": true\n}\n' "$arch" > "$work/bundle/manifest.json"
  digest=$(sha256sum "$work/bundle/manifest.json" | cut -d ' ' -f 1)
  if output=$(sh "$work/$entry.sh" "$work/bundle" "$digest" "$work/prefix" "$work/config.json" check 2>&1); then status=0; else status=$?; fi
  case "$output" in *INSTALL_UNSUPPORTED_PLATFORM*) rejected=1;; *) rejected=0;; esac
  case "$output" in *'docker: not found'*) missing_docker=1;; *) missing_docker=0;; esac
  if test -e "$work/prefix"; then prefix_created=1; else prefix_created=0; fi
  printf '%s\t%s\t%s\t%s\t%s\n' "$name" "$status" "$rejected" "$missing_docker" "$prefix_created"
}
measure old_arm arm64 old
measure new_arm arm64 new
measure new_amd64 amd64 new
'''
(root / 'harness.sh').write_text(script, encoding='utf-8', newline='\n')
ledger = {'owner': owner, 'imageId': image, 'sourceHead': head, 'oldSourceHead': old_head,
          'beganAt': datetime.now(timezone.utc).isoformat(), 'newVm': False,
          'scope': 'Linux amd64容器内启动器拒绝边界；合成最小manifest，不是有效完整发行包或安装验收，不测139',
          'scripts': {name: hashlib.sha256(data).hexdigest() for name,data in scripts.items()}}
def save():
    (root / 'result.json').write_text(json.dumps(ledger, ensure_ascii=False, indent=2) + '\n', encoding='utf-8')
save()
created = call(['create', '-i', '--network', 'none', '--cpus', '4', '--memory', '4g', '--memory-swap', '4g',
                '--pids-limit', '128', '--security-opt', 'no-new-privileges:true', '--tmpfs', '/data',
                '--label', label + '=' + owner, '--entrypoint', 'sh', image, '-s'])
assert created.returncode == 0, 'create failed; output withheld'
cid = created.stdout.decode().strip()
assert len(cid) == 64 and all(c in '0123456789abcdef' for c in cid)
ledger['containerId'] = cid
save()
try:
    inspected = call(['inspect', cid]); assert inspected.returncode == 0
    data = json.loads(inspected.stdout)[0]
    assert data['Id'] == cid and data['Image'] == image and data['Config']['Labels'][label] == owner
    assert not data['HostConfig'].get('Binds') and not data['HostConfig']['Privileged']
    assert not data['HostConfig'].get('Devices') and not data['HostConfig'].get('PortBindings')
    assert data['HostConfig']['Memory'] == data['HostConfig']['MemorySwap'] == 4 * 1024**3
    assert data['HostConfig']['NanoCpus'] == 4_000_000_000
    assert data['HostConfig']['NetworkMode'] == 'none'
    assert all(m['Type'] == 'tmpfs' for m in data['Mounts'])
    ledger['identityAndBoundaryVerified'] = True; save()
    began = time.monotonic()
    measured = call(['start', '--attach', '--interactive', cid], input=script.encode())
    (root / 'stdout.txt').write_bytes(measured.stdout)
    (root / 'stderr.txt').write_bytes(measured.stderr)
    ledger.update(exitCode=measured.returncode, seconds=time.monotonic()-began,
                  stdout=measured.stdout.decode(), stderrSha256=hashlib.sha256(measured.stderr).hexdigest())
    rows = [line.split('\t') for line in measured.stdout.decode().splitlines()]
    assert measured.returncode == 0
    assert rows == [['old_arm','127','0','1','0'], ['new_arm','1','1','0','0'], ['new_amd64','127','0','1','0']], rows
    ledger['boundaryAssertionsPassed'] = True; save()
finally:
    final = call(['inspect', cid]); assert final.returncode == 0
    value = json.loads(final.stdout)[0]
    assert value['Id'] == cid and value['Config']['Labels'][label] == owner
    ledger['beforeCleanup'] = {k:value['State'][k] for k in ['Status','Running','ExitCode','OOMKilled']}
    save()
    if value['State']['Running']:
        stopped = call(['stop', '--time', '10', cid]); assert stopped.returncode == 0
    removed = call(['rm', cid]); assert removed.returncode == 0
    absent = call(['inspect', cid])
    assert absent.returncode != 0 and b'No such' in absent.stderr
    ledger['removedAndAbsent'] = True; save()
print(json.dumps({'rows':ledger.get('stdout'), 'removedAndAbsent':ledger.get('removedAndAbsent')}))
