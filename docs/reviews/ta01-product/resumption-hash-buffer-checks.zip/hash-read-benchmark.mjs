import { createReadStream } from 'node:fs'
import { readFile, writeFile } from 'node:fs/promises'
import { createHash } from 'node:crypto'
import { performance } from 'node:perf_hooks'
import { fileHash } from '../../../scripts/server-distribution/manifest.mjs'

const input = new URL('../ci526-candidate-amd64.zip', import.meta.url)
const expected = '714f51991706cba0af5a3bf7e11d2fb65a3f67de10a06d8d4df91d2310d25012'
const runs = []
for (const highWaterMark of [64 * 1024, 1024 * 1024]) {
  const started = performance.now(), digest = createHash('sha256')
  let chunks = 0, bytes = 0
  for await (const block of createReadStream(input, { highWaterMark })) {
    digest.update(block); chunks += 1; bytes += block.length
  }
  const sha256 = digest.digest('hex')
  if (sha256 !== expected) throw new Error('BENCHMARK_INPUT_CHANGED')
  runs.push({ highWaterMark, chunks, bytes, sha256, milliseconds: performance.now() - started })
}
if (await fileHash(input) !== expected) throw new Error('BENCHMARK_IMPLEMENTATION_MISMATCH')
const result = {
  说明: '只读复用旧候选ZIP，Windows原生Node22的读取次数／SHA比较；顺序固定、缓存未控制，不代TCG性能、物理最低配置或完整验收，不认定超时根因。输入未修改或删除。',
  node: process.version, platform: process.platform, arch: process.arch,
  implementationSha256: createHash('sha256').update(await readFile(new URL('../../../scripts/server-distribution/manifest.mjs', import.meta.url))).digest('hex'),
  runs,
}
await writeFile(new URL('hash-read-benchmark.json', import.meta.url), JSON.stringify(result, null, 2) + '\n', { flag: 'wx' })
console.log(JSON.stringify(result))
