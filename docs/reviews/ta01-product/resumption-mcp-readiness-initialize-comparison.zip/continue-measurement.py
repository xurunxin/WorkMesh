from pathlib import Path
import ast,hashlib,json,subprocess,time
base=Path('.tmp/ta01-resumption/mcp-health-initialize-566');ledger=json.loads((base/'resources.json').read_bytes());identifier=ledger['containers'][0]['id']
sha=lambda b:hashlib.sha256(b).hexdigest()
# Preserve the first helper failure; Python did not parse, so no Node or VM began.
assert (base/'native-runner-exit.json').read_text().strip()=='{"exitCode": 1}'
assert b'SyntaxError' in (base/'native-runner.stderr').read_bytes()
ledger['helperFailures']=[{'stage':'native wrapper syntax','nodeStarted':False,'guestStarted':False,'sourceSha256':sha((base/'used-native-runner.py').read_bytes()),'stderrSha256':sha((base/'native-runner.stderr').read_bytes())}]
for name in ['used-component-tcg-guest.py','used-run-component-tcg.py']:
 ast.parse((base/name).read_text(encoding='utf8'))
for args in [['mkdir','/opt/micro/native-root'],['tar','-xzf','/opt/micro/node-rootfs.tar.gz','-C','/opt/micro/native-root'],['cp','/opt/micro/measurement.mjs','/opt/micro/native-root/tmp/measurement.mjs']]:
 value=subprocess.run(['docker','exec',identifier,*args],capture_output=True,timeout=90)
 assert value.returncode==0, 'native preparation failed; no runtime retry'
native='\n'.join(['import os,resource', 'resource.setrlimit(resource.RLIMIT_CORE,(0,0))', "os.environ['NODE_ENV']='production'", "os.execvp('chroot',['chroot','--userspec=10001:10001','/opt/micro/native-root','/usr/local/bin/node','/tmp/measurement.mjs','/app'])"])
ast.parse(native)
(base/'used-native-exec.py').write_text(native+'\n',encoding='utf8',newline='\n')
ledger['nativeExecSha256']=sha((native+'\n').encode());(base/'resources.json').write_text(json.dumps(ledger,ensure_ascii=False,indent=2)+'\n',encoding='utf8')
began=time.monotonic()
with (base/'native-measurement.stdout').open('xb') as out,(base/'native-measurement.stderr').open('xb') as err:
 value=subprocess.run(['docker','exec',identifier,'python3','-c',native],stdout=out,stderr=err,timeout=600)
metadata={'exitCode':value.returncode,'controllerCommandSeconds':time.monotonic()-began,'stdoutSha256':sha((base/'native-measurement.stdout').read_bytes()),'stderrSha256':sha((base/'native-measurement.stderr').read_bytes()),'coreLimit':0}
(base/'native-measurement.json').write_text(json.dumps(metadata,indent=2)+'\n',encoding='utf8')
print(json.dumps({'mode':'native',**metadata}),flush=True)
assert value.returncode==0,'native micro failed; no second environment or runtime retry'
probe=json.loads((base/'native-measurement.stdout').read_bytes());assert probe['mode']=='readiness-initialize-overlap' and len(probe['requests'])==24 and probe['unknownRequests']==0
with (base/'tcg-runner.stdout').open('xb') as out,(base/'tcg-runner.stderr').open('xb') as err:
 value=subprocess.run(['docker','exec',identifier,'python3','/opt/micro/run-component-tcg.py','--exact-mcp-role'],stdout=out,stderr=err,timeout=1250)
(base/'tcg-runner-exit.json').write_text(json.dumps({'exitCode':value.returncode})+'\n',encoding='utf8')
for source,target in [('guest/result.json','tcg-result.json'),('guest/serial.log','tcg-serial.log'),('guest/qemu-stderr.log','tcg-qemu-stderr.log')]:
 with (base/target).open('xb') as output:
  receipt=subprocess.run(['docker','exec',identifier,'cat','/opt/micro/'+source],stdout=output,stderr=subprocess.PIPE,timeout=30)
 assert receipt.returncode==0,'receipt missing; no runtime retry'
print(json.dumps({'mode':'tcg','runnerExitCode':value.returncode}),flush=True)
assert value.returncode==0
