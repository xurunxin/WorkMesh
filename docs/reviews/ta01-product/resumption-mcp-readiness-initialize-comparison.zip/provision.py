from pathlib import Path
import json
import subprocess
import uuid

root = Path('.tmp/ta01-resumption/mcp-health-initialize-566')
assert root.exists() and not (root / "resources.json").exists()
owner = str(uuid.uuid4())
def call(args, **kwargs):
    return subprocess.run(args, capture_output=True, timeout=30, **kwargs)
image = call(['docker', 'image', 'inspect', 'ubuntu:24.04'])
assert image.returncode == 0
image = json.loads(image.stdout)[0]
assert image['Architecture'] == 'amd64' and image['Os'] == 'linux'
ledger = {'owner': owner, 'imageId': image['Id'], 'repoDigests': image['RepoDigests'], 'containers': [],
    'scope': '仅同锁定QEMU版本的小组件TCG对照，非完整产品验收；无宿主挂载、端口、Docker socket或真实凭据。'}
def save():
    (root / 'resources.json').write_text(json.dumps(ledger, ensure_ascii=False, indent=2) + '\n', encoding='utf8')
save()
result = call(['docker', 'create', '--pull', 'never', '--cpus', '4', '--memory', '4g', '--memory-swap', '4g',
    '--pids-limit', '512', '--security-opt', 'no-new-privileges:true', '--label', 'io.workmesh.ta01.probe.owner=' + owner,
    '--entrypoint', '/bin/sleep', image['Id'], 'infinity'])
assert result.returncode == 0, 'owned container creation failed; stderr withheld'
identifier = result.stdout.decode().strip()
assert len(identifier) == 64
ledger['containers'].append({'id': identifier, 'purpose': 'qemu provisioning; no guest started'})
save()
started = call(['docker', 'start', identifier])
assert started.returncode == 0
for name, command in [('os', ['cat', '/etc/os-release']), ('apt-update', ['apt-get', 'update']),
        ('qemu-policy', ['apt-cache', 'policy', 'qemu-system-x86'])]:
    with (root / (name + '.stdout')).open('xb') as out, (root / (name + '.stderr')).open('xb') as err:
        value = subprocess.run(['docker', 'exec', identifier, *command], stdout=out, stderr=err, timeout=300)
    ledger[name + 'ExitCode'] = value.returncode
    save()
    assert value.returncode == 0, name + ' failed; log withheld'
assert b'VERSION_ID="24.04"' in (root / 'os.stdout').read_bytes()
expected = b'1:8.2.2+ds-0ubuntu1.18'
available = expected in (root / 'qemu-policy.stdout').read_bytes()
ledger['exactQemuPackageAvailable'] = available
save()
print(json.dumps({'containerId': identifier, 'exactQemuPackageAvailable': available}))
