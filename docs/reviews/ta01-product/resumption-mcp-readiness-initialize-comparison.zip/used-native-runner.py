import hashlib,json,os,pathlib,resource,subprocess,time
root=pathlib.Path('/opt/micro/native-root')
root.mkdir(exist_ok=False)
subprocess.run(['tar','-xzf','/opt/micro/node-rootfs.tar.gz','-C',str(root)],check=True,capture_output=True)
(root/'tmp/measurement.mjs').write_bytes(pathlib.Path('/opt/micro/measurement.mjs').read_bytes())
resource.setrlimit(resource.RLIMIT_CORE,(0,0))
began=time.monotonic()
value=subprocess.run(['chroot','--userspec=10001:10001',str(root),'/usr/local/bin/node','/tmp/measurement.mjs','/app'],capture_output=True,timeout=600,env={**os.environ,'NODE_ENV':'production'})
pathlib.Path('/opt/micro/native.stdout').write_bytes(value.stdout)
pathlib.Path('/opt/micro/native.stderr').write_bytes(value.stderr)
pathlib.Path('/opt/micro/native-result.json').write_text(json.dumps({'kernel':os.uname().release,'exitCode':value.returncode,'seconds':time.monotonic()-began,'stdoutSha256':hashlib.sha256(value.stdout).hexdigest(),'stderrSha256':hashlib.sha256(value.stderr).hexdigest(),'coreLimit':0})+'
')
raise SystemExit(0 if value.returncode==0 else 1)
