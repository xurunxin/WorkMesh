from pathlib import Path
import hashlib,json,subprocess,tarfile,time
base=Path('.tmp/ta01-resumption/mcp-health-initialize-566');ledger=json.loads((base/'resources.json').read_bytes());identifier=ledger['containers'][0]['id']
sha=lambda b:hashlib.sha256(b).hexdigest()
info=json.loads(subprocess.check_output(['docker','inspect',identifier]))[0]
assert info['Config']['Labels']['io.workmesh.ta01.probe.owner']==ledger['owner'] and info['Image']==ledger['imageId'] and not info['Mounts']
assert ledger['exactQemuPackageAvailable'] and ledger['aptInstallExitCode']==0
old=Path('.tmp/ta01-resumption/exact-mcp-9c8/node-rootfs.tar.gz')
assert sha(old.read_bytes())=='7f5c28b98d3df88b571135fd6ce0c53e4ca589155373430654a090baab419a9f'
image=Path('.tmp/ta01-resumption/local-guest-image-cache/amd64-6a81c375.img')
assert sha(image.read_bytes())=='6a81c37564db9b1ee84e141922625e1d7c5b389b99bb3c572e0243607d5bb4d2'
helper=Path('docs/reviews/ta01-product/tools/component-tcg-guest.py').read_text(encoding='utf8')
helper=helper.replace("*(['--repeat'] if startup else ['--segments', '--work-read-fixture'])", "*(['--repeat'] if startup else [])")
old_assert="assert value['unknownRequests'] == 0 and value['workReadFixture'] and len(value['requests']) == 24"
assert helper.count(old_assert)==1
helper=helper.replace(old_assert,"assert value['unknownRequests'] == 0 and value['mode'] == 'readiness-initialize-overlap' and len(value['requests']) == 24")
(base/'used-component-tcg-guest.py').write_text(helper,encoding='utf8',newline='\n')
host=Path('docs/reviews/ta01-product/tools/run-component-tcg.py').read_text(encoding='utf8').replace("else 'work-read'", "else 'readiness-initialize-overlap'")
(base/'used-run-component-tcg.py').write_text(host,encoding='utf8',newline='\n')
native="""import hashlib,json,os,pathlib,resource,subprocess,time
root=pathlib.Path('/opt/micro/native-root')
root.mkdir(exist_ok=False)
subprocess.run(['tar','-xzf','/opt/micro/node-rootfs.tar.gz','-C',str(root)],check=True,capture_output=True)
(root/'tmp/measurement.mjs').write_bytes(pathlib.Path('/opt/micro/measurement.mjs').read_bytes())
resource.setrlimit(resource.RLIMIT_CORE,(0,0))
began=time.monotonic()
value=subprocess.run(['chroot','--userspec=10001:10001',str(root),'/usr/local/bin/node','/tmp/measurement.mjs','/app'],capture_output=True,timeout=600,env={**os.environ,'NODE_ENV':'production'})
pathlib.Path('/opt/micro/native.stdout').write_bytes(value.stdout)
pathlib.Path('/opt/micro/native.stderr').write_bytes(value.stderr)
pathlib.Path('/opt/micro/native-result.json').write_text(json.dumps({'kernel':os.uname().release,'exitCode':value.returncode,'seconds':time.monotonic()-began,'stdoutSha256':hashlib.sha256(value.stdout).hexdigest(),'stderrSha256':hashlib.sha256(value.stderr).hexdigest(),'coreLimit':0})+'\n')
raise SystemExit(0 if value.returncode==0 else 1)
"""
(base/'used-native-runner.py').write_text(native,encoding='utf8',newline='\n')
inputs={'node-rootfs.tar.gz':old,'amd64.img':image,'measurement.mjs':Path('docs/reviews/ta01-product/tools/mcp-readiness-initialize-probe.mjs'),'component-tcg-guest.py':base/'used-component-tcg-guest.py','run-component-tcg.py':base/'used-run-component-tcg.py','native-runner.py':base/'used-native-runner.py'}
ledger['inputs']={name:{'bytes':p.stat().st_size,'sha256':sha(p.read_bytes())} for name,p in inputs.items()}
ledger['sourceHead']='541f6ba64841915801a1ccb123f9adb7f61ebe17';ledger['roleSourceHead']='9c8bbff749c1d2a52a3e6489dcec02d2d7c859af'
ledger['scope']='只对准确旧CI563角色做健康/initialize重叠变量对照；产品源码到541相同，不证明新候选二进制相同，无完整产品或真实后端结论。'
(base/'resources.json').write_text(json.dumps(ledger,ensure_ascii=False,indent=2)+'\n',encoding='utf8')
assert subprocess.run(['docker','exec',identifier,'mkdir','/opt/micro'],capture_output=True,timeout=30).returncode==0
copy=subprocess.Popen(['docker','cp','-',identifier+':/opt/micro'],stdin=subprocess.PIPE,stdout=subprocess.PIPE,stderr=subprocess.PIPE)
with tarfile.open(fileobj=copy.stdin,mode='w|') as archive:
 for name,p in inputs.items():archive.add(p,arcname=name,recursive=False)
copy.stdin.close();assert copy.wait(timeout=120)==0
print(json.dumps({'inputsCopied':len(inputs),'measurementSha256':ledger['inputs']['measurement.mjs']['sha256']}),flush=True)
for mode,command,budget in [('native',['python3','/opt/micro/native-runner.py'],650),('tcg',['python3','/opt/micro/run-component-tcg.py','--exact-mcp-role'],1250)]:
 with (base/(mode+'-runner.stdout')).open('xb') as output,(base/(mode+'-runner.stderr')).open('xb') as error:
  value=subprocess.run(['docker','exec',identifier,*command],stdout=output,stderr=error,timeout=budget)
 (base/(mode+'-runner-exit.json')).write_text(json.dumps({'exitCode':value.returncode})+'\n')
 for source,target in ([('native-result.json','native-result.json'),('native.stdout','native.stdout'),('native.stderr','native.stderr')] if mode=='native' else [('guest/result.json','tcg-result.json'),('guest/serial.log','tcg-serial.log'),('guest/qemu-stderr.log','tcg-qemu-stderr.log')]):
  with (base/target).open('xb') as output:
   receipt=subprocess.run(['docker','exec',identifier,'cat','/opt/micro/'+source],stdout=output,stderr=subprocess.PIPE,timeout=30)
  assert receipt.returncode==0, 'receipt unavailable; stop without rerun'
 print(json.dumps({'mode':mode,'runnerExitCode':value.returncode}),flush=True)
 assert value.returncode==0, 'micro failed; no next environment or retry'
