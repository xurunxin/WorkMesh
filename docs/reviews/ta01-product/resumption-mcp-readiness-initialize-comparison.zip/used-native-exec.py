import os,resource
resource.setrlimit(resource.RLIMIT_CORE,(0,0))
os.environ['NODE_ENV']='production'
os.execvp('chroot',['chroot','--userspec=10001:10001','/opt/micro/native-root','/usr/local/bin/node','/tmp/measurement.mjs','/app'])
