import hashlib
import json
import os
from pathlib import Path
import re
import struct
import subprocess
import time
import uuid

repo = Path.cwd().resolve()
base = repo / '.tmp/ta01-resumption/public-node-symbols'
assert base.is_relative_to(repo)
base.mkdir(exist_ok=False)
assert base.resolve() == base
owner = str(uuid.uuid4())
image = 'sha256:6b2127043c2faa4f15cdcdeb65a39fc9afbecf5559301898b754bbff561a8aa9'
ledger = {'说明': '只读复制既有公开Node基础镜像的单一二进制并生成公开ELF符号范围；目标core二进制SHA未匹配前不用于归因。不是产品安装／自然捕获通过。',
          'owner': owner, 'image': image, 'status': 'started', 'container': None, 'volumesCreated': 0}
def save():
    (base / 'results.json').write_text(json.dumps(ledger, ensure_ascii=False, indent=2), encoding='utf8')
def command(args, timeout=30):
    result = subprocess.run(args, capture_output=True, timeout=timeout)
    if result.returncode:
        ledger['firstFailure'] = {'exitCode': result.returncode, 'stderrSha256': hashlib.sha256(result.stderr).hexdigest()}
        save()
        raise RuntimeError('public binary operation failed; no retry')
    return result.stdout
save()
try:
    identity = json.loads(command(['docker', 'image', 'inspect', image]))[0]
    assert identity['Architecture'] == 'amd64' and identity['Os'] == 'linux' and not identity['Config'].get('Volumes')
    assert 'node:22.19.0-alpine3.21' in identity['RepoTags']
    ledger['startedUtcEpoch'] = time.time()
    save()
    cid = command(['docker', 'create', '--network', 'none', '--read-only', '--cap-drop', 'ALL',
        '--security-opt', 'no-new-privileges:true', '--label', 'io.workmesh.ta01.public-node=' + owner,
        '--entrypoint', '/bin/true', image]).decode().strip()
    assert re.fullmatch('[a-f0-9]{64}', cid)
    ledger['container'] = cid
    save()
    info = json.loads(command(['docker', 'inspect', cid]))[0]
    assert info['Config']['Labels']['io.workmesh.ta01.public-node'] == owner and info['Image'] == image
    assert not info['State']['Running'] and not info['Mounts']
    binary = base / 'node'
    assert not binary.exists()
    command(['docker', 'cp', cid + ':/usr/local/bin/node', str(binary)], timeout=60)
    assert binary.is_file() and not binary.is_symlink() and binary.resolve() == binary
    digest = hashlib.sha256()
    with binary.open('rb') as stream:
        while block := stream.read(1024 * 1024):
            digest.update(block)
    ledger['binaryBytes'], ledger['binarySha256'] = binary.stat().st_size, digest.hexdigest()
    ledger['binaryIdentity'] = {'device': binary.stat().st_dev, 'inode': binary.stat().st_ino}
    size = binary.stat().st_size
    assert 1 < size <= 256 * 1024 * 1024
    with binary.open('rb') as stream:
        def read(offset, length):
            assert 0 <= offset <= size and 0 <= length <= 32 * 1024 * 1024 and offset + length <= size
            stream.seek(offset)
            value = stream.read(length)
            assert len(value) == length
            return value
        header = read(0, 64)
        assert header[:7] == b'\x7fELF\x02\x01\x01'
        kind, machine = struct.unpack_from('<HH', header, 16)
        assert kind in {2, 3} and machine == 62
        offset = struct.unpack_from('<Q', header, 40)[0]
        stride, count = struct.unpack_from('<HH', header, 58)
        assert stride == 64 and 0 < count < 65535
        sections = list(struct.iter_unpack('<IIQQQQIIQQ', read(offset, stride * count)))
        symbols = set()
        tables = []
        for _, table_type, _, _, offset, length, link, _, _, entry_bytes in sections:
            if table_type not in {2, 11}:
                continue
            assert entry_bytes == 24 and length % 24 == 0 and 0 <= link < count
            strings = sections[link]
            assert strings[1] == 3
            names = read(strings[4], strings[5])
            rows = list(struct.iter_unpack('<IBBHQQ', read(offset, length)))
            tables.append({'type': table_type, 'entries': len(rows)})
            for name, info, _, section_index, value, symbol_size in rows:
                if info & 15 != 2 or not 0 < section_index < count or not symbol_size:
                    continue
                section = sections[section_index]
                if not section[2] & 4 or not section[3] <= value < value + symbol_size <= section[3] + section[5]:
                    continue
                assert name < len(names)
                end = names.find(b'\0', name)
                assert name <= end and end - name < 4096
                raw = names[name:end]
                if re.fullmatch(rb'[A-Za-z0-9_.$@]+', raw):
                    symbols.add((value, symbol_size, raw.decode('ascii')))
    assert symbols
    index = {'说明': '公开镜像二进制的ELF链接地址及STT_FUNC范围；不是进程ASLR地址／栈，尺寸未知的符号不猜范围。只在目标二进制SHA完全一致后解析故障位置。',
        'binarySha256': ledger['binarySha256'], 'image': image, 'architecture': 'amd64',
        'tables': tables, 'symbols': sorted(symbols), 'targetBinaryMatch': 'pending',
        'sources': ['https://gabi.xinuos.com/elf/03-sheader.html', 'https://gabi.xinuos.com/elf/05-symtab.html']}
    target = base / 'symbol-index.json'
    with target.open('x', encoding='utf8') as output:
        json.dump(index, output, ensure_ascii=False, separators=(',', ':'))
    ledger.update(status='indexed-public-binary-only', symbols=len(symbols), indexBytes=target.stat().st_size,
        indexSha256=hashlib.sha256(target.read_bytes()).hexdigest())
    save()
finally:
    if ledger['container']:
        info = json.loads(command(['docker', 'inspect', ledger['container']]))[0]
        assert info['Id'] == ledger['container'] and info['Config']['Labels']['io.workmesh.ta01.public-node'] == owner
        assert info['Image'] == image and not info['State']['Running'] and not info['Mounts']
        command(['docker', 'rm', ledger['container']])
        absent = subprocess.run(['docker', 'inspect', ledger['container']], capture_output=True)
        assert absent.returncode != 0 and b'no such' in absent.stderr.lower()
        ledger['cleanup'] = {'containerAbsent': True, 'volumesCreated': 0}
    save()
print(json.dumps({key: ledger.get(key) for key in ['status', 'binaryBytes', 'binarySha256', 'symbols', 'indexBytes', 'cleanup']}))
