import ast
from datetime import datetime, timezone
import hashlib
import json
from pathlib import Path
import re
import subprocess
import time
import uuid

output = Path(__file__).with_name('docker-events-probe.json')
assert not output.exists()
owner = str(uuid.uuid4())
label = 'io.workmesh.ta01.events-probe'
record = {'说明': '仅验证 Docker 历史事件命令和投影；退出7的合成 Node 进程，不是产品 MCP 崩溃或完整 guest 验收。', 'owner': owner}
def save():
    output.write_text(json.dumps(record, ensure_ascii=False, indent=2) + '\n', encoding='utf8')
with output.open('x', encoding='utf8') as target:
    json.dump(record, target)
def docker(*args):
    result = subprocess.run(['docker', *args], capture_output=True, timeout=30)
    result.check_returncode()
    return result.stdout
image = json.loads(docker('image', 'inspect', 'node:22.19.0-alpine3.21'))[0]
assert not image['Config'].get('Volumes')
record['image'] = image['Id']
identifier = None
try:
    since = datetime.now(timezone.utc).isoformat()
    identifier = docker('create', '--network', 'none', '--read-only', '--label', label + '=' + owner,
                        '--entrypoint', 'node', image['Id'], '-e', 'process.exit(7)').decode().strip()
    assert re.fullmatch('[a-f0-9]{64}', identifier)
    record['container'] = identifier
    save()
    docker('start', identifier)
    assert docker('wait', identifier).strip() == b'7'
    info = json.loads(docker('inspect', identifier))[0]
    assert info['Id'] == identifier and info['Config']['Labels'][label] == owner
    assert not info['State']['Running'] and not info['Mounts']
    record['exitCode'] = info['State']['ExitCode']
    save()
    # Docker events stores nanosecond timestamps; sample until after the exit.
    time.sleep(0.1)
    source = ast.parse(Path(__file__).with_name('guest.py').read_text(encoding='utf8'))
    functions = [node for node in source.body if isinstance(node, ast.FunctionDef)
                 and node.name in {'project_container_events', 'collect_container_events'}]
    scope = {'json': json, 're': re, 'datetime': datetime, 'timezone': timezone, 'subprocess': subprocess}
    exec(compile(ast.Module(body=functions, type_ignores=[]), 'event-projection', 'exec'), scope)
    projection = scope['collect_container_events']({'actions': [{'startedAt': since}]}, [(info, {'id': identifier, 'service': 'mcp'})])
    assert any(value['event'] == 'die' and value['exitCode'] == 7 for value in projection['events'])
    record['projection'] = projection
    record['status'] = 'passed'
finally:
    if identifier is not None:
        info = json.loads(docker('inspect', identifier))[0]
        assert info['Id'] == identifier and info['Config']['Labels'][label] == owner
        assert not info['State']['Running'] and not info['Mounts']
        docker('rm', identifier)
        absent = subprocess.run(['docker', 'inspect', identifier], capture_output=True, timeout=30)
        record['absentInspectExitCode'] = absent.returncode
        record['absentInspectStderrSha256'] = hashlib.sha256(absent.stderr).hexdigest()
        save()
        assert absent.returncode == 1 and b'no such object' in absent.stderr.lower()
        record['cleanup'] = {'containerAbsent': True, 'volumesCreated': 0}
    save()
print(json.dumps({'status': record['status'], 'events': len(record['projection']['events']), 'cleanup': record['cleanup']}))
