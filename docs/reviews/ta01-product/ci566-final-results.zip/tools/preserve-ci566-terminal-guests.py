import hashlib,json,subprocess,sys,zipfile
from pathlib import Path
root=Path('.tmp/ta01-resumption')
head='541f6ba64841915801a1ccb123f9adb7f61ebe17'
sha=lambda b:hashlib.sha256(b).hexdigest()
x=json.loads((root/'ci566-live-snapshot.json').read_bytes())
artifacts=json.loads(subprocess.check_output(['gh','api','repos/xurunxin/WorkMesh/actions/runs/38871063733/artifacts?per_page=100']))['artifacts']
producers=json.loads((root/'ci566-producer-projection.json').read_bytes())
result=[]
for j in x['jobs']:
 if not j['name'].startswith('Server full installation (') or j['status']!='completed':continue
 arch,profile=j['name'].removesuffix(')').split('(')[1].split(', ')
 assert j['conclusion'] in ['success','failure'], 'unexpected cancelled: preserve separately without inventing result'
 suffix='full-guest-pass' if j['conclusion']=='success' else 'first-failure'
 stem=f'ci566-{arch}-{profile}-{suffix}'
 target=root/'guest-evidence'/f'{stem}.json'
 name=f'server-install-raw-{arch}-{profile}-38871063733-1'
 matches=[a for a in artifacts if a['name']==name];assert len(matches)==1
 artifact=matches[0]
 raw_name=f'ci566-{arch}-{profile}-{artifact["id"]}-raw.zip'
 if not target.exists():
  r=subprocess.run([sys.executable,str(root/'inspect-ci566-guest.py'),raw_name,stem,'38871063733',str(j['databaseId']),str(artifact['id'])],capture_output=True,timeout=150)
  assert r.returncode==0, 'source-bound guest inspection failed; inspect local output rather than rerun guest'
 index=json.loads(target.read_bytes())
 assert index['sourceHead']==head and index['jobId']==j['databaseId'] and index['artifactId']==artifact['id']
 assert index['producer']['manifestSha256']==producers[arch]['manifestSha256']
 assert index['producer']['artifactId']==str(producers[arch]['candidateArtifact'])
 raw=root/raw_name
 with zipfile.ZipFile(raw) as z:
  assert sha(raw.read_bytes())==index['artifactZipSha256']
  assert z.read('server-install/source.txt')==z.read('server-install/source-after.txt')
  assert z.read('server-install/source.txt').decode().split()==[head,producers[arch]['tree']]
  inputs={}
  for line in z.read('server-install/input-sha256.txt').decode().splitlines():
   digest,path=line.split('  ',1)
   assert not path.startswith('/') and '..' not in path.split('/')
   assert sha(subprocess.check_output(['git','show',head+':'+path]))==digest
   inputs[path]=digest
  assert len(inputs)==22
  actual=json.loads(z.read('server-install/result.json'));manifest=json.loads(z.read('server-install/manifest.json'))
  assert actual['arch']==manifest['arch']==arch and actual['profilesRequested']==[profile] and actual['scope']=='single-configuration'
  assert actual['sourceHead']==head and actual['sourceTree']==producers[arch]['tree']
  assert actual['guestVcpus']==4 and actual['guestRamMiB']==4096 and actual['accelerator']=='tcg'
  assert actual['qemuVersion']=='QEMU emulator version 8.2.2 (Debian 1:8.2.2+ds-0ubuntu1.18)'
  expected_image='6a81c37564db9b1ee84e141922625e1d7c5b389b99bb3c572e0243607d5bb4d2' if arch=='amd64' else '1d6bffe64b848468ac97f821d369a4846d983de1800ccf6b5ec8853e85cefc55'
  assert actual['imageSha256']==expected_image
 index['allSourceInputsMatchGit']=True;index['allSourceInputCount']=len(inputs);index['guestShapeMatchesJob']=True;index['architecture']=arch
 # New source verification is derived metadata; original result, serial and all members remain untouched.
 target.write_text(json.dumps(index,ensure_ascii=False,indent=2)+'\n',encoding='utf8',newline='\n')
 result.append({'arch':arch,'profile':profile,'jobId':j['databaseId'],'conclusion':j['conclusion'],'index':target.name,'artifactId':artifact['id'],'rawZipSha256':index['artifactZipSha256'],'totalSeconds':index['totalSeconds']})
(root/'ci566-verified-guests.json').write_text(json.dumps(result,indent=2)+'\n',encoding='utf8')
print(json.dumps(result))
