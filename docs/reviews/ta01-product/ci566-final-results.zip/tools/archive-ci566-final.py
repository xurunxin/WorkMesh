from datetime import datetime,timezone
import hashlib,json,re,subprocess,zipfile
from pathlib import Path
root=Path('.tmp/ta01-resumption');out=Path('docs/reviews/ta01-product')
head='541f6ba64841915801a1ccb123f9adb7f61ebe17'
sha=lambda b:hashlib.sha256(b).hexdigest()
def api(path):
 r=subprocess.run(['gh','api','repos/xurunxin/WorkMesh/'+path],capture_output=True,timeout=35)
 assert r.returncode==0, 'GitHub read failed; stderr withheld'
 return json.loads(r.stdout)
run=api('actions/runs/38871063733'); jobs=api('actions/runs/38871063733/jobs?per_page=100')['jobs']
assert run['head_sha']==head and run['status']=='completed'
assert all(j['status']=='completed' for j in jobs)
guests=json.loads((root/'ci566-verified-guests.json').read_bytes())
assert len(guests)==6 and len({r['jobId'] for r in guests})==6
producers=json.loads((root/'ci566-producer-projection.json').read_bytes())
members={'initial-live-snapshot.json':(root/'ci566-initial-snapshot.json').read_bytes(),'last-live-snapshot.json':(root/'ci566-live-snapshot.json').read_bytes(),'producers.json':(root/'ci566-producer-projection.json').read_bytes()}
for g in guests:
 j=next(j for j in jobs if j['id']==g['jobId']); assert j['conclusion']==g['conclusion']
 stem=root/'guest-evidence'/g['index']; index=json.loads(stem.read_bytes())
 assert index['sourceHead']==head and index['allSourceInputsMatchGit'] and index['allSourceInputCount']==22
 assert index['producer']['manifestSha256']==producers[g['arch']]['manifestSha256']
 with zipfile.ZipFile(stem.with_suffix('.zip')) as z:
  assert len(z.namelist())==len(index['members'])==11
  for name,meta in index['members'].items():assert sha(z.read(name))==meta['sha256'] and len(z.read(name))==meta['bytes']
 assert sha(stem.with_suffix('.zip').read_bytes())==index['selectedZipSha256']
 for ext in ['.json','.zip']:
  target=out/(stem.stem+ext)
  assert not target.exists()
  target.write_bytes(stem.with_suffix(ext).read_bytes())
 g['indexSha256']=sha(stem.read_bytes());g['selectedZipSha256']=index['selectedZipSha256']
for arch,producer in producers.items():
 raw=root/f'ci566-build-{arch}-raw.zip'; assert sha(raw.read_bytes())==producer['rawZipSha256']
 with zipfile.ZipFile(raw) as z:
  members.update({arch+'/'+n:z.read(n) for n in z.namelist() if n.startswith('server-build/')})
members['source-gates/checkout.json']=(root/'ci566-source-gates-checkout.json').read_bytes()
members['source-gates/checkout-selected.txt']=(root/'ci566-source-gates-checkout-selected.txt').read_bytes()
members['fresh-refs.json']=(root/'ci566-fresh-refs.json').read_bytes()
# Keep only the existing source-gate logs relevant to precise reported checks.
with zipfile.ZipFile(root/'ci566-source-gates-raw.zip') as z:
 for name in ['lint.log','typecheck.log','test.log','ci-validate.log','clean-tree.log']:
  members['source-gates/'+name]=z.read(name)
analysis=json.loads((root/'ci566-amd64-team-analysis.json').read_bytes())
analysis['selectedIndexSha256']=next(g['indexSha256'] for g in guests if g['arch']=='amd64' and g['profile']=='team')
members['amd64-team-analysis.json']=(json.dumps(analysis,ensure_ascii=False,indent=2)+'\n').encode()
arm_analysis=json.loads((root/'ci566-arm64-personal-analysis.json').read_bytes())
arm_analysis['selectedIndexSha256']=next(g['indexSha256'] for g in guests if g['arch']=='arm64' and g['profile']=='personal')
members['arm64-personal-analysis.json']=(json.dumps(arm_analysis,ensure_ascii=False,indent=2)+'\n').encode()
for name in ['inspect-ci566-guest.py','preserve-ci566-terminal-guests.py','archive-ci566-final.py']:
 members['tools/'+name]=(root/name).read_bytes()
summary={'说明':'CI566终态、六guest与双生产者分别绑定541准确候选；旧原生故障与ARM失败未闭，不把单组合成功补作完整支持。新事实均来源执行者。',
 'sourceHead':head,'sourceTree':producers['amd64']['tree'],
 'run':{k:run[k] for k in ['id','status','conclusion','head_sha','created_at','updated_at']},
 'jobs':[{k:j[k] for k in ['id','name','status','conclusion','started_at','completed_at']} for j in jobs],
 'guests':guests,'producers':producers,'amd64TeamAnalysis':analysis,'arm64PersonalAnalysis':arm_analysis,
 'freshRefs':json.loads((root/'ci566-fresh-refs.json').read_bytes()),
 'sourceGatesCheckout':json.loads((root/'ci566-source-gates-checkout.json').read_bytes()),
 'sourceGatesRawArtifact':{'artifactId':12034950019,'rawZipSha256':sha((root/'ci566-source-gates-raw.zip').read_bytes()),'selectedLogsOnly':True},
 'executorOperations':'执行者只读等待有价值的CI566原运行全部终态后归档，未调用cancel/rerun，未手动追加整轮；完成一次固定条件的健康读取/initialize原生与TCG有界对照，独有资源已收尾。产品、诊断字段、CI、锁定运行时和原验收期限不变。',
 'observedAt':datetime.now(timezone.utc).isoformat()}
members['summary.json']=(json.dumps(summary,ensure_ascii=False,indent=2)+'\n').encode()
for data in members.values():assert not re.search(rb'wm[ips]_[A-Za-z0-9_-]{43}',data)
stem=out/'ci566-final-results'
assert not stem.with_suffix('.json').exists() and not stem.with_suffix('.zip').exists()
with zipfile.ZipFile(stem.with_suffix('.zip'),'x',compression=zipfile.ZIP_DEFLATED) as z:
 for name,data in members.items():z.writestr(name,data)
summary['selectedZipSha256']=sha(stem.with_suffix('.zip').read_bytes())
summary['members']={n:{'bytes':len(b),'sha256':sha(b)} for n,b in members.items()}
stem.with_suffix('.json').write_text(json.dumps(summary,ensure_ascii=False,indent=2)+'\n',encoding='utf8',newline='\n')
print(json.dumps({'run':run['conclusion'],'required':next(j['conclusion'] for j in jobs if j['name']=='Required CI'),'guests':[{k:g[k] for k in ['arch','profile','conclusion']} for g in guests],'archiveMembers':len(members)}))
