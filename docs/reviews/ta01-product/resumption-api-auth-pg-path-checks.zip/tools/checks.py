from pathlib import Path
import ast,hashlib,json,os,re,subprocess,zipfile
r=Path('.tmp/ta01-resumption/api-auth-pg-567');out=Path('docs/reviews/ta01-product/resumption-api-auth-pg-path-checks')
assert not out.with_suffix('.json').exists() and not out.with_suffix('.zip').exists()
node=Path('D:/Cache/TEMP/workmesh-ta00-nf20n0st/node-v22.19.0-win-x64/node.exe')
pnpm=Path('D:/Cache/TEMP/workmesh-ta00-nf20n0st/tools/node_modules/pnpm/bin/pnpm.cjs')
env={**os.environ,'PATH':str(node.parent)+os.pathsep+os.environ['PATH']}
summary={'说明':'本轮诊断工具、原件及文档适用检查；不代五根门禁、完整guest或Required。',
    'startingHead':'e2763da4dfdf25f7fc5c28c34a9619d4788f4541','rootFiveChecksRerunLocally':False,'checks':[]}
out.with_suffix('.json').write_text(json.dumps({'status':'pending'},indent=2)+'\n',encoding='utf8')
members={}
for name in ['ci567-amd64-personal-full-guest-pass','ci567-amd64-team-full-guest-pass','ci567-amd64-enterprise-full-guest-pass','resumption-api-auth-pg-path-comparison']:
    p=out.parent/name;index=json.loads(p.with_suffix('.json').read_bytes());raw=p.with_suffix('.zip').read_bytes()
    assert hashlib.sha256(raw).hexdigest()==index['selectedZipSha256']
    with zipfile.ZipFile(p.with_suffix('.zip')) as z:
        assert set(z.namelist())==set(index['members'])
        for filename,meta in index['members'].items():
            b=z.read(filename);assert len(b)==meta['bytes'] and hashlib.sha256(b).hexdigest()==meta['sha256']
    summary['checks'].append({'name':name,'members':len(index['members']),'allBytesAndShaMatched':True})
tool=Path('docs/reviews/ta01-product/tools/api-auth-pg-path-probe.mjs')
commands=[('node-syntax',[str(node),'--check',str(tool)]),('ci-validate',[str(node),str(pnpm),'ci:validate']),
    ('integration-docs',[str(node),str(pnpm),'check:integration-docs']),('diff-check',['git','diff','--check'])]
for name,args in commands:
    v=subprocess.run(args,capture_output=True,timeout=180,env=env)
    members[name+'.stdout']=v.stdout;members[name+'.stderr']=v.stderr
    summary['checks'].append({'name':name,'command':args,'exitCode':v.returncode})
    if v.returncode:
        (r/(name+'-failure.stdout')).write_bytes(v.stdout);(r/(name+'-failure.stderr')).write_bytes(v.stderr)
        out.with_suffix('.json').write_text(json.dumps(summary,ensure_ascii=False,indent=2)+'\n',encoding='utf8')
        raise RuntimeError(name+' failed; preserved exact output')
syntax=[]
for base in [r,Path('.tmp/ta01-resumption/api-auth-pg-native-567')]:
    for p in sorted(base.rglob('*.py')):
        ast.parse(p.read_text(encoding='utf8'));syntax.append({'path':str(p).replace('\\','/'),'sha256':hashlib.sha256(p.read_bytes()).hexdigest()})
summary['pythonHelpersSyntax']=syntax
assert not subprocess.check_output(['git','diff','--name-only','--','apps','packages','scripts','infra','.github','pnpm-lock.yaml','OPENAPI.yaml','SCHEMA.sql']).strip()
summary['productCiSchemaWorkingTreeDiffEmpty']=True
for p in [tool,*out.parent.glob('ci567-amd64-*-full-guest-pass.*'),out.parent/'resumption-api-auth-pg-path-comparison.json',out.parent/'resumption-api-auth-pg-path-comparison.zip']:
    a=subprocess.check_output(['git','hash-object','--no-filters',str(p)]).strip()
    b=subprocess.check_output(['git','hash-object','--path='+str(p),str(p)]).strip();assert a==b
summary['newFilesGitFilterBytesSame']=True
summary['writingSkill']={'commit':'ffda9353768dece8aabd26ccb3a4978025e9437c','references':['SKILL.md','manual-structure.md','typography.md'],'autocorrect':'unavailable; manual review; no global install'}
members['checks.json']=(json.dumps(summary,ensure_ascii=False,indent=2)+'\n').encode()
members['tools/checks.py']=Path(__file__).read_bytes()
for b in members.values():assert not re.search(rb'wm[ips]_[A-Za-z0-9_-]{43}',b)
with zipfile.ZipFile(out.with_suffix('.zip'),'x',compression=zipfile.ZIP_DEFLATED) as z:
    for name,b in members.items():z.writestr(name,b)
summary['selectedZipSha256']=hashlib.sha256(out.with_suffix('.zip').read_bytes()).hexdigest()
summary['members']={name:{'bytes':len(b),'sha256':hashlib.sha256(b).hexdigest()} for name,b in members.items()}
out.with_suffix('.json').write_text(json.dumps(summary,ensure_ascii=False,indent=2)+'\n',encoding='utf8',newline='\n')
print(json.dumps({'checksPassed':len(commands),'evidenceMembers':sum(x.get('members',0) for x in summary['checks']),
    'pythonHelpers':len(syntax),'productCiSchemaDiffEmpty':True}))
