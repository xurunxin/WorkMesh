from pathlib import Path
import json,subprocess
r=Path('.tmp/ta01-resumption/mcp-arm-565-micro/tcg');i=json.loads((r/'resources.json').read_bytes())['containers'][0]['id']
code="from pathlib import Path;import hashlib,json; p=Path('/usr/lib/ipxe/qemu/efi-virtio.rom'); assert p.is_file(); b=Path('/usr/bin/qemu-system-aarch64').read_bytes(); assert b'/usr/lib/ipxe/qemu' in b;print(json.dumps({'path':str(p),'sha256':hashlib.sha256(p.read_bytes()).hexdigest(),'qemuDefaultSearchPathPresent':True}))"
v=subprocess.run(['docker','exec',i,'python3','-c',code],capture_output=True,timeout=30);assert v.returncode==0;(r/'rom-proof.json').write_bytes(v.stdout);print(v.stdout.decode().strip())
with (r/'runner.stdout').open('xb') as out,(r/'runner.stderr').open('xb') as err:v=subprocess.run(['docker','exec',i,'python3','/opt/micro/run-component-tcg.py','--exact-mcp-role','--arm64'],stdout=out,stderr=err,timeout=1250)
print(json.dumps({'runnerExitCode':v.returncode,'afterExactCiRomRepair':True}));assert v.returncode==0
for source,name in [('guest/result.json','tcg-result.json'),('guest/serial.log','serial.log'),('guest/qemu-stderr.log','qemu-stderr.log')]:
 with (r/name).open('xb') as out:v=subprocess.run(['docker','exec',i,'cat','/opt/micro/'+source],stdout=out,stderr=subprocess.PIPE,timeout=30);assert v.returncode==0
