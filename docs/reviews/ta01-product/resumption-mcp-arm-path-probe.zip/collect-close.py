from pathlib import Path
import json,subprocess,hashlib
r=Path('.tmp/ta01-resumption/mcp-arm-565-micro/tcg');l=json.loads((r/'resources.json').read_bytes());i=l['containers'][0]['id']
x=json.loads((r/'tcg-result.json').read_bytes())
assert isinstance(x['qemuExitCode'],int)
v=subprocess.run(['docker','exec',i,'python3','-c',"import hashlib,json,os,pathlib;print(json.dumps({'qemuSha256':hashlib.sha256(pathlib.Path('/usr/bin/qemu-system-aarch64').read_bytes()).hexdigest(),'hostArchitecture':os.uname().machine,'kernel':os.uname().release,'activeQemuCount':sum(1 for p in pathlib.Path('/proc').iterdir() if p.name.isdigit() and (p/'comm').exists() and (p/'comm').read_text().startswith('qemu-system'))}))"],capture_output=True,timeout=30);assert v.returncode==0
meta=json.loads(v.stdout);assert meta['activeQemuCount']==0;(r/'outer-metadata.json').write_bytes(v.stdout)
v=subprocess.run(['docker','inspect',i],capture_output=True,timeout=30);info=json.loads(v.stdout)[0];assert info['Config']['Labels']['io.workmesh.ta01.probe.owner']==l['owner'] and not info['Mounts'] and info['Image']==l['imageId']
h=info['HostConfig'];controls={k:h.get(k) for k in ['NanoCpus','Memory','MemorySwap','Privileged','Devices','Binds','PortBindings','SecurityOpt','PidsLimit']};assert h['NanoCpus']==4000000000 and h['Memory']==4294967296 and not h['Privileged'] and not h['Devices'] and not h['Binds'] and not h['PortBindings'];(r/'outer-controls.json').write_text(json.dumps(controls,indent=2),encoding='utf8')
cache=Path('.tmp/ta01-resumption/local-guest-image-cache/arm64-1d6bffe6.img')
assert not cache.exists()
with cache.open('xb') as out:
 v=subprocess.run(['docker','exec',i,'cat','/opt/micro/arm64.img'],stdout=out,stderr=subprocess.PIPE,timeout=120);assert v.returncode==0
h=hashlib.sha256()
with cache.open('rb') as f:
 while b:=f.read(1024*1024):h.update(b)
assert h.hexdigest()=='1d6bffe64b848468ac97f821d369a4846d983de1800ccf6b5ec8853e85cefc55'
l['publicGuestImageCache']={'path':cache.as_posix(),'bytes':cache.stat().st_size,'sha256':h.hexdigest()}
v=subprocess.run(['docker','stop','--time','10',i],capture_output=True,timeout=30);assert v.returncode==0
info=json.loads(subprocess.check_output(['docker','inspect',i]))[0];assert not info['State']['Running'] and not info['State']['OOMKilled'];l['containers'][0].update(exitCode=info['State']['ExitCode'],oom=False,activeQemuCountBeforeStop=0)
(r/'resources.json').write_text(json.dumps(l,ensure_ascii=False,indent=2)+'\n',encoding='utf8')
assert subprocess.run(['docker','rm',i],capture_output=True,timeout=30).returncode==0
v=subprocess.run(['docker','inspect',i],capture_output=True,timeout=30);assert v.returncode!=0 and b'no such object' in v.stderr.lower();l['containers'][0]['removedAndAbsent']=True;l['privateGuestOverlaysRetained']=False;(r/'resources.json').write_text(json.dumps(l,ensure_ascii=False,indent=2)+'\n',encoding='utf8')
print(json.dumps({'qemuExitCode':x['qemuExitCode'],'nodeExitCode':x['receipts'][0].get('nodeExitCode') if x['receipts'] else None,'guestSeconds':x['elapsedSeconds'],'nodeSeconds':x['receipts'][0].get('nodeSeconds') if x['receipts'] else None,'outerExitCode':l['containers'][0]['exitCode'],'removed':True}))
