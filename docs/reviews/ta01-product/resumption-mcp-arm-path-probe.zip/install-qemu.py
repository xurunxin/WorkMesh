from pathlib import Path
import subprocess,json
r=Path('.tmp/ta01-resumption/mcp-arm-565-micro/tcg');l=json.loads((r/'resources.json').read_bytes());i=l['containers'][0]['id']
for name,args in [('firmware-policy',['apt-cache','policy','qemu-efi-aarch64']),('apt-install',['apt-get','install','-y','--no-install-recommends','qemu-system-arm=1:8.2.2+ds-0ubuntu1.18','qemu-utils=1:8.2.2+ds-0ubuntu1.18','qemu-efi-aarch64=2024.02-2ubuntu0.10','genisoimage','python3','ca-certificates'])]:
 with (r/(name+'.stdout')).open('xb') as out,(r/(name+'.stderr')).open('xb') as err:v=subprocess.run(['docker','exec',i,*args],stdout=out,stderr=err,timeout=300)
 l[name+'ExitCode']=v.returncode;(r/'resources.json').write_text(json.dumps(l,ensure_ascii=False,indent=2)+'\n',encoding='utf8');assert v.returncode==0
v=subprocess.run(['docker','exec',i,'qemu-system-aarch64','--version'],capture_output=True,timeout=30);assert v.returncode==0 and v.stdout.decode().splitlines()[0]=='QEMU emulator version 8.2.2 (Debian 1:8.2.2+ds-0ubuntu1.18)';(r/'qemu-version.stdout').write_bytes(v.stdout)
v=subprocess.run(['docker','exec',i,'sha256sum','/usr/share/AAVMF/AAVMF_CODE.fd'],capture_output=True,timeout=30);assert v.returncode==0;assert v.stdout.decode().split()[0]=='545e2eda871a00dba51c0df48a34829fe3b0de6ec10ea760c75f1fc1c6a29dc5';(r/'firmware-sha256.stdout').write_bytes(v.stdout)
print('exact QEMU and CI firmware matched before ARM guest or candidate download')
