from pathlib import Path
import json,subprocess,hashlib
r=Path('.tmp/ta01-resumption/mcp-arm-565-micro/tcg');l=json.loads((r/'resources.json').read_bytes());i=l['containers'][0]['id'];old=json.loads((r/'tcg-result.json').read_bytes());assert old['qemuExitCode']==1 and not old['receipts']
for n in ['tcg-result.json','serial.log','qemu-stderr.log','runner.stdout','runner.stderr']:
 p=r/n;assert p.resolve().parent==r.resolve();p.rename(r/('first-missing-rom-'+n))
l['firstAttempt']={'qemuExitCode':1,'seconds':old['elapsedSeconds'],'receipts':0,'guestBooted':False,'reason':'failed to find romfile efi-virtio.rom','resultSha256':hashlib.sha256((r/'first-missing-rom-tcg-result.json').read_bytes()).hexdigest()};(r/'resources.json').write_text(json.dumps(l,ensure_ascii=False,indent=2)+'\n',encoding='utf8')
code="from pathlib import Path;import json; a=Path('/opt/micro/guest'); b=Path('/opt/micro/guest-first-missing-rom');assert a.resolve().parent==Path('/opt/micro') and not b.exists(); x=json.loads((a/'result.json').read_bytes());assert x['qemuExitCode']==1 and not x['receipts'];assert not any(p.name.isdigit() and (p/'comm').exists() and (p/'comm').read_text().startswith('qemu-system') for p in Path('/proc').iterdir());a.rename(b)"
v=subprocess.run(['docker','exec',i,'python3','-c',code],capture_output=True,timeout=30);assert v.returncode==0
with (r/'rom-install.stdout').open('xb') as out,(r/'rom-install.stderr').open('xb') as err:v=subprocess.run(['docker','exec',i,'apt-get','install','-y','--no-install-recommends','ipxe-qemu=1.21.1+git-20220113.fbbdc3926-0ubuntu2','ipxe-qemu-256k-compat-efi-roms=1.0.0+git-20150424.a25a16d-0ubuntu5'],stdout=out,stderr=err,timeout=180)
l['romInstallExitCode']=v.returncode;(r/'resources.json').write_text(json.dumps(l,ensure_ascii=False,indent=2)+'\n',encoding='utf8');assert v.returncode==0
v=subprocess.run(['docker','exec',i,'sha256sum','/usr/share/qemu/efi-virtio.rom'],capture_output=True,timeout=30);assert v.returncode==0;(r/'rom-sha256.stdout').write_bytes(v.stdout)
with (r/'runner.stdout').open('xb') as out,(r/'runner.stderr').open('xb') as err:v=subprocess.run(['docker','exec',i,'python3','/opt/micro/run-component-tcg.py','--exact-mcp-role','--arm64'],stdout=out,stderr=err,timeout=1250)
print(json.dumps({'runnerExitCode':v.returncode,'targetedRomRepairOnly':True}));assert v.returncode==0
for source,name in [('guest/result.json','tcg-result.json'),('guest/serial.log','serial.log'),('guest/qemu-stderr.log','qemu-stderr.log')]:
 with (r/name).open('xb') as out:v=subprocess.run(['docker','exec',i,'cat','/opt/micro/'+source],stdout=out,stderr=subprocess.PIPE,timeout=30);assert v.returncode==0
