from pathlib import Path
import subprocess,json,hashlib,gzip,uuid,tarfile
r=Path('.tmp/ta01-resumption/mcp-arm-565-micro');x=json.loads((r/'extraction.json').read_bytes());image=x['image'];tag=x['ownedTag'];owner=str(uuid.uuid4());l={'owner':owner,'image':image,'containers':[],'preexisting':{}}
def call(a,timeout=30):return subprocess.run(['docker',*a],capture_output=True,timeout=timeout)
def save():(r/'image-resources.json').write_text(json.dumps(l,ensure_ascii=False,indent=2)+'\n',encoding='utf8')
assert not (r/'image-resources.json').exists()
for ref in [tag,image['id'],image['archiveId']]:
 v=call(['image','inspect',ref]);l['preexisting'][ref]=v.returncode==0
 if v.returncode:assert b'no such image' in v.stderr.lower()
save();assert not l['preexisting'][tag]
v=call(['load','--input',str(r/'mcp-only.tar')],180);l['loadExitCode']=v.returncode;save();assert v.returncode==0
info=json.loads(call(['image','inspect',tag]).stdout)[0];assert info['Architecture']=='arm64' and info['Id'] in {image['id'],image['archiveId']} and info['Config']['Labels']['org.opencontainers.image.revision']==image['revision'];l['actualImageId']=info['Id'];save()
v=call(['create','--platform','linux/arm64','--pull','never','--network','none','--label','io.workmesh.ta01.probe.owner='+owner,'--entrypoint','/bin/false',info['Id']]);assert v.returncode==0;i=v.stdout.decode().strip();assert len(i)==64;l['containers'].append({'id':i,'purpose':'export exact public ARM MCP rootfs, never started'});save()
info=json.loads(call(['inspect',i]).stdout)[0];assert not info['Mounts'] and not info['State']['Running'] and info['Image']==l['actualImageId'] and info['Config']['Labels']['io.workmesh.ta01.probe.owner']==owner
p=subprocess.Popen(['docker','export',i],stdout=subprocess.PIPE,stderr=subprocess.PIPE);h=hashlib.sha256();n=0
with (r/'node-rootfs.tar.gz').open('xb') as out,gzip.GzipFile(fileobj=out,mode='wb',mtime=0) as z:
 while b:=p.stdout.read(1024*1024):z.write(b);h.update(b);n+=len(b)
assert p.wait(timeout=60)==0
l['rootfs']={'bytes':(r/'node-rootfs.tar.gz').stat().st_size,'sha256':hashlib.sha256((r/'node-rootfs.tar.gz').read_bytes()).hexdigest(),'rawBytes':n,'rawSha256':h.hexdigest()};save()
with tarfile.open(r/'node-rootfs.tar.gz',mode='r|gz') as archive:
 for member in archive:
  if member.name=='usr/local/bin/node':
   assert member.isfile();f=archive.extractfile(member);first=f.read(64);assert first[:4]==b'\x7fELF' and int.from_bytes(first[18:20],'little')==183;h=hashlib.sha256(first)
   while b:=f.read(1024*1024):h.update(b)
   l['nodeSha256']=h.hexdigest();break
assert 'nodeSha256' in l;(r/'node-sha256.txt').write_text(l['nodeSha256']+'\n',encoding='utf8');save()
assert call(['rm',i]).returncode==0;v=call(['inspect',i]);assert v.returncode!=0 and b'no such object' in v.stderr.lower();l['containers'][-1]['removedAndAbsent']=True;save()
print(json.dumps({'actualImageId':l['actualImageId'],'nodeSha256':l['nodeSha256'],'rootfsBytes':l['rootfs']['bytes']}))
