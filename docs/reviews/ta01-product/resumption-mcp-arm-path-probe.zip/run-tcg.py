from pathlib import Path
import json,subprocess,tarfile,hashlib
r=Path('.tmp/ta01-resumption/mcp-arm-565-micro');t=r/'tcg';l=json.loads((t/'resources.json').read_bytes());i=l['containers'][0]['id']
inputs={'node-rootfs.tar.gz':r/'node-rootfs.tar.gz','node-sha256.txt':r/'node-sha256.txt','ci-inputs.json':r/'ci-inputs.json','measurement.mjs':Path('docs/reviews/ta01-product/tools/mcp-component-probe.mjs'),**{n:Path('docs/reviews/ta01-product/tools')/n for n in ['component-tcg-guest.py','run-component-tcg.py']}}
l['inputs']={n:{'bytes':p.stat().st_size,'sha256':hashlib.sha256(p.read_bytes()).hexdigest()} for n,p in inputs.items()};(t/'resources.json').write_text(json.dumps(l,ensure_ascii=False,indent=2),encoding='utf8')
assert subprocess.run(['docker','exec',i,'mkdir','/opt/micro'],capture_output=True,timeout=30).returncode==0
p=subprocess.Popen(['docker','cp','-',i+':/opt/micro'],stdin=subprocess.PIPE,stdout=subprocess.PIPE,stderr=subprocess.PIPE)
with tarfile.open(fileobj=p.stdin,mode='w|') as archive:
 for n,f in inputs.items():archive.add(f,arcname=n,recursive=False)
p.stdin.close();assert p.wait(timeout=120)==0
for n in ['component-tcg-guest.py','run-component-tcg.py']:(t/('used-'+n)).write_bytes(inputs[n].read_bytes())
with (t/'runner.stdout').open('xb') as out,(t/'runner.stderr').open('xb') as err:
 p=subprocess.run(['docker','exec',i,'python3','/opt/micro/run-component-tcg.py','--exact-mcp-role','--arm64'],stdout=out,stderr=err,timeout=1250)
print(json.dumps({'runnerExitCode':p.returncode}));assert p.returncode==0
for source,name in [('guest/result.json','tcg-result.json'),('guest/serial.log','serial.log'),('guest/qemu-stderr.log','qemu-stderr.log')]:
 with (t/name).open('xb') as out:
  p=subprocess.run(['docker','exec',i,'cat','/opt/micro/'+source],stdout=out,stderr=subprocess.PIPE,timeout=30);assert p.returncode==0
print(json.dumps({'resultCopied':True}))
