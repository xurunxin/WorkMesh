import io,json,tarfile,zipfile,hashlib
from pathlib import Path
r=Path('.tmp/ta01-resumption/mcp-arm-565-micro')
m=json.loads((r/'manifest.json').read_bytes())
class Parts(io.RawIOBase):
 def __init__(self,z): self.z=z;self.i=0;self.f=None;self.h=None;self.n=0
 def readable(self):return True
 def read(self,n=-1):
  assert n>=0
  out=bytearray()
  while len(out)<n:
   if self.f is None:
    if self.i==len(m['chunks']):break
    self.f=self.z.open(m['chunks'][self.i]['path']);self.h=hashlib.sha256();self.n=0
   b=self.f.read(n-len(out))
   if b:self.h.update(b);self.n+=len(b);out+=b
   else:
    row=m['chunks'][self.i];assert self.h.hexdigest()==row['sha256'] and self.n==row['bytes']
    self.f.close();self.f=None;self.i+=1
  return bytes(out)
def walk(visitor):
 with zipfile.ZipFile(r/'candidate.zip') as z:
  p=Parts(z)
  with tarfile.open(fileobj=p,mode='r|') as t:
   for x in t:
    assert x.isfile() or x.isdir()
    if x.isfile():visitor(x,t.extractfile(x))
  while p.read(1024*1024):pass
  assert p.i==len(m['chunks'])
small={};inventory={}
def first(x,f):
 h=hashlib.sha256();b=bytearray();size=0
 while v:=f.read(1024*1024):
  h.update(v);size+=len(v)
  if x.size<=1024*1024:b+=v
 assert size==x.size and x.name not in inventory
 digest=h.hexdigest()
 if x.name.startswith('blobs/sha256/'):assert x.name.split('/')[-1]==digest
 inventory[x.name]={'bytes':size,'sha256':digest}
 if x.size<=1024*1024:small[x.name]=bytes(b)
walk(first)
image=m['images']['mcp'];md=image['archiveId'].split(':')[1];cd=image['id'].split(':')[1]
manifest=json.loads(small['blobs/sha256/'+md]);assert manifest['config']['digest']=='sha256:'+cd
config=json.loads(small['blobs/sha256/'+cd]);assert config['architecture']=='arm64' and config['config']['Labels']['org.opencontainers.image.revision']==m['source']['commit']
index=json.loads(small['index.json']);descs=[x for x in index['manifests'] if x['digest']==image['archiveId']];assert len(descs)==1
needed={'blobs/sha256/'+md,'blobs/sha256/'+cd}|{'blobs/sha256/'+x['digest'].split(':')[1] for x in manifest['layers']}
for row in [manifest['config'],*manifest['layers']]:assert inventory['blobs/sha256/'+row['digest'].split(':')[1]]['bytes']==row['size']
tag='workmesh-ta01-diagnostic/mcp:ci565-ac0-arm-owned'
desc=dict(descs[0]);desc['annotations']={'io.containerd.image.name':'docker.io/'+tag,'org.opencontainers.image.ref.name':tag}
newindex=json.dumps({'schemaVersion':2,'manifests':[desc]},separators=(',',':')).encode()
classic=json.dumps([{'Config':'blobs/sha256/'+cd,'RepoTags':[tag],'Layers':['blobs/sha256/'+x['digest'].split(':')[1] for x in manifest['layers']]}],separators=(',',':')).encode()
with (r/'mcp-only.tar').open('xb') as out,tarfile.open(fileobj=out,mode='w|') as t:
 for name,data in [('oci-layout',small['oci-layout']),('index.json',newindex),('manifest.json',classic)]:
  info=tarfile.TarInfo(name);info.size=len(data);t.addfile(info,io.BytesIO(data))
 copied=set()
 def second(x,f):
  if x.name in needed:t.addfile(x,f);copied.add(x.name)
 walk(second)
 assert copied==needed
report={'source':m['source'],'sourceArtifact':json.loads((r/'artifact.json').read_bytes()),'trustedManifestSha256':hashlib.sha256((r/'manifest.json').read_bytes()).hexdigest(),'image':image,'ownedTag':tag,'originalIndex':json.loads(small['index.json']),'selectedManifest':manifest,'selectedConfig':{k:config[k] for k in ['architecture','os','rootfs']},'selectedBlobs':{k:inventory[k] for k in sorted(needed)},'allApplicationChunksVerifiedTwice':True,'originalIndexSha256':inventory['index.json']['sha256'],'derivedIndexSha256':hashlib.sha256(newindex).hexdigest(),'subsetBytes':(r/'mcp-only.tar').stat().st_size}
with (r/'extraction.json').open('x',encoding='utf8') as f:json.dump(report,f,indent=2)
print(json.dumps({'selectedBlobs':len(needed),'subsetBytes':report['subsetBytes'],'sourceArtifactVerified':True,'ownedTag':tag}))
