import hashlib
import json
from pathlib import Path, PurePosixPath
import struct
import sys
import urllib.request
import uuid
import zipfile

base = Path('.tmp/ta01-resumption/x86-decoder')
base.mkdir(exist_ok=False)
metadata = json.load(urllib.request.urlopen('https://pypi.org/pypi/iced-x86/1.21.0/json', timeout=30))
files = [row for row in metadata['urls'] if row['filename'].endswith('cp38-abi3-win_amd64.whl')]
assert len(files) == 1
wheel = files[0]
assert wheel['url'].startswith('https://files.pythonhosted.org/') and wheel['size'] < 5*1024*1024
body = urllib.request.urlopen(wheel['url'], timeout=30).read(5*1024*1024+1)
assert len(body) == wheel['size'] and hashlib.sha256(body).hexdigest() == wheel['digests']['sha256']
with (base / wheel['filename']).open('xb') as output:
    output.write(body)
with zipfile.ZipFile(base / wheel['filename']) as archive:
    for entry in archive.infolist():
        path = PurePosixPath(entry.filename)
        assert not path.is_absolute() and '..' not in path.parts and not (entry.external_attr >> 16) & 0o170000 == 0o120000
        assert path.parts[0] == 'iced_x86' or path.parts[0].endswith('.dist-info')
        target = base / Path(*path.parts)
        if entry.is_dir():
            target.mkdir(parents=True, exist_ok=True)
        else:
            target.parent.mkdir(parents=True, exist_ok=True)
            with target.open('xb') as output:
                output.write(archive.read(entry))
sys.path.insert(0, str(base.resolve()))
from iced_x86 import Decoder, Formatter, FormatterSyntax

match = json.loads(Path('.tmp/ta01-resumption/ci559-public-location-match.json').read_bytes())
symbol = match['matches'][0]
binary = Path('.tmp/ta01-resumption/public-node-symbols/node').read_bytes()
assert hashlib.sha256(binary).hexdigest() == match['targetBinarySha256']
header = struct.unpack_from('<16sHHIQQQIHHHHHH', binary)
phoff, phentsize, phnum = header[5], header[9], header[10]
assert phentsize == 56
segments = [struct.unpack_from('<IIQQQQQQ', binary, phoff+i*phentsize) for i in range(phnum)]
segments = [row for row in segments if row[0] == 1 and row[1] & 1 and
    row[3] <= symbol['elfAddress'] < symbol['elfAddress']+symbol['bytes'] <= row[3]+row[5]]
assert len(segments) == 1
segment = segments[0]
offset = segment[2] + symbol['elfAddress'] - segment[3]
code = binary[offset:offset+symbol['bytes']]
formatter = Formatter(FormatterSyntax.INTEL)
instructions = [{'address': row.ip, 'bytes': code[row.ip-symbol['elfAddress']:row.ip-symbol['elfAddress']+row.len].hex(),
    'instruction': formatter.format(row)} for row in Decoder(64, code, ip=symbol['elfAddress'])]
position = [i for i, row in enumerate(instructions) if row['address'] == match['location']['nodeElfAddress']]
assert len(position) == 1
result = {'说明': '仅解码SHA匹配的公开Node函数字节，不读取core、进程寄存器或私有内存；PC位于指令边界，不单独证明坏指针成因。',
    'owner': str(uuid.uuid4()), 'tool': {'package': wheel['filename'], 'sourceUrl': wheel['url'], 'sha256': wheel['digests']['sha256'], 'bytes': len(body), 'version': '1.21.0', 'scope': 'task-local; no global install'},
    'targetBinarySha256': match['targetBinarySha256'], 'symbol': symbol, 'publicFunctionFileOffset': offset,
    'publicFunctionBytesSha256': hashlib.sha256(code).hexdigest(), 'publicFunctionHex': code.hex(),
    'faultInstruction': instructions[position[0]], 'instructions': instructions}
with Path('.tmp/ta01-resumption/ci559-public-function-disassembly.json').open('x', encoding='utf8') as output:
    json.dump(result, output, ensure_ascii=False, indent=2)
print(json.dumps({'tool': result['tool'], 'faultInstruction': result['faultInstruction'],
    'surrounding': instructions[max(0,position[0]-5):position[0]+6]}, ensure_ascii=False, indent=2))
