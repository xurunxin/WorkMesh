import hashlib
import json
from pathlib import Path

base = Path('.tmp/ta01-resumption/public-node-symbols')
index_bytes = (base / 'symbol-index.json').read_bytes()
index = json.loads(index_bytes)
binary = base / 'node'
binary_sha = hashlib.sha256(binary.read_bytes()).hexdigest()
receipt_file = Path('docs/reviews/ta01-product/ci559-amd64-native-observation.json')
receipt = json.loads(receipt_file.read_bytes())
trace = receipt['receipts'][-1]['diagnostics']['nativeTrace']
assert trace['targetBinarySha256'] == binary_sha == index['binarySha256']
location = trace['location']
assert location['architecture'] == index['architecture'] == 'amd64'
assert location['faultModule'] == 'node' and location['executableSegment'] is True
address = location['nodeElfAddress']
assert type(address) is int and address >= 0
matches = [{'symbol': name, 'elfAddress': start, 'bytes': size, 'offsetInFunction': address-start}
           for start, size, name in index['symbols'] if start <= address < start+size]
assert 0 < len(matches) < 10
result = {'说明': '目标与公开二进制SHA逐字一致后，按ELF定义且有尺寸的函数范围匹配公开链接地址；不是栈、不是原始ASLR地址，也不单独证明最初触发原因。',
          'targetBinarySha256': binary_sha, 'publicIndexSha256': hashlib.sha256(index_bytes).hexdigest(),
          'sourceReceipt': receipt_file.as_posix(), 'sourceReceiptSha256': hashlib.sha256(receipt_file.read_bytes()).hexdigest(),
          'location': location, 'matches': matches}
with Path('.tmp/ta01-resumption/ci559-public-location-match.json').open('x', encoding='utf8') as output:
    json.dump(result, output, ensure_ascii=False, indent=2)
print(json.dumps(result, ensure_ascii=False, indent=2))
