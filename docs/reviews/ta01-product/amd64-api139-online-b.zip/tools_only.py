"""仅在已登记专用容器准备准确工具和输入；不启动VM。"""
from pathlib import Path
import ast, hashlib, json, subprocess
ROOT=Path(__file__).resolve().parent
OLD=ROOT.parent/'ta01-resumption/api-crash-window-a-6g-once'
ledger=json.loads((ROOT/'resources.json').read_bytes());cid=ledger['containers'][0]['id']
assert not ledger['vmStarted'] and not (ROOT/'attempt-started.json').exists()
def save():(ROOT/'resources.json').write_text(json.dumps(ledger,ensure_ascii=False,indent=2)+'\n',encoding='utf8')
def call(args,timeout=60):return subprocess.run(['docker',*args],capture_output=True,timeout=timeout)
def step(name,args,timeout=60):
    result=call(args,timeout);(ROOT/(name+'.stdout')).write_bytes(result.stdout);(ROOT/(name+'.stderr')).write_bytes(result.stderr)
    ledger[name]={'exitCode':result.returncode};save();result.check_returncode();return result.stdout
info=json.loads(step('preparation-inspect',['inspect',cid]))[0]
# inspect原文含本任务固定配置，无凭据；仅本地，入库另行安全投影。
assert info['Id']==cid and info['Config']['Labels'][ledger['label']]==ledger['owner'] and not info['Mounts']
memory=step('preparation-memory',['exec',cid,'cat','/proc/meminfo'])
fields={k:int(v.split()[0]) for k,v in (line.split(':',1) for line in memory.decode().splitlines()) if k in ['MemTotal','MemAvailable','SwapTotal','SwapFree']}
admitted=fields['MemAvailable']*1024>=6442450944
(ROOT/'capacity-before-provision.json').write_text(json.dumps({'hostMeminfoKiB':fields,'requiredHostAvailableBytes':6442450944,'admissionPassed':admitted},indent=2)+'\n',encoding='utf8')
assert admitted,'capacity insufficient; no VM'
step('apt-update',['exec',cid,'apt-get','update'],300)
step('qemu-policy',['exec',cid,'apt-cache','policy','qemu-system-x86','qemu-utils','genisoimage','python3'])
step('tool-install',['exec','-e','DEBIAN_FRONTEND=noninteractive',cid,'apt-get','install','-y','--no-install-recommends',
    'qemu-system-x86=1:8.2.2+ds-0ubuntu1.18','qemu-utils=1:8.2.2+ds-0ubuntu1.18','genisoimage=9:1.1.11-3.5','python3=3.12.3-0ubuntu2.1','ca-certificates'],600)
assert b'8.2.2 (Debian 1:8.2.2+ds-0ubuntu1.18)' in step('qemu-version',['exec',cid,'qemu-system-x86_64','--version'])
assert step('qemu-sha',['exec',cid,'sha256sum','/usr/bin/qemu-system-x86_64']).split()[0]==b'8a35ccba41582fc6c38b9df85fc9e35fa1d42f414d2d7d8090ee9b2f5e7c0854'
step('mkdir-input',['exec',cid,'mkdir','-p','/opt/api-window'])
ledger['exactToolsVerified']=True;save()
print('tools prepared; VM not started')
