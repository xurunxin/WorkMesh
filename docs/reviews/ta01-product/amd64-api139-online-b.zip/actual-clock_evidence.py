"""新A的有界安全记录；不记录HTTP内容、寄存器或私有内存。"""
import ast
import json
import math
import os
from pathlib import Path
import queue
import re
import signal
import subprocess
import threading
import time
import urllib.request

MAX_RECORDS = 31  # 另有一份handler首败标记，总计不超过32条。
MAX_BYTES = 4096
IDENTITY_KEYS = {'pid', 'startTicks', 'executableDevice', 'executableInode', 'executableBytes'}
STAGES = {'debugger-started','debugger-attached','debugger-running','debugger-signal','debugger-stack','debugger-detaching','debugger-exited','clock-driver-started', 'handler-started', 'client-intent', 'client-finished',
          'client-skipped', 'proxy-received', 'proxy-forward-intent', 'proxy-request-sent',
          'proxy-upstream-headers', 'proxy-upstream-complete', 'proxy-client-complete', 'proxy-failed',
          'prefix-cancel-intent', 'prefix-cancel-finished', 'marker-observed', 'diagnostic-error'}
EXTRA_KEYS = {'debuggerProcess','captureId', 'target', 'handlerStartedGuestMonotonic', 'markerRecordedGuestMonotonic',
              'requestSequence', 'status', 'exitCode', 'actionSequence', 'result', 'errorType'}
ERRORS = {'RemoteDisconnected', 'TimeoutError', 'TimeoutExpired', 'BrokenPipeError', 'ConnectionResetError',
          'IncompleteRead', 'OSError', 'SSLError', 'ValueError', 'PermissionError', 'FileNotFoundError', 'OtherError'}
RESULTS = {'late-debugger','early-handler', 'observer-rejected', 'command-terminated', 'command-exited',
           'underlying-helper-inflight-unknown', 'late-marker', 'projection-failed'}

class ClockFailure(RuntimeError): pass

def error_name(error):
    return type(error).__name__ if type(error).__name__ in ERRORS else 'OtherError'

def identity_valid(value):
    return isinstance(value, dict) and set(value) == IDENTITY_KEYS and all(type(v) is int and v >= 0 for v in value.values()) and value['pid'] > 1

def uuid_valid(value):
    return isinstance(value, str) and re.fullmatch(r'[a-f0-9]{8}(?:-[a-f0-9]{4}){3}-[a-f0-9]{12}', value) is not None

def validate_record(value):
    base = {'nonce', 'kind', 'stage', 'sequence', 'bootId', 'guestMonotonic'}
    if not isinstance(value, dict) or not base <= set(value) or set(value) - base - EXTRA_KEYS:
        raise ClockFailure('clock-schema')
    if value['kind'] != 'clock' or value['stage'] not in STAGES or not re.fullmatch('[a-f0-9]{32}', value['nonce']):
        raise ClockFailure('clock-identity')
    if not uuid_valid(value['bootId']) or type(value['sequence']) is not int or not 0 <= value['sequence'] <= MAX_RECORDS:
        raise ClockFailure('clock-sequence')
    for name in ['guestMonotonic', 'handlerStartedGuestMonotonic', 'markerRecordedGuestMonotonic']:
        if name in value and (type(value[name]) not in [int, float] or not math.isfinite(value[name]) or value[name] < 0):
            raise ClockFailure('clock-number')
    for name in ['requestSequence', 'status', 'exitCode', 'actionSequence']:
        if name in value and (type(value[name]) is not int or not -255 <= value[name] <= 599):
            raise ClockFailure('clock-integer')
    if 'captureId' in value and not re.fullmatch('[a-f0-9]{32}', value['captureId']):raise ClockFailure('clock-capture')
    if 'debuggerProcess' in value and not identity_valid(value['debuggerProcess']):raise ClockFailure('clock-debugger-identity')
    if 'target' in value and not identity_valid(value['target']):raise ClockFailure('clock-target')
    if 'errorType' in value and value['errorType'] not in ERRORS:raise ClockFailure('clock-error')
    if 'result' in value and value['result'] not in RESULTS:raise ClockFailure('clock-result')
    raw = json.dumps(value, allow_nan=False, separators=(',', ':')).encode()
    if len(raw) > MAX_BYTES - 256:raise ClockFailure('clock-bytes')
    return raw

def write_first_marker(path, nonce, boot_id, capture_id, identity, entered):
    value = {'nonce':nonce, 'kind':'clock', 'stage':'handler-started', 'sequence':0, 'bootId':boot_id,
             'guestMonotonic':entered, 'handlerStartedGuestMonotonic':entered,
             'markerRecordedGuestMonotonic':time.monotonic(), 'captureId':capture_id, 'target':identity}
    raw = validate_record(value)
    temporary = path.with_name(path.name + '.' + str(os.getpid()) + '.tmp')
    with temporary.open('xb') as stream:
        os.chmod(temporary, 0o600);stream.write(raw);stream.flush();os.fsync(stream.fileno())
    # owner核准后每个窗口仅一个handler；旧标记存在即拒绝覆盖。
    try:os.link(temporary, path)  # 原子且拒绝覆盖先前首败。
    finally:temporary.unlink()

class Journal:
    def __init__(self, root, nonce, boot_id, transport=True):
        self.root, self.nonce, self.boot_id = root, nonce, boot_id
        self.lock = threading.Lock();self.stop = threading.Event();self.rows = []
        self.error = None;self.binding = None;self.marker = None;self.last_check = float('-inf')
        self.sent = 0;self.transport_error = None;self.queue = queue.Queue(MAX_RECORDS)
        self.transport = transport;self.closed = threading.Event()
        self.worker = threading.Thread(target=self.send, daemon=True)
        if transport:self.worker.start()

    def bind(self, capture_id, identity):
        if self.binding is not None or not identity_valid(identity) or not re.fullmatch('[a-f0-9]{32}',capture_id):
            raise ClockFailure('clock-bind')
        self.binding = (capture_id, dict(identity))

    def record(self, stage, **fields):
        try:
            with self.lock:
                if len(self.rows) >= MAX_RECORDS:raise ClockFailure('clock-record-limit')
                value = {'nonce':self.nonce,'kind':'clock','stage':stage,'sequence':len(self.rows)+1,
                         'bootId':self.boot_id,'guestMonotonic':time.monotonic(),**fields}
                if self.binding:
                    value.setdefault('captureId',self.binding[0]);value.setdefault('target',self.binding[1])
                raw=validate_record(value)
                with (self.root/'clock-evidence.ndjson').open('ab') as stream:
                    stream.write(raw+b'\n');stream.flush();os.fsync(stream.fileno())
                self.rows.append(value)
                if self.transport:self.queue.put_nowait(raw)
                return value
        except Exception:
            self.error='projection-failed';self.stop.set();raise

    def send(self):
        while not self.closed.is_set() or not self.queue.empty():
            try:raw=self.queue.get(timeout=.1)
            except queue.Empty:continue
            try:
                request=urllib.request.Request('http://10.0.2.2:18080/clock-receipt',raw,{'content-type':'application/json'})
                with urllib.request.urlopen(request, timeout=3) as response:
                    if response.status != 200:raise ClockFailure('clock-receipt-rejected')
                    response.read()
                self.sent+=1
            except Exception as error:
                self.transport_error=error_name(error);self.stop.set();return
            finally:self.queue.task_done()

    def poll_marker(self, now=None):
        now=time.monotonic() if now is None else now
        with self.lock:
            if now-self.last_check < 1:return self.marker
            self.last_check=now
        path=self.root/'clock-first-failure.json'
        if not path.exists():return None
        if self.binding is None:return None  # 登记线程尚未完成；绝不认领未知目标。
        try:
            raw=path.read_bytes()
            if len(raw)>MAX_BYTES:raise ClockFailure('clock-marker-size')
            value=json.loads(raw);validate_record(value)
            if value['stage']!='handler-started' or value['sequence']!=0 or value['nonce']!=self.nonce or value['bootId']!=self.boot_id:
                raise ClockFailure('clock-marker-context')
            if not self.binding or (value['captureId'],value['target'])!=self.binding:
                raise ClockFailure('clock-marker-owner')
            if self.marker is None:
                self.marker=value;self.stop.set()
                self.record('marker-observed',handlerStartedGuestMonotonic=value['handlerStartedGuestMonotonic'],
                            markerRecordedGuestMonotonic=value['markerRecordedGuestMonotonic'],result='early-handler')
            return self.marker
        except Exception:
            self.error='projection-failed';self.stop.set();raise

    def finish(self):
        self.closed.set()
        if self.transport:self.worker.join(timeout=3)
        return {'bootId':self.boot_id,'records':self.rows,'firstFailure':self.marker,'projectionError':self.error,
                'transportError':self.transport_error,'recordsSent':self.sent,'pendingTransport':self.queue.qsize()}

class PrefixRunner:
    def __init__(self, journal, stop_exception, sequence):
        self.journal=journal;self.stop_exception=stop_exception;self.sequence=sequence

    def __getattr__(self, name):return getattr(subprocess,name)

    def run(self, args, **kwargs):
        if not (len(args)>1 and args[0]=='sh' and str(args[1]).endswith('/install.sh')):
            return subprocess.run(args,**kwargs)
        if self.journal.stop.is_set():raise self.stop_exception()
        timeout=kwargs.pop('timeout',None)
        data=kwargs.pop('input',None)
        if kwargs.pop('capture_output',False):kwargs.update(stdout=subprocess.PIPE,stderr=subprocess.PIPE)
        began=time.monotonic();deadline=began+timeout if timeout is not None else float('inf')
        proc=subprocess.Popen(args,start_new_session=True,**kwargs)
        def stop_owned(sig):
            try:
                if proc.poll() is None and os.getpgid(proc.pid)==proc.pid:os.killpg(proc.pid,sig)
            except ProcessLookupError:pass
        while True:
            if self.journal.stop.is_set():
                self.journal.record('prefix-cancel-intent',actionSequence=self.sequence(),result='underlying-helper-inflight-unknown')
                stop_owned(signal.SIGTERM)
                try:out,err=proc.communicate(timeout=max(.01,min(5,deadline-time.monotonic())))
                except subprocess.TimeoutExpired:
                    stop_owned(signal.SIGKILL)
                    out,err=proc.communicate(timeout=max(.01,min(1,deadline-time.monotonic())))
                self.journal.record('prefix-cancel-finished',actionSequence=self.sequence(),exitCode=proc.returncode,result='command-terminated')
                raise self.stop_exception()
            remaining=deadline-time.monotonic()
            if remaining<=0:
                stop_owned(signal.SIGKILL)
                out,err=proc.communicate()
                raise subprocess.TimeoutExpired(args,timeout,output=out,stderr=err)
            try:
                out,err=proc.communicate(input=data,timeout=min(.25,remaining))
                return subprocess.CompletedProcess(args,proc.returncode,out,err)
            except subprocess.TimeoutExpired:data=None

def instrument_proxy(source, namespace, begin, stage, failed):
    tree=ast.parse(source)
    proxy=next(n for n in tree.body if isinstance(n,ast.FunctionDef) and n.name=='proxy')
    handler=next(n for n in ast.walk(proxy) if isinstance(n,ast.FunctionDef) and n.name=='forward_request')
    original_dump=ast.dump(handler,include_attributes=False)
    counts={key:0 for key in ['forward-intent','request-sent','headers','upstream-complete','client-complete']}
    def hook(name):return ast.parse("_clock_stage(clock_token, 'proxy-"+name+"')").body[0]
    class Inject(ast.NodeTransformer):
        def visit_Expr(self,node):
            if isinstance(node.value,ast.Call):
                value=node.value
                if isinstance(value.func,ast.Attribute) and isinstance(value.func.value,ast.Name) and value.func.value.id=='backend' and value.func.attr=='request':
                    counts['forward-intent']+=1;counts['request-sent']+=1
                    return [hook('forward-intent'),node,hook('request-sent')]
                if isinstance(value.func,ast.Attribute) and value.func.attr=='write' and ast.dump(value.func.value)==ast.dump(ast.parse('self.wfile',mode='eval').body) and value.args and isinstance(value.args[0],ast.Name) and value.args[0].id=='payload':
                    # provider fixture分支也有write；只对token存在的auth路由记录。
                    counts['client-complete']+=1;return [node,hook('client-complete')]
            return self.generic_visit(node)
        def visit_Assign(self,node):
            if len(node.targets)==1 and isinstance(node.targets[0],ast.Name):
                if node.targets[0].id=='response' and isinstance(node.value,ast.Call) and isinstance(node.value.func,ast.Attribute) and node.value.func.attr=='getresponse':
                    counts['headers']+=1
                    return [node,ast.parse("_clock_stage(clock_token, 'proxy-upstream-headers', response.status)").body[0]]
                if node.targets[0].id=='payload' and isinstance(node.value,ast.Call) and isinstance(node.value.func,ast.Attribute) and isinstance(node.value.func.value,ast.Name) and node.value.func.value.id=='response' and node.value.func.attr=='read':
                    counts['upstream-complete']+=1;return [node,hook('upstream-complete')]
            return self.generic_visit(node)
    Inject().visit(handler)
    assert counts=={'forward-intent':1,'request-sent':1,'headers':1,'upstream-complete':1,'client-complete':2},counts
    body=handler.body
    handler.body=[ast.parse('clock_token = _clock_begin(self.command, self.path)').body[0],
        ast.Try(body=body,handlers=[ast.ExceptHandler(type=ast.Name(id='BaseException',ctx=ast.Load()),name='error',
            body=[ast.parse('_clock_failed(clock_token, error)').body[0],ast.Raise()])],orelse=[],finalbody=[])]
    module=ast.fix_missing_locations(ast.Module(body=[proxy],type_ignores=[]))
    namespace.update(_clock_begin=begin,_clock_stage=stage,_clock_failed=failed)
    exec(compile(module,'<approved-clock-proxy>','exec'),namespace)
    return counts,original_dump
