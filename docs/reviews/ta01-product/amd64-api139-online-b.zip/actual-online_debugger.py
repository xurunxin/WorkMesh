"""本次已批B：单次有界MI附加；原文只在内存，安全投影不含私有地址或值。"""
import bisect, hashlib, json, os, re, selectors, signal, subprocess, threading, time
from pathlib import Path
from native_diagnostic import process_identity, binary_hash, safe_trace
from core_metadata import _headers

TOTAL_SECONDS=900
SIGNAL_SECONDS=60
RAW_LIMIT=65536
NODE_SHA='638c77326270093b1251a5e72b4335c94c74856a210460341c73d6f3da647328'
SYMBOL=re.compile(r'^(v8::[A-Za-z0-9_:~]+|node::[A-Za-z0-9_:~]+|(?:OSSL|X509|SSL|EVP|CRYPTO|RSA|EC|BIO|RAND)_[A-Za-z0-9_]+)(?:\b|$)')

class DebuggerStop(RuntimeError):pass
class BudgetStop(DebuggerStop):pass
class OutputStop(DebuggerStop):pass
class ProjectionStop(DebuggerStop):pass
class GoalStop(DebuggerStop):pass

class Parser:
    def __init__(self,text):self.text=text;self.pos=0;self.items=0
    def key(self):
        match=re.match(r'[A-Za-z_][A-Za-z0-9_-]*',self.text[self.pos:])
        if not match:raise ProjectionStop('mi-key')
        self.pos+=len(match[0]);return match[0]
    def value(self,depth=0):
        if depth>16:raise ProjectionStop('mi-depth')
        self.items+=1
        if self.items>2048:raise ProjectionStop('mi-items')
        char=self.text[self.pos:self.pos+1]
        if char=='"':
            start=self.pos;self.pos+=1
            while self.pos<len(self.text):
                char=self.text[self.pos];self.pos+=1
                if char=='\\':self.pos+=1
                elif char=='"':return json.loads(self.text[start:self.pos])
            raise ProjectionStop('mi-string')
        if char=='{':self.pos+=1;return self.fields('}',depth+1)
        if char=='[':
            self.pos+=1;values=[]
            while self.text[self.pos:self.pos+1]!=']':
                if not self.text[self.pos:self.pos+1]:raise ProjectionStop('mi-list')
                if re.match(r'[A-Za-z_][A-Za-z0-9_-]*=',self.text[self.pos:]):
                    name=self.key();self.pos+=1;values.append({name:self.value(depth+1)})
                else:values.append(self.value(depth+1))
                if self.text[self.pos:self.pos+1]==',':self.pos+=1
                elif self.text[self.pos:self.pos+1]!=']':raise ProjectionStop('mi-list-delimiter')
            self.pos+=1;return values
        raise ProjectionStop('mi-value')
    def fields(self,end='',depth=0):
        value={}
        while self.pos<len(self.text) and (not end or self.text[self.pos]!=end):
            name=self.key()
            if name in value or self.text[self.pos:self.pos+1]!='=':raise ProjectionStop('mi-fields')
            self.pos+=1;value[name]=self.value(depth+1)
            if self.text[self.pos:self.pos+1]==',':self.pos+=1
            else:break
        if end:
            if self.text[self.pos:self.pos+1]!=end:raise ProjectionStop('mi-end')
            self.pos+=1
        return value

def mi_record(raw):
    text=raw.decode('utf8').strip()
    if text=='' or text=='(gdb)':return None
    if text[:1] in ['~','&','@']:return None  # 不投影console／log／target原文。
    match=re.fullmatch(r'(\d*)([\^*=+])([A-Za-z_-]+)(?:,(.*))?',text)
    if not match:raise ProjectionStop('mi-record')
    parser=Parser(match[4] or '');fields=parser.fields()
    if parser.pos!=len(parser.text):raise ProjectionStop('mi-tail')
    return (int(match[1]) if match[1] else None,match[2],match[3],fields)

class PublicNode:
    def __init__(self,identity,ranges_path):
        self.identity=identity;self.pid=identity['pid']
        assert process_identity(self.pid)==identity and binary_hash(self.pid)==NODE_SHA
        index=json.loads(Path(ranges_path).read_bytes());assert index['nodeBinarySha256']==NODE_SHA
        self.ranges=index['ranges'];self.starts=[a for a,b in self.ranges]
        with Path(f'/proc/{self.pid}/exe').open('rb') as stream:
            machine,self.size,self.segments=_headers(stream,{2,3});assert machine==62
    def public_pc(self,address):
        assert process_identity(self.pid)==self.identity
        matches=[]
        for line in Path(f'/proc/{self.pid}/maps').read_text().splitlines():
            fields=line.split(None,5)
            if len(fields)!=6 or fields[5]!='/usr/local/bin/node':continue
            begin,end=[int(v,16) for v in fields[0].split('-')]
            major,minor=[int(v,16) for v in fields[3].split(':')]
            if not begin<=address<end or os.makedev(major,minor)!=self.identity['executableDevice'] or int(fields[4])!=self.identity['executableInode']:continue
            offset=int(fields[2],16)+address-begin
            matches.extend(virtual+offset-source for kind,flags,source,virtual,_,size,_,_ in self.segments
                           if kind==1 and flags&1 and source<=offset<source+size<=self.size)
        if len(matches)!=1:return False
        index=bisect.bisect_right(self.starts,matches[0])-1
        return index>=0 and self.ranges[index][0]<=matches[0]<self.ranges[index][1]

def project_frames(fields,public_pc):
    stack=fields.get('stack')
    if not isinstance(stack,list) or len(stack)>12:raise ProjectionStop('frame-count')
    symbols=[];outside=False
    for index,item in enumerate(stack):
        if not isinstance(item,dict) or set(item)!={'frame'}:raise ProjectionStop('frame-shape')
        frame=item['frame']
        if frame.get('level')!=str(index) or not re.fullmatch(r'0x[0-9a-fA-F]+',frame.get('addr','')):raise ProjectionStop('frame-identity')
        if not public_pc(int(frame['addr'],16)):
            outside=True;break  # 不遍历或投影JIT／私有调用者。
        match=SYMBOL.match(frame.get('func',''))
        if match:symbols.append(match[1][:160])
    return {'symbols':symbols[:40],'framesReturned':len(stack),'projectionStopped':'outside-public-node' if outside else 'bounded-public-stack'}

class OnlineDebugger:
    def __init__(self,identity,capture_id,journal,base):
        self.identity=dict(identity);self.capture_id=capture_id;self.journal=journal;self.base=Path(base)
        self.began=time.monotonic();self.deadline=self.began+TOTAL_SECONDS;self.signal_at=None
        self.request_stop=threading.Event();self.finished=threading.Event();self.proc=None
        self.raw={'stdout':bytearray(),'stderr':bytearray()};self.buffers={'stdout':bytearray(),'stderr':bytearray()}
        self.responses={};self.token=0;self.running=False;self.attached=False;self.inferior_exited=False;self.had_signal=False;self.eof=set()
        self.selector=selectors.DefaultSelector();self.detached=False;self.thread_id=None;self.cleanup_limit=None
        self.result={'purpose':'approved-online-api-only','diagnosticIntervention':True,'captureId':capture_id,'registeredTarget':identity,
                     'startedGuestMonotonic':self.began,'totalMaximumSeconds':TOTAL_SECONDS,'signalMaximumSeconds':SIGNAL_SECONDS,
                     'rawCombinedLimitBytes':RAW_LIMIT,'status':'starting','detachedConfirmed':False}
        self.worker=threading.Thread(target=self.run,daemon=True);self.worker.start()
    def current_deadline(self):return min(self.deadline,self.signal_at+SIGNAL_SECONDS if self.signal_at is not None else self.deadline,self.cleanup_limit if self.cleanup_limit is not None else self.deadline)
    def stage(self,name,**fields):
        self.journal.record(name,**fields)
    def event(self,record):
        token,kind,status,fields=record
        if kind=='^':self.responses[token]=(status,fields);return
        if kind=='*' and status=='running':self.running=True
        if kind=='*' and status=='stopped':
            self.running=False
            if fields.get('reason','').startswith('exited'):
                self.inferior_exited=True;self.journal.stop.set()
            if fields.get('signal-name')=='SIGSEGV' and not self.had_signal:
                self.had_signal=True;self.signal_at=time.monotonic();self.thread_id=fields.get('thread-id')
                if not isinstance(self.thread_id,str) or not self.thread_id.isdigit():raise ProjectionStop('fault-thread')
                self.result.update(sigsegv=True,signalGuestMonotonic=self.signal_at)
                self.stage('debugger-signal');self.journal.stop.set()
            elif self.attached and self.cleanup_limit is None and fields.get('reason')=='signal-received':
                name=fields.get('signal-name')
                self.result['otherStopSignal']=name if name in {'SIGABRT','SIGILL','SIGBUS','SIGFPE','SIGTRAP','SIGINT','SIGSTOP'} else 'OtherSignal'
                self.journal.stop.set()
    def pump(self,deadline):
        if time.monotonic()>=deadline:raise BudgetStop('debugger-deadline')
        for key,_ in self.selector.select(timeout=max(0,min(.1,deadline-time.monotonic()))):
            remaining=RAW_LIMIT-sum(len(v) for v in self.raw.values())
            if remaining<=0:raise OutputStop('debugger-output-limit')
            data=os.read(key.fd,min(4096,remaining));name=key.data
            if not data:self.eof.add(name);self.selector.unregister(key.fileobj);continue
            self.raw[name].extend(data)
            if name=='stdout':
                self.buffers[name].extend(data)
                while b'\n' in self.buffers[name]:
                    line,_,rest=self.buffers[name].partition(b'\n');self.buffers[name]=bytearray(rest)
                    record=mi_record(bytes(line))
                    if record:self.event(record)
            if sum(len(v) for v in self.raw.values())>=RAW_LIMIT:raise OutputStop('debugger-output-limit')
    def command(self,command,cleanup=False):
        deadline=self.current_deadline()
        if not cleanup:
            deadline-=10  # 从同一总预算内预留detach／退出，不另加时间。
            if self.request_stop.is_set():raise GoalStop('goal-finished')
        if time.monotonic()>=deadline:raise BudgetStop('debugger-deadline-before-command')
        self.token+=1;token=self.token
        self.proc.stdin.write((str(token)+command+'\n').encode());self.proc.stdin.flush()
        while token not in self.responses:
            if not cleanup and self.request_stop.is_set():raise GoalStop('goal-finished')
            self.pump(deadline)
            if self.proc.poll() is not None and token not in self.responses:raise DebuggerStop('debugger-exited')
        status,fields=self.responses.pop(token)
        if status=='error':
            if command.startswith('-target-attach ') and any(v in fields.get('msg','') for v in ['Operation not permitted','Permission denied']):
                self.result['ptraceRejected']=True
            raise DebuggerStop('mi-rejected')
        return status,fields
    def stop_owned(self):
        if self.proc and self.proc.poll() is None:
            try:
                if process_identity(self.proc.pid)==self.process_identity:self.proc.kill()
            except (OSError,ValueError):pass
    def cleanup(self):
        if not self.proc or self.proc.poll() is not None:return
        deadline=self.current_deadline()
        self.stage('debugger-detaching')
        if self.attached and not self.inferior_exited:
            if self.running:
                self.command('-exec-interrupt',cleanup=True)
                while self.running:self.pump(deadline)
            self.command('-target-detach',cleanup=True)
            self.detached=True
            try:
                assert process_identity(self.identity['pid'])==self.identity
                status=Path(f"/proc/{self.identity['pid']}/status").read_text()
                self.result['detachedConfirmed']=bool(re.search(r'^TracerPid:\s+0$',status,re.M))
            except (OSError,ValueError,AssertionError):self.result['targetUnavailableAfterDetach']=True
            if not self.result['detachedConfirmed'] and not self.result.get('targetUnavailableAfterDetach'):raise DebuggerStop('detach-unconfirmed')
        self.command('-gdb-exit',cleanup=True)
        while self.proc.poll() is None:self.pump(deadline)
        if not self.inferior_exited:
            try:
                assert process_identity(self.identity['pid'])==self.identity
                status=Path(f"/proc/{self.identity['pid']}/status").read_text()
                self.result['untracedAfterDebuggerExit']=bool(re.search(r'^TracerPid:\s+0$',status,re.M))
                if not self.result['untracedAfterDebuggerExit']:raise DebuggerStop('target-still-traced')
            except (OSError,ValueError,AssertionError):self.result['targetUnavailableAfterDebuggerExit']=True
    def run(self):
        force_stop=False
        try:
            public=PublicNode(self.identity,self.base/'public-node-ranges.json')
            if self.journal.stop.is_set():raise GoalStop('earlier-stop')
            if time.monotonic()>=self.deadline-10:raise BudgetStop('debugger-preflight-deadline')
            env=dict(os.environ);env.update(LC_ALL='C',PYTHONDONTWRITEBYTECODE='1')
            self.proc=subprocess.Popen(['gdb','--nx','--quiet','--interpreter=mi2'],stdin=subprocess.PIPE,stdout=subprocess.PIPE,stderr=subprocess.PIPE,bufsize=0,env=env)
            self.process_identity=process_identity(self.proc.pid)
            self.result.update(debuggerProcess=self.process_identity,debuggerBinarySha256=binary_hash(self.proc.pid))
            for name in ['stdout','stderr']:
                stream=getattr(self.proc,name);os.set_blocking(stream.fileno(),False);self.selector.register(stream,selectors.EVENT_READ,name)
            self.stage('debugger-started',debuggerProcess=self.process_identity)
            for setting in ['pagination off','confirm off','auto-load off','debuginfod enabled off','auto-solib-add off',
                            'print frame-arguments none','print entry-values no','print thread-events off','mi-async on',
                            'sysroot /proc/'+str(self.identity['pid'])+'/root']:
                self.command('-gdb-set '+setting)
            for handling in ['handle SIGPIPE SIGUSR1 SIGUSR2 SIGALRM SIGTERM nostop noprint pass','handle SIGSEGV stop print pass']:
                self.command('-interpreter-exec console '+json.dumps(handling))
            self.command('-file-exec-and-symbols '+json.dumps('/proc/'+str(self.identity['pid'])+'/exe'))
            assert process_identity(self.identity['pid'])==self.identity
            self.command('-target-attach '+str(self.identity['pid']));self.attached=True
            assert process_identity(self.identity['pid'])==self.identity
            status=Path(f"/proc/{self.identity['pid']}/status").read_text()
            assert re.search(r'^TracerPid:\s+'+str(self.proc.pid)+r'$',status,re.M)
            self.result.update(attachedGuestMonotonic=time.monotonic(),status='attached')
            self.stage('debugger-attached')
            if not self.had_signal:
                self.command('-exec-continue');self.result['continuedGuestMonotonic']=time.monotonic();self.stage('debugger-running')
            while not self.had_signal and not self.inferior_exited:
                if self.request_stop.is_set():raise GoalStop('target-complete-or-prefix-stop')
                if self.journal.stop.is_set():raise GoalStop('earlier-first-failure')
                self.pump(self.current_deadline()-10)
            if self.had_signal:
                _,frames=self.command('-stack-list-frames --thread '+self.thread_id+' --no-frame-filters 0 11',cleanup=True)
                self.result.update(project_frames(frames,public.public_pc),status='first-signal-projected')
                self.stage('debugger-stack')
            else:self.result['status']='inferior-exited'
        except GoalStop:self.result['status']='stopped-at-original-boundary'
        except Exception as error:
            self.result.update(status='diagnostic-failed',errorType=type(error).__name__)
            self.journal.stop.set();force_stop=isinstance(error,(OutputStop,ProjectionStop))
        finally:
            self.cleanup_limit=min(self.current_deadline(),time.monotonic()+10)
            try:
                if force_stop:raise DebuggerStop('projection-output-rejected')
                self.cleanup()
            except Exception as error:
                self.result.update(cleanupErrorType=type(error).__name__,forceVmStop=True);self.journal.stop.set();self.stop_owned()
            if self.proc:
                self.result['debuggerExitCode']=self.proc.poll()
                if self.proc.poll() is None:self.stop_owned();self.result['forceVmStop']=True;self.journal.stop.set()
                for stream in [self.proc.stdin,self.proc.stdout,self.proc.stderr]:
                    try:stream.close()
                    except OSError:pass
            self.selector.close()
            safe=safe_trace(bytes(self.raw['stdout']),bytes(self.raw['stderr']),self.result.get('debuggerExitCode'))
            self.result['output']={k:safe[k] for k in ['stdoutSha256','stderrSha256','stdoutBytes','stderrBytes','categories','ptraceRejected']}
            self.result['output']['ptraceRejected']=bool(safe['ptraceRejected'] or self.result.get('ptraceRejected'))
            self.result['output'].update(eofStreams=sorted(self.eof),byteBoundary='仅实际捕获管道字节；缺EOF不冒称全部输出，原文未持久化')
            self.result.update(finishedGuestMonotonic=time.monotonic(),elapsedSeconds=time.monotonic()-self.began,
                               rawOutputPersisted=False,postCoreGdbAllowed=False)
            if self.result['elapsedSeconds']>TOTAL_SECONDS:self.result['totalBudgetExceeded']=True;self.journal.stop.set()
            if self.signal_at and time.monotonic()-self.signal_at>SIGNAL_SECONDS:self.result['signalBudgetExceeded']=True;self.journal.stop.set()
            try:self.stage('debugger-exited')
            except Exception:self.result['stageProjectionFailed']=True;self.journal.stop.set()
            self.finished.set()
    def finish(self):
        self.request_stop.set()
        self.finished.wait(timeout=max(0,self.current_deadline()-time.monotonic()))
        if not self.finished.is_set():
            self.stop_owned();self.journal.stop.set()
            return {**self.result,'forceVmStop':True,'finishedWithinBudget':False}
        return self.result
