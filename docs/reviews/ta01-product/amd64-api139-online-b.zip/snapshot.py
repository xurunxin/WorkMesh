from pathlib import Path
from datetime import datetime, timezone
import json, subprocess, time

ROOT=Path('.tmp/ta01-online-b-once')
ledger=json.loads((ROOT/'resources.json').read_bytes()); cid=ledger['containers'][0]['id']
def call(args): return subprocess.run(['docker',*args],capture_output=True,timeout=30)
info=call(['inspect',cid])
if info.returncode:
    print(json.dumps({'containerAbsent':True,'ledger':ledger.get('vmResult'),'removedAndAbsent':ledger.get('removedAndAbsent')}));raise SystemExit()
value=json.loads(info.stdout)[0]
assert value['Id']==cid and value['Config']['Labels'][ledger['label']]==ledger['owner']
for name in ['result.json','started.json','qemu-started.json','receipts.ndjson','serial.log','qemu-stderr.log']:
    result=call(['exec',cid,'cat','/opt/api-window/guest/'+name])
    if result.returncode==0:(ROOT/('live-'+name)).write_bytes(result.stdout)
samples={}
for name in ['memory.current','memory.peak','memory.events']:
    result=call(['exec',cid,'cat','/sys/fs/cgroup/'+name])
    if result.returncode==0:samples[name]=result.stdout.decode()
sample={'at':datetime.now(timezone.utc).isoformat(),'state':{k:value['State'][k] for k in ['Running','ExitCode','OOMKilled']},'cgroup':samples}
if (ROOT/'live-qemu-started.json').exists():
    identity=json.loads((ROOT/'live-qemu-started.json').read_bytes())
    pid=identity['qemuPid']
    stat=call(['exec',cid,'cat',f'/proc/{pid}/stat'])
    status=call(['exec',cid,'cat',f'/proc/{pid}/status'])
    if stat.returncode==status.returncode==0:
        fields=stat.stdout.decode().rsplit(')',1)[1].split()
        if int(fields[19])==identity['startTicks']:
            resource={'pid':pid,'startTicks':identity['startTicks'],'userTicks':int(fields[11]),'systemTicks':int(fields[12])}
            for line in status.stdout.decode().splitlines():
                key,_,raw=line.partition(':')
                if key in ['VmRSS','VmHWM','Threads']: resource[key]=raw.strip()
            sample['qemuResources']=resource
with (ROOT/'outer-live-samples.ndjson').open('a',encoding='utf8') as f:f.write(json.dumps(sample)+'\n')
receipts=[]
if (ROOT/'live-receipts.ndjson').exists(): receipts=[json.loads(x) for x in (ROOT/'live-receipts.ndjson').read_text().splitlines()]
progress=[]
if (ROOT/'live-serial.log').exists():
    for line in (ROOT/'live-serial.log').read_text(errors='replace').splitlines():
        start=line.find('{')
        if start<0:continue
        try:entry=json.loads(line[start:])
        except ValueError:continue
        if entry.get('tag') in ['ta01-progress','ta01-install-action','ta01-failure','ta01-installer-phase']:
            progress.append({k:entry[k] for k in ['tag','profile','stage','sequence','action','state','phase','code'] if k in entry})
print(json.dumps({'utc':sample['at'],'state':sample['state'],'cgroup':samples,'receiptCount':len(receipts),'latestStage':receipts[-1].get('stage',receipts[-1].get('kind')) if receipts else None,'serialProgress':progress[-4:],'finalAvailable':(ROOT/'live-result.json').exists()}))
