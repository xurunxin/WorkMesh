"""有界MI包装替身：不执行GDB／Node／ptrace或VM。"""
import ast,contextlib,io,json,os,re,sys,tempfile,threading,time,types,unittest
from pathlib import Path
from unittest.mock import patch
ROOT=Path(__file__).resolve().parent
sys.path.insert(0,str(ROOT/'source'))
import online_debugger as d
import clock_evidence as c

TARGET={'pid':123,'startTicks':456,'executableDevice':1,'executableInode':2,'executableBytes':124181928}
GDB={'pid':9999,'startTicks':789,'executableDevice':3,'executableInode':4,'executableBytes':100}
SECRET='fixture-private-never-project'

class MiTest(unittest.TestCase):
    def test_late_attachment_skips_request_without_wait(self):
        tree=ast.parse((ROOT/'diagnostic_guest.py').read_text(encoding='utf8'))
        request=next(n for n in tree.body if isinstance(n,ast.FunctionDef) and n.name=='request')
        class Stop(BaseException):pass
        with tempfile.TemporaryDirectory() as root:
            j=c.Journal(Path(root),'a'*32,'11111111-1111-1111-1111-111111111111',transport=False)
            calls=[];target={'attempts':0}
            ns={'g':types.SimpleNamespace(install_actions=8),'target':target,'clock':j,'observer':{},'watcher':None,
                'debugger':None,'WindowStop':Stop,'original_request':lambda *args,**kwargs:calls.append(1)}
            exec(compile(ast.fix_missing_locations(ast.Module(body=[request],type_ignores=[])),'<late-fixture>','exec'),ns)
            with self.assertRaises(Stop):ns['request'](None,'https://fixture/api/v1/auth/install',{'private-fixture':True})
            self.assertEqual(target['attempts'],0);self.assertEqual(calls,[]);self.assertTrue(j.stop.is_set())
    def test_parser_split_strings_nested_and_no_eval(self):
        value=d.mi_record(b'12^done,stack=[frame={level="0",addr="0x100",func="v8::Public<{}>(x)",args=[]}]')
        self.assertEqual(value[0],12);self.assertEqual(value[3]['stack'][0]['frame']['level'],'0')
        self.assertIsNone(d.mi_record(b'~"private-console\\n"'))
        for raw in [b'1^done,a="x",a="y"',b'__import__("os")',b'1^done,stack=[frame=oops]']:
            with self.subTest(raw=raw),self.assertRaises(Exception):d.mi_record(raw)
    def test_public_frame_filter_and_limits(self):
        frames={'stack':[{'frame':{'level':'0','addr':'0x100','func':'v8::Public::Allowed('+SECRET+')'}},
                         {'frame':{'level':'1','addr':'0x99999','func':'v8::'+SECRET}}]}
        value=d.project_frames(frames,lambda pc:pc==256)
        self.assertEqual(value['symbols'],['v8::Public::Allowed']);self.assertNotIn(SECRET,json.dumps(value))
        self.assertNotIn('0x',json.dumps(value));self.assertEqual(value['projectionStopped'],'outside-public-node')
        with self.assertRaises(d.ProjectionStop):d.project_frames({'stack':frames['stack']*7},lambda pc:True)
    def test_one_deadline_no_stage_reset(self):
        debugger=d.OnlineDebugger.__new__(d.OnlineDebugger)
        debugger.deadline=1900;debugger.signal_at=None;debugger.cleanup_limit=None
        self.assertEqual(debugger.current_deadline(),1900)
        debugger.signal_at=1800;self.assertEqual(debugger.current_deadline(),1860)
        debugger.cleanup_limit=1850;self.assertEqual(debugger.current_deadline(),1850)
        debugger.signal_at=1890;self.assertEqual(debugger.current_deadline(),1850)
    def test_aggregate_output_limit_and_no_extra_read(self):
        debugger=d.OnlineDebugger.__new__(d.OnlineDebugger)
        debugger.raw={'stdout':bytearray(b'x'*(d.RAW_LIMIT-4)),'stderr':bytearray()}
        debugger.buffers={'stdout':bytearray(),'stderr':bytearray()}
        debugger.selector=types.SimpleNamespace(select=lambda timeout:[(types.SimpleNamespace(fd=9,data='stderr'),1)])
        with patch.object(d.os,'read',return_value=b'abcd') as read:
            with self.assertRaises(d.OutputStop):debugger.pump(time.monotonic()+1)
        read.assert_called_once_with(9,4)
        self.assertEqual(sum(len(v) for v in debugger.raw.values()),65536)

@unittest.skipUnless(os.name=='posix','Linux管道／selectors替身在专用准备容器运行')
class WorkerTest(unittest.TestCase):
    @contextlib.contextmanager
    def fixture(self,mode):
        with tempfile.TemporaryDirectory() as root:
            root=Path(root);j=c.Journal(root,'a'*32,'11111111-1111-1111-1111-111111111111',transport=False)
            j.bind('b'*32,TARGET);state={'traced':False,'proc':None,'now':1000.0};events={}
            original_record=j.record
            def record(stage,**fields):
                value=original_record(stage,**fields);events.setdefault(stage,threading.Event()).set();return value
            j.record=record
            class FakeProc:
                def __init__(self,*args,**kwargs):
                    self.pid=9999;self.returncode=None;self.commands=[];state['proc']=self
                    out_read,self.out_write=os.pipe();err_read,self.err_write=os.pipe()
                    self.stdout=os.fdopen(out_read,'rb',buffering=0);self.stderr=os.fdopen(err_read,'rb',buffering=0)
                    self.stdin=types.SimpleNamespace(write=self.write,flush=lambda:None,close=lambda:None)
                def send(self,text):os.write(self.out_write,text.encode())
                def write(self,raw):
                    text=raw.decode().strip();match=re.fullmatch(r'(\d+)(-.*)',text);token,command=match.groups();self.commands.append(command)
                    if command.startswith('-target-attach'):
                        if mode=='reject':self.send(token+'^error,msg="Operation not permitted"\n');return
                        state['traced']=True
                        self.send('*stopped,reason="signal-received",signal-name="SIGSTOP",thread-id="1"\n'+token+'^done\n');return
                    if command=='-exec-continue':
                        self.send(token+'^running\n*running,thread-id="all"\n')
                        if mode in ['signal','hang-stack']:
                            self.send('*stopped,reason="signal-received",signal-name="SIGSEGV",thread-id="1",frame={func="'+SECRET+'",args=[]}\n')
                        if mode=='cap':os.write(self.out_write,b'a'*65536)
                        return
                    if command.startswith('-stack-list-frames'):
                        if mode=='hang-stack':return
                        self.send(token+'^done,stack=[frame={level="0",addr="0x100",func="v8::Public::Allowed"},frame={level="1",addr="0x99999",func="'+SECRET+'"}]\n');return
                    if command=='-exec-interrupt':
                        self.send(token+'^done\n*stopped,reason="signal-received",signal-name="SIGINT",thread-id="1"\n');return
                    if command=='-target-detach':
                        if mode=='detach-fails':self.send(token+'^error,msg="fixture detach failed"\n');return
                        state['traced']=False;self.send(token+'^done\n');return
                    if command=='-gdb-exit':
                        state['traced']=False;self.send(token+'^exit\n');self.returncode=0;return
                    self.send(token+'^done\n')
                def poll(self):return self.returncode
                def kill(self):self.returncode=-9;state['traced']=False
            real_path=d.Path
            def fake_path(value):
                if str(value)=='/proc/123/status':return types.SimpleNamespace(read_text=lambda:'TracerPid:\t'+('9999' if state['traced'] else '0')+'\n')
                return real_path(value)
            public=types.SimpleNamespace(public_pc=lambda pc:pc==256)
            with patch.object(d,'PublicNode',return_value=public),patch.object(d,'process_identity',side_effect=lambda pid:TARGET if pid==123 else GDB),\
                 patch.object(d,'binary_hash',return_value=d.NODE_SHA),patch.object(d,'Path',side_effect=fake_path),\
                 patch.object(d.subprocess,'Popen',side_effect=FakeProc),patch.object(d.time,'monotonic',side_effect=lambda:state['now']):
                debugger=d.OnlineDebugger(TARGET,'b'*32,j,root)
                try:yield debugger,j,state,events
                finally:
                    debugger.request_stop.set();debugger.finished.wait(2)
                    if state['proc']:
                        for fd in [state['proc'].out_write,state['proc'].err_write]:
                            try:os.close(fd)
                            except OSError:pass
    def wait_stage(self,events,name):
        until=time.time()+3
        while time.time()<until:
            if events.get(name) and events[name].is_set():return
            threading.Event().wait(.01)
        self.fail('missing fixture stage '+name)
    def test_goal_detach_and_one_attach(self):
        with self.fixture('goal') as (debugger,j,state,events):
            self.wait_stage(events,'debugger-running');result=debugger.finish()
            self.assertEqual(result['status'],'stopped-at-original-boundary');self.assertTrue(result['detachedConfirmed'])
            self.assertTrue(result['untracedAfterDebuggerExit']);self.assertEqual(result['debuggerExitCode'],0)
            self.assertEqual(sum(cmd.startswith('-target-attach') for cmd in state['proc'].commands),1)
            self.assertNotIn(SECRET,json.dumps(result))
    def test_first_signal_single_thread_no_private_frame(self):
        with self.fixture('signal') as (debugger,j,state,events):
            self.assertTrue(debugger.finished.wait(3));result=debugger.result
            self.assertEqual(result['status'],'first-signal-projected');self.assertTrue(result['sigsegv'])
            self.assertEqual(result['symbols'],['v8::Public::Allowed']);self.assertTrue(result['detachedConfirmed'])
            self.assertTrue(j.stop.is_set());self.assertNotIn(SECRET,json.dumps(result))
            commands=state['proc'].commands
            self.assertTrue(any('handle SIGSEGV stop print pass' in v for v in commands))
            self.assertFalse(any('SIGSEGV' in v and ('noprint' in v or 'nostop' in v) for v in commands))
            self.assertEqual(len([v for v in commands if v.startswith('-stack-list-frames')]),1)
            self.assertIn('--thread 1 --no-frame-filters 0 11',next(v for v in commands if v.startswith('-stack-list-frames')))
            self.assertFalse(any('thread apply' in v or 'locals' in v or 'register' in v for v in commands))
    def test_permission_rejection_stops_no_retry(self):
        with self.fixture('reject') as (debugger,j,state,events):
            self.assertTrue(debugger.finished.wait(3));self.assertEqual(debugger.result['status'],'diagnostic-failed')
            self.assertTrue(debugger.result['output']['ptraceRejected']);self.assertTrue(j.stop.is_set())
            self.assertEqual(sum(v.startswith('-target-attach') for v in state['proc'].commands),1)
    def test_detach_failure_forces_vm_stop(self):
        with self.fixture('detach-fails') as (debugger,j,state,events):
            self.wait_stage(events,'debugger-running');result=debugger.finish()
            self.assertTrue(result['forceVmStop']);self.assertFalse(result['detachedConfirmed']);self.assertTrue(j.stop.is_set())
    def test_whole_budget_includes_cleanup_no_reset(self):
        with self.fixture('budget') as (debugger,j,state,events):
            self.wait_stage(events,'debugger-running');state['now']=1890
            self.assertTrue(debugger.finished.wait(3));result=debugger.result
            self.assertEqual(result['errorType'],'BudgetStop');self.assertEqual(result['elapsedSeconds'],890)
            self.assertTrue(result['detachedConfirmed']);self.assertTrue(j.stop.is_set());self.assertEqual(debugger.deadline,1900)
    def test_signal_budget_includes_detach_no_extra_time(self):
        with self.fixture('hang-stack') as (debugger,j,state,events):
            self.wait_stage(events,'debugger-signal');state['now']=1060
            self.assertTrue(debugger.finished.wait(3));self.assertTrue(debugger.result['forceVmStop'])
            self.assertEqual(debugger.result['elapsedSeconds'],60);self.assertTrue(j.stop.is_set())

if __name__=='__main__':unittest.main(verbosity=2)
