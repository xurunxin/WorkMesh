"""仅复制已核缓存，仍不启动VM。"""
from pathlib import Path
import json,subprocess
ROOT=Path(__file__).resolve().parent
ledger=json.loads((ROOT/'resources.json').read_bytes());cache=json.loads((ROOT/'cache-recheck.json').read_bytes())
cid=ledger['containers'][0]['id'];assert ledger['wrapperTestsPassed'] and not (ROOT/'attempt-started.json').exists()
for name,source,target in [('guest',cache['guestPath'],'amd64.img'),('distribution',cache['distributionPath'],'distribution')]:
    result=subprocess.run(['docker','cp',source,cid+':/opt/api-window/'+target],capture_output=True,timeout=180)
    (ROOT/('copy-'+name+'.stdout')).write_bytes(result.stdout);(ROOT/('copy-'+name+'.stderr')).write_bytes(result.stderr)
    ledger['copy-'+name]={'exitCode':result.returncode};result.check_returncode()
ledger['inputsCopiedAndAstChecked']=True
(ROOT/'resources.json').write_text(json.dumps(ledger,ensure_ascii=False,indent=2)+'\n',encoding='utf8')
print(json.dumps({'candidateCopied':True,'vmStarted':False}))
