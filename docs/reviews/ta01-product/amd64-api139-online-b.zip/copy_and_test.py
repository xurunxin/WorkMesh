"""仅复制本次输入并校准包装；不启动VM。"""
from pathlib import Path
import ast,hashlib,json,subprocess
ROOT=Path(__file__).resolve().parent;A=ROOT.parent/'ta01-clock-a-once'
ledger=json.loads((ROOT/'resources.json').read_bytes());cid=ledger['containers'][0]['id']
assert ledger['exactToolsVerified'] and not (ROOT/'attempt-started.json').exists()
test=(A/'clock_evidence_test.py').read_text(encoding='utf8')
test=test.replace("'watcher':None,", "'watcher':None,'debugger':types.SimpleNamespace(finished=threading.Event(),result={'continuedGuestMonotonic':1}),")
test=test.replace('timeout=min(60, remaining)','postCoreGdbOmitted=True')
ast.parse(test);(ROOT/'clock_evidence_test.py').write_text(test,encoding='utf8',newline='\n')
for path in list(ROOT.glob('*.py'))+list((ROOT/'source').glob('*.py')):ast.parse(path.read_text(encoding='utf8'))
def save():(ROOT/'resources.json').write_text(json.dumps(ledger,ensure_ascii=False,indent=2)+'\n',encoding='utf8')
def step(name,args,timeout=120):
    result=subprocess.run(['docker',*args],capture_output=True,timeout=timeout)
    (ROOT/(name+'.stdout')).write_bytes(result.stdout);(ROOT/(name+'.stderr')).write_bytes(result.stderr)
    ledger[name]={'exitCode':result.returncode};save();result.check_returncode();return result.stdout
ledger['calibrationAttempts']=ledger.get('calibrationAttempts',0)+1;save();attempt=ledger['calibrationAttempts']
for name in ['source','input-preflight.json','clock_evidence_test.py','online_debugger_test.py','run_window.py','diagnostic_guest.py',
             'api_identity.py','clock_evidence.py','clock_core_pipe.py','online_debugger.py','public-node-ranges.json']:
    step('copy-'+name.replace('.','-'),['cp',str(ROOT/name),cid+':/opt/api-window/'+name])
for name in ['clock_evidence_test.py','online_debugger_test.py']:
    step('calibration-'+str(attempt)+'-'+name,['exec','-e','PYTHONDONTWRITEBYTECODE=1',cid,'python3','/opt/api-window/'+name],60)
ledger['wrapperTestsPassed']=True;save()
print(json.dumps({'calibrationAttempt':attempt,'testsPassed':True,'vmStarted':False}))
