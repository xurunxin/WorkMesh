"""在独有目录生成本次B诊断副本，保留A和原助手。"""
import ast,hashlib,json,shutil
from pathlib import Path
ROOT=Path(__file__).resolve().parent;A=ROOT.parent/'ta01-clock-a-once'
def read(name):return (A/name).read_text(encoding='utf8')
def put(name,text):
    ast.parse(text);(ROOT/name).write_text(text,encoding='utf8',newline='\n')
def change(text,before,after):
    assert text.count(before)==1,before[:80]
    return text.replace(before,after)
shutil.copyfile(A/'api_identity.py',ROOT/'api_identity.py')
clock=read('clock_evidence.py')
clock=change(clock,"STAGES = {", "STAGES = {'debugger-started','debugger-attached','debugger-running','debugger-signal','debugger-stack','debugger-detaching','debugger-exited',")
clock=change(clock,"EXTRA_KEYS = {", "EXTRA_KEYS = {'debuggerProcess',")
clock=change(clock,"RESULTS = {", "RESULTS = {'late-debugger',")
clock=change(clock,"    if 'target' in value", "    if 'debuggerProcess' in value and not identity_valid(value['debuggerProcess']):raise ClockFailure('clock-debugger-identity')\n    if 'target' in value")
put('clock_evidence.py',clock)
core=read('clock_core_pipe.py')
start=core.index("        result['captureStage'] = 'debugger'")
end=core.index('    except subprocess.TimeoutExpired',start)
core=core[:start]+"        result.update(captureStage='completed-metadata-only',postCoreGdbOmitted=True)\n"+core[end:]
assert "subprocess.run(['gdb'" not in core
put('clock_core_pipe.py',core)
guest=read('diagnostic_guest.py')
guest=change(guest,'from api_identity import select_api','from api_identity import select_api\nfrom online_debugger import OnlineDebugger')
guest=change(guest,"watcher = None", "watcher = None; debugger = None")
guest=change(guest,'    global watcher, events_process, observed_container','    global watcher, debugger, events_process, observed_container')
guest=change(guest,'                clock.bind(watcher.capture_id,watcher.identity)',
             '                clock.bind(watcher.capture_id,watcher.identity)\n                debugger=OnlineDebugger(watcher.identity,watcher.capture_id,clock,BASE)')
guest=change(guest,"    target.update(attempts=1", """    if debugger is None or debugger.finished.is_set() or not debugger.result.get('continuedGuestMonotonic'):
        target['notSentReason']='debugger-not-running-at-original-boundary'
        clock.record('client-skipped',result='late-debugger');clock.stop.set();raise WindowStop()
    target['debuggerAttachedBeforeRequest']=True
    target.update(attempts=1""")
guest=change(guest,'    if watcher:\n        if watcher.result.exists() or not target.get(\'completed\'):',
             "    if debugger:result['onlineDebugger']=debugger.finish()\n    if watcher:\n        if watcher.result.exists() or clock.marker is not None or (debugger and debugger.had_signal):")
guest=change(guest,"'purpose':'only-approved-api-window'", "'purpose':'approved-online-gdb-api-window'")
guest=change(guest,"'fullProductAcceptance':False", "'fullProductAcceptance':False,'diagnosticIntervention':True")
put('diagnostic_guest.py',guest)

host=read('run_window.py')
host=change(host,"'clock_evidence.py':(BASE/'clock_evidence.py').read_bytes(),", "'clock_evidence.py':(BASE/'clock_evidence.py').read_bytes(),\n         **{n:(BASE/n).read_bytes() for n in ['online_debugger.py','public-node-ranges.json']},")
host=change(host,"report['preparationOnly']=True", """report['diagnosticIntervention']=True
report['onlineGdbMaximumSeconds']=900
report['signalToExitMaximumSeconds']=60
report['controller']={'pid':os.getpid(),'startTicks':int(Path(f'/proc/{os.getpid()}/stat').read_text().rsplit(')',1)[1].split()[19]),
                      'beganHostMonotonic':began,'deadlineHostMonotonic':began+limit}
report['preparationOnly']=True""")
host=change(host,"'controllerElapsed':time.monotonic()-began", "'controller':report['controller'],'controllerElapsed':time.monotonic()-began")
put('run_window.py',host)

inputs=['run_window.py','diagnostic_guest.py','api_identity.py','clock_evidence.py','clock_core_pipe.py','online_debugger.py','public-node-ranges.json']
execute=read('execute_once.py').replace('.tmp/ta01-clock-a-once','.tmp/ta01-online-b-once').replace("'window':'new-clock-A'","'window':'online-gdb-B'")
old_list="['run_window.py','diagnostic_guest.py','api_identity.py','clock_evidence.py','clock_core_pipe.py']"
execute=execute.replace(old_list,repr(inputs))
execute=change(execute,"for name in "+repr(inputs)+":ast.parse((ROOT/name).read_text(encoding='utf8'))", "for name in "+repr(inputs)+":\n    if name.endswith('.py'):ast.parse((ROOT/name).read_text(encoding='utf8'))")
execute=change(execute,"    assert hashlib.sha256(actual.stdout).hexdigest()==hashlib.sha256((ROOT/name).read_bytes()).hexdigest()", "    assert hashlib.sha256(actual.stdout).hexdigest()==hashlib.sha256((ROOT/name).read_bytes()).hexdigest()\n    (ROOT/('actual-'+name)).write_bytes(actual.stdout)")
execute=change(execute,"ledger.update(vmLaunchCommandInvoked=True", "ledger.update(hostLauncherPid=__import__('os').getpid(),vmLaunchCommandInvoked=True")
put('execute_once.py',execute)
for name in ['snapshot.py']:
    put(name,read(name).replace('.tmp/ta01-clock-a-once','.tmp/ta01-online-b-once'))
index_path=Path('C:/Users/xurx/.tds/workspaces/01a138ab-2566-7f87-9d06-5b16bebd86c2/.tmp/ta01-resumption/public-node-symbols/symbol-index.json')
raw=index_path.read_bytes();assert hashlib.sha256(raw).hexdigest()=='0e360d773217d9bd4a55ea5bbe4ebdbc05326ec017d2cdcf78606a6f42302399'
index=json.loads(raw);assert index['binarySha256']=='638c77326270093b1251a5e72b4335c94c74856a210460341c73d6f3da647328'
ranges=[]
for start,size,name in sorted(set(tuple(row) for row in index['symbols'])):
    if size<=0:continue
    end=start+size
    if ranges and start<=ranges[-1][1]:ranges[-1][1]=max(ranges[-1][1],end)
    else:ranges.append([start,end])
(ROOT/'public-node-ranges.json').write_text(json.dumps({'nodeBinarySha256':index['binarySha256'],'publicIndexSha256':hashlib.sha256(raw).hexdigest(),
    'source':'原公开STT_FUNC非零范围的并集；只验证公开ELF位置，不提供进程地址或私有符号','ranges':ranges},separators=(',',':')),encoding='utf8')
bindings={'originals':{p.name:hashlib.sha256(p.read_bytes()).hexdigest() for p in (ROOT/'source').glob('*.py')},
          'diagnostic':{n:hashlib.sha256((ROOT/n).read_bytes()).hexdigest() for n in inputs+['execute_once.py']},
          'productSource':'9c8bbff749c1d2a52a3e6489dcec02d2d7c859af','planHead':'1ccb874b8cdd8be3a75fd7518fed19d0baeed992'}
(ROOT/'wrapper-bindings.json').write_text(json.dumps(bindings,indent=2)+'\n',encoding='utf8')
print(json.dumps({'generated':list(bindings['diagnostic']),'publicRangeCount':len(ranges)}))
