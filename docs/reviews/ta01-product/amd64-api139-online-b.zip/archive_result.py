"""归档本次已批B安全原字节，先核原件与准确资源终态。"""
from pathlib import Path
from datetime import datetime,timezone
import ast,hashlib,json,re,subprocess,zipfile
ROOT=Path(__file__).resolve().parent
OUT=Path('docs/reviews/ta01-product/amd64-api139-online-b')
OLD=ROOT.parent/'ta01-resumption/api-crash-window-a-6g-once'
sha=lambda raw:hashlib.sha256(raw).hexdigest()
blob=lambda raw:hashlib.sha1(b'blob '+str(len(raw)).encode()+b'\0'+raw).hexdigest()
ledger=json.loads((ROOT/'resources.json').read_bytes());r=json.loads((ROOT/'result.json').read_bytes())
assert ledger['removedAndAbsent'] and ledger['vmStarted'] and r['oneVmOnly'] and r['maximumSeconds']==9000
assert r['sourceHead']=='9c8bbff749c1d2a52a3e6489dcec02d2d7c859af'
assert r['manifestSha256']=='c34733df5e9d45ac6fddbc504a45540779e252071d55fe22eb9bfbee2744028b'
assert r['qemuBinarySha256']=='8a35ccba41582fc6c38b9df85fc9e35fa1d42f414d2d7d8090ee9b2f5e7c0854'
assert r['actualQemuStart']['qemuPid']==3173 and r['actualQemuStart']['startTicks']==69377091
assert r['actualQemuStart']['controller']==r['controller'] and r['controller']['deadlineHostMonotonic']==702767.6904406
assert r['actualTargetAttempts'] in [0,1,'unknown']
for name,digest in ledger['diagnosticSourceSha256'].items():
    assert sha((ROOT/name).read_bytes())==sha((ROOT/('actual-'+name)).read_bytes())==digest
members={};bindings=[]
for path in sorted(ROOT.iterdir()):
    if path.is_file() and not path.name.startswith('live-') and path.name!='preparation-inspect.stdout':
        assert path.suffix in {'.py','.json','.ndjson','.stdout','.stderr','.txt','.log'},path.name
        members[path.name]=path.read_bytes()
for path in sorted((ROOT/'source').glob('*.py')):
    logical='scripts/server-distribution/'+path.name
    data=subprocess.check_output(['git','show',r['sourceHead']+':'+logical]);assert data==path.read_bytes()
    bindings.append({'path':logical,'sourceHead':r['sourceHead'],'actualGitBlob':subprocess.check_output(['git','rev-parse',r['sourceHead']+':'+logical]).decode().strip(),
                     'bytes':len(data),'sha256':sha(data),'runtimeHandlerArchiveMember':'clock_core_pipe.py' if path.name=='core_pipe.py' else None})
    members['original-source/'+path.name]=data
members['approved-plan-1ccb874b.md']=subprocess.check_output(['git','show','1ccb874b:docs/plan/ta01-self-hosted-deployment/amd64-api139-next-gate.md'])
members['manifest.json']=(OLD/'distribution/manifest.json').read_bytes()
for name,data in members.items():
    assert 0<=len(data)<4*1024*1024,name
    assert not re.search(rb'wm[ips]_[A-Za-z0-9_-]{43}|-----BEGIN (?:RSA |EC |OPENSSH )?PRIVATE KEY-----',data),name
    assert not data.startswith(b'\x7fELF') and not name.endswith(('.img','.qcow2','.core')),name
    if name.endswith('.py'):ast.parse(data)
with zipfile.ZipFile(OUT.with_suffix('.zip'),'x',zipfile.ZIP_DEFLATED) as archive:
    for name,data in members.items():archive.writestr(name,data)
with zipfile.ZipFile(OUT.with_suffix('.zip')) as archive:
    assert archive.testzip() is None and set(archive.namelist())==set(members)
    for name,data in members.items():assert archive.read(name)==data
raw=OUT.with_suffix('.zip').read_bytes()
index={'observedUtc':datetime.now(timezone.utc).isoformat(),'source':'用户16:13批准、22:03要求继续的唯一B在线API取证；保留调试干预，不作产品通过或139闭合',
    'branch':'tds/conv-01a1572a-7aeb-7b6d-b7e8-83e89c2b723d','baseHead':'1ccb874b8cdd8be3a75fd7518fed19d0baeed992',
    'interruptionCheckpoint':'70a099896a1193f58b5fd2fc26af4e3943c8d4b0','productSourceHead':r['sourceHead'],
    'authorization':json.loads((ROOT/'authorization.json').read_bytes()),'sourceBindings':bindings,'runtimeInputs':ledger['diagnosticSourceSha256'],
    'runtimeSeedBindings':r['scripts'],'diagnosticIntervention':True,'result':r,
    'outer':{'containerId':ledger['containers'][0]['id'],'owner':ledger['owner'],'memoryBytes':6442450944,'memorySwapTotalBytes':6442450944,'cpuQuota':4,
        'lifetimeMemoryPeakBytes':int((ROOT/'outer-memory.peak.txt').read_text()),'memoryEvents':(ROOT/'outer-memory.events.txt').read_text(),
        'capacityBeforeLaunch':json.loads((ROOT/'capacity-before-launch.json').read_bytes()),'beforeStop':ledger['beforeStop'],'afterStop':ledger.get('afterStop'),
        'eventBoundary':'峰值含准备／复制／校准和VM；不是纯QEMU RSS，事件保留窗口不代缺失原件','hostLauncherExitCode':ledger['runnerExitCode']},
    'cleanup':json.loads((ROOT/'cleanup-verification.json').read_bytes()),'analysis':json.loads((ROOT/'analysis.json').read_bytes()),
    'privateCoreMemorySecretsRawGdbOrDiskArchived':False,'noAdditionalRunMcpOrMatrix':True,
    'p1State':{'p1-1':'已正式复审闭合','api139':'未闭','mcp139':'未闭'},'selectedZipSha256':sha(raw),'archiveBytes':len(raw),
    'expectedUnfilteredZipGitBlob':blob(raw),'byteBoundary':'ZIP -text；提交后再核实际Git ZIP blob。JSON本地CRLF与Git LF分别核算。',
    'members':{name:{'bytes':len(data),'sha256':sha(data),'rawUnfilteredBlobId':blob(data)} for name,data in members.items()}}
OUT.with_suffix('.json').write_text(json.dumps(index,ensure_ascii=False,indent=2)+'\n',encoding='utf8')
print(json.dumps({'members':len(members),'zipBytes':len(raw),'zipSha256':sha(raw),'expectedZipGitBlob':blob(raw),'targetAttempts':r['actualTargetAttempts']}))
