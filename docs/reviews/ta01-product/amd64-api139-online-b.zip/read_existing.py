"""只读接续同台B身份／原截止，绝不调用启动包装。"""
from pathlib import Path
from datetime import datetime,timezone
import json,subprocess
ROOT=Path(__file__).resolve().parent
ledger=json.loads((ROOT/'resources.json').read_bytes());cid=ledger['containers'][0]['id']
def call(args):return subprocess.run(['docker',*args],capture_output=True,timeout=30)
inspect=call(['inspect',cid])
if inspect.returncode:
    print(json.dumps({'absent':True,'removedAndAbsent':ledger.get('removedAndAbsent'),'terminal':ledger.get('vmResult')}));raise SystemExit()
info=json.loads(inspect.stdout)[0]
assert info['Id']==cid and info['Config']['Labels'][ledger['label']]==ledger['owner'] and not info['Mounts']
program="""from pathlib import Path
import hashlib,json,time
root=Path('/opt/api-window/guest');start=json.loads((root/'qemu-started.json').read_bytes());controller=start['controller']
value={'qemu':{k:start[k] for k in ['qemuPid','startTicks','qemuStartedUtc']},'controller':controller,'finalAvailable':root.joinpath('result.json').exists()}
for label,pid,ticks in [('qemu',start['qemuPid'],start['startTicks']),('controller',controller['pid'],controller['startTicks'])]:
    path=Path('/proc')/str(pid)
    try:
        actual=int(path.joinpath('stat').read_text().rsplit(')',1)[1].split()[19]);value[label+'SameProcessActive']=actual==ticks
    except (OSError,ValueError):value[label+'SameProcessActive']=False
value['observedOuterMonotonic']=time.monotonic();value['originalWindowRemainingSeconds']=max(0,controller['deadlineHostMonotonic']-time.monotonic())
value['controllerSourceSha256']=hashlib.sha256(Path('/opt/api-window/run_window.py').read_bytes()).hexdigest()
if value['finalAvailable']:
    final=json.loads(root.joinpath('result.json').read_bytes());value['terminal']={k:final.get(k) for k in ['status','totalSeconds','qemuExitCode','actualTargetAttempts']}
print(json.dumps(value))"""
result=call(['exec',cid,'python3','-c',program]);result.check_returncode();value=json.loads(result.stdout)
assert value['controllerSourceSha256']==ledger['diagnosticSourceSha256']['run_window.py']
value.update(observedUtc=datetime.now(timezone.utc).isoformat(),containerId=cid,owner=ledger['owner'],noNewVmOrBudgetReset=True)
with (ROOT/'external-state.ndjson').open('a',encoding='utf8') as out:out.write(json.dumps(value,ensure_ascii=False)+'\n')
print(json.dumps(value))
