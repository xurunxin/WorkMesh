"""新A的独有准备容器；不启动QEMU。"""
from pathlib import Path
from datetime import datetime,timezone
import ast, hashlib, json, shutil, subprocess, uuid

ROOT=Path(__file__).resolve().parent
OLD=ROOT.parent/'ta01-resumption/api-crash-window-a-6g-once'
OLD_TREE=Path('C:/Users/xurx/.tds/workspaces/01a138ab-2566-7f87-9d06-5b16bebd86c2')
IMAGE='sha256:534baea6a22c03a63003dbc8dbe78fe34bc0d7e595d9a9dc9834884ff530eb55'
LABEL='io.workmesh.ta01.api-window.owner'
def now():return datetime.now(timezone.utc).isoformat()
def sha(path):
    with path.open('rb') as stream:return hashlib.file_digest(stream,'sha256').hexdigest()
def write(name,value):(ROOT/name).write_text(json.dumps(value,ensure_ascii=False,indent=2)+'\n',encoding='utf8')
def call(args,timeout=60):return subprocess.run(['docker',*args],capture_output=True,timeout=timeout,check=True).stdout
assert not (ROOT/'resources.json').exists() and not (ROOT/'attempt-started.json').exists()
assert not call(['ps','-aq','--no-trunc','--filter','label='+LABEL]).strip()
image=json.loads(call(['image','inspect',IMAGE]))[0]
assert image['Id']==IMAGE and image['Architecture']=='amd64' and not image['Config'].get('Volumes')
expected=json.loads((OLD/'input-preflight.json').read_bytes())
for name,digest in expected['scripts'].items():assert sha(ROOT/'source'/name)==digest
distribution=OLD/'distribution';manifest=json.loads((distribution/'manifest.json').read_bytes())
assert sha(distribution/'manifest.json')==expected['manifestSha256']
entries={x['path']:x for x in manifest['files']+manifest['chunks']+manifest['bootstrapChunks']}
for name,entry in entries.items():assert sha(distribution/name)==entry['sha256'] and (distribution/name).stat().st_size==entry['bytes']
guest=OLD_TREE/'.tmp/ta01-resumption/local-guest-image-cache/amd64-6a81c375.img'
assert sha(guest)=='6a81c37564db9b1ee84e141922625e1d7c5b389b99bb3c572e0243607d5bb4d2'
raw=OLD_TREE/'.tmp/ta01-resumption/api-crash-window-a/candidate.zip'
assert sha(raw)==expected['rawZipSha256']
disk=shutil.disk_usage(ROOT)
assert disk.free>=15*1024**3
for path in list(ROOT.glob('*.py'))+list((ROOT/'source').glob('*.py')):ast.parse(path.read_text(encoding='utf8'))
owner=str(uuid.uuid4())
authorization={'observedUtc':now(),'answer':'执行在线调试（推荐）','source':'用户2026-10-20 16:13对Chief具体问题选择在线调试，22:03要求继续；本轮完整Spec及反馈确认。未给卡ID，不编造',
    'planHead':'1ccb874b8cdd8be3a75fd7518fed19d0baeed992',
    'planBlob':subprocess.check_output(['git','rev-parse','1ccb874b:docs/plan/ta01-self-hosted-deployment/amd64-api139-next-gate.md']).decode().strip(),
    'oneNewVmOnly':True,'previous6GiBConsumed':True,'noMcpMatrixOrAdditionalWindow':True,
    'limits':{'outerCpu':4,'outerMemoryBytes':6442450944,'outerMemorySwapTotalBytes':6442450944,
              'guestCpu':4,'guestMemoryMiB':4096,'guestDiskGiB':40,'windowSeconds':9000,
              'installSeconds':1800,'healthSeconds':180,'identityHttpSeconds':90,'businessSeconds':30,
              'coreBytes':536870912,'handlerSeconds':90,'gdbTotalSeconds':900,'signalToExitSeconds':60,'rawGdbBytes':65536,'newRecords':32,'recordBytes':4096}}
write('authorization.json',authorization)
expected.update(approval=authorization['answer'],guestNotStarted=True,previousStaticProof='复用上次准确候选，重新逐字核31成员和原ZIP；在线GDB及同钟包装另列')
write('input-preflight.json',expected)
write('cache-recheck.json',{'guestPath':str(guest),'guestSha256':sha(guest),'candidatePath':str(raw),'candidateSha256':sha(raw),
                            'distributionPath':str(distribution),'verifiedMembers':len(entries),'hostDiskFreeBytes':disk.free})
ledger={'owner':owner,'label':LABEL,'imageId':IMAGE,'createdAt':now(),'vmStarted':False,'hostInstall':False,
        'containers':[],'outerMemoryBytes':6442450944,'outerMemorySwapTotalBytes':6442450944,'outerCpuQuota':4,
        'approvalAnswer':authorization['answer'],'vmLimitSeconds':9000}
write('resources.json',ledger)
args=['run','-d','--name','ta01-online-b-'+owner[:8],'--label',LABEL+'='+owner,
      '--cpus','4','--memory','6g','--memory-swap','6g',IMAGE,'sleep','infinity']
cid=call(args).decode().strip();ledger['containers']=[{'id':cid}];ledger['createCommand']=['docker',*args];write('resources.json',ledger)
info=json.loads(call(['inspect',cid]))[0]
assert info['Id']==cid and info['Config']['Labels'][LABEL]==owner and not info['Mounts']
assert not info['HostConfig']['Devices'] and not info['HostConfig']['Privileged'] and not info['HostConfig']['PortBindings']
assert info['HostConfig']['Memory']==info['HostConfig']['MemorySwap']==6442450944 and info['HostConfig']['NanoCpus']==4000000000
ledger['boundaryVerified']=True;write('resources.json',ledger)
print(json.dumps({'containerId':cid,'owner':owner,'vmStarted':False}))
