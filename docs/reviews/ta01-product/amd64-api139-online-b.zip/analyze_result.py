"""核同次B预算与安全回执一致性；不以无故障样本关闭139。"""
from pathlib import Path
from datetime import datetime,timezone
import json
from clock_evidence import validate_record
ROOT=Path(__file__).resolve().parent
r=json.loads((ROOT/'result.json').read_bytes());f=r['final'];debugger=f['onlineDebugger'];clock=f['clockEvidence'];rows=clock['records']
assert r['status']=='sample-completed' and r['qemuExitCode']==0 and not r.get('deadlineReached') and r['totalSeconds']<9000
assert r['actualTargetAttempts']==f['target']['attempts']==1 and f['target']['httpStatus']==200
assert f['target']['debuggerAttachedBeforeRequest'] and f['installActions']==8
assert debugger['totalMaximumSeconds']==900 and debugger['signalMaximumSeconds']==60
assert debugger['status']=='stopped-at-original-boundary' and debugger['diagnosticIntervention']
assert debugger['detachedConfirmed'] and debugger['untracedAfterDebuggerExit'] and debugger['debuggerExitCode']==0
assert debugger['elapsedSeconds']<900 and not debugger.get('totalBudgetExceeded') and not debugger.get('signalBudgetExceeded')
assert not debugger.get('forceVmStop') and not debugger.get('sigsegv')
assert not debugger['rawOutputPersisted'] and not debugger['postCoreGdbAllowed']
assert abs(debugger['elapsedSeconds']-(debugger['finishedGuestMonotonic']-debugger['startedGuestMonotonic']))<.01
assert debugger['continuedGuestMonotonic']<f['target']['startedGuestMonotonic']<f['target']['finishedGuestMonotonic']<debugger['finishedGuestMonotonic']
assert debugger['output']['stdoutBytes']+debugger['output']['stderrBytes']<65536
assert clock['firstFailure'] is None and not clock['projectionError'] and not clock['transportError']
assert clock['recordsSent']==len(rows)==14 and clock['pendingTransport']==0
assert [v['sequence'] for v in rows]==list(range(1,15)) and len({v['bootId'] for v in rows})==1
assert all(rows[i]['guestMonotonic']<=rows[i+1]['guestMonotonic'] for i in range(13))
for value in rows:
    validate_record(value)
    if value['sequence']>1:
        assert value['target']==f['observer']['registeredIdentity'] and value['captureId']==f['observer']['captureId']
receipts=[json.loads(v) for v in (ROOT/'receipts.ndjson').read_bytes().splitlines()]
assert rows==[{k:v for k,v in row.items() if k not in ['hostUtc','hostElapsed']} for row in receipts if row.get('kind')=='clock']
assert not f['nativeTrace']['coreObserved'] and f['postTargetNodeSha256']=='638c77326270093b1251a5e72b4335c94c74856a210460341c73d6f3da647328'
assert f['observedApiState']=={'Running':True,'ExitCode':0,'OOMKilled':False,'RestartCount':0}
assert not f['containerEvents']['events'] and not f['containerEvents']['truncated']
events=dict(line.split() for line in (ROOT/'outer-memory.events.txt').read_text().splitlines())
assert all(int(events[name])==0 for name in ['max','oom','oom_kill','oom_group_kill'])
value={'observedUtc':datetime.now(timezone.utc).isoformat(),'scope':'仅同次既有安全原件一致性核验，不运行产品／GDB／VM或新窗口',
    'window':{'seconds':r['totalSeconds'],'maximumSeconds':9000,'qemuExitCode':0,'qmp':r['qmpEvents'],'targetAttempts':1},
    'debuggerBudget':{'startedGuestMonotonic':debugger['startedGuestMonotonic'],'originalDeadlineGuestMonotonic':debugger['startedGuestMonotonic']+900,
        'finishedGuestMonotonic':debugger['finishedGuestMonotonic'],'elapsedSeconds':debugger['elapsedSeconds'],'signalBudgetNotExercised':True,
        'sameContinuousClock':True,'noReset':True,'detachConfirmed':True,'untracedAfterExit':True,'exitCode':0},
    'timeline':[{'stage':v['stage'],'guestMonotonic':v['guestMonotonic']} for v in rows],
    'recordCount':14,'maximumClockRecordBytes':max(len(json.dumps(v,separators=(',',':')).encode()) for v in receipts if v.get('kind')=='clock'),
    'debuggerOutput':debugger['output'],'outputBoundary':'输出为捕获部分摘要；eofStreams为空，原文未持久化，不能重建或冒完整日志',
    'causalConclusion':'本次无可见SIGSEGV、首败或core；没有取得故障线程栈，不能补旧API139/MCP139因果或关闭P1-2',
    'intervention':'真实在线附加、目标停止与继续；HTTP200及A/B耗时差不代普通产品通过或因果比较',
    'namespaceWarning':'安全分类namespaceMismatch保留；准确身份、TracerPid检查及detach原件分别核，不据警告认定根因',
    'hostLauncherExit':'checkpoint后原工具会话失联；原宿主runner退出码未知，不拿QEMU0填runner0',
    'noNewRunOrPrivateExport':True}
(ROOT/'analysis.json').write_text(json.dumps(value,ensure_ascii=False,indent=2)+'\n',encoding='utf8')
print(json.dumps({'checks':'passed','records':14,'debuggerSeconds':debugger['elapsedSeconds'],'clientMilliseconds':f['target']['elapsedMilliseconds'],
                  'clockMaximumBytes':value['maximumClockRecordBytes']}))
