"""仅诊断包装替身验证；不启动VM，不调用产品或真实身份接口。"""
import ast, hashlib, io, json, os, subprocess, tempfile, threading, time, types, unittest
from pathlib import Path
from unittest.mock import patch
import clock_evidence as c

ROOT=Path(__file__).resolve().parent
NONCE='a'*32;BOOT='11111111-1111-1111-1111-111111111111';CAPTURE='b'*32
IDENTITY={'pid':123,'startTicks':456,'executableDevice':1,'executableInode':2,'executableBytes':3}

class ClockTest(unittest.TestCase):
    def test_driver_skips_after_first_failure_and_never_retries(self):
        tree=ast.parse((ROOT/'diagnostic_guest.py').read_text(encoding='utf8'))
        request=next(n for n in tree.body if isinstance(n,ast.FunctionDef) and n.name=='request')
        class Stop(BaseException):pass
        for early in [True,False]:
            with self.subTest(early=early),tempfile.TemporaryDirectory() as root:
                root=Path(root);j=c.Journal(root,NONCE,BOOT,transport=False);j.bind(CAPTURE,IDENTITY)
                if early:c.write_first_marker(root/'clock-first-failure.json',NONCE,BOOT,CAPTURE,IDENTITY,time.monotonic())
                calls=[];body={'fixture':'private-sentinel'};headers={'Idempotency-Key':'fixed-private-value'}
                def original(self,url,received,**kwargs):
                    calls.append((url,received,kwargs));return {},200,None
                target={'attempts':0}
                ns={'g':types.SimpleNamespace(install_actions=8),'target':target,'clock':j,'observer':{'registered':True},
                    'watcher':None,'debugger':types.SimpleNamespace(finished=threading.Event(),result={'continuedGuestMonotonic':1}),'WindowStop':Stop,'time':time,'hashlib':hashlib,'os':os,
                    'original_request':original,'emit':lambda *args,**kwargs:None,'error_name_from_target':lambda:'OtherError'}
                exec(compile(ast.fix_missing_locations(ast.Module(body=[request],type_ignores=[])),'<driver-fixture>','exec'),ns)
                with self.assertRaises(Stop):ns['request'](None,'https://fixture/api/v1/auth/install',body,headers=headers)
                self.assertEqual(len(calls),0 if early else 1)
                self.assertEqual(target['attempts'],0 if early else 1)
                if not early:
                    self.assertIs(calls[0][1],body);self.assertIs(calls[0][2]['headers'],headers)
                    self.assertEqual([r['stage'] for r in j.rows],['client-intent','client-finished'])
                    with self.assertRaises(AssertionError):ns['request'](None,'https://fixture/api/v1/auth/install',body)
                self.assertNotIn('private-sentinel',json.dumps(j.rows))

    def test_identity_first_marker_and_rate(self):
        with tempfile.TemporaryDirectory() as root:
            root=Path(root);j=c.Journal(root,NONCE,BOOT,transport=False);j.bind(CAPTURE,IDENTITY)
            self.assertIsNone(j.poll_marker(now=1))
            c.write_first_marker(root/'clock-first-failure.json',NONCE,BOOT,CAPTURE,IDENTITY,2)
            self.assertIsNone(j.poll_marker(now=1.5))
            marker=j.poll_marker(now=2)
            self.assertEqual(marker['target'],IDENTITY);self.assertTrue(j.stop.is_set())
            self.assertEqual(j.rows[0]['stage'],'marker-observed')
            original=(root/'clock-first-failure.json').read_bytes()
            with self.assertRaises(FileExistsError):c.write_first_marker(root/'clock-first-failure.json',NONCE,BOOT,CAPTURE,IDENTITY,3)
            self.assertEqual(original,(root/'clock-first-failure.json').read_bytes())

    def test_wrong_owner_boot_nonce_fail_closed(self):
        for field,replacement in [('bootId','22222222-2222-2222-2222-222222222222'),('nonce','c'*32),('captureId','d'*32),('target',{**IDENTITY,'pid':124})]:
            with self.subTest(field=field),tempfile.TemporaryDirectory() as root:
                root=Path(root);j=c.Journal(root,NONCE,BOOT,transport=False);j.bind(CAPTURE,IDENTITY)
                c.write_first_marker(root/'clock-first-failure.json',NONCE,BOOT,CAPTURE,IDENTITY,2)
                value=json.loads((root/'clock-first-failure.json').read_bytes());value[field]=replacement
                (root/'clock-first-failure.json').write_text(json.dumps(value))
                with self.assertRaises(c.ClockFailure):j.poll_marker(now=2)
                self.assertTrue(j.stop.is_set());self.assertIsNone(j.marker)

    def test_projection_limits_and_private_field_rejected(self):
        with tempfile.TemporaryDirectory() as root:
            j=c.Journal(Path(root),NONCE,BOOT,transport=False)
            for _ in range(c.MAX_RECORDS):self.assertLess(len(c.validate_record(j.record('clock-driver-started'))),4096)
            with self.assertRaises(c.ClockFailure):j.record('clock-driver-started')
            self.assertTrue(j.stop.is_set());self.assertEqual(len(j.rows),31)
            value={**j.rows[0],'body':'private-sentinel'}
            with self.assertRaises(c.ClockFailure):c.validate_record(value)
            value={**j.rows[0],'guestMonotonic':float('nan')}
            with self.assertRaises(c.ClockFailure):c.validate_record(value)

    def test_prefix_cancel_and_timeout(self):
        if os.name!='posix':self.skipTest('仅Linux进程组；在准备容器执行')
        class Stop(BaseException):pass
        with tempfile.TemporaryDirectory() as root:
            root=Path(root);script=root/'install.sh';script.write_text('sleep 30\n')
            j=c.Journal(root,NONCE,BOOT,transport=False);runner=c.PrefixRunner(j,Stop,lambda:7)
            timer=threading.Timer(.2,j.stop.set);timer.start();began=time.monotonic()
            with self.assertRaises(Stop):runner.run(['sh',str(script)],input=None,capture_output=True,timeout=10)
            timer.join();self.assertLess(time.monotonic()-began,3)
            self.assertEqual([r['stage'] for r in j.rows],['prefix-cancel-intent','prefix-cancel-finished'])
        with tempfile.TemporaryDirectory() as root:
            root=Path(root);script=root/'install.sh';script.write_text('sleep 30\n')
            j=c.Journal(root,NONCE,BOOT,transport=False);runner=c.PrefixRunner(j,Stop,lambda:7);began=time.monotonic()
            with self.assertRaises(subprocess.TimeoutExpired):runner.run(['sh',str(script)],input=None,capture_output=True,timeout=.3)
            self.assertLess(time.monotonic()-began,2)

    def test_proxy_payload_headers_and_stage_boundaries(self):
        source=(ROOT/'source/guest.py').read_text()
        def run(instrumented):
            received=[];stages=[];holder={}
            class Progress:
                def begin(self):return None
                def update(self,*args):pass
                def failure(self,*args):pass
            class Server:
                def __init__(self,address,handler):holder['handler']=handler;self.socket=None
                def serve_forever(self):pass
            class Context:
                def __init__(self,*args):pass
                def load_cert_chain(self,*args):pass
                def wrap_socket(self,*args,**kwargs):return None
            class Response:
                status=201
                def read(self):return b'{"safe-fixture":true}'
                def getheaders(self):return [('Content-Type','application/json'),('Set-Cookie','private-response')]
            class Backend:
                def __init__(self,*args,**kwargs):self.assert_timeout=kwargs['timeout'];assert self.assert_timeout==90
                def request(self,*args):received.append(args)
                def getresponse(self):return Response()
                def close(self):pass
            ns={'BaseHTTPRequestHandler':object,'McpProxyProgress':Progress,'ThreadingHTTPServer':Server,
                'ssl':types.SimpleNamespace(SSLContext=Context,PROTOCOL_TLS_SERVER=1),'threading':threading,
                'http':types.SimpleNamespace(client=types.SimpleNamespace(HTTPConnection=Backend))}
            if instrumented:
                c.instrument_proxy(source,ns,lambda method,path:1 if (method,path)==('POST','/api/v1/auth/install') else None,
                    lambda token,stage,status=None:stages.append((stage,status)) if token is not None else None,
                    lambda *args:self.fail('unexpected proxy error'))
            else:
                proxy=next(n for n in ast.parse(source).body if isinstance(n,ast.FunctionDef) and n.name=='proxy')
                exec(compile(ast.fix_missing_locations(ast.Module(body=[proxy],type_ignores=[])),'<original-proxy>','exec'),ns)
            ns['proxy'](443,8080,Path('/fixture'))
            handler=holder['handler']();handler.command='POST';handler.path='/api/v1/auth/install'
            handler.rfile=io.BytesIO(b'private-body');handler.wfile=io.BytesIO()
            handler.headers={'content-length':'12','Authorization':'private-header','connection':'close'}
            handler.client_address=('127.0.0.1',1)
            handler.send_response=lambda *args:None;handler.send_header=lambda *args:None;handler.end_headers=lambda:None
            handler.forward_request(None)
            return received,handler.wfile.getvalue(),stages
        before=run(False);after=run(True)
        self.assertEqual(before[:2],after[:2])
        self.assertEqual([r[0] for r in after[2]],['proxy-forward-intent','proxy-request-sent','proxy-upstream-headers','proxy-upstream-complete','proxy-client-complete'])

    def test_handler_marker_before_core_without_reading_core(self):
        if os.name!='posix':self.skipTest('仅Linux handler固定路径替身')
        tree=ast.parse((ROOT/'clock_core_pipe.py').read_text())
        main=next(n for n in tree.body if isinstance(n,ast.FunctionDef) and n.name=='main')
        with tempfile.TemporaryDirectory() as root:
            root=Path(root);owner=root/('owner-'+CAPTURE+'.json');owner.write_text(json.dumps(IDENTITY))
            marker=root/'marker.json';order=[]
            def write(*args):
                order.append('marker');c.write_first_marker(marker,*args[1:])
            def memory(_):
                order.append('memory-core');self.assertTrue(marker.exists());raise ValueError('fixture stop before private read')
            class FakePath:
                def __new__(cls,value):
                    if value=='/opt/server-install/window.json':return root/'window.json'
                    if value=='/root/server-install/clock-first-failure.json':return marker
                    return Path(value)
            (root/'window.json').write_text(json.dumps({'nonce':NONCE}))
            import signal,re,sys
            ns={'time':time,'Path':FakePath,'sys':types.SimpleNamespace(argv=['handler','123',CAPTURE],stdin=types.SimpleNamespace(buffer=None)),
                're':re,'OWNER':root/'owner.json','RESULT':root/'result.json','json':json,'signal':signal,'os':os,
                'process_identity':lambda pid:IDENTITY,'binary_hash':lambda pid:'e'*64,'write_first_marker':write,
                'memory_core':memory,'subprocess':subprocess}
            exec(compile(ast.fix_missing_locations(ast.Module(body=[main],type_ignores=[])),'<handler-fixture>','exec'),ns)
            ns['main']();self.assertEqual(order,['marker','memory-core'])
            value=json.loads((root/('result-'+CAPTURE+'.json')).read_bytes())
            self.assertFalse(value['coreCaptured']);self.assertEqual(value['captureErrorType'],'ValueError')
        text=(ROOT/'clock_core_pipe.py').read_text()
        for exact in ['signal.alarm(90)','postCoreGdbOmitted=True','MAX_BYTES = 512 * 1024 * 1024','os.close(descriptor)']:self.assertIn(exact,text)

if __name__=='__main__':unittest.main(verbosity=2)
