import hashlib
import json
from pathlib import Path
import re
import subprocess
import zipfile

sha = lambda data: hashlib.sha256(data).hexdigest()
head = 'ac0a4d21deba15a23c8c7b40f671b59c41f30f37'
results = {}
for arch, artifact, candidate in [('amd64', 12026480230, 12026048774), ('arm64', 12025533796, 12025743289)]:
    target = Path(f'.tmp/ta01-resumption/ci565-build-{arch}-raw.zip')
    with target.open('xb') as output:
        downloaded = subprocess.run(['gh', 'api', f'repos/xurunxin/WorkMesh/actions/artifacts/{artifact}/zip'], stdout=output, stderr=subprocess.PIPE)
    assert downloaded.returncode == 0, 'artifact download failed; stderr withheld'
    with zipfile.ZipFile(target) as archive:
        manifest = archive.read('server-build/manifest.json')
        value = json.loads(manifest)
        source = archive.read('server-build/source.txt').decode().split()
        assert source[0] == head
        assert value['source']['commit'] == head
        assert value['source']['tree'] == source[1]
        assert b'Ran 55 tests' in archive.read('server-build/native-privacy.log')
        assert b'# pass 16' in archive.read('server-build/unit.log')
        verified = {}
        for digest, name in re.findall(r'^([a-f0-9]{64})  scripts/server-distribution/([^\s]+\.py)$', archive.read('server-build/input-sha256.txt').decode(), re.M):
            assert '/' not in name and '\\' not in name
            assert sha(subprocess.check_output(['git', 'show', head + ':scripts/server-distribution/' + name])) == digest
            verified[name] = digest
        assert len(verified) == 6
        results[arch] = {'producerRawArtifact': artifact, 'candidateArtifact': candidate,
            'head': source[0], 'tree': source[1], 'manifestSha256': sha(manifest),
            'rawZipSha256': sha(target.read_bytes()), 'sourceFilesMatch': True,
            'manifestKeys': sorted(value), 'source': value.get('source'), 'images': sorted(value['images'])}
with Path('.tmp/ta01-resumption/ci565-producer-projection.json').open('x', encoding='utf8') as output:
    json.dump(results, output, indent=2)
print(json.dumps(results, indent=2))
