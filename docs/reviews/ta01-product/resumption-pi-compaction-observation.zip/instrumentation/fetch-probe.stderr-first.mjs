import { createHash } from 'node:crypto'

const original = globalThis.fetch
const codes = new Set(['ENOBUFS', 'EADDRINUSE', 'EADDRNOTAVAIL', 'ECONNREFUSED', 'ECONNRESET', 'EPIPE', 'ETIMEDOUT',
  'ENOTFOUND', 'UND_ERR_SOCKET', 'UND_ERR_CONNECT_TIMEOUT', 'UND_ERR_HEADERS_TIMEOUT', 'UND_ERR_BODY_TIMEOUT',
  'ERR_TLS_CERT_ALTNAME_INVALID', 'CERT_HAS_EXPIRED', 'UNABLE_TO_VERIFY_LEAF_SIGNATURE', 'DEPTH_ZERO_SELF_SIGNED_CERT',
  'UNABLE_TO_GET_ISSUER_CERT_LOCALLY', 'ABORT_ERR'])
const types = new Set(['Error', 'TypeError', 'AggregateError', 'AbortError', 'TimeoutError', 'DOMException'])
globalThis.fetch = function (input, init) {
  let observed = false
  try {
    const url = input instanceof URL ? input : new URL(typeof input === 'string' ? input : input.url)
    observed = url.protocol === 'https:' && ['127.0.0.1', 'localhost', '[::1]'].includes(url.hostname)
  } catch { /* Only observation selection; the original fetch validates input. */ }
  const began = performance.now()
  const pending = Reflect.apply(original, this, [input, init])
  if (!observed) return pending
  return pending.then(response => {
    console.error(JSON.stringify({ ta01Fetch: { state: 'response', status: response.status,
      elapsedMilliseconds: Math.round(performance.now() - began) } }))
    return response
  }, error => {
    const queue = [error], seen = new Set(), names = new Set(), known = new Set()
    while (queue.length && seen.size < 16) {
      const value = queue.shift()
      if (!value || typeof value !== 'object' || seen.has(value)) continue
      seen.add(value)
      if (types.has(value.name)) names.add(value.name)
      if (codes.has(value.code)) known.add(value.code)
      if (value.cause) queue.push(value.cause)
      if (Array.isArray(value.errors)) queue.push(...value.errors.slice(0, 8))
    }
    console.error(JSON.stringify({ ta01Fetch: { state: 'rejected', errorTypes: [...names], errorCodes: [...known],
      messageSha256: createHash('sha256').update(error instanceof Error ? error.message : 'unknown').digest('hex'),
      elapsedMilliseconds: Math.round(performance.now() - began) } }))
    throw error
  })
}
