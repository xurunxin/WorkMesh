from pathlib import Path
import hashlib
import json
import subprocess

root = Path.cwd().resolve()
folder = root / '.tmp/ta01-resumption/pi-transport-instrumentation'
binding = json.loads((folder / 'binding.json').read_text(encoding='utf8'))
assert binding['file'] == 'packages/conformance/src/planning-collaboration.fixture.ts'
target = root / binding['file']
assert target.resolve() == root / binding['file'] and not target.is_symlink()
assert hashlib.sha256(target.read_bytes()).hexdigest() == binding['instrumentedSha256']
original = (folder / 'original-fixture.ts').read_bytes()
assert hashlib.sha256(original).hexdigest() == binding['originalSha256']
target.write_bytes(original)
assert hashlib.sha256(target.read_bytes()).hexdigest() == binding['originalSha256']
unchanged = subprocess.run(['git', 'diff', '--quiet', '--', binding['file']]).returncode == 0
assert unchanged
(folder / 'restored.json').write_text(json.dumps({'file': binding['file'], 'sha256': binding['originalSha256'],
    'originalBytesRestored': True, 'gitDiffEmpty': unchanged}, indent=2) + '\n', encoding='utf8')
print(json.dumps({'originalBytesRestored': True, 'gitDiffEmpty': unchanged}))
