from pathlib import Path
import hashlib
import json
import subprocess

root = Path.cwd().resolve()
out = root / '.tmp/ta01-resumption/pi-transport-instrumentation'
out.mkdir(exist_ok=False)
file = root / 'packages/conformance/src/planning-collaboration.fixture.ts'
original = file.read_bytes()
git = subprocess.check_output(['git', 'show', '38a8923e267ff60b9b3aaf2df6c9f6f23a2e8428:packages/conformance/src/planning-collaboration.fixture.ts'])
assert original.replace(b'\r\n', b'\n') == git
(out / 'original-fixture.ts').write_bytes(original)
text = original.decode('utf8').replace('\r\n', '\n')
text = text.replace("import { randomUUID } from 'node:crypto'", "import { randomUUID, createHash } from 'node:crypto'", 1)
anchor = '    const captures: Array<{ tools: string[]; results: string[]; messages: string; call: ModelCall | null }> = []\n'
assert text.count(anchor) == 1
injection = '''    const diagnosticId = randomUUID(), diagnosticBegan = performance.now()
    const modelTransport: Array<Record<string, unknown>> = []
    const observeModel = (stage: string, fields: Record<string, unknown> = {}) => {
      if (modelTransport.length < 128) modelTransport.push({stage, elapsedMilliseconds: Math.round(performance.now() - diagnosticBegan), ...fields})
    }
    const modelError = (stage: string, error: unknown) => {
      const names = new Set(['Error', 'TypeError', 'SyntaxError', 'RangeError', 'AbortError'])
      const codes = new Set(['ECONNRESET', 'ERR_TLS_HANDSHAKE_TIMEOUT', 'ERR_SSL_UNEXPECTED_EOF_WHILE_READING', 'ERR_SSL_SSLV3_ALERT_HANDSHAKE_FAILURE', 'ERR_SSL_TLSV1_ALERT_UNKNOWN_CA'])
      const code = error && typeof error === 'object' && 'code' in error ? error.code : undefined
      observeModel(stage, {errorType: error instanceof Error && names.has(error.name) ? error.name : 'OtherError',
        code: typeof code === 'string' && codes.has(code) ? code : 'unknown',
        messageSha256: createHash('sha256').update(error instanceof Error ? error.message : 'unknown').digest('hex')})
      savePlanningEvidence(`pi-model-transport-${diagnosticId}.json`, {sessionId: execution.sessionId, modelTransport})
    }
'''
text = text.replace(anchor, anchor + injection)
anchor = "      const chunks: Buffer[] = []; for await (const chunk of request) chunks.push(Buffer.from(chunk))\n      const input = JSON.parse(Buffer.concat(chunks).toString('utf8')) as ModelInput\n"
assert text.count(anchor) == 1
text = text.replace(anchor, "      observeModel('received', {method: ['GET','POST'].includes(request.method ?? '') ? request.method : 'other'})\n" + anchor + "      observeModel('parsed', {hasTools: Array.isArray(input?.tools), toolCount: Array.isArray(input?.tools) ? input.tools.length : 0, hasMessages: Array.isArray(input?.messages), messageCount: Array.isArray(input?.messages) ? input.messages.length : 0})\n")
anchor = "      } catch (error) { response.writeHead(500); response.end(JSON.stringify({ error: { message: String(error) } })) }\n    })\n    models.push(model);"
assert text.count(anchor) == 1
text = text.replace(anchor, "      } catch (error) { modelError('handler-error', error); response.writeHead(500); response.end(JSON.stringify({ error: { message: String(error) } })) }\n    })\n    model.on('tlsClientError', error => modelError('tls-error', error))\n    models.push(model);")
anchor = '    } finally {\n      if (previous === undefined) delete process.env.WORKMESH_LLM_PRIVATE_HOST_ALLOWLIST'
assert text.count(anchor) == 1
text = text.replace(anchor, '    } finally {\n      savePlanningEvidence(`pi-model-transport-${diagnosticId}.json`, {sessionId: execution.sessionId, modelTransport})\n      if (previous === undefined) delete process.env.WORKMESH_LLM_PRIVATE_HOST_ALLOWLIST')
file.write_text(text, encoding='utf8', newline='\n')
(out / 'instrumented-fixture.ts').write_bytes(file.read_bytes())
(out / 'binding.json').write_text(json.dumps({'canonicalHead':'38a8923e267ff60b9b3aaf2df6c9f6f23a2e8428','file':file.relative_to(root).as_posix(),'originalSha256':hashlib.sha256(original).hexdigest(),'gitBlobSha256':hashlib.sha256(git).hexdigest(),'instrumentedSha256':hashlib.sha256(file.read_bytes()).hexdigest(),'scope':'本机临时模型夹具观测；不改变请求、响应、断言、预算；有观测开销，不是规范原入口通过。诊断完成须按原字节恢复。'},ensure_ascii=False,indent=2)+'\n',encoding='utf8')
print(json.dumps({'prepared':True,'originalSha256':hashlib.sha256(original).hexdigest(),'instrumentedSha256':hashlib.sha256(file.read_bytes()).hexdigest()}))
