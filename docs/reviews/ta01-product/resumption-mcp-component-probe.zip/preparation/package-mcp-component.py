import hashlib
import io
import json
from pathlib import Path
import subprocess
import tarfile
import posixpath
import os

repo = Path.cwd().resolve()
root = repo / '.tmp/ta01-resumption/mcp-component-5371'
root.mkdir(exist_ok=False)
packages, graph = [], []
def add(package):
    package = package.resolve()
    if package not in packages:
        packages.append(package)
    return packages.index(package)
add(repo / 'apps/mcp')
for package in packages:
    definition = json.loads((package / 'package.json').read_bytes())
    dependencies = dict.fromkeys([*definition.get('dependencies', {}), *definition.get('optionalDependencies', {}),
                                  *definition.get('peerDependencies', {})])
    links = {}
    for name in dependencies:
        for ancestor in [package, *package.parents]:
            candidate = ancestor / 'node_modules' / name
            if (candidate / 'package.json').is_file():
                links[name] = add(candidate)
                break
        else:
            if name not in definition.get('peerDependencies', {}) and name not in definition.get('optionalDependencies', {}):
                raise RuntimeError('required dependency unavailable: ' + name)
    graph.append({'name': definition['name'], 'version': definition.get('version'), 'dependencies': links})
assert len(packages) < 150
records = {}
with tarfile.open(root / 'runtime.tar', 'x') as archive:
    for index, package in enumerate(packages):
        files = []
        for directory, dirs, names in os.walk(package, followlinks=False):
            dirs[:] = [name for name in dirs if name not in {'node_modules', '.git', '.turbo'}]
            files.extend(Path(directory) / name for name in names if name not in {'.npmrc'} and not name.startswith('.env'))
        for file in files:
            relative = file.relative_to(package)
            if graph[index]['name'].startswith('@workmesh/') and relative.parts[0] not in {'dist', 'package.json'}:
                continue
            if not file.is_file():
                continue
            assert not file.is_symlink()
            data = file.read_bytes()
            name = f'pkgs/{index}/' + relative.as_posix()
            info = tarfile.TarInfo(name)
            info.size, info.mode = len(data), 0o644
            archive.addfile(info, io.BytesIO(data))
            records[name] = {'bytes': len(data), 'sha256': hashlib.sha256(data).hexdigest()}
        for name, target in graph[index]['dependencies'].items():
            full = f'pkgs/{index}/node_modules/{name}'
            info = tarfile.TarInfo(full)
            info.type = tarfile.SYMTYPE
            info.linkname = posixpath.relpath(f'pkgs/{target}', posixpath.dirname(full))
            assert posixpath.normpath(posixpath.join(posixpath.dirname(full), info.linkname)) == f'pkgs/{target}'
            archive.addfile(info)
    prepare = repo / 'infra/docker/prepare-production-deploy.mjs'
    data = prepare.read_bytes()
    info = tarfile.TarInfo('infra/docker/prepare-production-deploy.mjs')
    info.size, info.mode = len(data), 0o644
    archive.addfile(info, io.BytesIO(data))
    records[info.name] = {'bytes': len(data), 'sha256': hashlib.sha256(data).hexdigest()}
result = {'说明': '仅MCP组件依赖闭包，取已有锁定依赖及当前编译产物；Linux容器内运行原production prepare。不是完整发行候选，不安装依赖或执行生命周期钩子。',
          'head': subprocess.check_output(['git', 'rev-parse', 'HEAD']).decode().strip(),
          'packages': graph, 'files': records, 'tarBytes': (root / 'runtime.tar').stat().st_size,
          'tarSha256': hashlib.sha256((root / 'runtime.tar').read_bytes()).hexdigest()}
with (root / 'inputs.json').open('x', encoding='utf8', newline='\n') as output:
    json.dump(result, output, ensure_ascii=False, indent=2)
    output.write('\n')
print(json.dumps({'packages': len(packages), 'files': len(records), 'tarBytes': result['tarBytes']}))
