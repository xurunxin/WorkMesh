from datetime import datetime, timezone
import hashlib
import json
from pathlib import Path
import statistics
import subprocess
import zipfile

root = Path('.tmp/ta01-resumption/mcp-component-5371')
repo = Path.cwd().resolve()
sha = lambda data: hashlib.sha256(data).hexdigest()
head = subprocess.check_output(['git', 'rev-parse', 'HEAD']).decode().strip()
assert head == '5371f16e24db94415155228dfc8ac149523573a0'
assert subprocess.check_output(['git', 'diff', '9c8bbff749c1d2a52a3e6489dcec02d2d7c859af', head, '--',
    'apps/mcp/src', 'packages/agent-sdk/src', 'packages/contracts/src']) == b''
inputs = json.loads((root / 'inputs.json').read_bytes())
assert inputs['head'] == head
checked = {}
for index, package in enumerate(inputs['packages']):
    locations = {'@workmesh/mcp': 'apps/mcp', '@workmesh/agent-sdk': 'packages/agent-sdk', '@workmesh/contracts': 'packages/contracts'}
    if package['name'] not in locations:
        continue
    prefix = f'pkgs/{index}/'
    for name, metadata in inputs['files'].items():
        if not name.startswith(prefix):
            continue
        data = (repo / locations[package['name']] / name[len(prefix):]).read_bytes()
        assert len(data) == metadata['bytes'] and sha(data) == metadata['sha256']
        checked[name] = metadata
assert len(checked) == 59
first = json.loads((root / 'resources.json').read_bytes())
query = subprocess.run(['docker', 'ps', '-aq', '--no-trunc', '--filter',
    'label=io.workmesh.ta01.probe.owner=' + first['owner']], capture_output=True, timeout=30)
assert query.returncode == 0 and query.stdout.strip() == b''
first['matchingContainersAtFinalRead'] = 0
first['finalReadAt'] = datetime.now(timezone.utc).isoformat()
(root / 'resources-final-first-bind.json').write_text(json.dumps(first, ensure_ascii=False, indent=2) + '\n', encoding='utf8')
cases = []
mapping = {'stdin': 'measurement-unprofiled.mjs', 'profiled': 'measurement-profiled-first.mjs',
           'segmented': 'measurement-segmented.mjs', 'narrow': 'measurement-current.mjs', 'paired-full': 'measurement-current.mjs'}
for case, script in mapping.items():
    value = json.loads((root / (case + '-result.json')).read_bytes())
    ledger = json.loads((root / ('resources-' + case + '.json')).read_bytes())
    assert ledger['measurementSha256'] == sha((root / script).read_bytes())
    assert ledger['exitCode'] == 0 and value['unknownRequests'] == 0 and value['identitiesChecked'] == 2
    assert value['executableSha256'] == '638c77326270093b1251a5e72b4335c94c74856a210460341c73d6f3da647328'
    assert len(value['requests']) == 24
    for container in ledger['containers']:
        assert container['exitCode'] == 0 and container['removedAndAbsent'] and not container['oom']
        absent = subprocess.run(['docker', 'inspect', container['id']], capture_output=True, timeout=30)
        assert absent.returncode != 0 and b'no such object' in absent.stderr.lower()
    tools = [row for row in value['requests'] if row['method'] == 'tools/call']
    qualified = [segment for row in tools for segment in row.get('clientSegments', []) if segment['label'] == 'qualified']
    med = lambda values: statistics.median(values) if values else None
    cases.append({'case': case, 'source': script, 'measurementSha256': ledger['measurementSha256'],
        'httpRequests': 24, 'identities': 2, 'toolsCalls': len(tools), 'executableSha256': value['executableSha256'],
        'qualifiedResponseBytes': value.get('qualifiedResponseBytes'), 'qualifiedOperationCount': value.get('qualifiedOperationCount'),
        'toolWallMedianMs': med([row['elapsedMilliseconds'] for row in tools]),
        'toolCpuMedianMs': med([(row['userCpuMicroseconds'] + row['systemCpuMicroseconds']) / 1000 for row in tools]),
        'toolCpuSumMs': sum((row['userCpuMicroseconds'] + row['systemCpuMicroseconds']) / 1000 for row in tools),
        'qualifiedWallMedianMs': med([row['elapsedMilliseconds'] for row in qualified]),
        'qualifiedCpuMedianMs': med([(row['user'] + row['system']) / 1000 for row in qualified]),
        'containerId': ledger['containers'][0]['id'], 'removedAndAbsent': True, 'rssBytesAtEnd': value['rssBytes']})
proof = {'说明': '相同锁定Node可执行文件的有限合成组件测量；不代真实安装、TCG或排除139。两组最新相同脚本的完整/裁减fixture只测试成本，不改变产品资格合同。',
    'sourceHead': head, 'sourceTree': subprocess.check_output(['git', 'rev-parse', 'HEAD^{tree}']).decode().strip(),
    'componentSourceUnchangedSince9c8': True, 'workspaceCompiledBytesCheckedAfterBuild': checked,
    'buildOrdering': '闭包打包曾与build并行；完成后逐字核59个workspace输入一致，未冒称先等待build完成。',
    'containerLimits': {'cpus': 1, 'ramMiB': 512, 'swapMiB': 0, 'network': 'none', 'readOnly': True, 'uid': 10001,
        'pids': 128, 'tmpfsMiB': 256, 'capabilities': 'drop ALL', 'noNewPrivileges': True, 'hostPorts': [], 'mounts': []},
    'baseImageId': first['imageId'], 'cases': cases,
    'limits': ['只有Node可执行文件精确匹配旧捕获；宿主kernel、动态库、完整已安装镜像和TCG不同。',
        '同进程CPU包含合成API；Inspector timeDeltas为wall time，不能当CPU百分比。',
        '有限顺序样本、无统计置信区间；一次RSS快照不是峰值或泄漏证明。',
        '首个profile分类将GC/idle折为other，原件保留；后续segmented修正聚合名称。',
        '首次bind create30秒超时未取得ID；准确owner最终只读查询0，不补造历史不存在。',
        '首次成功运行rm后因错误大小写断言失败；未重试删除，后续只读确认absent。'],
    'observedAt': datetime.now(timezone.utc).isoformat()}
(root / 'component-proof.json').write_text(json.dumps(proof, ensure_ascii=False, indent=2) + '\n', encoding='utf8')
members = {}
names = ['inputs.json', 'component-proof.json', 'timeline.json', 'resources.json', 'resources-final-first-bind.json', *set(mapping.values())]
for case in mapping:
    names += [case + '-result.json', case + '-stdout.log', case + '-stderr.log', 'resources-' + case + '.json']
for name in sorted(set(names)):
    members['component/' + name] = (root / name).read_bytes()
for name in ['component-build-5371.log', 'package-mcp-component.py', 'run-mcp-component-stdin.py',
             'run-mcp-component-paired.py', 'run-mcp-component.py', 'finish-first-component-ledgers.py', 'archive-mcp-component.py']:
    members['preparation/' + name] = (root.parent / name).read_bytes()
for name in ['mcp-component-probe.mjs', 'analyze-failure-timeline.py']:
    members['tools/' + name] = (repo / 'docs/reviews/ta01-product/tools' / name).read_bytes()
assert all(len(data) < 2_000_000 for data in members.values())
stem = repo / 'docs/reviews/ta01-product/resumption-mcp-component-probe'
with zipfile.ZipFile(stem.with_suffix('.zip'), 'x', compression=zipfile.ZIP_DEFLATED) as archive:
    for name, data in members.items():
        archive.writestr(name, data)
proof['selectedZipSha256'] = sha(stem.with_suffix('.zip').read_bytes())
proof['members'] = {name: {'bytes': len(data), 'sha256': sha(data)} for name, data in members.items()}
with stem.with_suffix('.json').open('x', encoding='utf8', newline='\n') as output:
    json.dump(proof, output, ensure_ascii=False, indent=2)
    output.write('\n')
print(json.dumps({'members': len(members), 'zipBytes': stem.with_suffix('.zip').stat().st_size,
    'cases': len(cases), 'workspaceInputsChecked': len(checked), 'selectedZipSha256': proof['selectedZipSha256']}))
