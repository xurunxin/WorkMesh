import hashlib
import json
from pathlib import Path
import subprocess
import uuid

root = Path('.tmp/ta01-resumption/mcp-component-5371').resolve()
owner = str(uuid.uuid4())
image = 'sha256:6b2127043c2faa4f15cdcdeb65a39fc9afbecf5559301898b754bbff561a8aa9'
ledger = {'owner': owner, 'imageId': image, 'containers': [], 'scope': 'isolated component; not full guest or product acceptance'}
def save():
    (root / 'resources.json').write_text(json.dumps(ledger, indent=2) + '\n', encoding='utf8')
def docker(args):
    result = subprocess.run(['docker', *args], capture_output=True, timeout=30)
    assert result.returncode == 0, 'Docker operation failed; stderr withheld'
    return result.stdout
save()
mounts = [('runtime.tar', root / 'runtime.tar'), ('launch.mjs', root / 'launch.mjs'),
          ('measurement.mjs', Path('docs/reviews/ta01-product/tools/mcp-component-probe.mjs').resolve())]
args = ['create', '--pull', 'never', '--network', 'none', '--read-only', '--cpus', '1', '--memory', '512m',
        '--memory-swap', '512m', '--pids-limit', '128', '--cap-drop', 'ALL', '--security-opt', 'no-new-privileges:true',
        '--user', '10001:10001', '--tmpfs', '/tmp:rw,nosuid,nodev,size=256m',
        '--label', 'io.workmesh.ta01.probe.owner=' + owner, '--entrypoint', 'node']
for name, source in mounts:
    assert source.is_file()
    args += ['--mount', 'type=bind,src=' + str(source) + ',dst=/probe/' + name + ',readonly']
identifier = docker([*args, image, '/probe/launch.mjs']).decode().strip()
assert len(identifier) == 64
ledger['containers'].append({'id': identifier})
save()
try:
    result = subprocess.run(['docker', 'start', '--attach', identifier], capture_output=True, timeout=120)
    (root / 'stdout.log').write_bytes(result.stdout)
    (root / 'stderr.log').write_bytes(result.stderr)
    ledger['exitCode'] = result.returncode
    if result.returncode == 0:
        value = json.loads(result.stdout)
        assert value['executableSha256'] == '638c77326270093b1251a5e72b4335c94c74856a210460341c73d6f3da647328'
        with (root / 'result.json').open('x', encoding='utf8', newline='\n') as output:
            json.dump(value, output, ensure_ascii=False, indent=2)
            output.write('\n')
except subprocess.TimeoutExpired as error:
    ledger['timedOut'] = True
    (root / 'stdout.log').write_bytes(error.stdout or b'')
    (root / 'stderr.log').write_bytes(error.stderr or b'')
    docker(['stop', '--time', '10', identifier])
finally:
    info = json.loads(docker(['inspect', identifier]))[0]
    assert info['Id'] == identifier and info['Config']['Labels']['io.workmesh.ta01.probe.owner'] == owner
    assert info['Image'] == image and not info['State']['Running']
    assert not any(mount['Type'] == 'volume' for mount in info['Mounts'])
    ledger['containers'][0].update(exitCode=info['State']['ExitCode'], oom=info['State']['OOMKilled'], running=False)
    save()
    docker(['rm', identifier])
    absent = subprocess.run(['docker', 'inspect', identifier], capture_output=True)
    assert absent.returncode != 0 and b'No such object' in absent.stderr
    ledger['containers'][0]['removedAndAbsent'] = True
    save()
print(json.dumps(ledger))
