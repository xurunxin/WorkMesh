from datetime import datetime, timezone
import json
from pathlib import Path
import subprocess

root = Path('.tmp/ta01-resumption/mcp-component-5371')
for file in ['resources.json', 'resources-stdin.json']:
    ledger = json.loads((root / file).read_bytes())
    if file == 'resources.json':
        matches = subprocess.run(['docker', 'ps', '-a', '--no-trunc', '--filter', 'label=io.workmesh.ta01.probe.owner=' + ledger['owner'], '--format', '{{.ID}}'], capture_output=True, timeout=30)
        assert matches.returncode == 0 and not matches.stdout.strip()
        ledger.update(createTimedOutSeconds=30, matchingContainersAtRead=0, creationCompletion='unknown; no returned ID', observedAt=datetime.now(timezone.utc).isoformat())
    else:
        identifier = ledger['containers'][0]['id']
        absent = subprocess.run(['docker', 'inspect', identifier], capture_output=True, timeout=30)
        assert absent.returncode != 0 and b'no such object' in absent.stderr.lower()
        ledger['containers'][0]['removedAndAbsent'] = True
        ledger['cleanupCheckCorrection'] = '首次检查误用大小写敏感错误匹配；rm已成功，不重试删除。后续只读检查确认no such object。'
    (root / file).write_text(json.dumps(ledger, ensure_ascii=False, indent=2) + '\n', encoding='utf8')
source = Path('docs/reviews/ta01-product/tools/mcp-component-probe.mjs').read_bytes()
with (root / 'measurement-unprofiled.mjs').open('xb') as output:
    output.write(source)
print('first setup failure and native component source/cleanup preserved')
