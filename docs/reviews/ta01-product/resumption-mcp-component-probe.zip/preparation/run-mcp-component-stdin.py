import base64
import hashlib
import json
from pathlib import Path
import subprocess
import uuid
import sys

root = Path('.tmp/ta01-resumption/mcp-component-5371').resolve()
owner = str(uuid.uuid4())
image = 'sha256:6b2127043c2faa4f15cdcdeb65a39fc9afbecf5559301898b754bbff561a8aa9'
script = Path('docs/reviews/ta01-product/tools/mcp-component-probe.mjs').read_bytes()
tag = sys.argv[1]
assert tag in {'profiled', 'segmented', 'narrow'}
assert not (root / ('resources-' + tag + '.json')).exists()
bootstrap = """import{mkdirSync,writeFileSync,realpathSync,readdirSync}from'node:fs';import{spawnSync}from'node:child_process';import assert from'node:assert/strict';
mkdirSync('/tmp/probe');writeFileSync('/tmp/runtime.tar',Buffer.from(TAR,'base64'));
assert.equal(spawnSync('tar',['xf','/tmp/runtime.tar','-C','/tmp/probe'],{stdio:'inherit'}).status,0);
for(const n of readdirSync('/tmp/probe/pkgs/0/node_modules/@workmesh'))assert.ok(realpathSync('/tmp/probe/pkgs/0/node_modules/@workmesh/'+n).startsWith('/tmp/probe/pkgs/'));
assert.equal(spawnSync(process.execPath,['/tmp/probe/infra/docker/prepare-production-deploy.mjs','/tmp/probe/pkgs/0'],{stdio:'inherit'}).status,0);
writeFileSync('/tmp/measurement.mjs',Buffer.from(SCRIPT,'base64'));
process.exit(spawnSync(process.execPath,['/tmp/measurement.mjs','/tmp/probe/pkgs/0','--profile',...EXTRA],{stdio:'inherit'}).status??1);
"""
body = ('const EXTRA=' + json.dumps(['--narrow-fixture'] if tag == 'narrow' else []) + ';const TAR=' + json.dumps(base64.b64encode((root / 'runtime.tar').read_bytes()).decode()) + ';const SCRIPT=' +
        json.dumps(base64.b64encode(script).decode()) + ';\n' + bootstrap).encode()
ledger = {'owner': owner, 'imageId': image, 'containers': [], 'stdinBytes': len(body), 'stdinSha256': hashlib.sha256(body).hexdigest(),
          'measurementSha256': hashlib.sha256(script).hexdigest(), 'scope': 'same component, stdin transport; no host bind mount'}
def save():
    (root / ('resources-' + tag + '.json')).write_text(json.dumps(ledger, indent=2) + '\n', encoding='utf8')
def docker(args):
    result = subprocess.run(['docker', *args], capture_output=True, timeout=30)
    assert result.returncode == 0, 'Docker operation failed; stderr withheld'
    return result.stdout
save()
try:
    identifier = docker(['create', '--pull', 'never', '--interactive', '--network', 'none', '--read-only', '--cpus', '1',
        '--memory', '512m', '--memory-swap', '512m', '--pids-limit', '128', '--cap-drop', 'ALL',
        '--security-opt', 'no-new-privileges:true', '--user', '10001:10001', '--tmpfs', '/tmp:rw,nosuid,nodev,size=256m',
        '--label', 'io.workmesh.ta01.probe.owner=' + owner, '--entrypoint', 'node', image, '--input-type=module', '-']).decode().strip()
except subprocess.TimeoutExpired:
    ledger['createTimedOutSeconds'] = 30
    save()
    raise
assert len(identifier) == 64
ledger['containers'].append({'id': identifier})
save()
try:
    result = subprocess.run(['docker', 'start', '--attach', '--interactive', identifier], input=body, capture_output=True, timeout=120)
    (root / (tag + '-stdout.log')).write_bytes(result.stdout)
    (root / (tag + '-stderr.log')).write_bytes(result.stderr)
    ledger['exitCode'] = result.returncode
    if result.returncode == 0:
        value = json.loads(result.stdout)
        assert value['executableSha256'] == '638c77326270093b1251a5e72b4335c94c74856a210460341c73d6f3da647328'
        with (root / (tag + '-result.json')).open('x', encoding='utf8', newline='\n') as output:
            json.dump(value, output, ensure_ascii=False, indent=2)
            output.write('\n')
except subprocess.TimeoutExpired as error:
    ledger['timedOut'] = True
    (root / (tag + '-stdout.log')).write_bytes(error.stdout or b'')
    (root / (tag + '-stderr.log')).write_bytes(error.stderr or b'')
    docker(['stop', '--time', '10', identifier])
finally:
    info = json.loads(docker(['inspect', identifier]))[0]
    assert info['Id'] == identifier and info['Config']['Labels']['io.workmesh.ta01.probe.owner'] == owner
    assert info['Image'] == image and not info['State']['Running'] and not info['Mounts']
    ledger['containers'][0].update(exitCode=info['State']['ExitCode'], oom=info['State']['OOMKilled'], running=False)
    save()
    docker(['rm', identifier])
    absent = subprocess.run(['docker', 'inspect', identifier], capture_output=True)
    assert absent.returncode != 0 and b'no such object' in absent.stderr.lower()
    ledger['containers'][0]['removedAndAbsent'] = True
    save()
print(json.dumps(ledger))
