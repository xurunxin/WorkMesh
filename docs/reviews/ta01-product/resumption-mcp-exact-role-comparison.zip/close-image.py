from pathlib import Path
import json,subprocess,hashlib
r=Path('.tmp/ta01-resumption/exact-mcp-9c8');l=json.loads((r/'native-resources.json').read_bytes());i=l['actualImageId'];tag=l['sourceImage']['reference'];own=json.loads((r/'extraction.json').read_bytes())['ownedTag']
v=subprocess.run(['docker','ps','--all','--no-trunc','--filter','ancestor='+i,'--format','{{.ID}}'],capture_output=True,timeout=30);assert v.returncode==0 and not v.stdout.strip()
x=json.loads(subprocess.check_output(['docker','image','inspect',own]))[0];assert x['Id']==i and x['RepoTags']==[own] and not any(l['imagePreexisting'].values())
v=subprocess.run(['docker','image','rm',own],capture_output=True,timeout=30);assert v.returncode==0
v=subprocess.run(['docker','image','inspect',own],capture_output=True,timeout=30);assert v.returncode!=0 and b'no such image' in v.stderr.lower()
l['ownedImageTagRemoved']=True;l['imageConsumersBeforeRemoval']=0;l['sharedImagesRemoved']=False
l['largeTemporaryFilesRemoved']=[]
for n in ['candidate.zip','mcp-only.tar']:
 p=r/n;assert p.resolve().parent==r.resolve();h=hashlib.sha256()
 with p.open('rb') as f:
  while b:=f.read(1024*1024):h.update(b)
 l['largeTemporaryFilesRemoved'].append({'path':p.as_posix(),'bytes':p.stat().st_size,'sha256':h.hexdigest()});p.unlink()
(r/'native-resources.json').write_text(json.dumps(l,ensure_ascii=False,indent=2)+'\n',encoding='utf8')
print(json.dumps({'ownedImageTagRemoved':True,'onlyExactOwnedLargeFilesRemoved':len(l['largeTemporaryFilesRemoved']),'exactRootfsBytesRetained':(r/'node-rootfs.tar.gz').stat().st_size}))
