from pathlib import Path
import json,subprocess,hashlib
r=Path('.tmp/ta01-resumption/exact-mcp-9c8/tcg');l=json.loads((r/'resources.json').read_bytes());i=l['containers'][0]['id']
p=r/'tcg-result.json';assert p.stat().st_size==0;p.rename(r/'tcg-result-wrong-path.empty')
l['resultCopyCorrection']='原辅助工具误读/opt/micro/tcg-result.json，产生零字节文件；实际为/opt/micro/guest/result.json。只取回既有原件，没有重跑guest。'
for source,name in [('guest/result.json','tcg-result.json'),('guest/serial.log','serial.log'),('guest/qemu-stderr.log','qemu-stderr.log')]:
 with (r/name).open('xb') as out:
  v=subprocess.run(['docker','exec',i,'cat','/opt/micro/'+source],stdout=out,stderr=subprocess.PIPE,timeout=30);assert v.returncode==0
x=json.loads((r/'tcg-result.json').read_bytes());assert x['qemuExitCode']==0 and x['status']=='component-measured' and len(x['receipts'])==1
v=subprocess.run(['docker','exec',i,'python3','-c',"import hashlib,json,os,pathlib;print(json.dumps({'qemuSha256':hashlib.sha256(pathlib.Path('/usr/bin/qemu-system-x86_64').read_bytes()).hexdigest(),'kernel':os.uname().release,'activeQemuCount':sum(1 for p in pathlib.Path('/proc').iterdir() if p.name.isdigit() and (p/'comm').exists() and (p/'comm').read_text().startswith('qemu-system'))}))"],capture_output=True,timeout=30);assert v.returncode==0
meta=json.loads(v.stdout);assert meta['activeQemuCount']==0;(r/'outer-metadata.json').write_bytes(v.stdout)
v=subprocess.run(['docker','inspect',i],capture_output=True,timeout=30);info=json.loads(v.stdout)[0];assert info['Config']['Labels']['io.workmesh.ta01.probe.owner']==l['owner'] and not info['Mounts'] and info['Image']==l['imageId']
h=info['HostConfig'];controls={k:h.get(k) for k in ['NanoCpus','Memory','MemorySwap','Privileged','Devices','Binds','PortBindings','SecurityOpt','PidsLimit']};assert h['NanoCpus']==4000000000 and h['Memory']==4294967296 and not h['Privileged'] and not h['Devices'] and not h['Binds'] and not h['PortBindings'];(r/'outer-controls.json').write_text(json.dumps(controls,indent=2),encoding='utf8')
v=subprocess.run(['docker','stop','--time','10',i],capture_output=True,timeout=30);assert v.returncode==0
info=json.loads(subprocess.check_output(['docker','inspect',i]))[0];assert not info['State']['Running'] and not info['State']['OOMKilled'];l['containers'][0].update(exitCode=info['State']['ExitCode'],oom=False,activeQemuCountBeforeStop=0)
(r/'resources.json').write_text(json.dumps(l,ensure_ascii=False,indent=2)+'\n',encoding='utf8')
assert subprocess.run(['docker','rm',i],capture_output=True,timeout=30).returncode==0
v=subprocess.run(['docker','inspect',i],capture_output=True,timeout=30);assert v.returncode!=0 and b'no such object' in v.stderr.lower();l['containers'][0]['removedAndAbsent']=True;l['privateGuestOverlaysRetained']=False;(r/'resources.json').write_text(json.dumps(l,ensure_ascii=False,indent=2)+'\n',encoding='utf8')
print(json.dumps({'qemuExitCode':x['qemuExitCode'],'nodeExitCode':x['receipts'][0]['nodeExitCode'],'guestSeconds':x['elapsedSeconds'],'nodeSeconds':x['receipts'][0]['nodeSeconds'],'outerExitCode':l['containers'][0]['exitCode'],'removed':True}))
