from pathlib import Path
import json,subprocess
r=Path('.tmp/ta01-resumption/exact-mcp-9c8/tcg');l=json.loads((r/'resources.json').read_bytes());i=l['containers'][0]['id']
with (r/'apt-install.stdout').open('xb') as out,(r/'apt-install.stderr').open('xb') as err:
 v=subprocess.run(['docker','exec',i,'apt-get','install','-y','--no-install-recommends','qemu-system-x86=1:8.2.2+ds-0ubuntu1.18','qemu-utils=1:8.2.2+ds-0ubuntu1.18','genisoimage','python3','ca-certificates'],stdout=out,stderr=err,timeout=300)
l['aptInstallExitCode']=v.returncode;(r/'resources.json').write_text(json.dumps(l,ensure_ascii=False,indent=2));assert v.returncode==0
v=subprocess.run(['docker','exec',i,'qemu-system-x86_64','--version'],capture_output=True,timeout=30);assert v.returncode==0 and v.stdout.decode().splitlines()[0]=='QEMU emulator version 8.2.2 (Debian 1:8.2.2+ds-0ubuntu1.18)';(r/'qemu-version.stdout').write_bytes(v.stdout)
print('exact QEMU provisioned; no host installation')
