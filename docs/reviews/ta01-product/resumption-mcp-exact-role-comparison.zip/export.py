from pathlib import Path
import subprocess,json,gzip,hashlib
r=Path('.tmp/ta01-resumption/exact-mcp-9c8');l=json.loads((r/'native-resources.json').read_bytes());img=l['actualImageId'];owner=l['owner']
def call(a):return subprocess.run(['docker',*a],capture_output=True,timeout=30)
v=call(['create','--pull','never','--network','none','--label','io.workmesh.ta01.probe.owner='+owner,'--entrypoint','/bin/false',img]);assert v.returncode==0
identifier=v.stdout.decode().strip();assert len(identifier)==64
l['containers'].append({'id':identifier,'purpose':'export exact public CI563 MCP rootfs only, never started'});(r/'native-resources.json').write_text(json.dumps(l,ensure_ascii=False,indent=2))
info=json.loads(call(['inspect',identifier]).stdout)[0];assert not info['Mounts'] and not info['State']['Running'] and info['Image']==img and info['Config']['Labels']['io.workmesh.ta01.probe.owner']==owner
p=subprocess.Popen(['docker','export',identifier],stdout=subprocess.PIPE,stderr=subprocess.PIPE);raw=hashlib.sha256();n=0
with (r/'node-rootfs.tar.gz').open('xb') as out,gzip.GzipFile(fileobj=out,mode='wb',mtime=0) as compressed:
 while b:=p.stdout.read(1024*1024):compressed.write(b);raw.update(b);n+=len(b)
assert p.wait(timeout=60)==0
l['rootfs']={'uncompressedBytes':n,'uncompressedSha256':raw.hexdigest(),'gzipBytes':(r/'node-rootfs.tar.gz').stat().st_size,'gzipSha256':hashlib.sha256((r/'node-rootfs.tar.gz').read_bytes()).hexdigest()}
assert call(['rm',identifier]).returncode==0
v=call(['inspect',identifier]);assert v.returncode!=0 and b'no such object' in v.stderr.lower();l['containers'][-1]['removedAndAbsent']=True
(r/'native-resources.json').write_text(json.dumps(l,ensure_ascii=False,indent=2)+'\n');print(json.dumps(l['rootfs']))
