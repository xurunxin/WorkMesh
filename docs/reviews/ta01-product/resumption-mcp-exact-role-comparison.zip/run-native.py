from pathlib import Path
import subprocess,json,hashlib,base64,uuid
r=Path('.tmp/ta01-resumption/exact-mcp-9c8');x=json.loads((r/'extraction.json').read_bytes());tag=x['ownedTag'];img=x['image'];owner=str(uuid.uuid4())
def call(a,timeout=30,**kw):return subprocess.run(['docker',*a],capture_output=True,timeout=timeout,**kw)
ledger={'owner':owner,'sourceImage':img,'containers':[],'imagePreexisting':{},'scope':'准确CI563 MCP角色的原生组件；只用合成work:read，无生产身份／服务。'}
def save():(r/'native-resources.json').write_text(json.dumps(ledger,ensure_ascii=False,indent=2)+'\n',encoding='utf8')
assert not (r/'native-resources.json').exists()
for ref in [tag,img['id'],img['archiveId']]:
 v=call(['image','inspect',ref]);ledger['imagePreexisting'][ref]=v.returncode==0
 if v.returncode:assert b'no such image' in v.stderr.lower()
save();assert not ledger['imagePreexisting'][tag]
v=call(['load','--input',str(r/'mcp-only.tar')],timeout=180);ledger['loadExitCode']=v.returncode;ledger['loadStdoutSha256']=hashlib.sha256(v.stdout).hexdigest();save();assert v.returncode==0
info=json.loads(call(['image','inspect',tag]).stdout)[0]
assert info['Id'] in {img['id'],img['archiveId']} and info['Architecture']=='amd64' and info['Config']['Labels']['org.opencontainers.image.revision']==img['revision']
ledger['actualImageId']=info['Id'];save()
script=Path('docs/reviews/ta01-product/tools/mcp-component-probe.mjs').read_bytes()
body=("import{writeFileSync,readFileSync}from'node:fs';import{spawnSync}from'node:child_process';import{createHash}from'node:crypto';import assert from'node:assert/strict';assert.equal(createHash('sha256').update(readFileSync(process.execPath)).digest('hex'),'638c77326270093b1251a5e72b4335c94c74856a210460341c73d6f3da647328');writeFileSync('/tmp/measurement.mjs',Buffer.from("+json.dumps(base64.b64encode(script).decode())+",'base64'));process.exit(spawnSync(process.execPath,['/tmp/measurement.mjs','/app','--segments','--work-read-fixture'],{stdio:'inherit'}).status??1);").encode()
ledger['measurementSha256']=hashlib.sha256(script).hexdigest();ledger['stdinSha256']=hashlib.sha256(body).hexdigest();save()
v=call(['create','--pull','never','--interactive','--network','none','--read-only','--cpus','4','--cpuset-cpus','0-3','--memory','4g','--memory-swap','4g','--pids-limit','128','--cap-drop','ALL','--security-opt','no-new-privileges:true','--user','10001:10001','--tmpfs','/tmp:rw,nosuid,nodev,size=256m','--ulimit','core=0:0','--label','io.workmesh.ta01.probe.owner='+owner,'--entrypoint','node',info['Id'],'--input-type=module','-'])
assert v.returncode==0;identifier=v.stdout.decode().strip();assert len(identifier)==64;ledger['containers'].append({'id':identifier});save()
try:
 v=call(['start','--attach','--interactive',identifier],timeout=120,input=body)
 ledger.update(exitCode=v.returncode,stdoutSha256=hashlib.sha256(v.stdout).hexdigest(),stderrSha256=hashlib.sha256(v.stderr).hexdigest(),stderrBytes=len(v.stderr));save()
 if v.returncode==0:
  result=json.loads(v.stdout);assert result['executableSha256']=='638c77326270093b1251a5e72b4335c94c74856a210460341c73d6f3da647328' and result['unknownRequests']==0 and result['workReadFixture'] and len(result['requests'])==24
  (r/'native-result.json').write_text(json.dumps(result,indent=2)+'\n')
except subprocess.TimeoutExpired:
 ledger['timedOut']=True;save();assert call(['stop','--time','10',identifier]).returncode==0
finally:
 info=json.loads(call(['inspect',identifier]).stdout)[0];assert info['Id']==identifier and info['Config']['Labels']['io.workmesh.ta01.probe.owner']==owner and info['Image']==ledger['actualImageId'] and not info['Mounts'] and not info['State']['Running']
 ledger['containers'][0].update(exitCode=info['State']['ExitCode'],oom=info['State']['OOMKilled']);save();assert call(['rm',identifier]).returncode==0
 v=call(['inspect',identifier]);assert v.returncode!=0 and b'no such object' in v.stderr.lower();ledger['containers'][0]['removedAndAbsent']=True;save()
print(json.dumps({'actualImageId':ledger['actualImageId'],'exitCode':ledger.get('exitCode'),'removed':True}))
