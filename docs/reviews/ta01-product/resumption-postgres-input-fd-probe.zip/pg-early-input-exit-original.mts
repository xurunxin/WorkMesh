import { spawn } from 'node:child_process'
import { createReadStream, createWriteStream } from 'node:fs'
import { writeFile, unlink } from 'node:fs/promises'
import { fileURLToPath } from 'node:url'
const runPostgresTool = async (
  command: string,
  args: readonly string[],
  options: Readonly<{ stdinPath?: string; stdoutPath?: string; password?: string }> = {},
): Promise<void> => new Promise((resolve, reject) => {
  const container = process.env.WORKMESH_POSTGRES_TOOL_CONTAINER
  const executable = container ? 'docker' : command
  const actualArgs = container
    ? ['exec', ...(options.stdinPath ? ['-i'] : []), ...(options.password ? ['--env', 'PGPASSWORD'] : []), container, command, ...args]
    : [...args]
  const child = spawn(executable, actualArgs, {
    stdio: ['pipe', 'pipe', 'pipe'],
    windowsHide: true,
    env: options.password ? { ...process.env, PGPASSWORD: options.password } : process.env,
  })
  let stderr = ''
  const input = options.stdinPath ? createReadStream(options.stdinPath) : undefined
  const output = options.stdoutPath ? createWriteStream(options.stdoutPath, { flags: 'wx', mode: 0o600 }) : undefined
  if (input) input.pipe(child.stdin)
  else child.stdin.end()
  if (output) child.stdout.pipe(output)
  else child.stdout.resume()
  child.stderr.on('data', chunk => {
    if (stderr.length < 64_000) stderr += String(chunk)
  })
  let settled = false
  const fail = (error: Error, terminate = false): void => {
    if (settled) return
    settled = true
    if (terminate && child.exitCode === null && child.signalCode === null) child.kill()
    reject(error)
  }
  input?.once('error', error => fail(new Error(`RECOVERY_POSTGRES_TOOL_INPUT_FAILED:${error.message}`), true))
  output?.once('error', error => fail(new Error(`RECOVERY_POSTGRES_TOOL_OUTPUT_FAILED:${error.message}`), true))
  child.once('error', error => fail(new Error(`RECOVERY_POSTGRES_TOOL_START_FAILED:${command}:${error.message}`)))
  child.once('exit', (code, signal) => {
    if (settled) return
    if (code !== 0) {
      fail(new Error(`RECOVERY_POSTGRES_TOOL_FAILED:${command}:${code ?? signal ?? 'unknown'}:${stderr.trim()}`))
      return
    }
    const complete = (): void => {
      if (settled) return
      settled = true
      resolve()
    }
    if (output && !output.closed) output.once('close', complete)
    else complete()
  })
})


delete process.env.WORKMESH_POSTGRES_TOOL_CONTAINER
const file=fileURLToPath(new URL('./pg-early-input-exit-owned.bin', import.meta.url))
await writeFile(file,Buffer.alloc(32*1024*1024,7),{flag:'wx'})
try { await runPostgresTool(process.execPath,['-e',"require('node:fs').readSync(0,Buffer.alloc(64),0,64,null);process.exit(0)"],{stdinPath:file}); console.log('child-returned-zero') } finally { await unlink(file) }
