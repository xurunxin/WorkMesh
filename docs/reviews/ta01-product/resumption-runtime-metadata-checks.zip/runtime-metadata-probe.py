import hashlib
import json
import os
from pathlib import Path
import shutil
import stat
import subprocess
import time
import uuid

root = Path.cwd().resolve()
out = root / '.tmp/ta01-resumption/runtime-metadata-checks'
out.mkdir(exist_ok=False)
node = 'D:/Cache/TEMP/workmesh-ta00-nf20n0st/node-v22.19.0-win-x64/node.exe'
result = {'sourceHeadAtStart': subprocess.check_output(['git', 'rev-parse', 'HEAD']).decode().strip(),
          'sourceIsDirty': True, 'startedUtc': time.time(), 'node': subprocess.check_output([node, '--version']).decode().strip()}
result['sourceInputs'] = {name: hashlib.sha256((root / name).read_bytes()).hexdigest() for name in [
    'packages/contracts/src/index.ts', 'packages/contracts/src/runtime-metadata.ts', 'packages/contracts/package.json',
    'packages/config/src/index.ts', 'infra/docker/prepare-production-deploy.mjs']}
result['compiledInputs'] = {p.relative_to(root).as_posix(): hashlib.sha256(p.read_bytes()).hexdigest()
                           for package in ['config', 'contracts'] for p in (root / 'packages' / package / 'dist').rglob('*') if p.is_file()}
samples = []
for entry in ['index.js', 'runtime-metadata.js', 'runtime-metadata.js', 'index.js']:
    target = root / 'packages/contracts/dist' / entry
    code = 'const t=performance.now();const c=await import(' + json.dumps(target.as_uri()) + ');console.log(JSON.stringify({elapsedMilliseconds:performance.now()-t,exports:Object.keys(c).length,userCpuMicroseconds:process.resourceUsage().userCPUTime,systemCpuMicroseconds:process.resourceUsage().systemCPUTime,rssBytes:process.memoryUsage().rss}));'
    completed = subprocess.run([node, '--input-type=module', '-e', code], capture_output=True, check=True)
    samples.append({'entry': entry, **json.loads(completed.stdout)})
result['nativeWindowsSamples'] = samples
fixture = out / ('production-fixture-' + uuid.uuid4().hex)
fixture.mkdir()
result['fixture'] = fixture.relative_to(root).as_posix()
try:
    workspace = fixture / 'node_modules/@workmesh'
    workspace.mkdir(parents=True)
    for name in ['contracts', 'config']:
        target = workspace / name
        target.mkdir()
        shutil.copytree(root / 'packages' / name / 'dist', target / 'dist')
        shutil.copyfile(root / 'packages' / name / 'package.json', target / 'package.json')
    shutil.copytree((root / 'packages/contracts/node_modules/zod').resolve(), fixture / 'node_modules/zod')
    prepared = subprocess.run([node, 'infra/docker/prepare-production-deploy.mjs', str(fixture)], capture_output=True)
    result['productionPrepareExitCode'] = prepared.returncode
    assert prepared.returncode == 0
    result['productionManifest'] = json.loads((workspace / 'contracts/package.json').read_text())['exports']
    main = fixture / 'probe.mjs'
    main.write_text("import assert from 'node:assert/strict';import * as c from '@workmesh/config';import * as direct from '@workmesh/contracts/runtime-metadata';import * as publicEntry from '@workmesh/contracts';assert.equal(direct.featureDefinitions,publicEntry.featureDefinitions);assert.equal(direct.releaseMetadata,publicEntry.releaseMetadata);assert.equal(typeof c.loadConfig,'function');assert.equal(typeof c.loadDeploymentProfile,'function');console.log(JSON.stringify({sameObjects:true,version:direct.releaseMetadata.serverVersion,features:direct.featureDefinitions.length}));", encoding='utf8')
    full = subprocess.run([node, str(main)], capture_output=True, check=True)
    result['compiledProductionImport'] = json.loads(full.stdout)
    barrel = workspace / 'contracts/dist/index.js'
    held = barrel.with_name('index.js.owned-held')
    assert barrel.is_file() and not held.exists()
    barrel.rename(held)
    try:
        main.write_text("import assert from 'node:assert/strict';import * as c from '@workmesh/config';import * as direct from '@workmesh/contracts/runtime-metadata';for(const key of ['loadConfig','loadDeploymentProfile','loadFeatureConfig','loadRealtimeRedisHintConfig','loadRetentionConfig'])assert.equal(typeof c[key],'function');const flags=c.loadFeatureConfig({});assert.equal(Object.keys(flags).length,direct.featureDefinitions.length);console.log(JSON.stringify({configWithoutBarrel:true,features:direct.featureDefinitions.length}));", encoding='utf8')
        isolated = subprocess.run([node, str(main)], capture_output=True, check=True)
        result['barrelUnavailableNegativeFixture'] = json.loads(isolated.stdout)
    finally:
        held.rename(barrel)
finally:
    # This exact newly created copy has no aliases and no remaining Node child.
    assert fixture.resolve().parent == out.resolve() and fixture.resolve() != out.resolve()
    owned = list(fixture.rglob('*'))
    assert all(not p.is_symlink() and not (getattr(p.lstat(), 'st_file_attributes', 0) & stat.FILE_ATTRIBUTE_REPARSE_POINT) for p in owned)
    result['ownedFixtureFiles'] = {p.relative_to(fixture).as_posix(): hashlib.sha256(p.read_bytes()).hexdigest() for p in owned if p.is_file()}
    shutil.rmtree(fixture)
    result['fixtureAbsent'] = not fixture.exists()
result['endedUtc'] = time.time()
(out / 'probe.json').write_text(json.dumps(result, ensure_ascii=False, indent=2) + '\n', encoding='utf8')
print(json.dumps({'nativeWindowsSamples': samples, 'compiledProductionImport': result['compiledProductionImport'], 'barrelUnavailableNegativeFixture':result['barrelUnavailableNegativeFixture'], 'fixtureAbsent': result['fixtureAbsent']}))
