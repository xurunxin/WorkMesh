"""一次原企业前缀与auth/install，原应用/安装器字节不变。"""
import hashlib, importlib.util, json, os, subprocess, threading, time, urllib.request
from pathlib import Path
from api_identity import select_api
from clock_evidence import Journal, PrefixRunner, instrument_proxy, error_name
from native_diagnostic import NativeCrashWatcher, node_process_pid, binary_hash, process_identity

BASE = Path('/opt/server-install')
expected = json.loads((BASE/'window.json').read_bytes())
for name, digest in expected['scripts'].items():
    assert hashlib.sha256((BASE/name).read_bytes()).hexdigest() == digest
spec = importlib.util.spec_from_file_location('original_guest', BASE/'original_guest.py')
g = importlib.util.module_from_spec(spec); spec.loader.exec_module(g)
began = time.monotonic(); lock = threading.Lock(); stages = []; target = {'attempts':0}
observer = {'registered':False, 'polls':0, 'eventStreamStarted':False}; watcher = None
done = threading.Event(); events_process = None; observed_container = None


def emit(stage, **values):
    value = {'nonce':expected['nonce'],'kind':'stage','stage':stage,'guestMonotonic':time.monotonic(),
             'sinceDriverSeconds':time.monotonic()-began, **values}
    with lock:
        stages.append(value)
        with (g.ROOT/'window-stages.ndjson').open('a') as f:
            f.write(json.dumps(value)+'\n'); f.flush(); os.fsync(f.fileno())
    print(json.dumps({'tag':'ta01-api-window',**value}),flush=True)
    try:
        req=urllib.request.Request('http://10.0.2.2:18080/window-receipt',json.dumps(value).encode(),
                                   {'content-type':'application/json'})
        with urllib.request.urlopen(req,timeout=3) as response: response.read()
    except Exception: pass


class WindowStop(BaseException): pass

boot_id=Path('/proc/sys/kernel/random/boot_id').read_text().strip()
clock=Journal(g.ROOT,expected['nonce'],boot_id)
clock.record('clock-driver-started')
g.subprocess=PrefixRunner(clock,WindowStop,lambda:g.install_actions)
original_command=g.command
def command(*args,**kwargs):
    if clock.stop.is_set():raise WindowStop()
    return original_command(*args,**kwargs)
g.command=command
proxy_sequence=0
def proxy_begin(method,path):
    global proxy_sequence
    if method!='POST' or path!='/api/v1/auth/install':return None
    proxy_sequence+=1
    if proxy_sequence!=1:raise ValueError('clock proxy duplicate target')
    clock.record('proxy-received',requestSequence=proxy_sequence)
    return proxy_sequence
def proxy_stage(token,stage,status=None):
    if token is None:return
    clock.record(stage,requestSequence=token,**({'status':status} if status is not None else {}))
def proxy_failed(token,error):
    if token is not None:clock.record('proxy-failed',requestSequence=token,errorType=error_name(error))
instrument_proxy((BASE/'original_guest.py').read_text(),g.__dict__,proxy_begin,proxy_stage,proxy_failed)
def supervise():
    while not done.is_set():
        try:clock.poll_marker()
        except Exception:return
        if watcher and watcher.result.exists() and clock.marker is None:
            clock.error='projection-failed';clock.stop.set();return
        done.wait(1)
supervisor=threading.Thread(target=supervise,daemon=True)
supervisor.start()


def register_on_start(prefix, manifest):
    global watcher, events_process, observed_container
    try:
        root_hash=hashlib.sha256(str(prefix).encode()).hexdigest()
        args=['docker','events','--filter','label=com.docker.compose.service=api',
              '--filter','label=io.workmesh.installation-root='+root_hash,'--filter','event=start',
              '--format','{{json .}}']
        events_process=subprocess.Popen(args,stdout=subprocess.PIPE,stderr=subprocess.DEVNULL)
        observer['eventStreamStarted']=True
        # 只等原安装程序的start事件；不轮询前置镜像导入，也不阻塞原请求。
        for raw in events_process.stdout:
            if done.is_set(): return
            event=json.loads(raw); cid=event.get('id',event.get('Actor',{}).get('ID'))
            if not isinstance(cid,str) or len(cid)!=64: raise ValueError('event identity invalid')
            identity=json.loads((prefix/'installation.json').read_bytes())
            values=json.loads(subprocess.check_output(['docker','inspect',cid],timeout=30))
            info=select_api(values,identity,prefix,manifest);observed_container=info['Id']
            observer.update(containerId=info['Id'],imageId=info['Image'],apiStartTimeNano=event.get('timeNano'))
            for _ in range(90):
                if done.is_set(): return
                observer['polls']+=1
                try:
                    pid=node_process_pid(info['State']['Pid'])
                except (OSError, ValueError):
                    if done.wait(1): return
                    continue
                watcher=NativeCrashWatcher(pid,container_init_pid=info['State']['Pid'])
                clock.bind(watcher.capture_id,watcher.identity)
                observer.update(registered=True,registeredGuestMonotonic=time.monotonic(),
                                registeredIdentity=watcher.identity,captureId=watcher.capture_id)
                emit('api-observer-registered',captureId=watcher.capture_id,target=watcher.identity)
                return
            observer['registrationMissing']=True;emit('api-observer-missing')
            return
    except Exception as error:
        observer.update(errorType=type(error).__name__)
        emit('api-observer-error',errorType=type(error).__name__)


original_install=g.install
def install(*args,**kwargs):
    # 原首个真实部署为序号7；序号8为原healthy/pending快捷重试。
    if g.install_actions==6:
        assert args[4]=='install'
        thread=threading.Thread(target=register_on_start,args=(args[2],json.loads((args[0]/'manifest.json').read_bytes())),daemon=True)
        thread.start()
    return original_install(*args,**kwargs)
g.install=install
def error_name_from_target():
    from clock_evidence import ERRORS
    return target.get('errorType') if target.get('errorType') in ERRORS else 'OtherError'
original_request=g.Client.request
def request(self,url,body=None,**kwargs):
    assert url.endswith('/api/v1/auth/install') and body is not None and g.install_actions==8
    assert target['attempts']==0
    clock.poll_marker()
    if clock.stop.is_set() or observer.get('errorType') or (watcher and watcher.result.exists()):
        clock.record('client-skipped',result='early-handler' if clock.marker else 'observer-rejected')
        target['notSentReason']='observer-rejected-or-earlier-core'
        raise WindowStop()
    target.update(attempts=1,startedGuestMonotonic=time.monotonic(),
                  localCorrelationSha256=hashlib.sha256(os.urandom(32)).hexdigest(),
                  observerRegisteredBeforeRequest=observer['registered'])
    clock.record('client-intent',requestSequence=1)
    started=time.monotonic()
    try:
        # metadata只改变返回投影，原URL/body/headers/90秒首次身份调用不变。
        _,status,_=original_request(self,url,body,metadata=True,**kwargs)
        target.update(completed=True,httpStatus=status)
    except Exception as error:
        target.update(completed=False,errorType=type(error).__name__)
    finally:
        target['elapsedMilliseconds']=round((time.monotonic()-started)*1000)
        target['finishedGuestMonotonic']=time.monotonic()
        clock.record('client-finished',requestSequence=1,**({'status':target['httpStatus']} if target.get('completed') else {'errorType':error_name_from_target()}))
        emit('auth-install-started',attempts=1,correlationSha256=target['localCorrelationSha256'],
             observerRegisteredBeforeRequest=observer['registered'],originalClientSeconds=90,
             productBusinessSeconds=30)
        emit('auth-install-finished',**target)
    raise WindowStop()
g.Client.request=request
original_report=g.report
def report(value):
    # 只转发原助手的安全回执；不保存原业务响应。
    original_report(value)
g.report=report
result={'purpose':'only-approved-api-window','fullProductAcceptance':False,'target':target,'observer':observer,
        'sourceHead':expected['sourceHead'],'manifestSha256':expected['manifestSha256'],
        'clientBoundary':'原首次身份Client90秒，安装器产品业务30秒保持且本窗口不执行后者；不改变原调用'}
kernel=subprocess.check_output(['uname','-r']).decode().strip()
gdb_version=subprocess.check_output(['gdb','--version']).decode().splitlines()[0]
assert kernel==expected['expectedKernel']
assert '15.1-1ubuntu1~24.04.1' in gdb_version
runtime_packages=subprocess.check_output(['dpkg-query','-W','-f=${Package}=${Version}\n','docker.io','docker-compose-v2','gdb']).decode().splitlines()
assert sorted(runtime_packages)==sorted(['docker.io=29.1.3-0ubuntu3~24.04.2','docker-compose-v2=2.40.3+ds1-0ubuntu1~24.04.1','gdb=15.1-1ubuntu1~24.04.1'])
emit('driver-started',kernel=kernel,gdbVersion=gdb_version,runtimePackages=runtime_packages)
try:
    g.main()
    result['errorType']='UnexpectedFullJourneyReturn'
except WindowStop:
    result['status']='target-completed' if target.get('completed') else 'target-failed'
except Exception as error:
    result.update(status='prefix-failed',errorType=type(error).__name__)
finally:
    done.set()
    supervisor.join(timeout=2)
    g.command=original_command
    g.subprocess=subprocess  # 后续仅原有只读取证；不得驱动业务。
    if events_process and events_process.poll() is None:
        events_process.terminate()
        try: events_process.wait(timeout=3)
        except subprocess.TimeoutExpired: events_process.kill();events_process.wait(timeout=3)
    if watcher:
        if watcher.result.exists() or not target.get('completed'):
            result['nativeTrace']=watcher.finish()
        else:
            result['nativeTrace']={'coreObserved':False,'captured':False,'captureId':watcher.capture_id,
                                   'meaning':'到目标完成时未见处理回执，只是本样本；非排除历史崩溃'}
            watcher.restore()
        try:
            if process_identity(watcher.identity['pid'])!=watcher.identity:
                raise ValueError('registered target identity changed')
            result['postTargetNodeSha256']=binary_hash(watcher.identity['pid'])
        except (OSError,ValueError): result['postTargetNodeUnavailable']=True
    if observed_container:
        try:
            info=json.loads(subprocess.check_output(['docker','inspect',observed_container],timeout=30))[0]
            result['observedApiState']={k:info['State'][k] for k in ['Running','ExitCode','OOMKilled']}
            result['observedApiState']['RestartCount']=info['RestartCount']
            journal=json.loads((g.ROOT/'enterprise/journal.json').read_bytes())
            result['containerEvents']=g.collect_container_events(journal,[(info,{'id':observed_container,'service':'api'})])
        except Exception as error: result['eventsErrorType']=type(error).__name__
    try:clock.poll_marker(now=time.monotonic()+1)
    except Exception:pass
    result['clockEvidence']=clock.finish()
    result.update(elapsedSeconds=time.monotonic()-began,installActions=g.install_actions,completedChecks=g.checks,
                  samples=g.samples,target=target,observer=observer)
    (g.ROOT/'window-final.json').write_text(json.dumps(result,indent=2)+'\n')
    value={'nonce':expected['nonce'],'kind':'final','value':result}
    emit('window-stopped',status=result.get('status'),targetAttempts=target.get('attempts'))
    try:
        req=urllib.request.Request('http://10.0.2.2:18080/window-receipt',json.dumps(value).encode(),{'content-type':'application/json'})
        with urllib.request.urlopen(req,timeout=3) as response: response.read()
    except Exception: pass
