"""从已归档原助手生成本次诊断包装；不改旧目录或产品。"""
import ast, hashlib, json, shutil
from pathlib import Path

ROOT=Path(__file__).resolve().parent
OLD=ROOT.parent/'ta01-resumption/api-crash-window-a-6g-once'
def read(name):return (OLD/name).read_text(encoding='utf8')
def put(name, data):
    ast.parse(data)
    (ROOT/name).write_text(data,encoding='utf8',newline='\n')
def change(text, before, after):
    assert text.count(before)==1, before[:100]
    return text.replace(before,after)
(ROOT/'source').mkdir(exist_ok=True)
for path in (OLD/'source').glob('*.py'):shutil.copyfile(path,ROOT/'source'/path.name)
shutil.copyfile(OLD/'api_identity.py',ROOT/'api_identity.py')

core=read('source/core_pipe.py')
core=change(core,'from core_metadata import core_location','from core_metadata import core_location\nfrom clock_evidence import write_first_marker')
core=change(core,'def main():\n','def main():\n    entered = time.monotonic()\n    boot_id = Path("/proc/sys/kernel/random/boot_id").read_text().strip()\n')
core=change(core,"        result['captureStage'] = 'binary-hash'",'''        window = json.loads(Path('/opt/server-install/window.json').read_bytes())
        write_first_marker(Path('/root/server-install/clock-first-failure.json'),
                           window['nonce'], boot_id, capture_id, actual, entered)
        result.update(handlerStartedGuestMonotonic=entered, handlerBootId=boot_id)
        result['captureStage'] = 'binary-hash' ''')
put('clock_core_pipe.py',core)

guest=read('diagnostic_guest.py')
guest=change(guest,'from api_identity import select_api','from api_identity import select_api\nfrom clock_evidence import Journal, PrefixRunner, instrument_proxy, error_name')
guest=change(guest,'class WindowStop(BaseException): pass','''class WindowStop(BaseException): pass

boot_id=Path('/proc/sys/kernel/random/boot_id').read_text().strip()
clock=Journal(g.ROOT,expected['nonce'],boot_id)
clock.record('clock-driver-started')
g.subprocess=PrefixRunner(clock,WindowStop,lambda:g.install_actions)
original_command=g.command
def command(*args,**kwargs):
    if clock.stop.is_set():raise WindowStop()
    return original_command(*args,**kwargs)
g.command=command
proxy_sequence=0
def proxy_begin(method,path):
    global proxy_sequence
    if method!='POST' or path!='/api/v1/auth/install':return None
    proxy_sequence+=1
    if proxy_sequence!=1:raise ValueError('clock proxy duplicate target')
    clock.record('proxy-received',requestSequence=proxy_sequence)
    return proxy_sequence
def proxy_stage(token,stage,status=None):
    if token is None:return
    clock.record(stage,requestSequence=token,**({'status':status} if status is not None else {}))
def proxy_failed(token,error):
    if token is not None:clock.record('proxy-failed',requestSequence=token,errorType=error_name(error))
instrument_proxy((BASE/'original_guest.py').read_text(),g.__dict__,proxy_begin,proxy_stage,proxy_failed)
def supervise():
    while not done.is_set():
        try:clock.poll_marker()
        except Exception:return
        if watcher and watcher.result.exists() and clock.marker is None:
            clock.error='projection-failed';clock.stop.set();return
        done.wait(1)
supervisor=threading.Thread(target=supervise,daemon=True)
supervisor.start()''')
guest=change(guest,"                observer.update(registered=True", "                clock.bind(watcher.capture_id,watcher.identity)\n                observer.update(registered=True")
guest=change(guest,"    if observer.get('errorType') or (watcher and watcher.result.exists()):",'''    clock.poll_marker()
    if clock.stop.is_set() or observer.get('errorType') or (watcher and watcher.result.exists()):
        clock.record('client-skipped',result='early-handler' if clock.marker else 'observer-rejected')''')
guest=change(guest,"    emit('auth-install-started'", "    clock.record('client-intent',requestSequence=1)\n    emit('auth-install-started'")
# emit原本有同步HTTP回执；移到客户端调用后，避免观测投递推迟原请求。
begin=guest.index("    emit('auth-install-started'")
end=guest.index('    started=time.monotonic()',begin)
old_emit='\n'.join('    '+line for line in guest[begin:end].splitlines())+'\n'
guest=guest[:begin]+guest[end:]
guest=change(guest,"        target['finishedGuestMonotonic']=time.monotonic()", "        target['finishedGuestMonotonic']=time.monotonic()\n        clock.record('client-finished',requestSequence=1,**({'status':target['httpStatus']} if target.get('completed') else {'errorType':error_name_from_target()}))\n"+old_emit.rstrip())
guest=change(guest,'original_request=g.Client.request', '''def error_name_from_target():
    from clock_evidence import ERRORS
    return target.get('errorType') if target.get('errorType') in ERRORS else 'OtherError'
original_request=g.Client.request''')
guest=change(guest,'    done.set()','    done.set()\n    supervisor.join(timeout=2)\n    g.command=original_command\n    g.subprocess=subprocess  # 后续仅原有只读取证；不得驱动业务。')
guest=change(guest,"emit('driver-started',kernel=kernel,gdbVersion=gdb_version)","""runtime_packages=subprocess.check_output(['dpkg-query','-W','-f=${Package}=${Version}\\n','docker.io','docker-compose-v2','gdb']).decode().splitlines()
assert sorted(runtime_packages)==sorted(['docker.io=29.1.3-0ubuntu3~24.04.2','docker-compose-v2=2.40.3+ds1-0ubuntu1~24.04.1','gdb=15.1-1ubuntu1~24.04.1'])
emit('driver-started',kernel=kernel,gdbVersion=gdb_version,runtimePackages=runtime_packages)""")
guest=change(guest,'    result.update(elapsedSeconds=', '''    try:clock.poll_marker(now=time.monotonic()+1)
    except Exception:pass
    result['clockEvidence']=clock.finish()
    result.update(elapsedSeconds=''')
put('diagnostic_guest.py',guest)

host=read('run_window.py')
host=change(host,'from pathlib import Path','from pathlib import Path\nfrom clock_evidence import validate_record, MAX_RECORDS, MAX_BYTES')
host=change(host,'nonce=uuid.uuid4().hex;receipts=[];events=[];lock=threading.Lock()', 'nonce=uuid.uuid4().hex;receipts=[];events=[];lock=threading.Lock();clock_rows=[];clock_failure=threading.Event()')
host=change(host,"        if self.path not in {'/receipt','/window-receipt'}", "        if self.path not in {'/receipt','/window-receipt','/clock-receipt'}")
host=change(host,"        value=json.loads(raw)\n        if self.path",'''        value=json.loads(raw)
        if self.path=='/clock-receipt':
            try:
                if size>MAX_BYTES:raise ValueError('clock bytes')
                validate_record(value)
                with lock:
                    if value['nonce']!=nonce or value['sequence']!=len(clock_rows)+1 or len(clock_rows)>=MAX_RECORDS:raise ValueError('clock sequence')
                    clock_rows.append(value.copy())
                append(value);self.send_response(200);self.end_headers();return
            except Exception:
                clock_failure.set();self.send_error(400);return
        if self.path''')
host=change(host,"['native_diagnostic.py','core_pipe.py','core_metadata.py']", "['native_diagnostic.py','core_metadata.py']")
host=change(host,"'guest.py':(BASE/'diagnostic_guest.py').read_bytes()", "'core_pipe.py':(BASE/'clock_core_pipe.py').read_bytes(),\n         'clock_evidence.py':(BASE/'clock_evidence.py').read_bytes(),\n         'guest.py':(BASE/'diagnostic_guest.py').read_bytes()")
host=change(host,"            if any(x.get('stage')", "            if clock_failure.is_set():\n                report['clockProjectionRejected']=True;process.terminate();break\n            if any(x.get('stage')")
host=change(host,'report.update(totalSeconds=', 'report.update(clockRecords=clock_rows,totalSeconds=')
put('run_window.py',host)

execute=read('execute_once.py').replace(".tmp/ta01-resumption/api-crash-window-a-6g-once", ".tmp/ta01-clock-a-once")
execute=execute.replace("['run_window.py','diagnostic_guest.py','api_identity.py']", "['run_window.py','diagnostic_guest.py','api_identity.py','clock_evidence.py','clock_core_pipe.py']")
execute=change(execute,"'window':'A'", "'window':'new-clock-A'")
execute=change(execute,"assert not ledger['vmStarted']", "assert ledger['exactToolsVerified'] and ledger['wrapperTestsPassed'] and ledger['inputsCopiedAndAstChecked']\nassert not ledger['vmStarted']")
execute=change(execute,"memory=call(['exec',cid,'cat','/proc/meminfo'])", """assert call(['exec',cid,'test','!','-d','/opt/api-window/guest']).returncode==0
names=call(['exec',cid,'ps','-eo','comm']);assert names.returncode==0
assert not any(x in names.stdout for x in [b'qemu-system',b'python'])
bindings=json.loads((ROOT/'wrapper-bindings.json').read_bytes())
for name,digest in bindings['originals'].items():
    actual=call(['exec',cid,'cat','/opt/api-window/source/'+name]);assert actual.returncode==0 and hashlib.sha256(actual.stdout).hexdigest()==digest
memory=call(['exec',cid,'cat','/proc/meminfo'])""")
put('execute_once.py',execute)
bindings={'originals':{p.name:hashlib.sha256(p.read_bytes()).hexdigest() for p in (ROOT/'source').glob('*.py')},
          'diagnostic':{n:hashlib.sha256((ROOT/n).read_bytes()).hexdigest() for n in ['clock_evidence.py','clock_core_pipe.py','diagnostic_guest.py','run_window.py','execute_once.py','api_identity.py']},
          'baseHead':'02ae2085a6bbc891ab116b7a6ba4e41751a734e2','sourceHead':'9c8bbff749c1d2a52a3e6489dcec02d2d7c859af'}
(ROOT/'wrapper-bindings.json').write_text(json.dumps(bindings,indent=2)+'\n',encoding='utf8')
print(json.dumps({'generatedAndAstParsed':list(bindings['diagnostic'])}))
