"""归档新A安全原字节；必须先有同台终态与归属收尾证明。"""
from pathlib import Path
from datetime import datetime,timezone
import ast,hashlib,json,re,subprocess,zipfile
ROOT=Path(__file__).resolve().parent
OUT=Path('docs/reviews/ta01-product/amd64-api139-clock-a')
OLD=ROOT.parent/'ta01-resumption/api-crash-window-a-6g-once'
sha=lambda raw:hashlib.sha256(raw).hexdigest()
blob=lambda raw:hashlib.sha1(b'blob '+str(len(raw)).encode()+b'\0'+raw).hexdigest()
ledger=json.loads((ROOT/'resources.json').read_bytes());result=json.loads((ROOT/'result.json').read_bytes())
assert ledger['removedAndAbsent'] and ledger['vmStarted']
assert result['maximumSeconds']==9000 and result['oneVmOnly'] and result['fullProductAcceptance'] is False
assert result['sourceHead']=='9c8bbff749c1d2a52a3e6489dcec02d2d7c859af'
assert result['manifestSha256']=='c34733df5e9d45ac6fddbc504a45540779e252071d55fe22eb9bfbee2744028b'
assert result['qemuBinarySha256']=='8a35ccba41582fc6c38b9df85fc9e35fa1d42f414d2d7d8090ee9b2f5e7c0854'
assert result['actualQemuStart']['qemuPid']==3099 and result['actualQemuStart']['startTicks']==66092994
assert result['actualTargetAttempts'] in [0,1,'unknown']
for name,digest in ledger['diagnosticSourceSha256'].items():
    assert sha((ROOT/name).read_bytes())==sha((ROOT/('actual-'+name)).read_bytes())==digest
    ast.parse((ROOT/name).read_text(encoding='utf8'))
absent=subprocess.run(['docker','inspect',ledger['containers'][0]['id']],capture_output=True,timeout=30)
assert absent.returncode!=0 and b'no such object' in absent.stderr.lower()
members={};source_bindings=[]
for path in sorted(ROOT.iterdir()):
    if path.is_file() and not path.name.startswith('live-') and path.name!='preparation-inspect.stdout':
        assert path.suffix in {'.json','.py','.stdout','.stderr','.txt','.ndjson','.log'},path.name
        members[path.name]=path.read_bytes()
for path in sorted((ROOT/'source').glob('*.py')):
    logical='scripts/server-distribution/'+path.name
    data=subprocess.check_output(['git','show',result['sourceHead']+':'+logical])
    assert data==path.read_bytes()
    source_bindings.append({'path':logical,'commit':result['sourceHead'],'actualGitBlob':subprocess.check_output(['git','rev-parse',result['sourceHead']+':'+logical]).decode().strip(),
                            'bytes':len(data),'sha256':sha(data),'coreHandlerRuntime':'diagnostic/clock_core_pipe.py' if path.name=='core_pipe.py' else '原助手字节'})
    members['original-source/'+path.name]=data
plan=subprocess.check_output(['git','show','02ae2085:docs/plan/ta01-self-hosted-deployment/amd64-api139-next-gate.md'])
members['approved-plan-02ae2085.md']=plan
members['manifest.json']=(OLD/'distribution/manifest.json').read_bytes()
for name,data in members.items():
    assert len(data)<4*1024*1024,name
    assert not re.search(rb'wm[ips]_[A-Za-z0-9_-]{43}|-----BEGIN (?:RSA |EC |OPENSSH )?PRIVATE KEY-----',data),name
    assert not data.startswith(b'\x7fELF') and not name.endswith(('.qcow2','.img','.core')),name
with zipfile.ZipFile(OUT.with_suffix('.zip'),'x',zipfile.ZIP_DEFLATED) as archive:
    for name,data in members.items():archive.writestr(name,data)
with zipfile.ZipFile(OUT.with_suffix('.zip')) as archive:
    assert archive.testzip() is None and set(archive.namelist())==set(members)
    for name,data in members.items():assert archive.read(name)==data
zip_bytes=OUT.with_suffix('.zip').read_bytes()
index={'observedUtc':datetime.now(timezone.utc).isoformat(),
       'source':'用户13:03原卡q-PiHASaTSNU-05WBsiC5me新A单台的安全原件；不是完整产品验收或139闭合',
       'branch':'tds/conv-01a1572a-7aeb-7b6d-b7e8-83e89c2b723d','analysisBaseHead':'02ae2085a6bbc891ab116b7a6ba4e41751a734e2',
       'interruptionCheckpoint':'ee0ffd44bfe71fec7eb870595f50d94d207990b3','productSourceHead':result['sourceHead'],
       'sourceBindings':source_bindings,'runtimeDiagnosticBindings':ledger['diagnosticSourceSha256'],
       'authorization':json.loads((ROOT/'authorization.json').read_bytes()),
       'authorizationConfirmation':json.loads((ROOT/'authorization-confirmation.json').read_bytes()),
       'result':result,'outer':{'containerId':ledger['containers'][0]['id'],'owner':ledger['owner'],
           'memoryBytes':6442450944,'memorySwapTotalBytes':6442450944,'cpuQuota':4,
           'lifetimePeakBytes':int((ROOT/'outer-memory.peak.txt').read_text()),
           'memoryEvents':(ROOT/'outer-memory.events.txt').read_text(),
           'capacityBeforeLaunch':json.loads((ROOT/'capacity-before-launch.json').read_bytes()),
           'beforeStop':ledger['beforeStop'],'afterStop':ledger['afterStop'],
           'eventBoundary':'固定字段原事件；峰值为容器创建以来累计，含准备、复制及本次VM，不是纯QEMU RSS',
           'hostLauncherExitCode':'unknown-after-host-checkpoint'},
       'cleanup':json.loads((ROOT/'cleanup-verification.json').read_bytes()),
       'privateCoreMemorySecretsRawGdbOrDiskArchived':False,'noRetryNoMcpNoBNoMatrix':True,
       'p1State':{'p1-1':'正式复审已闭合','api139':'未闭','mcp139':'未闭'},
       'selectedZipSha256':sha(zip_bytes),'archiveBytes':len(zip_bytes),'expectedUnfilteredZipGitBlob':blob(zip_bytes),
       'gitByteBoundary':'ZIP -text；待提交后另核实际Git blob。普通JSON本地CRLF可能入Git转LF；不把两种字节混作原件。',
       'members':{name:{'bytes':len(data),'sha256':sha(data),'rawUnfilteredBlobId':blob(data)} for name,data in members.items()}}
OUT.with_suffix('.json').write_text(json.dumps(index,ensure_ascii=False,indent=2)+'\n',encoding='utf8')
print(json.dumps({'members':len(members),'zipSha256':sha(zip_bytes),'expectedZipGitBlob':blob(zip_bytes),'sampleStatus':result['status'],'targetAttempts':result['actualTargetAttempts']}))
