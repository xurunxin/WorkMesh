"""一台9000秒上限原组合窗口；不自动重试或续轮。"""
import base64, hashlib, json, os, re, socket, subprocess, threading, time, uuid
from datetime import datetime, timezone
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
from pathlib import Path
from clock_evidence import validate_record, MAX_RECORDS, MAX_BYTES

BASE=Path('/opt/api-window');ROOT=BASE/'guest';ROOT.mkdir(exist_ok=False)
began=time.monotonic();limit=9000
def sha(p):
    with p.open('rb') as f:return hashlib.file_digest(f,'sha256').hexdigest()
expected=json.loads((BASE/'input-preflight.json').read_bytes())
manifest=json.loads((BASE/'distribution/manifest.json').read_bytes())
assert sha(BASE/'distribution/manifest.json')==expected['manifestSha256']
assert manifest['source']['commit']==expected['sourceHead']
assert sha(BASE/'amd64.img')=='6a81c37564db9b1ee84e141922625e1d7c5b389b99bb3c572e0243607d5bb4d2'
version=subprocess.check_output(['qemu-system-x86_64','--version']).decode().splitlines()[0]
assert version=='QEMU emulator version 8.2.2 (Debian 1:8.2.2+ds-0ubuntu1.18)'
assert sha(Path('/usr/bin/qemu-system-x86_64'))=='8a35ccba41582fc6c38b9df85fc9e35fa1d42f414d2d7d8090ee9b2f5e7c0854'
served={'manifest.json',*[x['path'] for x in manifest['files']+manifest['chunks']+manifest['bootstrapChunks']]}
for entry in {x['path']:x for x in manifest['files']+manifest['chunks']+manifest['bootstrapChunks']}.values():
    p=BASE/'distribution'/entry['path'];assert p.stat().st_size==entry['bytes'] and sha(p)==entry['sha256']
nonce=uuid.uuid4().hex;receipts=[];events=[];lock=threading.Lock();clock_rows=[];clock_failure=threading.Event()
def append(value):
    value.update(hostUtc=time.time(),hostElapsed=time.monotonic()-began)
    with lock:
        receipts.append(value)
        with (ROOT/'receipts.ndjson').open('a') as out:
            out.write(json.dumps(value)+'\n');out.flush();os.fsync(out.fileno())
class Handler(BaseHTTPRequestHandler):
    def do_GET(self):
        name=self.path.removeprefix('/distribution/')
        if not self.path.startswith('/distribution/') or name not in served:self.send_error(404);return
        p=BASE/'distribution'/name;self.send_response(200);self.send_header('Content-Length',str(p.stat().st_size));self.end_headers()
        with p.open('rb') as f:
            while b:=f.read(1048576):self.wfile.write(b)
    def do_POST(self):
        size=int(self.headers.get('Content-Length','0'))
        if self.path not in {'/receipt','/window-receipt','/clock-receipt'} or not 0<size<=1048576:self.send_error(400);return
        raw=self.rfile.read(size)
        if re.search(rb'wm[ips]_[A-Za-z0-9_-]{43}|-----BEGIN .*PRIVATE KEY',raw):self.send_error(400);return
        value=json.loads(raw)
        if self.path=='/clock-receipt':
            try:
                if size>MAX_BYTES:raise ValueError('clock bytes')
                validate_record(value)
                with lock:
                    if value['nonce']!=nonce or value['sequence']!=len(clock_rows)+1 or len(clock_rows)>=MAX_RECORDS:raise ValueError('clock sequence')
                    clock_rows.append(value.copy())
                append(value);self.send_response(200);self.end_headers();return
            except Exception:
                clock_failure.set();self.send_error(400);return
        if self.path=='/window-receipt' and value.get('nonce')!=nonce:self.send_error(400);return
        if self.path=='/receipt':value={'kind':'original-guest-receipt','value':value}
        append(value);self.send_response(200);self.end_headers()
    def log_message(self,*_):pass
server=ThreadingHTTPServer(('127.0.0.1',18080),Handler)
threading.Thread(target=server.serve_forever,daemon=True).start()
scripts={'original_guest.py':(BASE/'source/guest.py').read_bytes(),
         **{n:(BASE/'source'/n).read_bytes() for n in ['native_diagnostic.py','core_metadata.py']},
         'core_pipe.py':(BASE/'clock_core_pipe.py').read_bytes(),
         'clock_evidence.py':(BASE/'clock_evidence.py').read_bytes(),
         'guest.py':(BASE/'diagnostic_guest.py').read_bytes(),'api_identity.py':(BASE/'api_identity.py').read_bytes()}
script_hashes={n:hashlib.sha256(b).hexdigest() for n,b in scripts.items()}
window={'nonce':nonce,'sourceHead':expected['sourceHead'],'manifestSha256':expected['manifestSha256'],
        'scripts':script_hashes,'expectedKernel':'6.8.0-142-generic'}
files=[('/opt/server-install/'+n,b,'0644') for n,b in scripts.items()]
files+=[('/opt/server-install/window.json',json.dumps(window).encode(),'0644'),
        ('/opt/server-install/expected.json',json.dumps({'manifestSha256':expected['manifestSha256'],
            'sourceHead':expected['sourceHead'],'arch':'amd64','nativeDiagnostic':False,'profiles':['enterprise']}).encode(),'0644')]
wrapper=b'''#!/bin/sh
test ! -e /root/node_modules && test ! -e /repo && test ! -e /workspace && test ! -e /workmesh || { systemctl --no-block poweroff; exit 1; }
test -z "$(command -v node || true)" || { systemctl --no-block poweroff; exit 1; }
PYTHONDONTWRITEBYTECODE=1 python3 /opt/server-install/guest.py
status=$?
systemctl --no-block poweroff
exit "$status"
'''
service=b'''[Unit]
Description=WorkMesh approved API original failure window
After=cloud-final.service network-online.target docker.service
Wants=network-online.target docker.service
[Service]
Type=oneshot
StandardOutput=journal+console
StandardError=journal+console
ExecStart=/opt/server-install/finish.sh
TimeoutStartSec=7200
[Install]
WantedBy=cloud-init.target
'''
files += [('/opt/server-install/finish.sh',wrapper,'0755'),('/etc/systemd/system/server-install.service',service,'0644')]
cloud='#cloud-config\napt:\n  conf: |\n    APT::Install-Recommends "false";\n    APT::Install-Suggests "false";\nusers:\n  - name: wmprobe\n    uid: 22020\n    lock_passwd: true\n    shell: /bin/sh\npackage_update: true\npackages:\n  - docker.io\n  - docker-compose-v2\n  - openssl\n  - [gdb, "15.1-1ubuntu1~24.04.1"]\nwrite_files:\n'
for path,data,mode in files:
    cloud+=f"  - path: {path}\n    encoding: b64\n    permissions: '{mode}'\n    content: {base64.b64encode(data).decode()}\n"
cloud+='runcmd:\n  - [systemctl, daemon-reload]\n  - [systemctl, enable, server-install.service]\n  - [systemctl, start, --no-block, server-install.service]\n'
(ROOT/'user-data').write_text(cloud);(ROOT/'meta-data').write_text('instance-id: api-window-'+nonce+'\nlocal-hostname: server-product\n')
subprocess.run(['genisoimage','-quiet','-output',str(ROOT/'seed.iso'),'-volid','cidata','-joliet','-rock',str(ROOT/'user-data'),str(ROOT/'meta-data')],check=True,capture_output=True)
subprocess.run(['qemu-img','create','-f','qcow2','-F','qcow2','-b',str(BASE/'amd64.img'),str(ROOT/'root.qcow2'),'40G'],check=True,capture_output=True)
args=['qemu-system-x86_64','-accel','tcg','-m','4096','-smp','4','-display','none','-serial','file:'+str(ROOT/'serial.log'),
      '-qmp','unix:'+str(ROOT/'qmp.sock')+',server=on,wait=off','-netdev','user,id=net0','-device','virtio-net-pci,netdev=net0',
      '-drive','if=virtio,format=qcow2,file='+str(ROOT/'root.qcow2'),'-drive','if=virtio,format=raw,readonly=on,file='+str(ROOT/'seed.iso')]
report={'sourceHead':expected['sourceHead'],'manifestSha256':expected['manifestSha256'],'qemuVersion':version,
        'qemuBinarySha256':sha(Path('/usr/bin/qemu-system-x86_64')),'guestSha256':sha(BASE/'amd64.img'),
        'scripts':script_hashes,'command':args,'maximumSeconds':limit,'seedSha256':sha(ROOT/'seed.iso'),
        'fullProductAcceptance':False,'oneVmOnly':True,'requestBoundary':'原首次身份Client90；原安装器产品30保持、不执行MCP'}
report['preparationOnly']=True
report['preparedUtc']=datetime.now(timezone.utc).isoformat()
report['outerCgroup']={n:Path('/sys/fs/cgroup',n).read_text().strip() for n in ['memory.max','memory.swap.max','cpu.max']}
(ROOT/'started.json').write_text(json.dumps(report,indent=2)+'\n')
process=None
def qmp():
    try:
        channel=socket.socket(socket.AF_UNIX)
        for _ in range(100):
            try:channel.connect(str(ROOT/'qmp.sock'));break
            except OSError:time.sleep(.1)
        else:return
        stream=channel.makefile('rwb');stream.readline();stream.write(b'{"execute":"qmp_capabilities"}\n');stream.flush()
        for raw in stream:
            value=json.loads(raw)
            if 'event' in value:events.append({'event':value['event'],'hostElapsed':time.monotonic()-began})
    except OSError:pass
try:
    with (ROOT/'qemu-stderr.log').open('wb') as err:
        process=subprocess.Popen(args,stdout=subprocess.DEVNULL,stderr=err)
        actual_start={'qemuPid':process.pid,'qemuStartedUtc':datetime.now(timezone.utc).isoformat(),
                      'controllerElapsed':time.monotonic()-began,'qemuBinarySha256':report['qemuBinarySha256'],
                      'startTicks':int(Path(f'/proc/{process.pid}/stat').read_text().rsplit(')',1)[1].split()[19])}
        (ROOT/'qemu-started.json').write_text(json.dumps(actual_start,indent=2)+'\n')
        report['actualQemuStart']=actual_start
        threading.Thread(target=qmp,daemon=True).start()
        while process.poll() is None:
            if clock_failure.is_set():
                report['clockProjectionRejected']=True;process.terminate();break
            if any(x.get('stage') in {'api-observer-error','api-observer-missing'} for x in receipts):
                report['observerPreparationStoppedWindow']=True;process.terminate();break
            if time.monotonic()-began>=limit:
                report['deadlineReached']=True;process.terminate();break
            time.sleep(1)
        report['qemuExitCode']=process.wait(timeout=max(1,min(15,limit-(time.monotonic()-began))))
finally:
    if process and process.poll() is None:process.kill();process.wait(timeout=10)
    report.update(clockRecords=clock_rows,totalSeconds=time.monotonic()-began,receipts=receipts,qmpEvents=events)
    finals=[x['value'] for x in receipts if x.get('kind')=='final']
    report['final']=finals[0] if len(finals)==1 else None
    report['status']='sample-completed' if report.get('qemuExitCode')==0 and not report.get('deadlineReached') and len(finals)==1 else 'incomplete-or-failed'
    report['actualTargetAttempts']=finals[0]['target']['attempts'] if len(finals)==1 else 'unknown'
    (ROOT/'result.json').write_text(json.dumps(report,indent=2)+'\n');server.shutdown();server.server_close()
print(json.dumps({k:report[k] for k in ['status','totalSeconds','actualTargetAttempts']}))
