"""只读核同一外部执行；没有启动、重启或延长窗口的操作。"""
from pathlib import Path
from datetime import datetime,timezone
import hashlib,json,subprocess
ROOT=Path(__file__).resolve().parent
ledger=json.loads((ROOT/'resources.json').read_bytes());cid=ledger['containers'][0]['id']
def call(args):return subprocess.run(['docker',*args],capture_output=True,timeout=30,check=True).stdout
info=json.loads(call(['inspect',cid]))[0]
assert info['Id']==cid and info['Config']['Labels'][ledger['label']]==ledger['owner'] and not info['Mounts']
program="""from pathlib import Path
import hashlib,json,os,time
r=Path('/opt/api-window/guest');start=json.loads((r/'qemu-started.json').read_bytes());pid=start['qemuPid']
parts=Path(f'/proc/{pid}/stat').read_text().rsplit(')',1)[1].split()
assert pid==3099 and int(parts[19])==start['startTicks']==66092994
ppid=int(parts[1]);p=Path(f'/proc/{ppid}');controller=p.joinpath('stat').read_text().rsplit(')',1)[1].split()
assert p.joinpath('cmdline').read_bytes()==b'python3\\0/opt/api-window/run_window.py\\0'
elapsed=time.monotonic()-int(parts[19])/os.sysconf('SC_CLK_TCK')+start['controllerElapsed']
print(json.dumps({'qemuPid':pid,'qemuStartTicks':int(parts[19]),'controllerPid':ppid,'controllerStartTicks':int(controller[19]),
 'controllerSha256':hashlib.sha256(Path('/opt/api-window/run_window.py').read_bytes()).hexdigest(),
 'originalWindowMaximumSeconds':9000,'originalWindowElapsedApproxSeconds':elapsed,'originalBudgetRemainingApproxSeconds':max(0,9000-elapsed),
 'approximation':'same Linux monotonic and process start ticks; clock tick quantization; original controller remains authoritative',
 'finalAvailable':r.joinpath('result.json').exists()}))"""
value=json.loads(call(['exec',cid,'python3','-c',program]))
assert value['controllerSha256']==ledger['diagnosticSourceSha256']['run_window.py']
value.update(observedUtc=datetime.now(timezone.utc).isoformat(),containerId=cid,owner=ledger['owner'],
             currentBranchHead=subprocess.check_output(['git','rev-parse','HEAD']).decode().strip(),
             noNewVmOrBudgetReset=True,hostLauncherSession='原79333已不可查询；当前无本任务execute_once.py宿主进程，Linux控制器仍在运行')
(ROOT/'interruption-resume.json').write_text(json.dumps(value,ensure_ascii=False,indent=2)+'\n',encoding='utf8')
print(json.dumps(value))
