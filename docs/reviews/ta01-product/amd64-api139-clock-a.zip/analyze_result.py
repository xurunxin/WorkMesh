"""只核本次安全回执的一致性；不从成功样本推导139因果。"""
from pathlib import Path
from datetime import datetime,timezone
import hashlib,json,subprocess
from clock_evidence import validate_record
ROOT=Path(__file__).resolve().parent
r=json.loads((ROOT/'result.json').read_bytes());f=r['final'];clock=f['clockEvidence'];rows=clock['records']
assert r['status']=='sample-completed' and r['qemuExitCode']==0 and not r.get('deadlineReached')
assert r['actualTargetAttempts']==f['target']['attempts']==1 and f['target']['httpStatus']==200
assert f['installActions']==8 and clock['firstFailure'] is None
assert not clock['projectionError'] and not clock['transportError'] and clock['pendingTransport']==0
assert clock['recordsSent']==len(rows)==9
assert [v['sequence'] for v in rows]==list(range(1,10))
assert [v['stage'] for v in rows]==['clock-driver-started','client-intent','proxy-received','proxy-forward-intent',
    'proxy-request-sent','proxy-upstream-headers','proxy-upstream-complete','proxy-client-complete','client-finished']
assert len({v['bootId'] for v in rows})==1 and rows[0]['bootId']==clock['bootId']
assert all(rows[i]['guestMonotonic']<=rows[i+1]['guestMonotonic'] for i in range(8))
for value in rows:
    validate_record(value)
    if value['sequence']>1:
        assert value['captureId']==f['observer']['captureId'] and value['target']==f['observer']['registeredIdentity']
receipts=[json.loads(line) for line in (ROOT/'receipts.ndjson').read_bytes().splitlines()]
sent=[{k:v for k,v in row.items() if k not in ['hostUtc','hostElapsed']} for row in receipts if row.get('kind')=='clock']
assert rows==sent
assert max(len(json.dumps(v,separators=(',',':')).encode()) for v in receipts if v.get('kind')=='clock')<=4096
assert not f['containerEvents']['events'] and not f['containerEvents']['truncated']
assert f['observedApiState']=={'Running':True,'ExitCode':0,'OOMKilled':False,'RestartCount':0}
assert f['postTargetNodeSha256']=='638c77326270093b1251a5e72b4335c94c74856a210460341c73d6f3da647328'
eventfields=dict(line.split() for line in (ROOT/'outer-memory.events.txt').read_text().splitlines())
assert all(int(eventfields[key])==0 for key in ['max','oom','oom_kill','oom_group_kill'])
value={'observedUtc':datetime.now(timezone.utc).isoformat(),'scope':'只核当前安全回执；无新实验、产品、矩阵、CI或成果审',
    'recordCount':9,'recordLimit':32,'sameGuestBoot':clock['bootId'],'ownerCaptureId':f['observer']['captureId'],
    'targetAttempts':1,'requestSequence':1,'status':200,'clientMilliseconds':f['target']['elapsedMilliseconds'],
    'clockTimeline':[{k:v[k] for k in ['sequence','stage','guestMonotonic','status'] if k in v} for v in rows],
    'maximumSerializedHostClockRecordBytes':max(len(json.dumps(v,separators=(',',':')).encode()) for v in receipts if v.get('kind')=='clock'),
    'firstFailure':None,'nodeBinarySha256':f['postTargetNodeSha256'],
    'sourceAndBudgets':'原CI562企业候选与Node/QEMU/guest/设备不变，旧HTTP90/业务30/安装1800/健康180/handler90/GDB60/全窗9000不变',
    'termination':{'seconds':r['totalSeconds'],'qemuExitCode':r['qemuExitCode'],'qmp':r['qmpEvents'],'reason':'目标完成后原finish.sh关闭同一guest；未到期、未重试'},
    'causalConclusion':'本次没有可见故障，不能检验首败相对请求的边界假说，更不能修复或关闭旧API139/MCP139；同钟请求顺序只属于本样本。',
    'hostInterruption':'原启动包装没有最终stdout/exitCode留存；Linux控制器原件可核终态。未补造宿主退出码。',
    'noPrivateCoreOrRawGdbRetained':True,'noAdditionalRun':True}
(ROOT/'analysis.json').write_text(json.dumps(value,ensure_ascii=False,indent=2)+'\n',encoding='utf8')
print(json.dumps({'checks':'passed','records':9,'targetAttempts':1,'clientMilliseconds':value['clientMilliseconds'],'maxRecordBytes':value['maximumSerializedHostClockRecordBytes']}))
