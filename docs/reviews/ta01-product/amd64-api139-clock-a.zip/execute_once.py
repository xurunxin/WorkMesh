from pathlib import Path
from datetime import datetime,timezone
import ast,hashlib,json,subprocess,time

ROOT=Path('.tmp/ta01-clock-a-once')
ledger=json.loads((ROOT/'resources.json').read_text(encoding='utf8'))
cid=ledger['containers'][0]['id']
assert ledger['exactToolsVerified'] and ledger['wrapperTestsPassed'] and ledger['inputsCopiedAndAstChecked']
assert not ledger['vmStarted'] and not (ROOT/'attempt-started.json').exists()
def save():(ROOT/'resources.json').write_text(json.dumps(ledger,ensure_ascii=False,indent=2)+'\n',encoding='utf8')
def call(args,timeout=60):return subprocess.run(['docker',*args],capture_output=True,timeout=timeout)
for name in ['run_window.py','diagnostic_guest.py','api_identity.py','clock_evidence.py','clock_core_pipe.py']:ast.parse((ROOT/name).read_text(encoding='utf8'))
value=json.loads(call(['inspect',cid]).stdout)[0]
assert value['Id']==cid and value['Config']['Labels'][ledger['label']]==ledger['owner'] and not value['Mounts']
assert not value['HostConfig']['Privileged'] and not value['HostConfig'].get('Devices') and not value['HostConfig'].get('PortBindings')

assert value['HostConfig']['Memory']==value['HostConfig']['MemorySwap']==6442450944 and value['HostConfig']['NanoCpus']==4_000_000_000
assert call(['exec',cid,'test','!','-d','/opt/api-window/guest']).returncode==0
names=call(['exec',cid,'ps','-eo','comm']);assert names.returncode==0
assert not any(x in names.stdout for x in [b'qemu-system',b'python'])
bindings=json.loads((ROOT/'wrapper-bindings.json').read_bytes())
for name,digest in bindings['originals'].items():
    actual=call(['exec',cid,'cat','/opt/api-window/source/'+name]);assert actual.returncode==0 and hashlib.sha256(actual.stdout).hexdigest()==digest
memory=call(['exec',cid,'cat','/proc/meminfo']);assert memory.returncode==0
fields={k:int(v.split()[0]) for k,v in (line.split(':',1) for line in memory.stdout.decode().splitlines()) if k in ['MemTotal','MemAvailable','SwapTotal','SwapFree']}
capacity={'observedAt':datetime.now(timezone.utc).isoformat(),'hostMeminfoKiB':fields,'requiredHostAvailableBytes':6442450944,'admissionPassed':fields['MemAvailable']*1024>=6442450944}
(ROOT/'capacity-before-launch.json').write_text(json.dumps(capacity,indent=2)+'\n',encoding='utf8')
if not capacity['admissionPassed']:
    ledger['launchStoppedForCapacity']=True
    ledger['preparationContainerPreserved']=True;save()
    raise SystemExit('capacity insufficient; no QEMU launch, no retry')
for name in ['run_window.py','diagnostic_guest.py','api_identity.py','clock_evidence.py','clock_core_pipe.py']:
    actual=call(['exec',cid,'cat','/opt/api-window/'+name]);assert actual.returncode==0
    assert hashlib.sha256(actual.stdout).hexdigest()==hashlib.sha256((ROOT/name).read_bytes()).hexdigest()

ledger.update(vmLaunchCommandInvoked=True,launchUtc=datetime.now(timezone.utc).isoformat(),
              command=['docker','exec',cid,'python3','/opt/api-window/run_window.py'],
              externalNetwork='仅原guest准备从Ubuntu源获取Docker/固定GDB；原程序下载候选后删除默认路由，业务不联网拉镜像',
              diagnosticSourceSha256={n:hashlib.sha256((ROOT/n).read_bytes()).hexdigest() for n in ['run_window.py','diagnostic_guest.py','api_identity.py','clock_evidence.py','clock_core_pipe.py']})
save()
with (ROOT/'attempt-started.json').open('x',encoding='utf8') as out:
    out.write(json.dumps({'at':ledger['launchUtc'],'maximumSeconds':9000,'oneVmOnly':True,'noRetry':True,'window':'new-clock-A'})+'\n')
start=time.monotonic()
try:
    try:
        value=call(['exec',cid,'python3','/opt/api-window/run_window.py'],9030)
        ledger['runnerExitCode']=value.returncode
        (ROOT/'runner.stdout').write_bytes(value.stdout);(ROOT/'runner.stderr').write_bytes(value.stderr)
    except subprocess.TimeoutExpired:
        ledger['outerCleanupBackstopReached']=True
finally:
    ledger['runnerSeconds']=time.monotonic()-start;save()
    for name in ['result.json','started.json','qemu-started.json','receipts.ndjson','serial.log','qemu-stderr.log']:
        value=call(['exec',cid,'cat','/opt/api-window/guest/'+name],30)
        if value.returncode==0:(ROOT/name).write_bytes(value.stdout)
    ledger['vmPrepared']=(ROOT/'started.json').exists()
    ledger['vmStarted']=(ROOT/'qemu-started.json').exists()
    if (ROOT/'result.json').exists():
        result=json.loads((ROOT/'result.json').read_text());ledger['vmResult']={k:result.get(k) for k in ['status','totalSeconds','qemuExitCode','deadlineReached','actualTargetAttempts']}
    value=call(['exec',cid,'sh','-c','ps -eo comm | sort | uniq -c'])
    if value.returncode==0:(ROOT/'process-names-before-stop.txt').write_bytes(value.stdout)
    for name in ['memory.current','memory.peak','memory.max','memory.swap.max','memory.events','cpu.max']:
        snapshot=call(['exec',cid,'cat','/sys/fs/cgroup/'+name])
        if snapshot.returncode==0:(ROOT/('outer-'+name+'.txt')).write_bytes(snapshot.stdout)
    events=call(['events','--since',ledger['createdAt'],'--until',datetime.now(timezone.utc).isoformat(),
                 '--filter','container='+cid,'--format','{{json .}}'])
    if events.returncode==0:
        safe_events=[]
        for raw in events.stdout.splitlines():
            event=json.loads(raw)
            safe_events.append({'id':event.get('id',event.get('Actor',{}).get('ID')),
                                'action':event.get('Action',event.get('status')),'timeNano':event.get('timeNano')})
        (ROOT/'outer-events-before-stop.json').write_text(json.dumps(safe_events,indent=2)+'\n',encoding='utf8')
    value=json.loads(call(['inspect',cid]).stdout)[0]
    assert value['Id']==cid and value['Config']['Labels'][ledger['label']]==ledger['owner'] and not value['Mounts']
    ledger['beforeStop']={k:value['State'][k] for k in ['Running','ExitCode','OOMKilled']};save()
    if value['State']['Running']:assert call(['stop','--time','10',cid]).returncode==0
    assert call(['rm',cid]).returncode==0
    absent=call(['inspect',cid]);assert absent.returncode!=0 and b'no such object' in absent.stderr.lower()
    ledger['removedAndAbsent']=True;save()
print(json.dumps({'runnerExitCode':ledger.get('runnerExitCode'),'vm':ledger.get('vmResult'),'removedAndAbsent':ledger.get('removedAndAbsent')}))
