"""接续已启动新A：只收终态安全原件，并收尾准确归属外层；绝不启动VM。"""
from pathlib import Path
from datetime import datetime,timezone
import hashlib,json,subprocess,time
ROOT=Path(__file__).resolve().parent
ledger=json.loads((ROOT/'resources.json').read_bytes());cid=ledger['containers'][0]['id']
assert (ROOT/'attempt-started.json').exists() and not ledger.get('removedAndAbsent')
def now():return datetime.now(timezone.utc).isoformat()
def save():(ROOT/'resources.json').write_text(json.dumps(ledger,ensure_ascii=False,indent=2)+'\n',encoding='utf8')
def call(args,timeout=30):return subprocess.run(['docker',*args],capture_output=True,timeout=timeout)
def checked(args,timeout=30):
    value=call(args,timeout);value.check_returncode();return value.stdout
info=json.loads(checked(['inspect',cid]))[0]
assert info['Id']==cid and info['Config']['Labels'][ledger['label']]==ledger['owner'] and not info['Mounts']
assert not info['HostConfig']['Privileged'] and not info['HostConfig']['Devices'] and not info['HostConfig']['PortBindings']
assert info['HostConfig']['Memory']==info['HostConfig']['MemorySwap']==6442450944 and info['HostConfig']['NanoCpus']==4000000000
if info['State']['Running']:
    names=checked(['exec',cid,'ps','-eo','comm'])
    if b'qemu-system' in names:raise SystemExit('same VM active; collection deferred; no restart or cleanup')
    # 原控制器可能正在最后写 result；不在它仍持有原件时移除容器。
    for _ in range(10):
        state=call(['exec',cid,'test','-d','/proc/3086'])
        if state.returncode!=0:break
        time.sleep(1)
    else:raise SystemExit('original controller still active; preserve for completion')
    for name in ['result.json','started.json','qemu-started.json','receipts.ndjson','serial.log','qemu-stderr.log']:
        value=call(['exec',cid,'cat','/opt/api-window/guest/'+name])
        if value.returncode==0:(ROOT/name).write_bytes(value.stdout)
    for name in ['run_window.py','diagnostic_guest.py','api_identity.py','clock_evidence.py','clock_core_pipe.py']:
        data=checked(['exec',cid,'cat','/opt/api-window/'+name]);(ROOT/('actual-'+name)).write_bytes(data)
        assert hashlib.sha256(data).hexdigest()==ledger['diagnosticSourceSha256'][name]
    for name in ['memory.current','memory.peak','memory.max','memory.swap.max','memory.events','cpu.max']:
        (ROOT/('outer-'+name+'.txt')).write_bytes(checked(['exec',cid,'cat','/sys/fs/cgroup/'+name]))
    (ROOT/'process-names-before-stop.txt').write_bytes(checked(['exec',cid,'ps','-eo','pid,ppid,stat,comm']))
else:
    # 外层意外退出时仍只取既有安全文件；不导出guest磁盘，不重启容器。
    for name in ['result.json','started.json','qemu-started.json','receipts.ndjson','serial.log','qemu-stderr.log']:
        value=call(['cp',cid+':/opt/api-window/guest/'+name,str(ROOT/name)])
        ledger['copyAfterOuterExit-'+name]=value.returncode
ledger['vmPrepared']=(ROOT/'started.json').exists();ledger['vmStarted']=(ROOT/'qemu-started.json').exists()
assert ledger['vmStarted']
if (ROOT/'result.json').exists():
    result=json.loads((ROOT/'result.json').read_bytes())
    ledger['vmResult']={k:result.get(k) for k in ['status','totalSeconds','qemuExitCode','deadlineReached','actualTargetAttempts']}
else:ledger['vmResult']={'status':'incomplete-outer-exit','actualTargetAttempts':'unknown'}
ledger['runnerExitCode']='unknown-after-host-checkpoint'
ledger['collectedExistingExecutionUtc']=now()
ledger['beforeStop']={k:info['State'][k] for k in ['Running','ExitCode','OOMKilled']};save()
if info['State']['Running']:checked(['stop','--time','10',cid])
post=json.loads(checked(['inspect',cid]))[0]
ledger['afterStop']={k:post['State'][k] for k in ['Running','ExitCode','OOMKilled']};save()
assert not post['State']['Running']
events=checked(['events','--since',ledger['createdAt'],'--until',now(),'--filter','container='+cid,'--format','{{json .}}'])
safe=[]
for raw in events.splitlines():
    event=json.loads(raw);assert event.get('id',event.get('Actor',{}).get('ID'))==cid
    entry={'id':cid,'action':event.get('Action',event.get('status')),'timeNano':event.get('timeNano')}
    code=event.get('Actor',{}).get('Attributes',{}).get('exitCode')
    if code is not None:entry['exitCode']=code
    safe.append(entry)
(ROOT/'outer-events-after-stop.json').write_text(json.dumps(safe,indent=2)+'\n',encoding='utf8')
checked(['rm',cid]);absent=call(['inspect',cid])
assert absent.returncode!=0 and b'no such object' in absent.stderr.lower()
ledger.update(removedAndAbsent=True,cleanupFinishedUtc=now(),noNewVmOrBudgetReset=True);save()
(ROOT/'cleanup-verification.json').write_text(json.dumps({'observedUtc':now(),'containerId':cid,'owner':ledger['owner'],
    'inspectExitCode':absent.returncode,'safeError':'no such object','stderrSha256':hashlib.sha256(absent.stderr).hexdigest(),
    'onlyOwnedContainerRemoved':True,'privateCoreDiskOrRawGdbExported':False},ensure_ascii=False,indent=2)+'\n',encoding='utf8')
print(json.dumps({'vm':ledger['vmResult'],'removedAndAbsent':True}))
