"""仅解析已核容器身份；不执行部署或请求。"""
import hashlib


def select_api(containers, identity, prefix, manifest):
    root_hash = hashlib.sha256(str(prefix).encode()).hexdigest()
    accepted = {manifest['images']['api']['id'], manifest['images']['api']['archiveId']}
    selected = []
    for info in containers:
        labels = info['Config']['Labels']
        if (labels.get('com.docker.compose.service') == 'api'
                and labels.get('com.docker.compose.project') == identity['project']
                and labels.get('io.workmesh.installation') == identity['id']
                and labels.get('io.workmesh.installation-root') == root_hash):
            if (info['Image'] not in accepted or info['HostConfig']['ReadonlyRootfs'] is not True
                    or not info['State']['Running'] or info['State']['Pid'] < 2):
                raise ValueError('API image or runtime identity rejected')
            selected.append(info)
    if len(selected) != 1:
        raise ValueError('API target identity must be unique')
    return selected[0]
