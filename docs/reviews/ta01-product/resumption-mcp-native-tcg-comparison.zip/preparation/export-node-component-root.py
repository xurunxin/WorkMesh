from pathlib import Path
import gzip
import hashlib
import json
import subprocess

r = Path('.tmp/ta01-resumption/mcp-tcg-component-5371')
l = json.loads((r / 'resources.json').read_bytes())
image = 'sha256:6b2127043c2faa4f15cdcdeb65a39fc9afbecf5559301898b754bbff561a8aa9'
def call(args):
    p = subprocess.run(['docker', *args], capture_output=True, timeout=180)
    assert p.returncode == 0, 'Docker operation failed; stderr withheld'
    return p.stdout
identifier = call(['create', '--pull', 'never', '--network', 'none', '--label',
    'io.workmesh.ta01.probe.owner=' + l['owner'], '--entrypoint', '/bin/true', image]).decode().strip()
assert len(identifier) == 64
l['containers'].append({'id': identifier, 'purpose': 'export public cached Node rootfs only', 'imageId': image})
(r / 'resources.json').write_text(json.dumps(l, ensure_ascii=False, indent=2) + '\n', encoding='utf8')
try:
    data = call(['export', identifier])
    compressed = gzip.compress(data, compresslevel=1, mtime=0)
    with (r / 'node-rootfs.tar.gz').open('xb') as out:
        out.write(compressed)
    l['nodeRootfs'] = {'bytes': len(data), 'sha256': hashlib.sha256(data).hexdigest(),
        'gzipBytes': len(compressed), 'gzipSha256': hashlib.sha256(compressed).hexdigest()}
finally:
    info = json.loads(call(['inspect', identifier]))[0]
    assert info['Id'] == identifier and info['Image'] == image and not info['State']['Running'] and not info['Mounts']
    assert info['Config']['Labels']['io.workmesh.ta01.probe.owner'] == l['owner']
    call(['rm', identifier])
    absent = subprocess.run(['docker', 'inspect', identifier], capture_output=True, timeout=30)
    assert absent.returncode != 0 and b'no such object' in absent.stderr.lower()
    # Provisioning may have updated its own ledger in parallel; preserve that copy.
    current = json.loads((r / 'resources.json').read_bytes())
    current['containers'] = l['containers']
    current['containers'][-1]['removedAndAbsent'] = True
    current['nodeRootfs'] = l['nodeRootfs']
    (r / 'resources.json').write_text(json.dumps(current, ensure_ascii=False, indent=2) + '\n', encoding='utf8')
print(json.dumps(l['nodeRootfs']))
