from pathlib import Path
import hashlib
import io
import json
import subprocess
import tarfile

r = Path('.tmp/ta01-resumption/mcp-tcg-component-5371')
ledger = json.loads((r / 'resources.json').read_bytes())
outer = ledger['containers'][0]['id']
export_id = '74fe90c9db7e2dba275294045890efc8e3ebf4410be1cedfbb469c73b0e2aa4b'
absent = subprocess.run(['docker', 'inspect', export_id], capture_output=True, timeout=30)
assert absent.returncode != 0 and b'no such object' in absent.stderr.lower()
ledger['containers'].append({'id': export_id, 'purpose': 'export public cached Node rootfs only',
    'imageId': 'sha256:6b2127043c2faa4f15cdcdeb65a39fc9afbecf5559301898b754bbff561a8aa9', 'removedAndAbsent': True})
ledger['ledgerCorrection'] = '并行provision旧副本覆盖导出条目；按先前工具实际读取的完整ID及当前只读absent补登记，未重导出或重删。'
assert hashlib.sha256((r / 'node-rootfs.tar.gz').read_bytes()).hexdigest() == '5d4146b3e88a9c5fdd919c416747a25d71bc1f7a433d832b1e5afa85ca57fc2c'
assert subprocess.check_output(['git', 'diff', '5371f16e24db94415155228dfc8ac149523573a0', 'HEAD', '--',
    'apps/mcp/src', 'packages/agent-sdk/src', 'packages/contracts/src']) == b''
inputs = {'node-rootfs.tar.gz': r / 'node-rootfs.tar.gz',
          'runtime.tar': Path('.tmp/ta01-resumption/mcp-component-5371/runtime.tar'),
          'measurement.mjs': Path('docs/reviews/ta01-product/tools/mcp-component-probe.mjs'),
          **{name: Path('docs/reviews/ta01-product/tools') / name for name in ['component-tcg-guest.py', 'run-component-tcg.py']}}
ledger['inputs'] = {name: {'bytes': path.stat().st_size, 'sha256': hashlib.sha256(path.read_bytes()).hexdigest()}
                    for name, path in inputs.items()}
ledger['probeSourceHead'] = subprocess.check_output(['git', 'rev-parse', 'HEAD']).decode().strip()
(r / 'resources.json').write_text(json.dumps(ledger, ensure_ascii=False, indent=2) + '\n', encoding='utf8')
subprocess.run(['docker', 'exec', outer, 'mkdir', '/opt/micro'], check=True, capture_output=True, timeout=30)
copy = subprocess.Popen(['docker', 'cp', '-', outer + ':/opt/micro'], stdin=subprocess.PIPE, stdout=subprocess.PIPE, stderr=subprocess.PIPE)
with tarfile.open(fileobj=copy.stdin, mode='w|') as archive:
    for name, path in inputs.items():
        archive.add(path, arcname=name, recursive=False)
copy.stdin.close()
copy.wait(timeout=120)
assert copy.returncode == 0, 'private input copy failed; stderr withheld'
print(json.dumps({'inputsCopied': len(inputs), 'bytes': sum(value['bytes'] for value in ledger['inputs'].values()),
                  'probeSourceHead': ledger['probeSourceHead']}))
