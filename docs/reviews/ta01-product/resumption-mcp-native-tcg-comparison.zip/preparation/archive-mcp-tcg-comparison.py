from datetime import datetime, timezone
import hashlib
import json
from pathlib import Path
import re
import statistics
import subprocess
import zipfile

root = Path('.tmp/ta01-resumption/mcp-tcg-component-5371')
native = root.parent / 'mcp-component-5371'
sha = lambda data: hashlib.sha256(data).hexdigest()
tcg = json.loads((root / 'tcg-result.json').read_bytes())
startup = json.loads((root / 'tcg-startup-result.json').read_bytes())
n = json.loads((native / 'matched-native-result.json').read_bytes())
sn = json.loads((native / 'startup-native-result.json').read_bytes())
controls = json.loads((root / 'outer-container-controls.json').read_bytes())
metadata = json.loads((root / 'outer-metadata.json').read_bytes())
resources = json.loads((root / 'resources.json').read_bytes())
for case in [tcg, startup]:
    assert case['qemuExitCode'] == 0 and case['guestVcpus'] == 4 and case['guestRamMiB'] == 4096
    assert case['qemuVersion'] == 'QEMU emulator version 8.2.2 (Debian 1:8.2.2+ds-0ubuntu1.18)'
    assert case['imageSha256'] == '6a81c37564db9b1ee84e141922625e1d7c5b389b99bb3c572e0243607d5bb4d2'
    assert case['receipts'][0]['cpuCount'] == 4
    assert case['receipts'][0]['nodeExitCode'] == 0
assert tcg['receipts'][0]['bootId'] != startup['receipts'][0]['bootId']
for case in [n, sn, tcg['receipts'][0]['probe'], startup['receipts'][0]['probe']]:
    assert case['executableSha256'] == '638c77326270093b1251a5e72b4335c94c74856a210460341c73d6f3da647328'
assert tcg['inputs']['inputs']['measurement.mjs'] == sha((root / 'used-first-measurement.mjs').read_bytes())
assert startup['inputs']['inputs']['startup.mjs'] == sha((root / 'used-startup-startup.mjs').read_bytes())
for case, script in [('matched-native', 'used-first-measurement.mjs'), ('startup-native', 'used-startup-startup.mjs')]:
    ledger = json.loads((native / ('resources-' + case + '.json')).read_bytes())
    assert ledger['measurementSha256'] == sha((root / script).read_bytes())
    for container in ledger['containers']:
        assert container['exitCode'] == 0 and container['removedAndAbsent'] and not container['oom']
assert all(container['removedAndAbsent'] for container in resources['containers'])
summary = {'说明': '固定Node/guest/QEMU的隔离AMD64组件原生/TCG对照及零POST进程冷启动；不代完整已安装候选、真实授权/PG/Redis/S3或ARM。有限未139不排除。',
    'componentSourceHead': '5371f16e24db94415155228dfc8ac149523573a0',
    'toolBaseHead': 'ac0a4d21deba15a23c8c7b40f671b59c41f30f37',
    'componentSourceUnchangedAtToolBase': subprocess.check_output(['git', 'diff', '5371f16e24db94415155228dfc8ac149523573a0',
        'ac0a4d21deba15a23c8c7b40f671b59c41f30f37', '--', 'apps/mcp/src', 'packages/agent-sdk/src', 'packages/contracts/src']) == b'',
    'cases': {}, 'coldStartup': {}, 'controls': controls, 'outerMetadata': metadata,
    'resources': resources, 'nodeBaseImageId': 'sha256:6b2127043c2faa4f15cdcdeb65a39fc9afbecf5559301898b754bbff561a8aa9',
    'limits': ['相同组件/Node/公开基础镜像rootfs；完整生产MCP镜像的apk升级、生产打包、API/PG和真实负载未覆盖。',
        '原生Docker宿主与Ubuntu TCG guest的kernel不同，QEMU只核版本和本地二进制SHA，CI没有可比QEMU二进制SHA。',
        'work:read身份、scope/features/工作项均为合成，真实资格响应大小未知。',
        'HTTP客户端与合成API同进程，CPU含fixture；30秒计时不等同独立安装器客户端的抢占期限。',
        '冷启动每进程只有两次健康读取及2秒等待，不覆盖真实长期待命或混合负载；零POST未复现不证明业务请求是必要条件。',
        '首次VM使用ac0工具原件；冷启动VM使用本轮准确source快照并禁止core落盘。两VM均Node0/QEMU0，无原生捕获，不冒故障关闭。',
        '控制容器在两个QEMU均退出且无活动QEMU后stop，容器exit137不是Node139，OOM=false。'],
    'observedAt': datetime.now(timezone.utc).isoformat()}
for label, value in [('native', n), ('tcg', tcg['receipts'][0]['probe'])]:
    assert value['workReadFixture'] and value['unknownRequests'] == 0 and len(value['requests']) == 24
    row = {'importMilliseconds': value['importMilliseconds'], 'qualifiedResponseBytes': value['qualifiedResponseBytes'],
           'measurementSha256': sha((root / 'used-first-measurement.mjs').read_bytes()), 'requests': {}}
    for method in ['initialize', 'tools/call']:
        rows = [r for r in value['requests'] if r['method'] == method]
        qualified = [s for r in rows for s in r['clientSegments'] if s['label'] == 'qualified']
        labels = sorted({s['label'] for r in rows for s in r['fixtureCalls']})
        assert labels == ([] if method == 'initialize' else ['qualified', 'work-item'])
        row['requests'][method] = {'count': len(rows), 'wallMedianMs': statistics.median(r['elapsedMilliseconds'] for r in rows),
            'wallMaxMs': max(r['elapsedMilliseconds'] for r in rows),
            'cpuMedianMs': statistics.median((r['userCpuMicroseconds'] + r['systemCpuMicroseconds']) / 1000 for r in rows),
            'fixtureCalls': labels, 'qualifiedWallMedianMs': statistics.median(s['elapsedMilliseconds'] for s in qualified) if qualified else None}
    summary['cases'][label] = row
for label, value in [('native', sn), ('tcg', startup['receipts'][0]['probe'])]:
    rows = value['startupRuns']
    assert len(rows) == 12 and all(r['exitCode'] == 0 for r in rows)
    assert all(r['measurement']['mcpPosts'] == r['measurement']['qualifiedReads'] == r['measurement']['unknownRequests'] == 0 for r in rows)
    assert all(r['measurement']['apiReadinessRequests'] == 2 for r in rows)
    summary['coldStartup'][label] = {'processes': len(rows), 'allExitZero': True, 'mcpPosts': 0, 'qualifiedReads': 0,
        'readinessRequests': 24, 'importMedianMs': statistics.median(r['measurement']['importMilliseconds'] for r in rows),
        'measurementSha256': sha((root / 'used-startup-startup.mjs').read_bytes())}
members = {}
for name in ['tcg-result.json', 'tcg-serial.log', 'tcg-qemu-stderr.log', 'tcg-host.stdout', 'tcg-host.stderr', 'tcg-host-exit.json',
    'tcg-startup-result.json', 'tcg-startup-serial.log', 'tcg-startup-qemu-stderr.log', 'tcg-startup-host.stdout', 'tcg-startup-host.stderr',
    'tcg-startup-host-exit.json', 'outer-container-controls.json', 'outer-metadata.json', 'resources.json', 'startup-inputs.json',
    'used-first-component-tcg-guest.py', 'used-first-run-component-tcg.py', 'used-first-measurement.mjs',
    'used-startup-component-tcg-guest.py', 'used-startup-run-component-tcg.py', 'used-startup-startup.mjs',
    'qemu-version.txt', 'os.stdout', 'os.stderr', 'apt-update.stdout', 'apt-update.stderr', 'qemu-policy.stdout', 'qemu-policy.stderr',
    'apt-install.stdout', 'apt-install.stderr']:
    members['tcg/' + name] = (root / name).read_bytes()
for case in ['matched-native', 'startup-native']:
    for name in [case + '-result.json', case + '-stdout.log', case + '-stderr.log', 'resources-' + case + '.json']:
        members['native/' + name] = (native / name).read_bytes()
for name in ['provision-component-tcg.py', 'export-node-component-root.py', 'prepare-component-tcg-inputs.py',
    'run-mcp-component-matched-native.py', 'run-mcp-component-startup-native.py', 'close-component-tcg.py', 'archive-mcp-tcg-comparison.py']:
    members['preparation/' + name] = (root.parent / name).read_bytes()
members['summary.json'] = (json.dumps(summary, ensure_ascii=False, indent=2) + '\n').encode()
for data in members.values():
    assert len(data) < 2_000_000
    assert not re.search(rb'wm[ips]_[A-Za-z0-9_-]{43}', data)
stem = Path('docs/reviews/ta01-product/resumption-mcp-native-tcg-comparison')
with zipfile.ZipFile(stem.with_suffix('.zip'), 'x', compression=zipfile.ZIP_DEFLATED) as archive:
    for name, data in members.items():
        archive.writestr(name, data)
summary['selectedZipSha256'] = sha(stem.with_suffix('.zip').read_bytes())
summary['members'] = {name: {'bytes': len(data), 'sha256': sha(data)} for name, data in members.items()}
with stem.with_suffix('.json').open('x', encoding='utf8', newline='\n') as output:
    json.dump(summary, output, ensure_ascii=False, indent=2)
    output.write('\n')
print(json.dumps({'members': len(members), 'zipBytes': stem.with_suffix('.zip').stat().st_size,
                  'nodeBusinessSamplesPerEnvironment': 24, 'coldStartsPerEnvironment': 12,
                  'selectedZipSha256': summary['selectedZipSha256']}))
