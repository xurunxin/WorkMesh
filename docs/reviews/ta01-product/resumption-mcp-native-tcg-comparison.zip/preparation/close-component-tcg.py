from pathlib import Path
import hashlib
import json
import subprocess

r = Path('.tmp/ta01-resumption/mcp-tcg-component-5371')
l = json.loads((r / 'resources.json').read_bytes())
identifier = l['containers'][0]['id']
def docker(args):
    value = subprocess.run(['docker', *args], capture_output=True, timeout=45)
    assert value.returncode == 0, 'Docker operation failed; stderr withheld'
    return value.stdout
for name in ['tcg-result.json', 'tcg-startup-result.json']:
    value = json.loads((r / name).read_bytes())
    assert value['qemuExitCode'] == 0 and value['status'] == 'component-measured'
assert json.loads((r / 'outer-metadata.json').read_bytes())['activeQemuCount'] == 0
info = json.loads(docker(['inspect', identifier]))[0]
assert info['Id'] == identifier and info['Image'] == l['imageId']
assert info['Config']['Labels']['io.workmesh.ta01.probe.owner'] == l['owner'] and not info['Mounts']
cache = Path('.tmp/ta01-resumption/local-guest-image-cache')
cache.mkdir(exist_ok=True)
image = cache / 'amd64-6a81c375.img'
with image.open('xb') as out:
    copied = subprocess.run(['docker', 'exec', identifier, 'cat', '/opt/micro/amd64.img'], stdout=out, stderr=subprocess.PIPE, timeout=120)
assert copied.returncode == 0
checksum = hashlib.sha256()
with image.open('rb') as source:
    while block := source.read(1024 * 1024):
        checksum.update(block)
assert checksum.hexdigest() == '6a81c37564db9b1ee84e141922625e1d7c5b389b99bb3c572e0243607d5bb4d2'
l['publicGuestImageCache'] = {'path': image.as_posix(), 'bytes': image.stat().st_size, 'sha256': checksum.hexdigest()}
l['activeQemuCountBeforeStop'] = 0
docker(['stop', '--time', '10', identifier])
info = json.loads(docker(['inspect', identifier]))[0]
assert not info['State']['Running'] and not info['State']['OOMKilled']
l['containers'][0].update(stopped=True, exitCode=info['State']['ExitCode'], oom=False)
(r / 'resources.json').write_text(json.dumps(l, ensure_ascii=False, indent=2) + '\n', encoding='utf8')
docker(['rm', identifier])
absent = subprocess.run(['docker', 'inspect', identifier], capture_output=True, timeout=30)
assert absent.returncode != 0 and b'no such object' in absent.stderr.lower()
l['containers'][0]['removedAndAbsent'] = True
l['privateGuestOverlaysRetained'] = False
l['sharedImagesRemoved'] = False
(r / 'resources.json').write_text(json.dumps(l, ensure_ascii=False, indent=2) + '\n', encoding='utf8')
print(json.dumps({'outerRemovedAndAbsent': True, 'publicImageCacheBytes': image.stat().st_size,
    'outerExitCode': info['State']['ExitCode'], 'privateGuestOverlaysRetained': False}))
