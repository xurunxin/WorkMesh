from pathlib import Path
from datetime import datetime, timezone
import hashlib, json, os, re, subprocess, zipfile

ROOT=Path('.tmp/ta01-gate-static')
OUT=Path('docs/reviews/ta01-product/api139-next-gate-materials')
materials=(ROOT/'materials-audit.json').read_bytes()
value=json.loads(materials)
OUT.with_suffix('.json').write_bytes(materials)
files=['docs/plan/ta01-self-hosted-deployment/amd64-api139-next-gate.md',
       'docs/plan/ta01-self-hosted-deployment/current-delivery.md',
       'docs/plan/ta01-self-hosted-deployment/amd64-crash-investigation-plan.md',
       'docs/plan/ta01-self-hosted-deployment/implementation-plan.md']
links=0
for name in files:
    p=Path(name);data=p.read_bytes();text=data.decode('utf8')
    assert data.endswith(b'\n') and not any(line.rstrip()!=line for line in text.splitlines())
    for target in re.findall(r'\[[^\]]+\]\(([^)]+)\)',text):
        path=target.split('#',1)[0]
        if not path or '://' in path:continue
        assert (p.parent/path).exists(),(name,path)
        links+=1
env=dict(os.environ)
env['NODE_PATH']='C:/Users/xurx/.tds/workspaces/01a138ab-2566-7f87-9d06-5b16bebd86c2/scripts/ci-bootstrap/node_modules'
checks=[]
for args in [['node','scripts/check-integration-docs.mjs'],['git','diff','--check']]:
    result=subprocess.run(args,capture_output=True,env=env,timeout=120)
    checks.append({'command':args,'exitCode':result.returncode,'stdout':result.stdout.decode(errors='replace'),
        'stderr':result.stderr.decode(errors='replace'),'stdoutSha256':hashlib.sha256(result.stdout).hexdigest(),
        'stderrSha256':hashlib.sha256(result.stderr).hexdigest()})
verification={'at':datetime.now(timezone.utc).isoformat(),'hostNode':subprocess.check_output(['node','--version']).decode().strip(),
              'commands':checks,'checkedPlanLinks':links,'markdownWhitespace':'passed',
              'noVmDebuggerProductCiOrReviewRun':True,
              'scope':'本轮仅静态文档与材料校验；没有执行新方案夹具、原候选或产品，不代五根门禁。'}
assert all(row['exitCode']==0 for row in checks)
members={'materials-audit.json':materials,'audit-materials.py':(ROOT/'audit_materials.py').read_bytes(),
         'static-verification.json':(json.dumps(verification,ensure_ascii=False,indent=2)+'\n').encode('utf8'),
         'publish-audit.py':Path(__file__).read_bytes()}
for name,data in members.items():
    assert not re.search(rb'wm[ips]_[A-Za-z0-9_-]{43}|-----BEGIN (?:RSA |EC |OPENSSH )?PRIVATE KEY-----',data),name
with zipfile.ZipFile(OUT.with_suffix('.zip'),'x',zipfile.ZIP_DEFLATED) as z:
    for name,data in members.items():z.writestr(name,data)
with zipfile.ZipFile(OUT.with_suffix('.zip')) as z:
    assert z.testzip() is None
    for name,data in members.items():assert z.read(name)==data
value['verification']=verification
value['auditArchive']={'sha256':hashlib.sha256(OUT.with_suffix('.zip').read_bytes()).hexdigest(),
    'members':{name:{'bytes':len(data),'sha256':hashlib.sha256(data).hexdigest()} for name,data in members.items()},
    'scope':'仅安全审计、静态校验和审计脚本；没有原core、内存、秘密、GDB会话原文或磁盘。'}
OUT.with_suffix('.json').write_text(json.dumps(value,ensure_ascii=False,indent=2)+'\n',encoding='utf8',newline='\n')
print(json.dumps({'planLinksVerified':links,'staticCommandFailures':sum(row['exitCode']!=0 for row in checks),'auditArchiveMembers':len(members)}))
