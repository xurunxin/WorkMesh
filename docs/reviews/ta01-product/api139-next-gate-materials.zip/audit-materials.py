from pathlib import Path
import hashlib, json, subprocess, zipfile
from datetime import datetime, timezone

OUT=Path('.tmp/ta01-gate-static')
HEAD='970565f9a2dff382dc60e98391666828b7644f1c'
OLD=Path('C:/Users/xurx/.tds/workspaces/01a138ab-2566-7f87-9d06-5b16bebd86c2')
ROOT=Path('.tmp/ta01-resumption/api-crash-window-a-6g-once')
def sha(data):return hashlib.sha256(data).hexdigest()
def git(path):return subprocess.check_output(['git','show',HEAD+':'+path])
def binding(path):
    data=git(path)
    return {'path':path,'gitBlob':subprocess.check_output(['git','rev-parse',HEAD+':'+path]).decode().strip(),'bytes':len(data),'sha256':sha(data)}
index_path='docs/reviews/ta01-product/amd64-api-crash-window-a-6g-once.json'
zip_path='docs/reviews/ta01-product/amd64-api-crash-window-a-6g-once.zip'
index=json.loads(git(index_path));raw=git(zip_path)
assert sha(raw)==index['selectedZipSha256']
archive=OUT/'committed-window.zip';archive.write_bytes(raw)
with zipfile.ZipFile(archive) as z:
    assert z.testzip() is None and set(z.namelist())==set(index['members'])
    for name,entry in index['members'].items():
        data=z.read(name);assert len(data)==entry['bytes'] and sha(data)==entry['sha256']
    result=json.loads(z.read('result.json'))
    names=z.namelist()
    assert not any(n.endswith(('.qcow2','.core','.dmp')) or n.rsplit('/',1)[-1]=='core' for n in names)
    runtime_bindings=[]
    for name in ['core_pipe.py','core_metadata.py','native_diagnostic.py','guest.py','run.py','native_diagnostic_test.py']:
        path='scripts/server-distribution/'+name
        data=subprocess.check_output(['git','show','9c8bbff749c1d2a52a3e6489dcec02d2d7c859af:'+path])
        assert z.read('original-source/'+name)==data
        runtime_bindings.append({'path':path,'sourceHead':'9c8bbff749c1d2a52a3e6489dcec02d2d7c859af',
            'gitBlob':subprocess.check_output(['git','rev-parse','9c8bbff749c1d2a52a3e6489dcec02d2d7c859af:'+path]).decode().strip(),'sha256':sha(data)})
cid=index['outer']['containerId']
probe=subprocess.run(['docker','inspect',cid],capture_output=True,timeout=30)
assert probe.returncode!=0 and b'no such object' in probe.stderr.lower()
local=[]
for root in [ROOT, OLD/'.tmp/ta01-resumption/api-crash-window-a-6g-once',Path('.tmp/ta01-recovery')]:
    files=[p for p in root.rglob('*') if p.is_file()]
    candidates=[]
    for p in files:
        if p.name=='core' or p.suffix in ['.core','.dmp','.qcow2'] or p.name.startswith('native-core-trace-'):
            candidates.append({'path':str(p),'bytes':p.stat().st_size})
    local.append({'root':str(root.resolve()),'filesExaminedByName':len(files),'guestDirectoryExists':(root/'guest').exists(),'rawCoreOrGuestCandidates':candidates,
                  'debuggerNamedFiles':[p.relative_to(root).as_posix() for p in files if 'gdb' in p.name.lower()]})
    assert not candidates
public=OLD/'.tmp/ta01-resumption/public-node-symbols'
with (public/'node').open('rb') as f:binary_sha=hashlib.file_digest(f,'sha256').hexdigest()
symbol_bytes=(public/'symbol-index.json').read_bytes()
assert binary_sha==result['final']['nativeTrace']['targetBinarySha256']
assert sha(symbol_bytes)=='0e360d773217d9bd4a55ea5bbe4ebdbc05326ec017d2cdcf78606a6f42302399'
trace=result['final']['nativeTrace']
value={'observedAt':datetime.now(timezone.utc).isoformat(),'sourceHead':HEAD,'scope':'仅既有材料静态读取、摘要核验和准确容器ID只读inspect；无GDB、候选程序或实验执行。',
       'archive':binding(zip_path),'index':binding(index_path),'archiveMembersVerified':len(names),'runtimeSourceBindings':runtime_bindings,
       'materialAvailability':{'core':'本次只在guest匿名memfd短暂存在，源码finally关闭；准确外层已不存在。授权账本和限定目录未发现留存core或qcow2。没有可供离线重解析的本次原core。',
         'rawGdbStdoutStderr':'未在源码中持久化或列入本次64成员导出；只有safe_trace摘要和阶段。71字节各自的原输出未保，不重建或冒称可读。',
         'gdbProjection':trace['trace'],'captureId':trace['captureId'],'coreBytes':trace['coreBytes'],'coreSha256':trace['coreSha256'],
         'containerProbe':{'id':cid,'exitCode':probe.returncode,'safeError':'no such object','stderrSha256':sha(probe.stderr)},'localPathChecks':local,
         'boundary':'没有扫描其他项目、未知目录、共享数据或Docker内部存储；不宣称全机不存在任何其他core。私有旧日志备份未打开，不是本次core留存证明。'},
       'publicBinary':{'path':str((public/'node').resolve()),'bytes':(public/'node').stat().st_size,'sha256':binary_sha,
          'symbolIndexSha256':sha(symbol_bytes),'actualRunOrNewDownload':False},
       'evidenceFacts':{'apiWindow':{'target':result['final']['target'],'coreLocation':trace['location'],'apiState':result['final']['observedApiState'],
          'apiEvents':result['final']['containerEvents'],'qemuExitCode':result['qemuExitCode'],'qmpEvents':result['qmpEvents'],'outerMemoryEvents':index['outer']['memoryEvents']},
          'mcpEvidence':binding('docs/reviews/ta01-product/ci566-amd64-team-first-failure.json'),
          'oldOomEvidence':binding('docs/reviews/ta01-product/amd64-api-crash-window-a.json')},
       'limits':'安全公开帧不携带JS调用点、私有寄存器操作数或完整栈；UTC与monotonic不混算，登记、断连、die事件不证明请求触发。'}
(OUT/'materials-audit.json').write_text(json.dumps(value,ensure_ascii=False,indent=2)+'\n',encoding='utf8',newline='\n')
print(json.dumps({'archiveMembersVerified':len(names),'localRawCoreAvailable':False,'rawGdbOutputAvailable':False,
                  'publicBinarySha256':binary_sha,'runtimeGitSourcesVerified':len(runtime_bindings)}))
