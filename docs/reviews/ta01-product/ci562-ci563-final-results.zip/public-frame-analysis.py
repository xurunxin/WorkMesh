import hashlib
import json
from pathlib import Path

base = Path('.tmp/ta01-resumption/public-node-symbols')
source = Path('.tmp/ta01-resumption/guest-evidence/ci563-amd64-team-native-observation.json')
receipt = json.loads(source.read_bytes())
trace = receipt['receipts'][-1]['diagnostics']['nativeTrace']
index_bytes = (base / 'symbol-index.json').read_bytes()
index = json.loads(index_bytes)
binary_sha = hashlib.sha256((base / 'node').read_bytes()).hexdigest()
assert trace['targetBinarySha256'] == binary_sha == index['binarySha256']
location = trace['location']
assert location['architecture'] == index['architecture'] == 'amd64'
assert location['publicFrameChain']['stopped'] == 'frame-link-invalid'
addresses = [('fault', location['nodeElfAddress'])]
addresses += [('frame-' + str(i + 1), frame['lookupNodeElfAddress']) for i, frame in enumerate(location['publicFrameChain']['frames'])]
matches = []
for kind, address in addresses:
    symbols = [{'symbol': name, 'elfAddress': start, 'bytes': size, 'offsetInFunction': address - start}
               for start, size, name in index['symbols'] if start <= address < start + size]
    matches.append({'kind': kind, 'publicElfLookupAddress': address, 'symbols': symbols})
result = {'说明': '按准确目标二进制SHA匹配公开ELF函数范围；两个帧指针返回地址来自有界栈解析，不是完整栈或原始私有地址。handler开始早于journal业务读取，不能称该读取触发故障。',
          'targetBinarySha256': binary_sha, 'publicIndexSha256': hashlib.sha256(index_bytes).hexdigest(),
          'receiptSha256': hashlib.sha256(source.read_bytes()).hexdigest(),
          'handlerStartedUtcEpoch': trace['handlerStartedUtcEpoch'],
          'businessStartedUtcEpoch': trace['businessStartedUtcEpoch'],
          'handlerBeforeBusinessSeconds': trace['businessStartedUtcEpoch'] - trace['handlerStartedUtcEpoch'],
          'matches': matches, 'frameStop': location['publicFrameChain']['stopped'],
          'debuggerStages': trace['trace']['debuggerStages']}
with Path('.tmp/ta01-resumption/ci563-public-frames.json').open('x', encoding='utf8', newline='\n') as output:
    json.dump(result, output, ensure_ascii=False, indent=2)
    output.write('\n')
print(json.dumps(result, ensure_ascii=False, indent=2))
