#!/bin/sh
set -eu
umask 077
unset NODE_OPTIONS NODE_PATH LD_PRELOAD LD_LIBRARY_PATH
directory=$(CDPATH= cd -- "$(dirname -- "$0")" && pwd -P)
cd "$directory"
if ! sha256sum --check --status <<'WORKMESH_HELPER_SUMS'
54718ffb33e267090b3daefdcc6c5a4d256f957c08162df8579a15585198cd31  installer/bin/workmesh-connector-installer
868dd922bcd130f676694a6d8aadd5abc8023df3f3fb1d1cc3693db085d4d5ae  installer/node_modules/@koromix/koffi-linux-arm64/index.js
05321eeb58dbadda2f84aecdccafc015141d19ce53e9c833835e6607c62d8911  installer/node_modules/@koromix/koffi-linux-arm64/linux_arm64/koffi.node
fc90da55dd6b4192de80e7118cc8539a16d4608919b98fef6b991dfbea77aa1d  installer/node_modules/@koromix/koffi-linux-arm64/package.json
22bcbbbacd739b026a8dc484f62a31484ce4c4e31f3408b60b29b4e41d62b290  installer/node_modules/koffi/LICENSE.txt
d5e4c3b53c1166265f3b7a386a0aec446bb99c41bf58c6c05643d1dcade12ffd  installer/node_modules/koffi/cnoke.cjs
a200e15ec168d00cb3155794808a98243051c61dd7f6989c23c57ee220c918b9  installer/node_modules/koffi/index.cjs
34508972d2e18b79fd4a289943568a68bbaf18badd2e82a25c8deb1af27f6225  installer/node_modules/koffi/index.js
f36c7fd3caa9c43da3db45e1ee272892087b4001b6f575fffb76dd80574829b1  installer/node_modules/koffi/indirect.cjs
5c5045c5b5ec2083535efdfdbd95f5212545ce29a4b7f33a683504a35e5b6a02  installer/node_modules/koffi/indirect.js
80d8fbff4730e3314f3036fefd5af0d89203ed8a01c61d134727f1d38a16d72b  installer/node_modules/koffi/package.json
5e8bf2ce51906244b2b8e8c5c321afd79c2f8d65c9846a118f845db96dbb33d0  installer/node_modules/koffi/src/koffi/index.cjs
025b00fbc7f952eef40c98e4778832108585260be3611d2175584eff93d5604b  installer/node_modules/koffi/src/koffi/index.js
ca74165a3a78b02cab86eda18147e073a43ca2f7123c5bc0aa575a34150b2377  installer/node_modules/koffi/src/koffi/indirect.cjs
fda9ae20155cac5038d5d254670df48b40b9e828a4bd23a90934ebb2ba7a0947  installer/node_modules/koffi/src/koffi/indirect.js
522a9d98e271b565de4013910b8c81bb061a34d3460e43fd9a92daab8fbadddc  installer/node_modules/koffi/src/koffi/src/static.cjs
a2a6ea215e4d5f26d039b48eee1e7c8ca037935c4fcba8d0ec2b6e680fa7a976  installer/node_modules/koffi/src/koffi/src/static.js
82895e2a78b911b297e7497d9d6033ab87a0afe64f4904615dacfa318d83adfa  installer/node_modules/koffi/src/koffi/src/trampolines.cjs
WORKMESH_HELPER_SUMS
then
  echo INSTALL_HELPER_HASH >&2
  exit 1
fi
exec "$directory/installer/bin/workmesh-connector-installer" --uninstall "$@"
