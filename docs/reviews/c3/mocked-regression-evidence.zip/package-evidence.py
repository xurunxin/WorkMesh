import hashlib,json,pathlib,re,subprocess,zipfile
root=pathlib.Path(__file__).resolve().parent
repo=root.parent.parent
dest=repo/'docs/reviews/c3'
data=json.loads((root/'parsed-reports.json').read_text(encoding='utf8'))
source=json.loads((root/'source.json').read_text(encoding='utf8'))
assert json.loads((root/'comparison-differences.json').read_text(encoding='utf8'))==[]
for label in ['baseline','head']:
    assert data[label]['stats']['expected']==15 and data[label]['stats']['unexpected']==32
    assert data[label]['stats']['skipped']==0 and data[label]['stats']['flaky']==0
    assert len(data[label]['tests'])==47
    patches={p['path']:p for p in source['source'][label]['portPatches']}
    for path,item in source['source'][label].items():
        if path=='portPatches':continue
        assert hashlib.sha256((root/label/path).read_bytes()).hexdigest()==patches.get(path,{}).get('runSha256',item['sha256']),path
    source['source'][label]['runtime']=json.loads((root/(label+'-runtime.json')).read_text(encoding='utf-8-sig'))
source['mainReadback']={'mechanism':'平台只读 git ls-remote origin refs/heads/main；不使用共享 FETCH_HEAD 作为稳定绑定','commit':'1078bbcd527550bfabee73093b7ffd0032d3fd24'}
source['verificationScope']='Git archive 原字节、各副本 workspace package 真实解析路径、完整非 docs 已跟踪文件；实际运行字节仅有登记的端口与证据目录调整。最终交付仅文档/证据变化，产品保持 head 源码。'
(dest/'mocked-regression-sources.json').write_text(json.dumps(source,ensure_ascii=False,indent=2)+'\n',encoding='utf8')
old=json.loads((root/'old-errors.json').read_text(encoding='utf8'))
groups={
 'A':{'reason':'Agent 旧夹具缺少严格 DTO 的必填字段，页面呈现校验错误；卡片、详情或 roving link 因而不存在。DOM 中记录了缺字段错误。','files':['apps/web/app/lib/agents.ts','packages/contracts/src/agent-response.ts','apps/web/app/agents/page.tsx','apps/web/app/agents/[id]/page.tsx']},
 'R':{'reason':'断言访问旧 Settings ?tab= 路径，页面直接 notFound；另一项在无 tab 的 Settings 等待已移除的 Planning & Operations 标签。现行 Settings 仅保留 Workspace 标签。','files':['apps/web/app/settings/page.tsx','packages/ui/src/primitives/tabs.tsx']},
 'C':{'reason':'Sessions 旧用例仍要求同时显示 Connections 区域；当前结构把 Connections 放在独立标签，Sessions DOM 中没有该区域。','files':['apps/web/app/agents/page.tsx','apps/web/app/agent-connections-panel.tsx']},
 'S':{'reason':'Operations 状态节点已使用 wm-visually-hidden；旧测试查找 sr-only，数量为零。','files':['apps/web/app/operations-content.tsx']},
 'M':{'reason':'UsageMetrics 已使用 StatGrid/StatCard；旧测试的 operations-metrics-grid / operations-metric-card 选择器不存在，计数与几何测量无法命中。','files':['apps/web/app/operations/usage-metrics.tsx']},
 'D':{'reason':'Delete Team 宽屏对话框几何约束失败：overflowCount 两者都为 3，测试要求 0。对话框组件及应用样式完全相同；这是实际复现的既有溢出失败，未推断为 Agent 夹具问题。','files':['apps/web/app/settings/delete-team-dialog.tsx','apps/web/app/styles.css']},
 'T':{'reason':'sticky 断言在 scrollIntoView 后滚动 window，期望导航 top 为 48，两者实测均为 -160。当前 shell 有独立 app-content 滚动容器，测试仍按 window 几何模型测量。','files':['apps/web/app/styles.css','apps/web/app/operations/page.tsx']},
 'F':{'reason':'Recent runs 滚动区获得焦点后，计算 outlineStyle 为 none，未满足原有焦点可见性断言。两份源码及失败值一致，保留这项既有焦点约束失败。','files':['apps/web/app/operations-content.tsx','apps/web/app/styles.css']},
 'W':{'reason':'测试只调用 window.scrollTo；页面使用 shell 内部滚动容器，背景 snapshot.scrollY 仍为 0，未达到 > 0 的准备前提。失败发生在打开删除层之前。','files':['apps/web/app/styles.css','apps/web/app/settings/page.tsx']},
 'H':{'reason':'Home 输入 ga 后立即同步读取 URL；原有 router.push 通过异步导航更新过滤 URL，断言时 search 仍为 null。控制台随后可见 search=ga 请求；Home/过滤器/快捷键源码未变。此归因限定为原有 URL 提交时序断言失配。','files':['apps/web/app/page.tsx','apps/web/features/work-items/work-surfaces.tsx','packages/ui/src/domain/work-item.tsx','apps/web/app/lib/use-hotkeys.ts']}
}
mapping={1:'A',2:'A',3:'A',4:'A',5:'R',6:'A',7:'C',8:'R',9:'S',10:'M',11:'A',12:'M',13:'A',14:'M',15:'A',16:'R',17:'R',18:'R',19:'R',20:'D',21:'T',22:'R',23:'F',24:'M',25:'A',26:'W',27:'A',28:'W',29:'H',30:'A',31:'H',32:'A'}
for group in groups.values():
    for path in group['files']:
        assert source['source']['baseline'][path]['sha256']==source['source']['head'][path]['sha256'],path
rows=[]
for oldrow in old:
    parts=oldrow['test'].split(' › ')
    key=parts[0].split(':')[0].replace('\\','/').removeprefix('e2e/')+' › '+' › '.join(parts[1:])
    a,b=data['baseline']['tests'][key],data['head']['tests'][key]
    assert a['status']==b['status'] and a['status']!='passed'
    assert [e['fingerprint'] for e in a['errors']]==[e['fingerprint'] for e in b['errors']]
    rows.append({'originalFailureId':int(oldrow['id']),'key':key,'category':mapping[int(oldrow['id'])],'classification':'既有失败；同环境精确提交对照已复现','baseline':a,'head':b})
comparison={'sourceCommits':source['refs'],'stats':{k:v['stats'] for k,v in data.items()},'totalTests':47,'passedBoth':15,'failedBoth':32,'newRegressions':0,'unknownClassification':0,'assertionChanges':False,'timeoutChanges':False,'policy':'匹配完整标题、视口、状态、逐用例 timeout、全部错误的断言/选择器/期望/实际值及等待目标；忽略 ANSI、调用轮询次数、堆栈路径和源码行号位移。原始报告无损保留，不能从相同的首个失败推断后续未执行步骤通过。','categories':groups,'failures':rows,'allTests':data}
(dest/'mocked-regression-comparison.json').write_text(json.dumps(comparison,ensure_ascii=False,indent=2)+'\n',encoding='utf8')
lines=['# C3 模拟浏览器回归逐项对照','', '用精确实施前提交 `'+source['refs']['baseline']+'` 与产品提交 `'+source['refs']['head']+'` 的独立 Git archive 副本，在同一机器顺序执行原五组完整集合。两者各 **47 项，15 通过、32 失败、零跳过、零 flaky**；47 项状态、逐用例 timeout 与全部失败指纹一致，原报告 32 项全部匹配。本组未发现新增回归，未分类项为零。模拟套件仍失败；相同首个失败之后未执行的步骤不计通过。','', '## 环境与复现','', 'Windows、Node `v24.20.0`、pnpm `9.15.4`、Playwright `1.61.1`、Next `15.5.22`、React `19.2.8`。Chromium executable 字节哈希、workspace 依赖真实路径和所有非 docs 跟踪文件的 Git blob / SHA-256 见 [mocked-regression-sources.json](mocked-regression-sources.json)。源码副本有独立 `.next` 和 `node_modules`，使用相同锁文件离线安装；没有切换交付分支或运行真实提供方服务。','', '原端口由其他工作区占用，两份副本都将端口字面量改为 `3240/3241`，原固定外部证据目录改到本轮临时目录。每项调整的原始/运行哈希已登记；除此之外基点的 1372 个与产品的 1378 个跟踪文件字节未变。原配置和测试内已有的 `test.slow()` / `setTimeout` 保持原值；没有增加 timeout、删除断言或修改产品。','', '完整执行命令（在各副本根目录运行；设置绝对 `WORKMESH_PLAYWRIGHT_RUN_DIR` 与 `PLAYWRIGHT_JSON_OUTPUT_NAME`，`NODE_ENV=development`）：','', '```powershell','pnpm --filter @workmesh/web... install --offline --frozen-lockfile','pnpm --filter @workmesh/web exec playwright test --config playwright.mocked.config.ts e2e/mocked/operations-ux.mocked.spec.ts e2e/mocked/loading-states.mocked.spec.ts e2e/mocked/overlay-contract.mocked.spec.ts e2e/mocked/page-hotkeys.mocked.spec.ts e2e/mocked/accessibility-keyboard.mocked.spec.ts --reporter=list,json','```','', '两次退出码均为 `1`，不改写为测试通过。原命令、起止时间、完整 JSON、控制台、DOM、截图、几何附件及本轮 prepare/run/analyze 脚本见 [mocked-regression-evidence.zip](mocked-regression-evidence.zip)，字节与 CRC 索引见 [mocked-regression-evidence-index.json](mocked-regression-evidence-index.json)。源文件和完整 47 项结果可由下列命令独立核验：','', '```powershell','python docs/reviews/c3/fixtures/verify-regression-evidence.py','```','', '## 原 32 项失败分类','', '编号沿用原运行失败序号。文件名均位于 `apps/web/e2e/mocked/`；位置列为基点／产品的测试定义行。完整标题、实际断言行和原始错误见 [mocked-regression-comparison.json](mocked-regression-comparison.json)。每行在两份源码中均失败，分类为既有失败。','', '| 原编号 | 用例与基点／产品位置 | 相同失败证据 | 原因组 |','| --- | --- | --- | --- |']
for row in rows:
    a,b=row['baseline'],row['head']
    error=a['errors'][0]['fingerprint'].split('等待目标:')[0].strip()
    error=re.sub(r'\s+',' ',error).replace('|','\\|')
    lines.append(f"| {row['originalFailureId']} | `{a['file'].split('/')[-1]}:{a['line']}/{b['line']}`<br>{a['title']} | {error} | {row['category']} |")
lines+=['','## 原因与源码绑定','']
for name,group in groups.items():
    lines.append('- **'+name+'**：'+group['reason']+' 源码：'+ '、'.join('`'+p+'`' for p in group['files'])+'；列示文件在两提交中的 Git blob 与 SHA-256 相同。')
lines+=['','这里的“原因”记录已执行的失败层级及可核对的结构/时序，不宣称对话框溢出和焦点样式等所有旧缺陷已修复。C3 相关变化另含功能枚举、完整注册表夹具补键与数量、LLM 文案和预置表单；已在两份各自完整源码中运行，不能以单个 Agent 夹具对照解释全部结果。','', '## 交接与收尾','', '本轮仅追加证据和修正交接说明，保留原 32 失败、首败及上轮原始归档；正式 E2E 的历史通过未用于替代本组对照。未修改目录、安全规范化、连接保存与显式模型登记行为。成果仍须独立复核、最新提交 CI 和 Chief 确认，不代表已发布或合入。资源 ID、路径、清理结果与保留原因见 [mocked-regression-resources.json](mocked-regression-resources.json)。','']
(dest/'mocked-regression-comparison.md').write_text('\n'.join(lines),encoding='utf8')
print('comparison documents written')
