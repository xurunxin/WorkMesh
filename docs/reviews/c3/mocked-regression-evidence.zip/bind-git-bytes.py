import hashlib,json,pathlib,subprocess
root=pathlib.Path(__file__).resolve().parent
repo=root.parent.parent
paths=[root/'source.json',repo/'docs/reviews/c3/mocked-regression-sources.json']
doc=json.loads(paths[0].read_text(encoding='utf8'))
ids=[]
for label in ['baseline','head']:
    ids += [v['gitBlob'] for k,v in doc['source'][label].items() if k not in ['runtime','portPatches']]
ids=list(dict.fromkeys(ids))
raw=subprocess.check_output(['git','cat-file','--batch'],input='\n'.join(ids).encode()+b'\n',cwd=repo)
blobs={}; offset=0
for oid in ids:
    end=raw.index(b'\n',offset); header=raw[offset:end].decode().split(); assert header[:2]==[oid,'blob']
    size=int(header[2]); blobs[oid]=raw[end+1:end+1+size]; offset=end+1+size+1
assert offset==len(raw)
for target in paths:
    source=json.loads(target.read_text(encoding='utf8'))
    counts={}
    for label in ['baseline','head']:
        counts[label]={'identity':0,'lf-to-crlf':0}
        for path,item in source['source'][label].items():
            if path in ['runtime','portPatches']:continue
            blob=blobs[item['gitBlob']]
            sha=hashlib.sha256(blob).hexdigest()
            if sha==item['sha256']:
                transform='identity'
            else:
                expanded=blob.replace(b'\r\n',b'\n').replace(b'\n',b'\r\n')
                assert len(expanded)==item['bytes'] and hashlib.sha256(expanded).hexdigest()==item['sha256'],path
                transform='lf-to-crlf'
            item.update({'gitBytes':len(blob),'gitSha256':sha,'archiveTransform':transform})
            counts[label][transform]+=1
    source['bytePolicy']='bytes/sha256 为 Git archive 后、端口和证据路径调整前的真实副本字节；gitBytes/gitSha256 为原 Git blob 字节。逐文件核对 identity 或 LF→CRLF，未猜测其他内容转换。runSha256 为明确调整后的实际运行文件。'
    source['archiveTransforms']=counts
    source['verificationScope']='Git 提交、Git blob 原字节与 archive 实际字节分开绑定；各副本 workspace 依赖真实路径已核对。运行字节仅有登记的端口与证据路径调整，产品内容未变。'
    target.write_text(json.dumps(source,ensure_ascii=False,indent=2)+'\n',encoding='utf8')
print(json.dumps(counts,ensure_ascii=False))
(root/'verification-first-failure.json').write_text(json.dumps({'stage':'独立 Git 字节核验首败','exitCode':1,'file':'.dockerignore','gitBytes':591,'archiveBytes':631,'reason':'Git archive 按 Windows core.autocrlf 展开 CRLF；原核验错误地用副本长度检查 Git blob 长度。','resolution':'分别绑定 Git 与 archive 字节，逐文件核对换行转换；实际测试副本与已执行结果未修改。'},ensure_ascii=False,indent=2)+'\n',encoding='utf8')
