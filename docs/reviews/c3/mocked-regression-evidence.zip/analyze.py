import hashlib, json, pathlib, re
root=pathlib.Path(__file__).resolve().parent
def plain(text):
    return re.sub(r'\x1b\[[0-9;]*m','',text)
def fingerprint(message):
    value=plain(message)
    waiting=re.findall(r'waiting for ([^\n]+)',value)
    value=re.split(r'Call [Ll]og:',value)[0]
    value=re.split(r'\n\s*>?\s*\d+\s*\||\n\s+at ',value)[0]
    value=value.replace(str(root/'baseline'),'<source>').replace(str(root/'head'),'<source>')
    value=re.sub(r':\d+:\d+',':<line>:<column>',value)
    return value.strip()+ ('\n等待目标: '+waiting[0] if waiting else '')
def read(label):
    report=json.loads((root/(label+'-report.json')).read_text(encoding='utf8'))
    rows={}
    def walk(suite, titles):
        parents=titles+[suite['title']] if titles is not None else []
        for spec in suite.get('specs',[]):
            title=' › '.join(parents+[spec['title']])
            file=spec['file'].replace('\\','/')
            file=file[file.index('mocked/'):]
            key=file+' › '+title
            for test in spec['tests']:
                result=test['results'][-1]
                errors=result.get('errors',[])
                rows[key]={'file':file,'title':title,'line':spec['line'],'timeout':test['timeout'],'status':result['status'],'duration':result['duration'],'errors':[{'message':plain(e.get('message','')),'fingerprint':fingerprint(e.get('message','')),'line':e.get('location',{}).get('line'),'snippet':plain(e.get('snippet','') or (result.get('error',{}).get('snippet','') if index==0 else ''))} for index,e in enumerate(errors)]}
        for child in suite.get('suites',[]): walk(child,parents)
    for suite in report['suites']: walk(suite,None)
    return report['stats'],rows
labels=[label for label in ['baseline','head'] if (root/(label+'-report.json')).exists()]
data={label:read(label) for label in labels}
for label,(stats,rows) in data.items():
    print(label,stats)
    print('rows',len(rows),'failures',sum(v['status']!='passed' for v in rows.values()))
if 'head' in data:
    a,b=data['baseline'][1],data['head'][1]
    assert set(a)==set(b)
    changes=[]
    for key in a:
        assert a[key]['timeout']==b[key]['timeout']
        ae=[e['fingerprint'] for e in a[key]['errors']]
        be=[e['fingerprint'] for e in b[key]['errors']]
        def snippets(row):
            return [re.sub(r'(?m)^\s*>?\s*\d+\s*\|','|',e['snippet']) for e in row['errors']]
        if a[key]['status']!=b[key]['status'] or ae!=be or snippets(a[key])!=snippets(b[key]):
            changes.append({'test':key,'baseline':a[key],'head':b[key]})
    (root/'comparison-differences.json').write_text(json.dumps(changes,ensure_ascii=False,indent=2),encoding='utf8')
    print('differences',len(changes))
(root/'parsed-reports.json').write_text(json.dumps({k:{'stats':v[0],'tests':v[1]} for k,v in data.items()},ensure_ascii=False,indent=2),encoding='utf8')
