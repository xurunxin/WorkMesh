import datetime, hashlib, json, os, pathlib, platform, re, subprocess, time
root = pathlib.Path(__file__).resolve().parent
manifest = json.loads((root/'source.json').read_text(encoding='utf8'))
specs = ['e2e/mocked/'+name+'.mocked.spec.ts' for name in ['operations-ux','loading-states','overlay-contract','page-hotkeys','accessibility-keyboard']]
for label in ['baseline','head']:
    copy = root/label
    for name in ['loading-states','overlay-contract']:
        rel = 'apps/web/e2e/mocked/'+name+'.mocked.spec.ts'
        file = copy/rel
        original = file.read_bytes()
        changed = re.sub(rb'^const evidenceRoot = .*$', ('const evidenceRoot = '+json.dumps((root/(label+'-external-evidence')).as_posix())).encode(), original, flags=re.M)
        file.write_bytes(changed)
        for patch in manifest['source'][label]['portPatches']:
            if patch['path']==rel:
                patch['runSha256'] = hashlib.sha256(changed).hexdigest()
                patch['change'] += '；固定外部证据目录改为本轮临时路径'
    manifest['resources'] += [str(root/(label+'-external-evidence')),str(root/(label+'-run'))]
(root/'source.json').write_text(json.dumps(manifest,ensure_ascii=False,indent=2),encoding='utf8')
env = os.environ.copy()
env.update({'NODE_ENV':'development','NEXT_TELEMETRY_DISABLED':'1','FORCE_COLOR':'0'})
runtime = {'node':subprocess.check_output(['node','--version'],text=True).strip(), 'platform':platform.platform(), 'ports':[3240,3241], 'workers':1, 'testTimeout':30000,'expectTimeout':10000,'setupTimeout':90000, 'specs':specs, 'environment':{k:env.get(k) for k in ['NODE_ENV','NEXT_TELEMETRY_DISABLED','FORCE_COLOR','CI','WORKMESH_WEB_SAME_ORIGIN_API','NEXT_API_UPSTREAM','NEXT_DEV_API_UPSTREAM','NEXT_PUBLIC_API_URL']}}
(root/'environment.json').write_text(json.dumps(runtime,ensure_ascii=False,indent=2),encoding='utf8')
for label in ['baseline','head']:
    cwd = root/label
    runenv=env.copy()
    runenv['WORKMESH_PLAYWRIGHT_RUN_DIR']=str(root/(label+'-run'))
    runenv['PLAYWRIGHT_JSON_OUTPUT_NAME']=str(root/(label+'-report.json'))
    command=['cmd.exe','/d','/c','pnpm.cmd','--filter','@workmesh/web','exec','playwright','test','--config','playwright.mocked.config.ts',*specs,'--reporter=list,json']
    started=datetime.datetime.now(datetime.timezone.utc).isoformat()
    with (root/(label+'-browser.log')).open('wb') as log:
        p=subprocess.Popen(command,cwd=cwd,env=runenv,stdout=log,stderr=subprocess.STDOUT)
        (root/(label+'-process.json')).write_text(json.dumps({'pid':p.pid,'startedAt':started,'cwd':str(cwd),'command':command},indent=2),encoding='utf8')
        print(label+' running PID '+str(p.pid),flush=True)
        code=p.wait()
    result={'sourceCommit':manifest['refs'][label],'startedAt':started,'finishedAt':datetime.datetime.now(datetime.timezone.utc).isoformat(),'exitCode':code,'command':command,'cwd':str(cwd)}
    (root/(label+'-result.json')).write_text(json.dumps(result,ensure_ascii=False,indent=2),encoding='utf8')
    print(label+' exit '+str(code),flush=True)
