import hashlib,json,pathlib,zipfile
root=pathlib.Path(__file__).resolve().parent
dest=root.parent.parent/'docs/reviews/c3'
members=[]; excluded=[]
selected=['prepare.py','run.py','analyze.py','package-evidence.py','bind-git-bytes.py','archive.py','verification-first-failure.json','source.json','environment.json','baseline-runtime.json','head-runtime.json','baseline-install.log','head-install.log','baseline-browser.log','head-browser.log','baseline-report.json','head-report.json','baseline-result.json','head-result.json','baseline-process.json','head-process.json','baseline-server-ownership.json','head-server-ownership.json','comparison-differences.json','old-errors.json']
files=[root/name for name in selected]
for label in ['baseline','head']:
    for directory in [root/(label+'-run'),root/(label+'-external-evidence')]:
        if directory.exists():
            for file in sorted(directory.rglob('*')):
                if not file.is_file():continue
                rel=file.relative_to(root).as_posix()
                data=file.read_bytes()
                if file.name=='trace.zip' or '.auth' in file.parts:
                    excluded.append({'path':str(file),'bytes':len(data),'sha256':hashlib.sha256(data).hexdigest(),'reason':'原始 trace/认证状态不提交；必要失败控制台、DOM、截图已另行保全'})
                elif file.suffix in ['.json','.md','.png','.txt']:
                    files.append(file)
                else:
                    excluded.append({'path':str(file),'bytes':len(data),'sha256':hashlib.sha256(data).hexdigest(),'reason':'非必要报告缓存；必要记录已另存'})
# 样例秘密仅用于泄露扫描，不在报告输出其值。
needles=[b'loading-state-csrf',b'csrf-preview',b'operations-csrf',b'workmesh_session=']
hits=[]
archive=dest/'mocked-regression-evidence.zip'
payloads=[(file,file.read_bytes()) for file in files]
for file,data in payloads:
    # 扫描实际报告和附件；脚本内的扫描规则字面量不是认证材料。
    if file.suffix!='.py' and any(word in data for word in needles): hits.append(file.relative_to(root).as_posix())
assert hits==[],hits
with zipfile.ZipFile(archive,'w',compression=zipfile.ZIP_DEFLATED,compresslevel=9) as z:
    for file,data in payloads:
        rel=file.relative_to(root).as_posix()
        z.writestr(rel,data)
        info=z.getinfo(rel)
        members.append({'member':rel,'originalPath':str(file),'bytes':len(data),'sha256':hashlib.sha256(data).hexdigest(),'crc32':f'{info.CRC:08x}'})
with zipfile.ZipFile(archive) as z:
    assert z.testzip() is None
    for file in members:
        data=z.read(file['member'])
        assert len(data)==file['bytes'] and hashlib.sha256(data).hexdigest()==file['sha256']
index={'archive':archive.name,'archiveSha256':hashlib.sha256(archive.read_bytes()).hexdigest(),'policy':'两次完整执行原报告、日志与必要附件原字节无损归档；未删除失败，不把匹配失败计成通过。trace/认证状态不进入提交。','members':members,'excluded':excluded,'secretScan':{'fixtureSecretOrCookieHits':hits,'realProviderCredentialsUsed':False},'verification':'逐成员原字节、SHA-256、CRC 与 ZIP.testzip 均一致；独立 verifier 再检查源码 Git blob 与 47 项语义结果'}
(dest/'mocked-regression-evidence-index.json').write_text(json.dumps(index,ensure_ascii=False,indent=2)+'\n',encoding='utf8')
print(json.dumps({'archiveBytes':archive.stat().st_size,'members':len(members),'excluded':len(excluded),'secretHits':len(hits)},ensure_ascii=False))
