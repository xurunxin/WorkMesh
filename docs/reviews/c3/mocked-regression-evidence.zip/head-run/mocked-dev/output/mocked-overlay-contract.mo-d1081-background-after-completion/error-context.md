# Instructions

- Following Playwright test failed.
- Explain why, be concise, respect Playwright best practices.
- Provide a snippet of code with the fix, if possible.

# Test info

- Name: mocked\overlay-contract.mocked.spec.ts >> overlay contract at 1920x1080 >> keeps busy delete nondismissible and restores the exact background after completion
- Location: e2e\mocked\overlay-contract.mocked.spec.ts:424:5

# Error details

```
Error: expect(received).toBeGreaterThan(expected)

Expected: > 0
Received:   0
```

# Page snapshot

```yaml
- generic [active] [ref=e1]:
  - button "Open Next.js Dev Tools" [ref=e7] [cursor=pointer]:
    - img [ref=e8]
  - alert [ref=e11]
  - generic [ref=e12]:
    - link "跳到主要内容" [ref=e13] [cursor=pointer]:
      - /url: "#workmesh-main"
    - complementary "主导航" [ref=e14]:
      - generic [ref=e15]:
        - strong [ref=e17]: WorkMesh
        - generic [ref=e18]: Alex Morgan
      - button "收起导航栏" [expanded] [ref=e19] [cursor=pointer]:
        - img [ref=e20]
        - generic [ref=e22]: 收起导航栏
      - generic [ref=e24]:
        - text: 团队
        - combobox "当前团队" [ref=e25]:
          - option "无团队" [disabled]
          - option "Runtime Reliability (RUN)" [selected]
          - option "Platform (PLAT)"
      - navigation "工作区导航" [ref=e26]:
        - link "返回 Issues" [ref=e27] [cursor=pointer]:
          - /url: /?view=my-work
          - img [ref=e29]
          - generic [ref=e31]: 返回 Issues
      - navigation "管理导航" [ref=e32]:
        - link "设置" [ref=e33] [cursor=pointer]:
          - /url: /settings
          - img [ref=e35]
          - generic [ref=e37]: 设置
      - generic [ref=e39]:
        - button "退出登录" [ref=e40] [cursor=pointer]:
          - img [ref=e42]
          - generic [ref=e44]: 退出登录
        - generic [ref=e45]: v1.0.0 · 构建 project-work-preview · 数据库架构 24
    - generic [ref=e46]:
      - banner [ref=e47]:
        - paragraph [ref=e48]:
          - generic [ref=e49]: 工作区
        - button "搜索" [ref=e51] [cursor=pointer]:
          - img [ref=e53]
          - generic [ref=e55]:
            - generic [ref=e56]: 搜索
            - generic [ref=e57]: Ctrl K
        - generic [ref=e58]:
          - button "切换到浅色主题" [ref=e59]:
            - img [ref=e60]
          - group "语言" [ref=e63]:
            - button "中" [pressed] [ref=e64]
            - button "EN" [ref=e65]
      - main [ref=e66]:
        - generic [ref=e67]:
          - generic [ref=e69]:
            - heading "设置" [level=1] [ref=e70]
            - paragraph [ref=e71]: 工作区管理与日常规划保持分离。
          - generic [ref=e72]:
            - tablist "设置分区" [ref=e73]:
              - tab "工作区" [selected] [ref=e74]:
                - generic [ref=e75]: 工作区
            - tabpanel "工作区" [ref=e76]:
              - generic [ref=e77]:
                - region "团队" [ref=e78]:
                  - paragraph [ref=e79]: 工作区结构
                  - heading "团队" [level=2] [ref=e80]
                  - generic [ref=e81]:
                    - generic [ref=e82]:
                      - text: 团队名称
                      - textbox "团队名称" [ref=e83]
                    - generic [ref=e84]:
                      - text: 团队标识
                      - textbox "团队标识" [ref=e85]:
                        - /placeholder: ENG
                    - button "新建团队" [ref=e86] [cursor=pointer]:
                      - img [ref=e88]
                      - generic [ref=e90]: 新建团队
                - region "团队详情" [ref=e91]:
                  - paragraph [ref=e92]: 已选团队
                  - heading "团队详情" [level=2] [ref=e93]
                  - generic [ref=e94]:
                    - generic [ref=e95]:
                      - text: 团队名称
                      - textbox "团队名称" [ref=e96]: Runtime Reliability
                    - generic [ref=e97]:
                      - text: 团队标识
                      - textbox "团队标识" [ref=e98]: RUN
                    - button "保存更改" [ref=e99] [cursor=pointer]:
                      - img [ref=e101]
                      - generic [ref=e103]: 保存更改
                  - generic [ref=e104]:
                    - generic [ref=e105]:
                      - strong [ref=e106]: 删除团队
                      - paragraph [ref=e107]: 从活动导航中移除此团队；关联工作将保留，但不可用。
                    - button "删除团队" [ref=e108] [cursor=pointer]:
                      - img [ref=e110]
                      - generic [ref=e112]: 删除团队
                - region "工作流状态" [ref=e113]:
                  - paragraph [ref=e114]: 团队工作流
                  - heading "工作流状态" [level=2] [ref=e115]
                  - article [ref=e117]:
                    - generic [ref=e120]:
                      - strong [ref=e121]: Ready
                      - generic [ref=e122]: 已规划
                    - button "编辑状态 Ready" [ref=e123] [cursor=pointer]:
                      - img [ref=e125]
                      - generic [ref=e127]: 编辑
                  - generic [ref=e128]:
                    - generic [ref=e129]:
                      - text: 状态名称
                      - textbox "状态名称" [ref=e130]
                    - generic [ref=e131]:
                      - text: 分类
                      - combobox "分类" [ref=e132]:
                        - option "待办"
                        - option "已规划" [selected]
                        - option "进行中"
                        - option "已完成"
                        - option "已取消"
                    - group "状态颜色" [ref=e133]:
                      - generic [ref=e134]: 状态颜色
                      - generic [ref=e135]:
                        - generic [ref=e136] [cursor=pointer]:
                          - radio "中性" [checked] [ref=e137]
                          - generic [ref=e139]: 中性
                        - generic [ref=e140] [cursor=pointer]:
                          - radio "蓝色" [ref=e141]
                          - generic [ref=e143]: 蓝色
                        - generic [ref=e144] [cursor=pointer]:
                          - radio "绿色" [ref=e145]
                          - generic [ref=e147]: 绿色
                        - generic [ref=e148] [cursor=pointer]:
                          - radio "琥珀色" [ref=e149]
                          - generic [ref=e151]: 琥珀色
                        - generic [ref=e152] [cursor=pointer]:
                          - radio "红色" [ref=e153]
                          - generic [ref=e155]: 红色
                        - generic [ref=e156] [cursor=pointer]:
                          - radio "自定义" [ref=e157]
                          - generic [ref=e159]: 自定义
                    - button "新建状态" [ref=e160] [cursor=pointer]:
                      - img [ref=e162]
                      - generic [ref=e164]: 新建状态
              - region "模型服务接入" [ref=e165]:
                - paragraph [ref=e166]: Agent workbench
                - heading "模型服务接入" [level=2] [ref=e167]
                - paragraph [ref=e168]: 管理 Chat Completions 与 Responses 模型服务、凭据和模型目录。
                - link "打开接入设置" [ref=e169] [cursor=pointer]:
                  - /url: /settings/agent-workbench
```

# Test source

```ts
  69  |   bodyStyle: string | null
  70  |   htmlStyle: string | null
  71  |   main: Rect
  72  |   scrollX: number
  73  |   scrollY: number
  74  | }
  75  | 
  76  | function deferred(): { promise: Promise<void>; resolve: () => void } {
  77  |   let resolve: () => void = () => undefined
  78  |   const promise = new Promise<void>(done => { resolve = done })
  79  |   return { promise, resolve }
  80  | }
  81  | 
  82  | async function fulfillJson(route: Parameters<Parameters<Page['route']>[1]>[0], payload: unknown): Promise<void> {
  83  |   await route.fulfill({ status: 200, headers: responseHeaders, body: JSON.stringify(payload) })
  84  | }
  85  | 
  86  | async function installAgentFixtures(page: Page, requests: string[]): Promise<void> {
  87  |   await page.route(`${apiUrl}/api/v1/**`, async route => {
  88  |     const request = route.request()
  89  |     const url = new URL(request.url())
  90  |     requests.push(`${request.method()} ${url.pathname}`)
  91  |     if (request.method() === 'OPTIONS') return route.fulfill({ status: 204, headers: responseHeaders, body: '' })
  92  |     if (url.pathname === '/api/v1/features') return fulfillJson(route, {
  93  |       features: canonicalFeatures.map(key => ({ key, tier: key.includes('EXPERIMENTAL') ? 'experimental' : 'beta', enabled: key === 'WORKMESH_BETA_PLANNING' || key === 'WORKMESH_BETA_OPERATIONS_UI' })),
  94  |     })
  95  |     if (url.pathname === '/api/v1/agents') return fulfillJson(route, { items: [agent], nextCursor: null })
  96  |     if (url.pathname === '/api/v1/teams') return fulfillJson(route, { items: teams, nextCursor: null })
  97  |     if (url.pathname === '/api/v1/agent-sessions' || url.pathname === '/api/v1/actors/humans')
  98  |       return fulfillJson(route, { items: [], nextCursor: null })
  99  |     if (url.pathname === '/api/v1/approvals') return fulfillJson(route, { items: [], nextCursor: null })
  100 |     await route.continue()
  101 |   })
  102 | }
  103 | 
  104 | async function installSettingsFixtures(page: Page, requests: string[]) {
  105 |   const deletion = deferred()
  106 |   const target = { id: 'team/delete-overlay', name: 'Runtime Reliability', key: 'RUN', revision: 11 }
  107 |   const survivor = { id: 'team-survivor', name: 'Platform', key: 'PLAT', revision: 4 }
  108 |   let deleted = false
  109 |   let deleteCount = 0
  110 |   await page.route(`${apiUrl}/api/v1/**`, async route => {
  111 |     const request = route.request()
  112 |     const url = new URL(request.url())
  113 |     requests.push(`${request.method()} ${url.pathname}`)
  114 |     if (request.method() === 'OPTIONS') return route.fulfill({ status: 204, headers: responseHeaders, body: '' })
  115 |     if (url.pathname === '/api/v1/features') return fulfillJson(route, {
  116 |       features: canonicalFeatures.map(key => ({ key, tier: key.includes('EXPERIMENTAL') ? 'experimental' : 'beta', enabled: true })),
  117 |     })
  118 |     if (request.method() === 'DELETE' && url.pathname === '/api/v1/teams/team%2Fdelete-overlay') {
  119 |       deleteCount += 1
  120 |       await deletion.promise
  121 |       deleted = true
  122 |       return route.fulfill({ status: 204, headers: responseHeaders, body: '' })
  123 |     }
  124 |     if (url.pathname === '/api/v1/teams') return fulfillJson(route, {
  125 |       items: deleted ? [survivor] : [target, survivor],
  126 |       nextCursor: null,
  127 |     })
  128 |     const stateMatch = url.pathname.match(/^\/api\/v1\/teams\/([^/]+)\/states$/)
  129 |     if (stateMatch) return fulfillJson(route, {
  130 |       items: [{ id: `state-${decodeURIComponent(stateMatch[1]!)}`, name: 'Ready', category: 'planned', color: '#64748b', revision: 1 }],
  131 |       nextCursor: null,
  132 |     })
  133 |     await route.continue()
  134 |   })
  135 |   return {
  136 |     deleteCount: () => deleteCount,
  137 |     release: deletion.resolve,
  138 |     survivor,
  139 |     target,
  140 |   }
  141 | }
  142 | 
  143 | async function prepareScrollableBackground(page: Page): Promise<BackgroundSnapshot> {
  144 |   await page.evaluate(async () => {
  145 |     document.documentElement.style.setProperty('--task-6-2-html-preserved', '1')
  146 |     document.body.style.setProperty('--task-6-2-body-preserved', '1')
  147 |     const spacer = document.createElement('div')
  148 |     spacer.dataset.task62Spacer = 'true'
  149 |     spacer.style.height = '1800px'
  150 |     spacer.style.pointerEvents = 'none'
  151 |     spacer.style.width = '1px'
  152 |     document.body.append(spacer)
  153 |     await new Promise<void>(resolve => requestAnimationFrame(() => resolve()))
  154 |     window.scrollTo(0, 180)
  155 |     await new Promise<void>(resolve => requestAnimationFrame(() => resolve()))
  156 |   })
  157 |   const snapshot = await page.evaluate(() => {
  158 |     const main = document.querySelector<HTMLElement>('#workmesh-main')
  159 |     if (!main) throw new Error('Main landmark missing')
  160 |     const rect = main.getBoundingClientRect()
  161 |     return {
  162 |       bodyStyle: document.body.getAttribute('style'),
  163 |       htmlStyle: document.documentElement.getAttribute('style'),
  164 |       main: { bottom: rect.bottom, height: rect.height, left: rect.left, right: rect.right, top: rect.top, width: rect.width },
  165 |       scrollX: window.scrollX,
  166 |       scrollY: window.scrollY,
  167 |     }
  168 |   })
> 169 |   expect(snapshot.scrollY).toBeGreaterThan(0)
      |                            ^ Error: expect(received).toBeGreaterThan(expected)
  170 |   return snapshot
  171 | }
  172 | 
  173 | async function assertBackgroundRestored(page: Page, snapshot: BackgroundSnapshot): Promise<void> {
  174 |   await expect.poll(() => page.evaluate(() => window.scrollY)).toBe(snapshot.scrollY)
  175 |   const restored = await page.evaluate(() => ({
  176 |     bodyStyle: document.body.getAttribute('style'),
  177 |     htmlStyle: document.documentElement.getAttribute('style'),
  178 |     scrollX: window.scrollX,
  179 |   }))
  180 |   expect(restored).toEqual({ bodyStyle: snapshot.bodyStyle, htmlStyle: snapshot.htmlStyle, scrollX: snapshot.scrollX })
  181 | }
  182 | 
  183 | async function expectValidPostDeleteFocus(page: Page): Promise<{
  184 |   connected: boolean
  185 |   identity: string
  186 |   visible: boolean
  187 | }> {
  188 |   await expect.poll(() => page.evaluate(() => {
  189 |     const active = document.activeElement
  190 |     if (!(active instanceof HTMLElement)) return false
  191 |     return active.matches('.app-team-switcher select, #team-settings-heading, #workmesh-main')
  192 |   })).toBe(true)
  193 | 
  194 |   const evidence = await page.evaluate(() => {
  195 |     const active = document.activeElement
  196 |     if (!(active instanceof HTMLElement)) throw new Error('Post-delete focus is not an HTML element')
  197 |     const rect = active.getBoundingClientRect()
  198 |     const style = window.getComputedStyle(active)
  199 |     return {
  200 |       connected: active.isConnected,
  201 |       identity: active.id ? `#${active.id}` : `${active.tagName.toLowerCase()}${active.className ? `.${String(active.className).trim().replace(/\s+/g, '.')}` : ''}`,
  202 |       visible: style.display !== 'none'
  203 |         && style.visibility !== 'hidden'
  204 |         && active.getClientRects().length > 0
  205 |         && rect.width > 0
  206 |         && rect.height > 0,
  207 |     }
  208 |   })
  209 |   expect(evidence.connected).toBe(true)
  210 |   expect(evidence.visible).toBe(true)
  211 |   expect(evidence.identity).not.toBe('body')
  212 |   return evidence
  213 | }
  214 | 
  215 | async function measureOverlay(dialog: Locator, before: BackgroundSnapshot) {
  216 |   return dialog.evaluate((element, snapshot) => {
  217 |     if (!(element instanceof HTMLElement)) throw new Error('Overlay root missing')
  218 |     const main = document.querySelector<HTMLElement>('#workmesh-main')
  219 |     if (!main) throw new Error('Main landmark missing')
  220 |     const toRect = (target: HTMLElement) => {
  221 |       const rect = target.getBoundingClientRect()
  222 |       return { bottom: rect.bottom, height: rect.height, left: rect.left, right: rect.right, top: rect.top, width: rect.width }
  223 |     }
  224 |     const rect = toRect(element)
  225 |     const mainRect = toRect(main)
  226 |     return {
  227 |       activeInside: element.contains(document.activeElement),
  228 |       bodyPosition: document.body.style.position,
  229 |       bodyTop: document.body.style.top,
  230 |       centerDelta: Math.abs(rect.left - (window.innerWidth - rect.right)),
  231 |       dialog: rect,
  232 |       document: { clientWidth: document.documentElement.clientWidth, scrollWidth: document.documentElement.scrollWidth },
  233 |       htmlOverflow: document.documentElement.style.overflow,
  234 |       inertCount: document.querySelectorAll('[inert]').length,
  235 |       internalScroll: { clientHeight: element.clientHeight, scrollHeight: element.scrollHeight, scrollTop: element.scrollTop },
  236 |       main: mainRect,
  237 |       mainShift: { left: Math.abs(mainRect.left - snapshot.main.left), width: Math.abs(mainRect.width - snapshot.main.width) },
  238 |       scroll: { x: window.scrollX, y: window.scrollY },
  239 |       viewport: { height: window.innerHeight, width: window.innerWidth },
  240 |     }
  241 |   }, before)
  242 | }
  243 | 
  244 | function expectContained(evidence: Awaited<ReturnType<typeof measureOverlay>>, maxWidth: number): void {
  245 |   expect(evidence.dialog.width).toBeLessThanOrEqual(maxWidth + 0.5)
  246 |   expect(evidence.dialog.left).toBeGreaterThanOrEqual(-0.5)
  247 |   expect(evidence.dialog.top).toBeGreaterThanOrEqual(-0.5)
  248 |   expect(evidence.dialog.right).toBeLessThanOrEqual(evidence.viewport.width + 0.5)
  249 |   expect(evidence.dialog.bottom).toBeLessThanOrEqual(evidence.viewport.height + 0.5)
  250 |   expect(evidence.document.scrollWidth).toBe(evidence.document.clientWidth)
  251 |   expect(evidence.mainShift.left).toBeLessThanOrEqual(1)
  252 |   expect(evidence.mainShift.width).toBeLessThanOrEqual(1)
  253 |   expect(evidence.bodyPosition).toBe('fixed')
  254 |   expect(evidence.htmlOverflow).toBe('hidden')
  255 |   expect(evidence.inertCount).toBeGreaterThan(0)
  256 |   expect(evidence.activeInside).toBe(true)
  257 | }
  258 | 
  259 | async function persistEvidence(page: Page, testInfo: TestInfo, name: string, payload: unknown): Promise<void> {
  260 |   await mkdir(evidenceRoot, { recursive: true })
  261 |   await page.evaluate(() => { document.querySelectorAll('nextjs-portal').forEach(element => element.remove()) })
  262 |   const jsonPath = join(evidenceRoot, `${name}.json`)
  263 |   const screenshotPath = join(evidenceRoot, `${name}.png`)
  264 |   await writeFile(jsonPath, JSON.stringify(payload, null, 2), 'utf8')
  265 |   await page.screenshot({ path: screenshotPath })
  266 |   await testInfo.attach(name, { path: jsonPath, contentType: 'application/json' })
  267 |   await testInfo.attach(`${name}-screenshot`, { path: screenshotPath, contentType: 'image/png' })
  268 | }
  269 | 
```