# Instructions

- Following Playwright test failed.
- Explain why, be concise, respect Playwright best practices.
- Provide a snippet of code with the fix, if possible.

# Test info

- Name: mocked\loading-states.mocked.spec.ts >> Task 6.4 Settings loading authority >> separates Team and State initialization and retains the State surface through refresh failure
- Location: e2e\mocked\loading-states.mocked.spec.ts:622:3

# Error details

```
Error: expect(locator).toBeVisible() failed

Locator: locator('.settings-page').locator('.settings-loading-skeleton .skeleton-list')
Expected: visible
Timeout: 10000ms
Error: element(s) not found

Call log:
  - Expect "toBeVisible" with timeout 10000ms
  - waiting for locator('.settings-page').locator('.settings-loading-skeleton .skeleton-list')

```

```yaml
- alert
- main:
  - heading "Page not found" [level=1]
  - paragraph: The page you are looking for does not exist or has been moved.
  - link "Back to home":
    - /url: /
```

# Test source

```ts
  536 | test.describe('Task 6.4 Agent secondary surfaces', () => {
  537 |   test.use({ viewport: { height: 900, width: 1440 } })
  538 | 
  539 |   test('owns Sessions, Diagnostics, Connections and Approval states without stale actions', async ({ page }) => {
  540 |     const routes = new RouteScenarios()
  541 |     await routes.install(page)
  542 |     await page.context().addCookies([{ name: 'workmesh_locale', value: 'en', url: webUrl }])
  543 | 
  544 |     const sessionsPath = '/api/v1/agent-sessions?limit=100'
  545 |     const connectionsPath = '/api/v1/agent-connections?limit=50'
  546 |     const pendingPath = '/api/v1/approvals?status=pending&limit=100'
  547 |     const historyPath = '/api/v1/approvals?status=approved&limit=100'
  548 |     const sessionsPending = deferredResponse()
  549 |     const connectionsPending = deferredResponse()
  550 |     const attentionPending = deferredResponse()
  551 |     const pendingApprovals = deferredResponse()
  552 |     const historyPending = deferredResponse()
  553 |     routes.set('/api/v1/agents', { body: { items: [browserAgent], nextCursor: null } })
  554 |     routes.set(sessionsPath, sessionsPending.promise)
  555 |     routes.set(connectionsPath, connectionsPending.promise)
  556 |     routes.set('/api/v1/human-attention', attentionPending.promise)
  557 |     routes.set(pendingPath, pendingApprovals.promise)
  558 |     routes.set(historyPath, historyPending.promise)
  559 |     await page.goto('/agents?tab=sessions&approvalView=history&approvalStatus=approved', { waitUntil: 'domcontentloaded' })
  560 | 
  561 |     const sessions = page.getByRole('region', { name: 'Sessions', exact: true })
  562 |     const diagnostics = page.getByRole('region', { name: 'Diagnostics', exact: true })
  563 |     const connections = page.getByRole('region', { name: 'Connections', exact: true })
  564 |     await expect(sessions.locator('.skeleton-list')).toBeVisible()
  565 |     await expect(diagnostics.locator('.skeleton-list')).toBeVisible()
  566 |     await expect(connections.locator('.skeleton-list')).toBeVisible()
  567 |     await expect(sessions).not.toHaveAttribute('aria-busy')
  568 |     await expect(diagnostics).not.toHaveAttribute('aria-busy')
  569 |     await expect(connections).not.toHaveAttribute('aria-busy')
  570 | 
  571 |     const notFound = {
  572 |       body: { error: { code: 'NOT_FOUND', correlationId: 'safe-optional-404', message: 'Not found.' } },
  573 |       status: 404,
  574 |     } satisfies JsonResponse
  575 |     routes.set(sessionsPath, { body: { items: [], nextCursor: null } })
  576 |     sessionsPending.resolve(notFound)
  577 |     routes.set(connectionsPath, { body: { items: [], nextCursor: null } })
  578 |     connectionsPending.resolve({ body: { items: [], nextCursor: null } })
  579 |     routes.set('/api/v1/human-attention', { body: { items: [], nextCursor: null } })
  580 |     attentionPending.resolve({ body: { items: [], nextCursor: null } })
  581 |     await expect(sessions.locator('.skeleton-list')).toHaveCount(0)
  582 |     await expect(diagnostics.locator('.skeleton-list')).toHaveCount(0)
  583 |     await expect(connections.locator('.skeleton-list')).toHaveCount(0)
  584 |     await expect(connections.locator('.connection-empty')).toBeVisible()
  585 |     await page.getByRole('tab', { name: 'Approvals', exact: true }).click()
  586 |     await expect(page.locator('.approval-history .skeleton-list')).toBeVisible()
  587 |     routes.set(historyPath, { body: { items: [], nextCursor: null } })
  588 |     historyPending.resolve(notFound)
  589 |     await expect(page.locator('.approval-history .skeleton-list')).toHaveCount(0)
  590 |     await expect(page.getByText('safe-optional-404')).toHaveCount(0)
  591 | 
  592 |     await page.getByRole('tab', { name: 'Pending', exact: true }).click()
  593 |     const pendingProjection = page.locator('.approval-projection').filter({ has: page.locator('.skeleton-list') })
  594 |     await expect(pendingProjection.locator('.skeleton-list')).toBeVisible()
  595 |     await expect(pendingProjection).not.toHaveAttribute('aria-busy')
  596 |     const pendingResponse = { body: { items: [browserApproval], nextCursor: 'cursor-pending' } } satisfies JsonResponse
  597 |     routes.set(pendingPath, pendingResponse)
  598 |     pendingApprovals.resolve(pendingResponse)
  599 |     await expect(page.getByTestId(`approval-row-${browserApproval.id}`)).toBeVisible()
  600 |     await expect(page.getByTestId('load-more-approvals')).toBeVisible()
  601 | 
  602 |     const priorPendingRequests = routes.requests.filter(request => request === pendingPath).length
  603 |     routes.set(pendingPath, {
  604 |       body: { error: { code: 'RESOURCE_SCOPE_DENIED', correlationId: 'safe-pending-revoke', message: 'Denied.' } },
  605 |       status: 403,
  606 |     })
  607 |     await page.getByRole('button', { name: 'Refresh', exact: true }).evaluate((button: HTMLButtonElement) => button.click())
  608 |     await routes.waitFor(pendingPath, priorPendingRequests + 1)
  609 |     await expect(page.getByTestId(`approval-row-${browserApproval.id}`)).toHaveCount(0)
  610 |     await expect(page.getByTestId('load-more-approvals')).toHaveCount(0)
  611 |     await expect(page.getByRole('heading', { name: 'Agent workspace needs attention' })).toBeVisible()
  612 |     await expect(page.locator('.control-summary')).toHaveCount(0)
  613 |     await expect(page.locator('.approval-projection .empty')).toHaveCount(0)
  614 |     await expect(page.getByText('safe-pending-revoke')).toHaveCount(0)
  615 |     expect(routes.unexpected).toEqual([])
  616 |   })
  617 | })
  618 | 
  619 | test.describe('Task 6.4 Settings loading authority', () => {
  620 |   test.use({ viewport: { height: 900, width: 1440 } })
  621 | 
  622 |   test('separates Team and State initialization and retains the State surface through refresh failure', async ({ page }) => {
  623 |     const routes = new RouteScenarios()
  624 |     await routes.install(page)
  625 |     await page.context().addCookies([{ name: 'workmesh_locale', value: 'en', url: webUrl }])
  626 | 
  627 |     const teamsPending = deferredResponse()
  628 |     const statesPending = deferredResponse()
  629 |     const statesPath = `/api/v1/teams/${team.id}/states`
  630 |     routes.set('/api/v1/teams', teamsPending.promise)
  631 |     routes.setRequest('GET', statesPath, statesPending.promise)
  632 |     await page.goto('/settings?tab=workspace', { waitUntil: 'domcontentloaded' })
  633 | 
  634 |     const settings = page.locator('.settings-page')
  635 |     const initialSkeleton = settings.locator('.settings-loading-skeleton .skeleton-list')
> 636 |     await expect(initialSkeleton).toBeVisible()
      |                                   ^ Error: expect(locator).toBeVisible() failed
  637 |     await expect(settings).not.toHaveAttribute('aria-busy')
  638 |     await expect(settings.locator('[aria-busy="true"]')).toHaveCount(1)
  639 |     await expect(settings.getByText('No Team', { exact: true })).toHaveCount(0)
  640 | 
  641 |     const teamsResponse = { body: { items: [team], nextCursor: null } } satisfies JsonResponse
  642 |     routes.set('/api/v1/teams', teamsResponse)
  643 |     teamsPending.resolve(teamsResponse)
  644 |     const workflow = settings.locator('[aria-labelledby="workflow-settings-heading"]')
  645 |     await expect(workflow.locator('.skeleton-list')).toBeVisible()
  646 |     await expect(workflow).not.toHaveAttribute('aria-busy')
  647 |     await expect(workflow.locator('[aria-busy="true"]')).toHaveCount(1)
  648 | 
  649 |     const state = { category: 'backlog', color: '#a8a29e', id: 'state-backlog', name: 'Backlog', revision: 1 }
  650 |     const statesResponse = { body: { items: [state], nextCursor: null } } satisfies JsonResponse
  651 |     routes.setRequest('GET', statesPath, statesResponse)
  652 |     statesPending.resolve(statesResponse)
  653 |     const stateRow = workflow.locator('.workflow-state-list article').first()
  654 |     await expect(stateRow).toContainText('Backlog')
  655 | 
  656 |     const stateName = workflow.locator('input[name="name"]')
  657 |     await stateName.fill('Review')
  658 |     await stateName.evaluate(element => { element.dataset.loadingIdentity = 'retained-state-form' })
  659 |     const refreshPending = deferredResponse()
  660 |     const pagedStatesPath = `${statesPath}?limit=100`
  661 |     const priorRequests = routes.requests.filter(request => request === pagedStatesPath).length
  662 |     routes.setRequest('POST', statesPath, { body: { ...state, id: 'state-review', name: 'Review' } })
  663 |     routes.setRequest('GET', pagedStatesPath, refreshPending.promise)
  664 |     await workflow.locator('form').evaluate((form: HTMLFormElement) => form.requestSubmit())
  665 |     await routes.waitFor(pagedStatesPath, priorRequests + 1)
  666 |     await expect(workflow).toHaveAttribute('aria-busy', 'true')
  667 |     await expect(stateRow).toContainText('Backlog')
  668 |     await expect(stateName).toHaveAttribute('data-loading-identity', 'retained-state-form')
  669 |     await expect(stateName).toBeFocused()
  670 | 
  671 |     routes.setRequest('GET', pagedStatesPath, statesResponse)
  672 |     refreshPending.resolve({
  673 |       body: { error: { code: 'TEMPORARY_UNAVAILABLE', correlationId: 'safe-state-refresh', message: 'Please retry.' } },
  674 |       status: 500,
  675 |     })
  676 |     await expect(workflow).not.toHaveAttribute('aria-busy')
  677 |     await expect(stateRow).toContainText('Backlog')
  678 |     await expect(stateName).toHaveAttribute('data-loading-identity', 'retained-state-form')
  679 |     await expect(stateName).toBeFocused()
  680 |     await expect(workflow.locator('[role="status"]')).toHaveCount(0)
  681 |     await expect(page.locator('.settings-page [role="alert"]')).toContainText('Unable to load Settings.')
  682 |     await expect(page.getByRole('button', { name: 'Retry', exact: true })).toBeVisible()
  683 |     await expect(page.getByText('safe-state-refresh')).toHaveCount(0)
  684 |     expect(routes.unexpected).toEqual([])
  685 |   })
  686 | })
  687 | 
  688 | test.describe('Task 6.4 Operations loading authority', () => {
  689 |   test.use({ viewport: { height: 900, width: 1440 } })
  690 | 
  691 |   test('uses real pending owners, resolves independently, and retains focus through refresh failure', async ({ page }) => {
  692 |     const routes = new RouteScenarios()
  693 |     await routes.install(page)
  694 |     await page.context().addCookies([{ name: 'workmesh_locale', value: 'en', url: webUrl }])
  695 | 
  696 |     const featuresPending = deferredResponse()
  697 |     routes.set('/api/v1/features', featuresPending.promise)
  698 |     await page.goto('/operations', { waitUntil: 'domcontentloaded' })
  699 | 
  700 |     const featureStatus = page.getByRole('status', { name: 'Loading Operations' })
  701 |     await expect(featureStatus).toBeVisible()
  702 |     await expect(page.locator('.operations-loading')).not.toHaveAttribute('aria-busy')
  703 |     await expect(page.locator('.operations-loading [aria-busy="true"]')).toHaveCount(1)
  704 | 
  705 |     const pendingCollections = new Map<string, ReturnType<typeof deferredResponse>>()
  706 |     for (const path of Object.keys(collectionPayloads)) {
  707 |       const pending = deferredResponse()
  708 |       pendingCollections.set(path, pending)
  709 |       routes.set(path, pending.promise)
  710 |     }
  711 |     const usagePending = deferredResponse()
  712 |     routes.set('/api/v1/usage-summary', usagePending.promise)
  713 |     routes.set('/api/v1/features', allFeatures)
  714 |     featuresPending.resolve(allFeatures)
  715 | 
  716 |     await expect(page.locator('.operations-usage-loading .skeleton-list')).toBeVisible()
  717 |     await expect(page.locator('.operations-grid .skeleton-list')).toHaveCount(6)
  718 |     await expect(page.locator('.operations-grid section[aria-busy="true"]')).toHaveCount(0)
  719 |     await expect(page.locator('.operations-grid .skeleton-list[aria-busy="true"]')).toHaveCount(6)
  720 | 
  721 |     routes.set('/api/v1/usage-summary', usage)
  722 |     usagePending.resolve(usage)
  723 |     for (const [path, pending] of pendingCollections) {
  724 |       const response = collectionPayloads[path]!
  725 |       routes.set(path, response)
  726 |       pending.resolve(response)
  727 |     }
  728 | 
  729 |     const dryRun = page.getByRole('button', { name: 'Dry run' })
  730 |     await expect(dryRun).toBeVisible()
  731 |     await dryRun.focus()
  732 |     const automation = page.getByTestId('automation-panel')
  733 |     await dryRun.evaluate(element => { element.dataset.loadingIdentity = 'retained-rule-control' })
  734 | 
  735 |     const rulesFailure = deferredResponse()
  736 |     routes.set('/api/v1/automation-rules', rulesFailure.promise)
```