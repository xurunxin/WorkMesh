# Instructions

- Following Playwright test failed.
- Explain why, be concise, respect Playwright best practices.
- Provide a snippet of code with the fix, if possible.

# Test info

- Name: mocked\page-hotkeys.mocked.spec.ts >> page hotkeys at 1920px >> keeps global navigation, one visible filter, no-filter surfaces and command-center ownership deterministic
- Location: e2e\mocked\page-hotkeys.mocked.spec.ts:166:5

# Error details

```
Error: expect(received).toBe(expected) // Object.is equality

Expected: "ga"
Received: null
```

# Page snapshot

```yaml
- generic [ref=e1]:
  - generic [ref=e6] [cursor=pointer]:
    - button "Open Next.js Dev Tools" [ref=e7]:
      - img [ref=e8]
    - generic [ref=e11]:
      - button "Open issues overlay" [ref=e12]:
        - generic [ref=e13]:
          - generic [ref=e14]: "0"
          - generic [ref=e15]: "1"
        - generic [ref=e16]: Issue
      - button "Collapse issues badge" [ref=e17]:
        - img [ref=e18]
  - alert [ref=e20]
  - generic [ref=e21]:
    - link "跳到主要内容" [ref=e22] [cursor=pointer]:
      - /url: "#workmesh-main"
    - complementary "主导航" [ref=e23]:
      - generic [ref=e24]:
        - strong [ref=e26]: WorkMesh
        - generic [ref=e27]: Alex Morgan
      - button "收起导航栏" [expanded] [ref=e28] [cursor=pointer]:
        - img [ref=e29]
        - generic [ref=e31]: 收起导航栏
      - generic [ref=e33]:
        - text: 团队
        - combobox "当前团队" [ref=e34]:
          - option "无团队" [disabled]
          - option "WorkMesh Product (WM)" [selected]
      - navigation "工作区导航" [ref=e35]:
        - generic [ref=e36]:
          - paragraph [ref=e37]: 工作台
          - link "工作台" [ref=e38] [cursor=pointer]:
            - /url: /workbench
            - img [ref=e40]
            - generic [ref=e42]: 工作台
          - link "我的工作" [ref=e43] [cursor=pointer]:
            - /url: /?view=home
            - img [ref=e45]
            - generic [ref=e47]: 我的工作
          - link "Issues" [ref=e48] [cursor=pointer]:
            - /url: /?view=my-work
            - img [ref=e50]
            - generic [ref=e52]: Issues
            - generic [ref=e53]: "0"
          - link "指南" [ref=e54] [cursor=pointer]:
            - /url: /?view=guidance
            - img [ref=e56]
            - generic [ref=e58]: 指南
        - generic [ref=e59]:
          - paragraph [ref=e60]: 治理
          - link "需要我处理" [ref=e61] [cursor=pointer]:
            - /url: /?view=inbox
            - img [ref=e63]
            - generic [ref=e65]: 需要我处理
          - link "Session" [ref=e66] [cursor=pointer]:
            - /url: /?view=sessions
            - img [ref=e68]
            - generic [ref=e70]: Session
          - link "恢复中心" [ref=e71] [cursor=pointer]:
            - /url: /?view=recovery
            - img [ref=e73]
            - generic [ref=e75]: 恢复中心
          - link "项目" [ref=e76] [cursor=pointer]:
            - /url: /?view=projects
            - img [ref=e78]
            - generic [ref=e80]: 项目
            - generic [ref=e81]: "1"
          - link "智能体" [ref=e82] [cursor=pointer]:
            - /url: /agents
            - img [ref=e84]
            - generic [ref=e86]: 智能体
        - generic [ref=e87]:
          - paragraph [ref=e88]: 运营
          - link "运营" [ref=e89] [cursor=pointer]:
            - /url: /operations
            - img [ref=e91]
            - generic [ref=e93]: 运营
      - navigation "管理导航" [ref=e94]:
        - link "设置" [ref=e95] [cursor=pointer]:
          - /url: /settings
          - img [ref=e97]
          - generic [ref=e99]: 设置
      - generic [ref=e101]:
        - button "退出登录" [ref=e102] [cursor=pointer]:
          - img [ref=e104]
          - generic [ref=e106]: 退出登录
        - generic [ref=e107]: v1.0.0 · 构建 project-work-preview · 数据库架构 24
    - generic [ref=e108]:
      - banner [ref=e109]:
        - paragraph [ref=e110]:
          - generic [ref=e111]: Issues
        - button "搜索" [ref=e113] [cursor=pointer]:
          - img [ref=e115]
          - generic [ref=e117]:
            - generic [ref=e118]: 搜索
            - generic [ref=e119]: Ctrl K
        - generic [ref=e120]:
          - button "切换到浅色主题" [ref=e121]:
            - img [ref=e122]
          - generic [ref=e124]:
            - group "语言" [ref=e125]:
              - button "中" [pressed] [ref=e126]
              - button "EN" [ref=e127]
            - generic "正在重新连接" [ref=e128]:
              - generic [ref=e129]: 正在重新连接
      - main [ref=e130]:
        - generic [ref=e131]:
          - generic [ref=e132]:
            - heading "Issues" [level=1] [ref=e134]
            - button "新建 Issue" [ref=e136] [cursor=pointer]:
              - img [ref=e138]
              - generic [ref=e140]: 新建 Issue
          - region "工作项视图" [ref=e141]:
            - region "Issue 筛选器" [ref=e142]:
              - generic [ref=e143]:
                - generic [ref=e144]:
                  - text: 搜索
                  - textbox "搜索" [active] [ref=e145]:
                    - /placeholder: 搜索 Issue 标题或编号
                    - text: ga
                - generic [ref=e146]:
                  - text: 状态
                  - combobox "状态" [ref=e147]:
                    - option "全部状态" [selected]
                    - option "Backlog"
                    - option "Ready"
                    - option "In Progress"
                    - option "Review"
                    - option "Done"
                - generic [ref=e148]:
                  - text: 优先级
                  - combobox "优先级" [ref=e149]:
                    - option "全部优先级" [selected]
                    - option "无优先级"
                    - option "紧急"
                    - option "高"
                    - option "中"
                    - option "低"
                - generic [ref=e150]:
                  - text: 负责人
                  - combobox "负责人" [ref=e151]:
                    - option "全部负责人" [selected]
                    - option "Alex Morgan"
                - generic [ref=e152]:
                  - text: 项目
                  - combobox "项目" [ref=e153]:
                    - option "全部项目" [selected]
                    - option "Kaneo UI Adoption"
                - button "更多筛选" [ref=e154] [cursor=pointer]:
                  - generic [ref=e155]: 更多筛选
                - button "清除筛选" [ref=e156] [cursor=pointer]:
                  - img [ref=e158]
                  - generic [ref=e160]: 清除筛选
              - generic [ref=e162]:
                - generic [ref=e163]: 保存视图名称
                - textbox "保存视图名称" [ref=e164]:
                  - /placeholder: 保存视图
                - button "保存视图" [ref=e165] [cursor=pointer]:
                  - img [ref=e167]
                  - generic [ref=e169]: 保存视图
            - generic "Issue 视图布局" [ref=e170]:
              - button "列表视图" [pressed] [ref=e171] [cursor=pointer]:
                - img [ref=e173]
                - generic [ref=e175]: 列表视图
              - button "看板视图" [ref=e176] [cursor=pointer]:
                - img [ref=e178]
                - generic [ref=e180]: 看板视图
              - button "Issue 密度" [ref=e181] [cursor=pointer]:
                - generic [ref=e182]: 紧凑
            - status [ref=e183]:
              - generic [ref=e185]:
                - heading "没有 Issue" [level=2] [ref=e186]
                - paragraph [ref=e187]: 当前筛选条件下没有可访问的 Issue。
```

# Test source

```ts
  86  | async function attachGeometry(testInfo: TestInfo, name: string, target: Locator): Promise<void> {
  87  |   const evidence = await target.evaluate(element => {
  88  |     const rect = element.getBoundingClientRect()
  89  |     const style = getComputedStyle(element)
  90  |     return {
  91  |       activeTag: document.activeElement?.tagName ?? null,
  92  |       boxShadow: style.boxShadow,
  93  |       documentClientWidth: document.documentElement.clientWidth,
  94  |       documentScrollWidth: document.documentElement.scrollWidth,
  95  |       outlineStyle: style.outlineStyle,
  96  |       outlineWidth: style.outlineWidth,
  97  |       rect: { bottom: rect.bottom, height: rect.height, left: rect.left, right: rect.right, top: rect.top, width: rect.width },
  98  |       url: `${location.pathname}${location.search}${location.hash}`,
  99  |       viewport: { height: innerHeight, width: innerWidth },
  100 |     }
  101 |   })
  102 |   expect(evidence.rect.left).toBeGreaterThanOrEqual(0)
  103 |   expect(evidence.rect.top).toBeGreaterThanOrEqual(0)
  104 |   expect(evidence.rect.right).toBeLessThanOrEqual(evidence.viewport.width)
  105 |   expect(evidence.rect.bottom).toBeLessThanOrEqual(evidence.viewport.height)
  106 |   expect(evidence.documentScrollWidth).toBe(evidence.documentClientWidth)
  107 |   expect(evidence.outlineStyle !== 'none' || evidence.boxShadow !== 'none').toBe(true)
  108 |   console.info('TASK_6_1_MOCKED_GEOMETRY', JSON.stringify({ name, evidence }))
  109 |   const jsonPath = testInfo.outputPath(`${name}.json`)
  110 |   const screenshotPath = testInfo.outputPath(`${name}.png`)
  111 |   await writeFile(jsonPath, JSON.stringify(evidence, null, 2), 'utf8')
  112 |   await target.page().screenshot({ path: screenshotPath })
  113 |   await testInfo.attach(name, { path: jsonPath, contentType: 'application/json' })
  114 |   await testInfo.attach(`${name}-screenshot`, { path: screenshotPath, contentType: 'image/png' })
  115 | }
  116 | 
  117 | const hotkeyViewports = [{ width: 390, height: 844 }, { width: 1920, height: 1080 }] as const
  118 | 
  119 | for (const viewport of hotkeyViewports) {
  120 |   test.describe(`public and unknown route shortcut boundary at ${viewport.width}px`, () => {
  121 |     test.use({ viewport })
  122 | 
  123 |     test('makes zero authenticated requests and mounts no command center or page chord', async ({ page }, testInfo) => {
  124 |       const authenticatedRequests: string[] = []
  125 |       const publicPaths = new Set([
  126 |         '/.well-known/workmesh-agent',
  127 |         '/api/v1/auth/install',
  128 |         '/api/v1/auth/login',
  129 |         '/api/v1/info',
  130 |         '/api/v1/install-status',
  131 |       ])
  132 |       page.on('request', request => {
  133 |         const url = new URL(request.url())
  134 |         if (url.origin === apiUrl && !publicPaths.has(url.pathname))
  135 |           authenticatedRequests.push(`${request.method()} ${url.pathname}`)
  136 |       })
  137 | 
  138 |       const evidence: Array<{ requested: string; settled: string; authenticatedRequests: readonly string[] }> = []
  139 |       for (const path of ['/login', '/install', '/connect', '/future-unknown-route']) {
  140 |         authenticatedRequests.length = 0
  141 |         await page.goto(path)
  142 |         await page.waitForLoadState('domcontentloaded')
  143 |         await page.waitForTimeout(300)
  144 |         const settled = new URL(page.url()).pathname
  145 |         const before = page.url()
  146 |         await page.keyboard.press('/')
  147 |         await page.keyboard.press('Control+K')
  148 |         await pressChord(page, 'a')
  149 |         await page.waitForTimeout(100)
  150 |         expect(page.url()).toBe(before)
  151 |         await expect(page.getByTestId('command-center-trigger')).toHaveCount(0)
  152 |         expect(authenticatedRequests).toEqual([])
  153 |         evidence.push({ requested: path, settled, authenticatedRequests: [...authenticatedRequests] })
  154 |       }
  155 |       const evidencePath = testInfo.outputPath(`public-zero-auth-requests-${viewport.width}.json`)
  156 |       await writeFile(evidencePath, JSON.stringify(evidence, null, 2), 'utf8')
  157 |       await testInfo.attach(`public-zero-auth-requests-${viewport.width}`, { path: evidencePath, contentType: 'application/json' })
  158 |     })
  159 |   })
  160 | }
  161 | 
  162 | for (const viewport of hotkeyViewports) {
  163 |   test.describe(`page hotkeys at ${viewport.width}px`, () => {
  164 |     test.use({ viewport })
  165 | 
  166 |     test('keeps global navigation, one visible filter, no-filter surfaces and command-center ownership deterministic', async ({ page }, testInfo) => {
  167 |       await installHotkeyFixtures(page)
  168 |       await page.goto('/?view=my-work')
  169 |       const issueSearch = page.locator('[data-hotkey-filter="true"]')
  170 |       await expect(issueSearch).toHaveCount(1)
  171 |       await page.keyboard.press('f')
  172 |       await expect(issueSearch).toBeFocused()
  173 |       await attachGeometry(testInfo, `home-filter-${viewport.width}`, issueSearch)
  174 |       await page.evaluate(() => (document.activeElement as HTMLElement | null)?.blur())
  175 | 
  176 |       const historyLength = await page.evaluate(() => history.length)
  177 |       await pressChord(page, 'i')
  178 |       await expect(page).toHaveURL(`${webUrl}/?view=my-work`)
  179 |       expect(await page.evaluate(() => history.length)).toBe(historyLength)
  180 | 
  181 |       await issueSearch.focus()
  182 |       await pressChord(page, 'a')
  183 |       await expect(issueSearch).toBeFocused()
  184 |       expect(new URL(page.url()).pathname).toBe('/')
  185 |       expect(new URL(page.url()).searchParams.get('view')).toBe('my-work')
> 186 |       expect(new URL(page.url()).searchParams.get('search')).toBe('ga')
      |                                                              ^ Error: expect(received).toBe(expected) // Object.is equality
  187 |       await issueSearch.fill('')
  188 |       await expect.poll(() => new URL(page.url()).searchParams.get('search')).toBeNull()
  189 |       await page.evaluate(() => (document.activeElement as HTMLElement | null)?.blur())
  190 | 
  191 |       const contextUrl = page.url()
  192 |       const select = page.locator('select:visible').first()
  193 |       await select.focus()
  194 |       await pressChord(page, 'a')
  195 |       await expect(select).toBeFocused()
  196 |       expect(page.url()).toBe(contextUrl)
  197 | 
  198 |       const button = page.getByTestId('command-center-trigger')
  199 |       await button.focus()
  200 |       await pressChord(page, 's')
  201 |       await expect(button).toBeFocused()
  202 |       expect(page.url()).toBe(contextUrl)
  203 | 
  204 |       const link = page.locator('a:visible').first()
  205 |       await link.focus()
  206 |       await pressChord(page, 'a')
  207 |       await expect(link).toBeFocused()
  208 |       expect(page.url()).toBe(contextUrl)
  209 | 
  210 |       await page.evaluate(() => {
  211 |         const editable = document.createElement('div')
  212 |         editable.contentEditable = 'plaintext-only'
  213 |         editable.dataset.hotkeyContext = 'contenteditable'
  214 |         editable.tabIndex = 0
  215 |         editable.textContent = 'Editable shortcut guard'
  216 |         document.body.append(editable)
  217 |       })
  218 |       const editable = page.locator('[data-hotkey-context="contenteditable"]')
  219 |       await editable.focus()
  220 |       await pressChord(page, 's')
  221 |       await expect(editable).toBeFocused()
  222 |       expect(page.url()).toBe(contextUrl)
  223 |       await editable.evaluate(element => element.remove())
  224 |       await page.evaluate(() => (document.activeElement as HTMLElement | null)?.blur())
  225 | 
  226 |       const stableHomeUrl = page.url()
  227 |       await page.keyboard.press('g')
  228 |       await page.keyboard.press('z')
  229 |       expect(page.url()).toBe(stableHomeUrl)
  230 |       await page.keyboard.press('g')
  231 |       await page.waitForTimeout(1_050)
  232 |       await page.keyboard.press('a')
  233 |       expect(page.url()).toBe(stableHomeUrl)
  234 | 
  235 |       await pressChord(page, 'a')
  236 |       await expect(page).toHaveURL(`${webUrl}/agents`)
  237 | 
  238 |       await page.goto('/?view=my-work')
  239 |       await page.keyboard.press('/')
  240 |       await expect(page.getByTestId('command-center')).toHaveCount(1)
  241 |       await page.evaluate(() => (document.activeElement as HTMLElement | null)?.blur())
  242 |       const modalUrl = page.url()
  243 |       await pressChord(page, 'a')
  244 |       expect(page.url()).toBe(modalUrl)
  245 |       await page.keyboard.press('f')
  246 |       expect(page.url()).toBe(modalUrl)
  247 |       await page.keyboard.press('/')
  248 |       await expect(page.getByTestId('command-center')).toHaveCount(1)
  249 |       await page.getByRole('button', { name: /关闭|Close/ }).click()
  250 |       await page.keyboard.press('Control+K')
  251 |       await expect(page.getByTestId('command-center')).toHaveCount(1)
  252 |       await page.getByRole('button', { name: /关闭|Close/ }).click()
  253 | 
  254 |       for (const path of ['/?view=inbox', '/?view=guidance', '/settings']) {
  255 |         await page.goto(path)
  256 |         await expect(page.locator('[data-hotkey-filter="true"]')).toHaveCount(0)
  257 |         const anchor = page.locator('a:visible').first()
  258 |         await anchor.focus()
  259 |         await page.keyboard.press('f')
  260 |         await expect(anchor).toBeFocused()
  261 |       }
  262 | 
  263 |       await page.goto('/operations')
  264 |       const operationsSearch = page.locator('[data-hotkey-filter="true"]')
  265 |       await expect(operationsSearch).toHaveCount(1)
  266 |       await page.keyboard.press('f')
  267 |       await expect(operationsSearch).toBeFocused()
  268 |       await attachGeometry(testInfo, `operations-filter-${viewport.width}`, operationsSearch)
  269 | 
  270 |       await page.evaluate(() => (document.activeElement as HTMLElement | null)?.blur())
  271 |       await pressChord(page, 's')
  272 |       await expect(page).toHaveURL(`${webUrl}/settings`)
  273 |       await page.waitForTimeout(300)
  274 |       await page.evaluate(() => (document.activeElement as HTMLElement | null)?.blur())
  275 |       await pressChord(page, 'i')
  276 |       await expect(page).toHaveURL(`${webUrl}/?view=my-work`)
  277 |     })
  278 | 
  279 |     test('wraps Agent links, preserves native controls and keeps focus, Peek and approval state independent', async ({ page }, testInfo) => {
  280 |       await installHotkeyFixtures(page)
  281 |       await page.goto('/agents')
  282 |       const links = page.locator('[data-agent-roving-link="true"]')
  283 |       const agentSearch = page.locator('[data-hotkey-filter="true"]')
  284 |       await expect(agentSearch).toHaveCount(1)
  285 |       await page.evaluate(() => (document.activeElement as HTMLElement | null)?.blur())
  286 |       await page.keyboard.press('f')
```