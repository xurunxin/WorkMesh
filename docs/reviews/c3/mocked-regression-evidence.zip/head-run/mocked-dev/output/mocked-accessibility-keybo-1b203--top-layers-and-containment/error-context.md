# Instructions

- Following Playwright test failed.
- Explain why, be concise, respect Playwright best practices.
- Provide a snippet of code with the fix, if possible.

# Test info

- Name: mocked\accessibility-keyboard.mocked.spec.ts >> Task 6.6 phone Chinese keyboard and semantic journey >> covers compact selectors, mobile navigation, local table scrolling, top layers, and containment
- Location: e2e\mocked\accessibility-keyboard.mocked.spec.ts:511:3

# Error details

```
Error: expect(locator).toHaveCount(expected) failed

Locator:  locator('.agent-registry-card')
Expected: 2
Received: 0
Timeout:  10000ms

Call log:
  - Expect "toHaveCount" with timeout 10000ms
  - waiting for locator('.agent-registry-card')
    23 × locator resolved to 0 elements
       - unexpected value "0"

```

# Page snapshot

```yaml
- generic [active] [ref=e1]:
  - generic [ref=e2]:
    - link "跳到主要内容" [ref=e3] [cursor=pointer]:
      - /url: "#workmesh-main"
    - generic [ref=e4]:
      - banner [ref=e5]:
        - group [ref=e6]:
          - generic "菜单" [ref=e7] [cursor=pointer]
        - button "搜索" [ref=e9] [cursor=pointer]:
          - img [ref=e11]
          - generic [ref=e14]: 搜索
      - main [ref=e15]:
        - generic [ref=e16]:
          - generic [ref=e17]:
            - generic [ref=e18]:
              - paragraph [ref=e19]: 人类控制面
              - heading "智能体" [level=1] [ref=e20]
              - paragraph [ref=e21]: 监控委派工作、处理审批，并在不接触凭据的情况下诊断连接。
            - button "刷新" [ref=e22] [cursor=pointer]:
              - generic [ref=e23]: 刷新
          - alert [ref=e24]:
            - generic [ref=e26]:
              - heading "智能体工作区需要关注" [level=2] [ref=e27]
              - paragraph [ref=e28]: "[ { \"code\": \"invalid_type\", \"expected\": \"string\", \"received\": \"undefined\", \"path\": [ \"icon\" ], \"message\": \"Required\" }, { \"code\": \"invalid_type\", \"expected\": \"string\", \"received\": \"undefined\", \"path\": [ \"endpoint_url\" ], \"message\": \"Required\" }, { \"code\": \"invalid_type\", \"expected\": \"array\", \"received\": \"undefined\", \"path\": [ \"output_artifact_types\" ], \"message\": \"Required\" }, { \"code\": \"invalid_type\", \"expected\": \"object\", \"received\": \"undefined\", \"path\": [ \"metadata\" ], \"message\": \"Required\" }, { \"expected\": \"'active' | 'archived'\", \"received\": \"undefined\", \"code\": \"invalid_type\", \"path\": [ \"lifecycle_status\" ], \"message\": \"Required\" }, { \"code\": \"invalid_type\", \"expected\": \"string\", \"received\": \"undefined\", \"path\": [ \"archived_at\" ], \"message\": \"Required\" }, { \"code\": \"invalid_type\", \"expected\": \"string\", \"received\": \"undefined\", \"path\": [ \"archived_by_actor_id\" ], \"message\": \"Required\" }, { \"code\": \"invalid_type\", \"expected\": \"string\", \"received\": \"undefined\", \"path\": [ \"archived_reason\" ], \"message\": \"Required\" }, { \"code\": \"invalid_type\", \"expected\": \"string\", \"received\": \"undefined\", \"path\": [ \"created_at\" ], \"message\": \"Required\" }, { \"code\": \"invalid_type\", \"expected\": \"string\", \"received\": \"undefined\", \"path\": [ \"updated_at\" ], \"message\": \"Required\" } ]"
            - button "重试" [ref=e29] [cursor=pointer]:
              - generic [ref=e30]: 重试
          - generic [ref=e31]:
            - generic [ref=e32]:
              - generic [ref=e33]: 智能体
              - combobox "智能体工作区分区" [ref=e34]:
                - option "智能体" [selected]
                - option "连接"
                - option "自动接入策略"
                - option "已归档"
            - tabpanel "智能体" [ref=e35]:
              - region "注册表" [ref=e36]:
                - generic [ref=e37]:
                  - generic [ref=e38]:
                    - paragraph [ref=e39]: 注册表
                    - heading "智能体" [level=2] [ref=e40]
                    - paragraph [ref=e41]: 先检查定义；仅在需要审阅时展开团队权限。
                  - generic [ref=e42]:
                    - button "全部" [ref=e43]
                    - button "活跃" [ref=e44]
                    - button "停用" [ref=e45]
                - group "智能体筛选" [ref=e46]:
                  - generic [ref=e47]:
                    - generic [ref=e48]: 名称
                    - searchbox "名称" [ref=e49]
                  - generic [ref=e50]:
                    - generic [ref=e51]: 团队
                    - combobox "团队" [ref=e52]:
                      - option "全部团队" [selected]
                      - option "General"
                      - option "Operations"
                  - generic [ref=e53]:
                    - generic [ref=e54]: 能力
                    - combobox "能力" [ref=e55]:
                      - option "全部能力" [selected]
                  - generic [ref=e56]:
                    - generic [ref=e57]: 状态
                    - combobox "状态" [ref=e58]:
                      - option "全部" [selected]
                      - option "活跃"
                      - option "停用"
  - button "Open Next.js Dev Tools" [ref=e64] [cursor=pointer]:
    - img [ref=e65]
  - alert [ref=e68]
```

# Test source

```ts
  446 |     await expect(approvalTabs).toBeVisible()
  447 |     const pendingGrid = page.locator('.approval-grid')
  448 |     await expect(pendingGrid).toBeVisible()
  449 |     await expect(pendingGrid.getByRole('row')).toHaveCount(2)
  450 |     await expect(pendingGrid.getByTestId(`approval-row-${accessibilityIds.approvalPending}`).getByRole('button', { name: 'Approve' })).toBeVisible()
  451 |     await expect(pendingGrid.getByTestId(`approval-row-${accessibilityIds.approvalPending}`).getByRole('button', { name: 'Reject' })).toBeVisible()
  452 |     await expect(pendingGrid.getByTestId(`approval-row-${accessibilityIds.approvalPending}`).getByRole('button', { name: 'Other feedback' })).toBeVisible()
  453 |     await expectSemanticIntegrity(page, 'Pending approvals panel')
  454 |     await exerciseTablist(approvalTabs, 'Approval Pending and History tabs')
  455 |     const historyWrap = page.locator('.approval-history-table-wrap')
  456 |     const historyTab = approvalTabs.getByRole('tab').last()
  457 |     await page.keyboard.press('End')
  458 |     await expect.soft(historyTab, 'Approval History is selected with End').toHaveAttribute('aria-selected', 'true')
  459 |     await expect(historyWrap).toBeVisible()
  460 |     await expectNativeTable(historyWrap, 7, 'Approval history')
  461 |     await expectSemanticIntegrity(page, 'Approval History panel')
  462 | 
  463 |     await page.goto('/settings?tab=workspace')
  464 |     await expect(page.locator('.settings-page')).toBeVisible()
  465 |     evidence.settingsSkip = await expectSkipJourney(page, 'Settings', 'en')
  466 |     evidence.settings = await expectSemanticPage(page, 'Settings')
  467 |     const deleteTrigger = page.getByRole('button', { name: 'Delete Team' })
  468 |     expect.soft(await tabUntilFocused(page, deleteTrigger), 'Delete Team is keyboard reachable').toBe(true)
  469 |     if (await deleteTrigger.evaluate(element => element === document.activeElement)) await page.keyboard.press('Enter')
  470 |     const deleteDialog = page.getByRole('dialog')
  471 |     await expect(deleteDialog).toBeVisible()
  472 |     await expectSemanticIntegrity(page, 'Delete Team layer')
  473 |     await page.keyboard.press('/')
  474 |     await page.keyboard.press('Control+K')
  475 |     await expect.soft(page.getByTestId('command-center'), 'Delete dialog suppresses command-center shortcuts').toHaveCount(0)
  476 |     await page.keyboard.press('Escape')
  477 |     await expect(deleteDialog).toHaveCount(0)
  478 |     await expect.soft(deleteTrigger, 'Canceling delete restores the destructive trigger').toBeFocused()
  479 |     const settingsTabs = page.locator('.settings-page > .wm-tabs > .wm-tab-list')
  480 |     await exerciseTablist(settingsTabs, 'Settings tabs')
  481 |     await page.keyboard.press('End')
  482 |     await expect.soft(page.locator('.settings-page > header h1'), 'Embedded Operations retains Settings h1').toHaveCount(1)
  483 |     await expect.soft(page.locator('.settings-tab-heading > h2'), 'Embedded Operations owns h2').toHaveCount(1)
  484 |     await expectSemanticIntegrity(page, 'Embedded Operations panel')
  485 | 
  486 |     await page.goto('/operations#operations-runs')
  487 |     const runsWrap = page.getByTestId('operations-table-scroll')
  488 |     await expect(runsWrap).toBeVisible()
  489 |     evidence.operationsSkip = await expectSkipJourney(page, 'Standalone Operations', 'en')
  490 |     evidence.operations = await expectSemanticPage(page, 'Standalone Operations')
  491 |     evidence.operationsGeometry = await expectStandaloneOperationsGeometry(page, '1920 Standalone Operations', 24)
  492 |     await expectNativeTable(runsWrap, 6, 'Operations Runs')
  493 |     await expect.soft(runsWrap.locator('caption'), 'Runs has a native caption').toHaveCount(1)
  494 |     const runRow = page.getByTestId(`run-row-${accessibilityIds.run}`)
  495 |     await expect.soft(runRow, 'Runs fixture is non-empty').toBeVisible()
  496 |     const errorReference = await runRow.getAttribute('aria-describedby')
  497 |     expect.soft(errorReference, 'Failed Run describes its error row').toBeTruthy()
  498 |     if (errorReference) await expect.soft(page.locator(`#${errorReference}`), 'Run error description ID resolves').toContainText('deterministic provider')
  499 |     await expect.soft(runRow.getByRole('link'), 'Run Session uses a native link').toHaveAttribute('href', `/agent-sessions/${accessibilityIds.session}`)
  500 | 
  501 |     fixture.expectNoUnexpected()
  502 |     evidence.requests = fixture.requests
  503 |     await attachScreenshot(testInfo, page, 'accessibility-desktop-english')
  504 |     await attachJson(testInfo, 'accessibility-desktop-english', evidence)
  505 |   })
  506 | })
  507 | 
  508 | test.describe('Task 6.6 phone Chinese keyboard and semantic journey', () => {
  509 |   test.use({ viewport: { width: 390, height: 844 } })
  510 | 
  511 |   test('covers compact selectors, mobile navigation, local table scrolling, top layers, and containment', async ({ page }, testInfo) => {
  512 |     test.setTimeout(120_000)
  513 |     const fixture = new AccessibilityFixture()
  514 |     await fixture.install(page)
  515 |     await useLocale(page, 'zh-CN')
  516 |     const evidence: Record<string, unknown> = {}
  517 | 
  518 |     await page.goto('/?view=my-work&layout=list')
  519 |     await expect(page.locator(`[data-work-item-id="${accessibilityIds.workItem}"]`)).toBeVisible()
  520 |     const mobileMenu = page.locator('.mobile-navigation > summary')
  521 |     const menuReached = await tabUntilFocused(page, mobileMenu, 20)
  522 |     expect.soft(menuReached, '390: real Tab navigation reaches mobile navigation').toBe(true)
  523 |     if (menuReached) {
  524 |       evidence.mobileNavigationFocus = await expectVisibleFocus(mobileMenu, '390 mobile navigation')
  525 |       await page.keyboard.press('Enter')
  526 |       await expect.soft(page.locator('.mobile-navigation[open] nav'), '390: Enter opens labelled mobile navigation').toBeVisible()
  527 |       await page.keyboard.press('Enter')
  528 |       await expect.soft(page.locator('.mobile-navigation[open]'), '390: Enter closes mobile navigation').toHaveCount(0)
  529 |     }
  530 |     await page.reload()
  531 |     await expect(page.locator(`[data-work-item-id="${accessibilityIds.workItem}"]`)).toBeVisible()
  532 |     evidence.homeSkip = await expectSkipJourney(page, '390 Home', 'zh-CN')
  533 |     evidence.home = await expectSemanticPage(page, '390 Home')
  534 |     const workItemTrigger = page.locator(`[data-work-item-id="${accessibilityIds.workItem}"] .wm-work-item-title`)
  535 |     expect.soft(await tabUntilFocused(page, workItemTrigger), '390 Work Item is keyboard reachable').toBe(true)
  536 |     if (await workItemTrigger.evaluate(element => element === document.activeElement)) await page.keyboard.press('Enter')
  537 |     const detailDialog = page.getByRole('dialog')
  538 |     await expect(detailDialog).toBeVisible()
  539 |     await expectSemanticIntegrity(page, '390 Work Item detail layer')
  540 |     await expectCompactTabs(detailDialog.locator('.work-item-detail-layout > .wm-tabs'), '390 Work Item detail')
  541 |     await page.keyboard.press('Escape')
  542 |     await expect(detailDialog).toHaveCount(0)
  543 |     await expect.soft(workItemTrigger, '390 closing Work Item detail restores focus').toBeFocused()
  544 | 
  545 |     await page.goto('/agents?tab=agents')
> 546 |     await expect(page.locator('.agent-registry-card')).toHaveCount(2)
      |                                                        ^ Error: expect(locator).toHaveCount(expected) failed
  547 |     evidence.agents = await expectSemanticPage(page, '390 Agents')
  548 |     const agentTabs = page.locator('.agent-center > .wm-tabs')
  549 |     await expectCompactTabs(agentTabs, '390 Agents primary tabs')
  550 |     const agentSelector = agentTabs.locator(':scope > .wm-tab-list-compact select.wm-tab-select')
  551 |     expect.soft(await tabUntilFocused(page, agentSelector), '390 Agents selector is keyboard reachable').toBe(true)
  552 |     await agentSelector.selectOption('approvals')
  553 |     const approvalTabs = page.locator('.approval-inbox > .wm-tabs')
  554 |     await expectCompactTabs(approvalTabs, '390 Approval views')
  555 |     const pendingGrid = page.locator('.approval-grid')
  556 |     await expect(pendingGrid).toBeVisible()
  557 |     await expect(pendingGrid.getByRole('row')).toHaveCount(2)
  558 |     const pendingRow = pendingGrid.getByTestId(`approval-row-${accessibilityIds.approvalPending}`)
  559 |     await expect(pendingRow.getByRole('button', { name: 'Approve' })).toBeVisible()
  560 |     await expect(pendingRow.getByRole('button', { name: 'Reject' })).toBeVisible()
  561 |     await expect(pendingRow.getByRole('button', { name: 'Other feedback' })).toBeVisible()
  562 |     await expectSemanticIntegrity(page, '390 Pending approvals panel')
  563 |     evidence.pendingApprovalCard = await pendingRow.evaluate(element => {
  564 |       const actions = element.querySelector<HTMLElement>('.approval-row-actions')
  565 |       const bounds = actions?.getBoundingClientRect()
  566 |       return {
  567 |         actionBottom: bounds?.bottom ?? null,
  568 |         actionLeft: bounds?.left ?? null,
  569 |         actionRight: bounds?.right ?? null,
  570 |         documentClientWidth: document.documentElement.clientWidth,
  571 |         documentScrollWidth: document.documentElement.scrollWidth,
  572 |         gridClientWidth: element.parentElement?.clientWidth ?? null,
  573 |         gridScrollWidth: element.parentElement?.scrollWidth ?? null,
  574 |       }
  575 |     })
  576 |     expect(evidence.pendingApprovalCard).toMatchObject({ documentScrollWidth: 390, documentClientWidth: 390, gridScrollWidth: 390, gridClientWidth: 390 })
  577 |     const approvalSelector = approvalTabs.locator(':scope > .wm-tab-list-compact select.wm-tab-select')
  578 |     expect.soft(await tabUntilFocused(page, approvalSelector), '390 Approval selector is keyboard reachable').toBe(true)
  579 |     await approvalSelector.selectOption('history')
  580 |     const historyWrap = page.locator('.approval-history-table-wrap')
  581 |     await expect(historyWrap).toBeVisible()
  582 |     await expectNativeTable(historyWrap, 7, '390 Approval history')
  583 |     await expectSemanticIntegrity(page, '390 Approval History panel')
  584 |     evidence.historyScroll = await expectKeyboardLocalScroll(historyWrap, '390 Approval history')
  585 |     expect.soft(await tabUntilFocused(page, agentSelector), '390 Agents selector can return to Registry').toBe(true)
  586 |     if (await agentSelector.evaluate(element => element === document.activeElement)) await page.keyboard.press('Home')
  587 |     await expect(page.locator('.agent-registry-card')).toHaveCount(2)
  588 |     await openTeamAccess(page, true)
  589 | 
  590 |     await page.goto('/settings?tab=workspace')
  591 |     await expect(page.locator('.settings-page')).toBeVisible()
  592 |     evidence.settings = await expectSemanticPage(page, '390 Settings')
  593 |     const settingsTabs = page.locator('.settings-page > .wm-tabs')
  594 |     await expectCompactTabs(settingsTabs, '390 Settings tabs')
  595 |     const settingsSelector = settingsTabs.locator(':scope > .wm-tab-list-compact select.wm-tab-select')
  596 |     expect.soft(await tabUntilFocused(page, settingsSelector), '390 Settings selector is keyboard reachable').toBe(true)
  597 |     if (await settingsSelector.evaluate(element => element === document.activeElement)) await page.keyboard.press('End')
  598 |     await expect.soft(page.locator('.settings-tab-heading > h2'), '390 embedded Operations remains h2').toHaveCount(1)
  599 |     await expectSemanticIntegrity(page, '390 Embedded Operations panel')
  600 | 
  601 |     await page.goto('/operations#operations-runs')
  602 |     const runsWrap = page.getByTestId('operations-table-scroll')
  603 |     await expect(runsWrap).toBeVisible()
  604 |     evidence.operationsSkip = await expectSkipJourney(page, '390 Standalone Operations', 'zh-CN')
  605 |     evidence.operations = await expectSemanticPage(page, '390 Standalone Operations')
  606 |     evidence.operationsGeometry = await expectStandaloneOperationsGeometry(page, '390 Standalone Operations', 14)
  607 |     await expectNativeTable(runsWrap, 6, '390 Operations Runs')
  608 |     evidence.runsScroll = await expectKeyboardLocalScroll(runsWrap, '390 Operations Runs')
  609 | 
  610 |     fixture.expectNoUnexpected()
  611 |     evidence.requests = fixture.requests
  612 |     await attachScreenshot(testInfo, page, 'accessibility-phone-chinese')
  613 |     await attachJson(testInfo, 'accessibility-phone-chinese', evidence)
  614 |   })
  615 | })
  616 | 
  617 | const deepLinkCases = [
  618 |   { locale: 'en' as const, viewport: { width: 1920, height: 1080 } },
  619 |   { locale: 'zh-CN' as const, viewport: { width: 390, height: 844 } },
  620 | ]
  621 | 
  622 | for (const entry of deepLinkCases) {
  623 |   test(`Agent and Session deep-link semantic smoke at ${entry.viewport.width}px ${entry.locale}`, async ({ page }, testInfo) => {
  624 |     test.setTimeout(60_000)
  625 |     await page.setViewportSize(entry.viewport)
  626 |     const fixture = new AccessibilityFixture()
  627 |     await fixture.install(page)
  628 |     await useLocale(page, entry.locale)
  629 |     const evidence: Record<string, unknown> = {}
  630 | 
  631 |     await page.goto(`/agents/${accessibilityIds.agentOne}`)
  632 |     await expect(page.locator('.agent-detail-panel')).toBeVisible()
  633 |     evidence.agentSkip = await expectSkipJourney(page, `${entry.viewport.width} Agent detail`, entry.locale)
  634 |     evidence.agent = await expectSemanticPage(page, `${entry.viewport.width} Agent detail`)
  635 |     const teamAccessLink = page.locator(`a[href*="teamAccessAgent=${accessibilityIds.agentOne}"]`)
  636 |     await expect.soft(teamAccessLink, 'Agent detail exposes one Team Access deep link').toHaveCount(1)
  637 |     await expect.soft(teamAccessLink, 'Agent detail Team Access deep link has an accessible name').toHaveAccessibleName(/\S/)
  638 |     await expect.soft(teamAccessLink, 'Agent detail Team Access deep link preserves the exact agent identity').toHaveAttribute('href', new RegExp(`teamAccessAgent=${accessibilityIds.agentOne}`))
  639 | 
  640 |     await page.goto(`/agent-sessions/${accessibilityIds.session}`)
  641 |     await expect(page.getByTestId('agent-session-detail')).toBeVisible()
  642 |     evidence.sessionSkip = await expectSkipJourney(page, `${entry.viewport.width} Session detail`, entry.locale)
  643 |     evidence.session = await expectSemanticPage(page, `${entry.viewport.width} Session detail`)
  644 |     await expect.soft(page.locator('.session-facts dt'), 'Session detail exposes native fact terms').not.toHaveCount(0)
  645 | 
  646 |     fixture.expectNoUnexpected()
```