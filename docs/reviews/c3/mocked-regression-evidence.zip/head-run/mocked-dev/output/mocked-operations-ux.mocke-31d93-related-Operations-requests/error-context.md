# Instructions

- Following Playwright test failed.
- Explain why, be concise, respect Playwright best practices.
- Provide a snippet of code with the fix, if possible.

# Test info

- Name: mocked\operations-ux.mocked.spec.ts >> proves all eight feature sets on standalone and embedded surfaces without unrelated Operations requests
- Location: e2e\mocked\operations-ux.mocked.spec.ts:579:1

# Error details

```
Error: master-off / embedded

expect(locator).toBeVisible() failed

Locator: getByTestId('operations-disabled')
Expected: visible
Timeout: 10000ms
Error: element(s) not found

Call log:
  - master-off / embedded with timeout 10000ms
  - waiting for getByTestId('operations-disabled')

```

```yaml
- alert
- main:
  - heading "Page not found" [level=1]
  - paragraph: The page you are looking for does not exist or has been moved.
  - link "Back to home":
    - /url: /
```

# Test source

```ts
  552 |   await expect(page.getByTestId('operations-section-navigation')).toHaveCount(0)
  553 | 
  554 |   enabled = [operations]
  555 |   await page.reload()
  556 |   await expect(page.getByTestId('operations-sections-empty')).toContainText('No Operations modules are available')
  557 |   await expect(page.getByTestId('operations-section-navigation')).toHaveCount(0)
  558 |   await expect(page.locator('.operations-grid')).toHaveCount(0)
  559 | })
  560 | 
  561 | test('matches each child feature to only its owned anchors', async ({ page }) => {
  562 |   let enabled: readonly FeatureKey[] = [operations, 'WORKMESH_BETA_COSTS']
  563 |   await installOperationsRoutes(page, () => enabled)
  564 |   const matrix: Array<readonly [FeatureKey, readonly string[]]> = [
  565 |     ['WORKMESH_BETA_COSTS', ['#operations-metrics']],
  566 |     ['WORKMESH_BETA_PLANNING', ['#operations-cycles', '#operations-initiatives']],
  567 |     ['WORKMESH_EXPERIMENTAL_AUTOMATION', ['#operations-automation', '#operations-runs']],
  568 |     ['WORKMESH_EXPERIMENTAL_AGENT_LOOPS', ['#operations-loops']],
  569 |     ['WORKMESH_BETA_TEMPLATES', ['#operations-templates']],
  570 |   ]
  571 | 
  572 |   for (const [feature, expected] of matrix) {
  573 |     enabled = [operations, feature]
  574 |     await page.goto(`/operations?feature=${encodeURIComponent(feature)}`)
  575 |     await expect.poll(() => navigationHrefs(page)).toEqual(expected)
  576 |   }
  577 | })
  578 | 
  579 | test('proves all eight feature sets on standalone and embedded surfaces without unrelated Operations requests', async ({ context }) => {
  580 |   test.slow()
  581 |   expect(canonicalFeatures).toHaveLength(12)
  582 | 
  583 |   const relevantDataPaths = ['/api/v1/usage-summary', ...collectionPaths] as const
  584 |   const relevantDataPathSet = new Set<string>(relevantDataPaths)
  585 |   const scenarios: Array<Readonly<{
  586 |     name: string
  587 |     enabled: readonly FeatureKey[]
  588 |     hrefs: readonly string[]
  589 |     apiPaths: readonly string[]
  590 |     hasSearch: boolean
  591 |   }>> = [
  592 |     { name: 'master-off', enabled: [], hrefs: [], apiPaths: [], hasSearch: false },
  593 |     { name: 'Operations-only', enabled: [operations], hrefs: [], apiPaths: [], hasSearch: false },
  594 |     {
  595 |       name: 'Planning-only',
  596 |       enabled: [operations, 'WORKMESH_BETA_PLANNING'],
  597 |       hrefs: ['#operations-cycles', '#operations-initiatives'],
  598 |       apiPaths: ['/api/v1/cycles', '/api/v1/initiatives'],
  599 |       hasSearch: true,
  600 |     },
  601 |     {
  602 |       name: 'Costs-only',
  603 |       enabled: [operations, 'WORKMESH_BETA_COSTS'],
  604 |       hrefs: ['#operations-metrics'],
  605 |       apiPaths: ['/api/v1/usage-summary'],
  606 |       hasSearch: false,
  607 |     },
  608 |     {
  609 |       name: 'Automation-only',
  610 |       enabled: [operations, 'WORKMESH_EXPERIMENTAL_AUTOMATION'],
  611 |       hrefs: ['#operations-automation', '#operations-runs'],
  612 |       apiPaths: ['/api/v1/automation-rules', '/api/v1/automation-runs'],
  613 |       hasSearch: true,
  614 |     },
  615 |     {
  616 |       name: 'Loops-only',
  617 |       enabled: [operations, 'WORKMESH_EXPERIMENTAL_AGENT_LOOPS'],
  618 |       hrefs: ['#operations-loops'],
  619 |       apiPaths: ['/api/v1/loops'],
  620 |       hasSearch: true,
  621 |     },
  622 |     {
  623 |       name: 'Templates-only',
  624 |       enabled: [operations, 'WORKMESH_BETA_TEMPLATES'],
  625 |       hrefs: ['#operations-templates'],
  626 |       apiPaths: ['/api/v1/templates'],
  627 |       hasSearch: true,
  628 |     },
  629 |     {
  630 |       name: 'all-enabled',
  631 |       enabled: allOperationsFeatures,
  632 |       hrefs: sectionHrefs,
  633 |       apiPaths: relevantDataPaths,
  634 |       hasSearch: true,
  635 |     },
  636 |   ]
  637 |   const surfaces = [
  638 |     { name: 'standalone', url: '/operations' },
  639 |     { name: 'embedded', url: '/settings?tab=operations' },
  640 |   ] as const
  641 | 
  642 |   for (const scenario of scenarios) {
  643 |     for (const surface of surfaces) {
  644 |       const scenarioPage = await context.newPage()
  645 |       const requestLog: string[] = []
  646 |       const label = `${scenario.name} / ${surface.name}`
  647 |       try {
  648 |         await installOperationsRoutes(scenarioPage, () => scenario.enabled, { requestLog })
  649 |         await scenarioPage.goto(surface.url)
  650 | 
  651 |         if (scenario.name === 'master-off') {
> 652 |           await expect(scenarioPage.getByTestId('operations-disabled'), label).toBeVisible()
      |                                                                                ^ Error: master-off / embedded
  653 |         } else if (scenario.name === 'Operations-only') {
  654 |           await expect(scenarioPage.getByTestId('operations-sections-empty'), label).toBeVisible()
  655 |         }
  656 | 
  657 |         const navigation = scenarioPage.getByTestId('operations-section-navigation')
  658 |         if (scenario.hrefs.length === 0) {
  659 |           await expect(navigation, `${label}: navigation`).toHaveCount(0)
  660 |         } else {
  661 |           await expect(navigation, `${label}: navigation`).toBeVisible()
  662 |           await expect.poll(
  663 |             () => navigationHrefs(scenarioPage),
  664 |             { message: `${label}: ordered anchors` },
  665 |           ).toEqual(scenario.hrefs)
  666 |         }
  667 | 
  668 |         const targets = scenarioPage.locator('.operations-section-target')
  669 |         await expect(targets, `${label}: target count`).toHaveCount(scenario.hrefs.length)
  670 |         expect(
  671 |           await targets.evaluateAll(elements => elements.map(element => `#${element.id}`)),
  672 |           `${label}: ordered targets`,
  673 |         ).toEqual(scenario.hrefs)
  674 |         for (const href of sectionHrefs) {
  675 |           await expect(
  676 |             scenarioPage.locator(href),
  677 |             `${label}: ${scenario.hrefs.includes(href) ? 'owned' : 'hidden'} target ${href}`,
  678 |           ).toHaveCount(scenario.hrefs.includes(href) ? 1 : 0)
  679 |         }
  680 | 
  681 |         await expect(
  682 |           scenarioPage.getByTestId('operations-search'),
  683 |           `${label}: search ${scenario.hasSearch ? 'present' : 'absent'}`,
  684 |         ).toHaveCount(scenario.hasSearch ? 1 : 0)
  685 | 
  686 |         await expect.poll(
  687 |           () => requestLog.some(value => new URL(value).pathname === '/api/v1/features'),
  688 |           { message: `${label}: feature registry request completed` },
  689 |         ).toBe(true)
  690 |         const expectedApiPaths = [...scenario.apiPaths].sort()
  691 |         const observedApiPaths = () => [...new Set(
  692 |           requestLog
  693 |             .map(value => new URL(value).pathname)
  694 |             .filter(path => relevantDataPathSet.has(path)),
  695 |         )].sort()
  696 |         if (expectedApiPaths.length > 0) {
  697 |           await expect.poll(
  698 |             observedApiPaths,
  699 |             { message: `${label}: relevant API presence and absence` },
  700 |           ).toEqual(expectedApiPaths)
  701 |         }
  702 |         await scenarioPage.evaluate(() => new Promise<void>(resolve => {
  703 |           requestAnimationFrame(() => requestAnimationFrame(() => resolve()))
  704 |         }))
  705 |         expect(observedApiPaths(), `${label}: zero unrelated Operations endpoints`).toEqual(expectedApiPaths)
  706 |       } finally {
  707 |         await scenarioPage.close()
  708 |       }
  709 |     }
  710 |   }
  711 | })
  712 | 
  713 | test('keeps real Operations controls in the initial viewport at supported widths', async ({ page }) => {
  714 |   await installOperationsRoutes(page, () => allOperationsFeatures)
  715 |   for (const viewport of [
  716 |     { width: 390, height: 844 },
  717 |     { width: 1440, height: 900 },
  718 |     { width: 1920, height: 1080 },
  719 |   ]) {
  720 |     await page.setViewportSize(viewport)
  721 |     await page.goto(`/operations?viewport=${viewport.width}`)
  722 |     const box = await page.getByTestId('operations-section-navigation').boundingBox()
  723 |     expect(box, `${viewport.width}x${viewport.height} navigation bounds`).not.toBeNull()
  724 |     expect(box?.y ?? viewport.height).toBeLessThan(viewport.height)
  725 |   }
  726 | })
  727 | 
  728 | test('scrolls an asynchronously mounted direct-hash target into view before focusing it', async ({ page }) => {
  729 |   await page.setViewportSize({ width: 1440, height: 900 })
  730 |   await installOperationsRoutes(page, () => allOperationsFeatures, { usageDelayMs: 250 })
  731 |   await page.goto('/operations#operations-runs')
  732 | 
  733 |   const navigation = page.getByTestId('operations-section-navigation')
  734 |   const runs = navigation.getByRole('link', { name: 'Recent runs' })
  735 |   const target = page.locator('#operations-runs')
  736 |   await expect(runs).toHaveAttribute('aria-current', 'location')
  737 |   await expect(target).toBeFocused()
  738 |   await expect.poll(async () => (await target.boundingBox())?.y ?? 900).toBeLessThan(900)
  739 | })
  740 | 
  741 | test('restores embedded current state without taking focus when the real Settings tab becomes visible', async ({ page }, testInfo) => {
  742 |   await installOperationsRoutes(page, () => allOperationsFeatures, settingsRouteFixtures)
  743 |   await page.goto('/settings?tab=workspace&team=team-1&opsQuery=Archived&x=keep#operations-runs')
  744 |   const workspaceTab = page.getByRole('tab', { name: 'Workspace' })
  745 |   await expect(workspaceTab).toHaveAttribute('aria-selected', 'true')
  746 | 
  747 |   const beforeMount = await page.evaluate(async () => {
  748 |     window.scrollTo(0, Math.min(120, document.documentElement.scrollHeight - window.innerHeight))
  749 |     await new Promise<void>(resolve => requestAnimationFrame(() => requestAnimationFrame(() => resolve())))
  750 |     return { scrollY: window.scrollY, viewportHeight: window.innerHeight }
  751 |   })
  752 |   expect(beforeMount.scrollY).toBeGreaterThan(0)
```