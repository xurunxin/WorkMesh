# Instructions

- Following Playwright test failed.
- Explain why, be concise, respect Playwright best practices.
- Provide a snippet of code with the fix, if possible.

# Test info

- Name: mocked\operations-ux.mocked.spec.ts >> keeps Settings route history, shared responsive semantics, and dense 390/1920 geometry
- Location: e2e\mocked\operations-ux.mocked.spec.ts:832:1

# Error details

```
Error: expect(locator).toHaveAttribute(expected) failed

Locator: getByRole('tab', { name: 'Planning & Operations' })
Expected: "true"
Timeout: 10000ms
Error: element(s) not found

Call log:
  - Expect "toHaveAttribute" with timeout 10000ms
  - waiting for getByRole('tab', { name: 'Planning & Operations' })

```

```yaml
- alert
- main:
  - heading "Page not found" [level=1]
  - paragraph: The page you are looking for does not exist or has been moved.
  - link "Back to home":
    - /url: /
```

# Test source

```ts
  741 | test('restores embedded current state without taking focus when the real Settings tab becomes visible', async ({ page }, testInfo) => {
  742 |   await installOperationsRoutes(page, () => allOperationsFeatures, settingsRouteFixtures)
  743 |   await page.goto('/settings?tab=workspace&team=team-1&opsQuery=Archived&x=keep#operations-runs')
  744 |   const workspaceTab = page.getByRole('tab', { name: 'Workspace' })
  745 |   await expect(workspaceTab).toHaveAttribute('aria-selected', 'true')
  746 | 
  747 |   const beforeMount = await page.evaluate(async () => {
  748 |     window.scrollTo(0, Math.min(120, document.documentElement.scrollHeight - window.innerHeight))
  749 |     await new Promise<void>(resolve => requestAnimationFrame(() => requestAnimationFrame(() => resolve())))
  750 |     return { scrollY: window.scrollY, viewportHeight: window.innerHeight }
  751 |   })
  752 |   expect(beforeMount.scrollY).toBeGreaterThan(0)
  753 |   const workspaceTabBox = await workspaceTab.boundingBox()
  754 |   expect(workspaceTabBox).not.toBeNull()
  755 |   expect(workspaceTabBox?.y ?? -1).toBeGreaterThanOrEqual(0)
  756 |   expect((workspaceTabBox?.y ?? beforeMount.viewportHeight) + (workspaceTabBox?.height ?? 0)).toBeLessThan(beforeMount.viewportHeight)
  757 | 
  758 |   const operationsTab = page.getByRole('tab', { name: 'Planning & Operations' })
  759 |   await operationsTab.click()
  760 |   const navigation = page.getByTestId('operations-section-navigation')
  761 |   await expect(navigation).toBeVisible()
  762 |   await expect(page).toHaveURL('/settings?tab=operations&team=team-1&opsQuery=Archived&x=keep#operations-runs')
  763 |   await expect(navigation.getByRole('link', { name: 'Recent runs' })).toHaveAttribute('aria-current', 'location')
  764 |   await expect(operationsTab).toBeFocused()
  765 |   const runsTarget = page.locator('#operations-runs')
  766 |   await expect(runsTarget).not.toBeFocused()
  767 |   const afterMount = await runsTarget.evaluate(element => ({
  768 |     scrollY: window.scrollY,
  769 |     targetTop: element.getBoundingClientRect().top,
  770 |     viewportHeight: window.innerHeight,
  771 |   }))
  772 |   expect(Math.abs(afterMount.scrollY - beforeMount.scrollY)).toBeLessThanOrEqual(1)
  773 |   expect(afterMount.targetTop).toBeGreaterThan(afterMount.viewportHeight)
  774 | 
  775 |   const localeControl = page.getByRole('button', { exact: true, name: 'EN' })
  776 |   await localeControl.focus()
  777 |   const templatesTarget = page.locator('#operations-templates')
  778 |   const beforeHash = await templatesTarget.evaluate(element => ({
  779 |     scrollY: window.scrollY,
  780 |     targetTop: element.getBoundingClientRect().top,
  781 |   }))
  782 |   await page.evaluate(() => {
  783 |     const url = new URL(window.location.href)
  784 |     url.hash = '#operations-templates'
  785 |     window.history.replaceState(window.history.state, '', url)
  786 |     window.dispatchEvent(new HashChangeEvent('hashchange'))
  787 |   })
  788 |   await expect(navigation.getByRole('link', { name: 'Templates' })).toHaveAttribute('aria-current', 'location')
  789 |   const afterHash = await templatesTarget.evaluate(element => ({
  790 |     scrollY: window.scrollY,
  791 |     targetTop: element.getBoundingClientRect().top,
  792 |   }))
  793 |   expect(Math.abs(afterHash.scrollY - beforeHash.scrollY)).toBeLessThanOrEqual(1)
  794 |   expect(Math.abs(afterHash.targetTop - beforeHash.targetTop)).toBeLessThanOrEqual(1)
  795 |   await expect(localeControl).toBeFocused()
  796 |   await expect(templatesTarget).not.toBeFocused()
  797 | 
  798 |   const beforePopstate = await runsTarget.evaluate(element => ({
  799 |     scrollY: window.scrollY,
  800 |     targetTop: element.getBoundingClientRect().top,
  801 |   }))
  802 |   await page.evaluate(() => {
  803 |     const url = new URL(window.location.href)
  804 |     url.hash = '#operations-runs'
  805 |     window.history.replaceState(window.history.state, '', url)
  806 |     window.dispatchEvent(new PopStateEvent('popstate', { state: window.history.state }))
  807 |   })
  808 |   await expect(navigation.getByRole('link', { name: 'Recent runs' })).toHaveAttribute('aria-current', 'location')
  809 |   const afterPopstate = await runsTarget.evaluate(element => ({
  810 |     scrollY: window.scrollY,
  811 |     targetTop: element.getBoundingClientRect().top,
  812 |   }))
  813 |   expect(Math.abs(afterPopstate.scrollY - beforePopstate.scrollY)).toBeLessThanOrEqual(1)
  814 |   expect(Math.abs(afterPopstate.targetTop - beforePopstate.targetTop)).toBeLessThanOrEqual(1)
  815 |   await expect(localeControl).toBeFocused()
  816 |   await expect(runsTarget).not.toBeFocused()
  817 | 
  818 |   const evidencePath = testInfo.outputPath('task-5.1-embedded-passive-scroll-pass.json')
  819 |   await writeFile(evidencePath, JSON.stringify({
  820 |     beforeMount,
  821 |     workspaceTabBox,
  822 |     afterMount,
  823 |     hashchange: { before: beforeHash, after: afterHash },
  824 |     popstate: { before: beforePopstate, after: afterPopstate },
  825 |   }, null, 2), 'utf8')
  826 |   await testInfo.attach('task-5.1-embedded-passive-scroll-pass', {
  827 |     contentType: 'application/json',
  828 |     path: evidencePath,
  829 |   })
  830 | })
  831 | 
  832 | test('keeps Settings route history, shared responsive semantics, and dense 390/1920 geometry', async ({ page }, testInfo) => {
  833 |   const directUrl = '/settings?tab=operations&team=team-1&opsQuery=Archived&x=keep#operations-templates'
  834 |   const routedOperationsUrl = '/settings?team=team-1&opsQuery=Archived&x=keep&tab=operations#operations-templates'
  835 |   await installOperationsRoutes(page, () => allOperationsFeatures, settingsRouteFixtures)
  836 | 
  837 |   await page.setViewportSize({ width: 1920, height: 1080 })
  838 |   await page.goto(directUrl)
  839 |   const operationsTab = page.getByRole('tab', { name: 'Planning & Operations' })
  840 |   const workspaceTab = page.getByRole('tab', { name: 'Workspace' })
> 841 |   await expect(operationsTab).toHaveAttribute('aria-selected', 'true')
      |                               ^ Error: expect(locator).toHaveAttribute(expected) failed
  842 |   await expect(page.getByRole('searchbox', { name: 'Search loaded Operations records' })).toHaveValue('Archived')
  843 |   await expect(page.getByRole('link', { name: 'Templates' })).toHaveAttribute('aria-current', 'location')
  844 |   await expect(page).toHaveURL(`${webUrl}${directUrl}`)
  845 | 
  846 |   await page.reload()
  847 |   await expect(page.getByRole('tab', { name: 'Planning & Operations' })).toHaveAttribute('aria-selected', 'true')
  848 |   await expect(page.getByRole('link', { name: 'Templates' })).toHaveAttribute('aria-current', 'location')
  849 |   await expect(page).toHaveURL(`${webUrl}${directUrl}`)
  850 |   await page.evaluate(() => window.history.replaceState({ ...window.history.state, task51: 'kept' }, '', window.location.href))
  851 | 
  852 |   const initialLength = await page.evaluate(() => window.history.length)
  853 |   await page.getByRole('tab', { name: 'Workspace' }).click()
  854 |   await expect(page).toHaveURL(`${webUrl}/settings?team=team-1&opsQuery=Archived&x=keep#operations-templates`)
  855 |   expect(await page.evaluate(() => window.history.length)).toBe(initialLength + 1)
  856 |   expect(await page.evaluate(() => window.history.state.task51)).toBe('kept')
  857 | 
  858 |   await page.getByRole('tab', { name: 'Workspace' }).click()
  859 |   expect(await page.evaluate(() => window.history.length)).toBe(initialLength + 1)
  860 | 
  861 |   await page.getByRole('tab', { name: 'Workspace' }).press('End')
  862 |   await expect(page.getByRole('tab', { name: 'Planning & Operations' })).toBeFocused()
  863 |   await expect(page).toHaveURL(`${webUrl}${routedOperationsUrl}`)
  864 |   expect(await page.evaluate(() => window.history.length)).toBe(initialLength + 2)
  865 | 
  866 |   await page.getByRole('tab', { name: 'Planning & Operations' }).press('End')
  867 |   expect(await page.evaluate(() => window.history.length)).toBe(initialLength + 2)
  868 |   await page.getByRole('tab', { name: 'Planning & Operations' }).press('Home')
  869 |   await expect(page.getByRole('tab', { name: 'Workspace' })).toBeFocused()
  870 |   expect(await page.evaluate(() => window.history.length)).toBe(initialLength + 3)
  871 |   await page.getByRole('tab', { name: 'Workspace' }).press('ArrowLeft')
  872 |   await expect(page.getByRole('tab', { name: 'Planning & Operations' })).toBeFocused()
  873 |   expect(await page.evaluate(() => window.history.length)).toBe(initialLength + 4)
  874 | 
  875 |   const localeControl = page.getByRole('button', { exact: true, name: 'EN' })
  876 |   await localeControl.focus()
  877 |   await page.goBack()
  878 |   await expect(page).toHaveURL(`${webUrl}/settings?team=team-1&opsQuery=Archived&x=keep#operations-templates`)
  879 |   await expect(page.getByRole('tab', { name: 'Workspace' })).toHaveAttribute('aria-selected', 'true')
  880 |   await expect(localeControl).toBeFocused()
  881 |   await page.goForward()
  882 |   await expect(page).toHaveURL(`${webUrl}${routedOperationsUrl}`)
  883 |   await expect(page.getByRole('tab', { name: 'Planning & Operations' })).toHaveAttribute('aria-selected', 'true')
  884 |   await expect(localeControl).toBeFocused()
  885 | 
  886 |   const geometry: Awaited<ReturnType<typeof measureSettingsGeometry>>[] = []
  887 |   const wide = await measureSettingsGeometry(page)
  888 |   geometry.push(wide)
  889 |   expect(wide.document.scrollWidth).toBe(wide.document.clientWidth)
  890 |   expect(wide.content.width / wide.main.width).toBeGreaterThanOrEqual(.85)
  891 |   expect(wide.content.width).toBeLessThanOrEqual(1480)
  892 |   expect(wide.panel.width / wide.contentInnerWidth).toBeGreaterThanOrEqual(.98)
  893 |   expect(wide.operationsRoot.width / wide.panel.width).toBeGreaterThanOrEqual(.98)
  894 |   const wideScreenshot = testInfo.outputPath('task-5.1-settings-wide-pass.png')
  895 |   await page.screenshot({ fullPage: true, path: wideScreenshot })
  896 |   await testInfo.attach('task-5.1-settings-wide-pass', { contentType: 'image/png', path: wideScreenshot })
  897 | 
  898 |   await page.setViewportSize({ width: 390, height: 844 })
  899 |   await page.goto(directUrl)
  900 |   const selector = page.getByRole('combobox', { name: 'Settings sections' })
  901 |   await expect(selector).toHaveValue('operations')
  902 |   await expect(page.getByRole('tablist')).toHaveCount(0)
  903 |   await expect(page.getByRole('tab')).toHaveCount(0)
  904 |   await expect(page.getByRole('tabpanel')).toHaveCount(1)
  905 |   await selector.focus()
  906 |   await selector.selectOption('workspace')
  907 |   await expect(selector).toBeFocused()
  908 |   await expect(page).toHaveURL(`${webUrl}/settings?team=team-1&opsQuery=Archived&x=keep#operations-templates`)
  909 |   expect(await page.evaluate(() => document.documentElement.scrollWidth)).toBe(390)
  910 | 
  911 |   await selector.selectOption('operations')
  912 |   await expect(selector).toBeFocused()
  913 |   const narrow = await measureSettingsGeometry(page)
  914 |   geometry.push(narrow)
  915 |   expect(narrow.document.scrollWidth).toBe(narrow.document.clientWidth)
  916 |   expect(narrow.content.width).toBeLessThanOrEqual(390)
  917 |   expect(narrow.panel.width / narrow.contentInnerWidth).toBeGreaterThanOrEqual(.98)
  918 |   const narrowScreenshot = testInfo.outputPath('task-5.1-settings-narrow-pass.png')
  919 |   await page.screenshot({ fullPage: true, path: narrowScreenshot })
  920 |   await testInfo.attach('task-5.1-settings-narrow-pass', { contentType: 'image/png', path: narrowScreenshot })
  921 | 
  922 |   const geometryPath = testInfo.outputPath('task-5.1-settings-geometry-pass.json')
  923 |   await writeFile(geometryPath, JSON.stringify(geometry, null, 2), 'utf8')
  924 |   await testInfo.attach('task-5.1-settings-geometry-pass', { contentType: 'application/json', path: geometryPath })
  925 | })
  926 | 
  927 | test('scopes Team resolution to Workspace with serial deep-link pagination and dense 390/1920 geometry', async ({ page }, testInfo) => {
  928 |   const requestLog: string[] = []
  929 |   const teamRequestSequence = () => requestLog
  930 |     .map(request => new URL(request))
  931 |     .filter(url => url.pathname === '/api/v1/teams' || /^\/api\/v1\/teams\/[^/]+\/states$/.test(url.pathname))
  932 |     .map(url => `${url.pathname}${url.search}`)
  933 |   const resolutionSequence = [
  934 |     '/api/v1/teams?limit=100',
  935 |     '/api/v1/teams?limit=100&cursor=teams-page-2',
  936 |     '/api/v1/teams/team-second-page/states?limit=100',
  937 |   ]
  938 |   await installOperationsRoutes(page, () => allOperationsFeatures, {
  939 |     requestLog,
  940 |     settingsTeamPages: {
  941 |       first: { items: [settingsTeamOne], nextCursor: 'teams-page-2' },
```