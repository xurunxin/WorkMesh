# Instructions

- Following Playwright test failed.
- Explain why, be concise, respect Playwright best practices.
- Provide a snippet of code with the fix, if possible.

# Test info

- Name: mocked\operations-ux.mocked.spec.ts >> scopes Team resolution to Workspace with serial deep-link pagination and dense 390/1920 geometry
- Location: e2e\mocked\operations-ux.mocked.spec.ts:927:1

# Error details

```
Test timeout of 30000ms exceeded.
```

```
Error: locator.click: Test timeout of 30000ms exceeded.
Call log:
  - waiting for getByRole('tab', { name: 'Planning & Operations' })

```

# Page snapshot

```yaml
- generic [active] [ref=e1]:
  - button "Open Next.js Dev Tools" [ref=e7] [cursor=pointer]:
    - img [ref=e8]
  - alert [ref=e11]
  - generic [ref=e12]:
    - link "Skip to content" [ref=e13] [cursor=pointer]:
      - /url: "#workmesh-main"
    - complementary "Main navigation" [ref=e14]:
      - generic [ref=e15]:
        - strong [ref=e17]: WorkMesh
        - generic [ref=e18]: Alex Morgan
      - button "Collapse sidebar" [expanded] [ref=e19] [cursor=pointer]:
        - img [ref=e20]
        - generic [ref=e22]: Collapse sidebar
      - generic [ref=e24]:
        - text: Team
        - combobox "Current team" [ref=e25]:
          - option "No team" [disabled]
          - option "Runtime (RUN)"
          - option "Platform (PLAT)" [selected]
      - navigation "Workspace navigation" [ref=e26]:
        - link "Back to Issues" [ref=e27] [cursor=pointer]:
          - /url: /?view=my-work
          - img [ref=e29]
          - generic [ref=e31]: Back to Issues
      - navigation "Administration navigation" [ref=e32]:
        - link "Settings" [ref=e33] [cursor=pointer]:
          - /url: /settings
          - img [ref=e35]
          - generic [ref=e37]: Settings
      - generic [ref=e39]:
        - button "Sign out" [ref=e40] [cursor=pointer]:
          - img [ref=e42]
          - generic [ref=e44]: Sign out
        - generic [ref=e45]: v1.0.0 · build project-work-preview · schema 24
    - generic [ref=e46]:
      - banner [ref=e47]:
        - paragraph [ref=e48]:
          - generic [ref=e49]: Workspace
        - button "Search" [ref=e51] [cursor=pointer]:
          - img [ref=e53]
          - generic [ref=e55]:
            - generic [ref=e56]: Search
            - generic [ref=e57]: Ctrl K
        - generic [ref=e58]:
          - button "Switch to the light theme" [ref=e59]:
            - img [ref=e60]
          - group "Language" [ref=e63]:
            - button "中" [ref=e64]
            - button "EN" [pressed] [ref=e65]
      - main [ref=e66]:
        - generic [ref=e67]:
          - generic [ref=e69]:
            - heading "Settings" [level=1] [ref=e70]
            - paragraph [ref=e71]: Workspace administration stays separate from daily planning.
          - generic [ref=e72]:
            - tablist "Settings sections" [ref=e73]:
              - tab "Workspace" [selected] [ref=e74]:
                - generic [ref=e75]: Workspace
            - tabpanel "Workspace" [ref=e76]:
              - generic [ref=e77]:
                - region "Teams" [ref=e78]:
                  - paragraph [ref=e79]: Workspace structure
                  - heading "Teams" [level=2] [ref=e80]
                  - generic [ref=e81]:
                    - generic [ref=e82]:
                      - text: Team name
                      - textbox "Team name" [ref=e83]
                    - generic [ref=e84]:
                      - text: Team key
                      - textbox "Team key" [ref=e85]:
                        - /placeholder: ENG
                    - button "Create team" [ref=e86] [cursor=pointer]:
                      - img [ref=e88]
                      - generic [ref=e90]: Create team
                - region "Team details" [ref=e91]:
                  - paragraph [ref=e92]: Selected team
                  - heading "Team details" [level=2] [ref=e93]
                  - generic [ref=e94]:
                    - generic [ref=e95]:
                      - text: Team name
                      - textbox "Team name" [ref=e96]: Platform
                    - generic [ref=e97]:
                      - text: Team key
                      - textbox "Team key" [ref=e98]: PLAT
                    - button "Save changes" [ref=e99] [cursor=pointer]:
                      - img [ref=e101]
                      - generic [ref=e103]: Save changes
                  - generic [ref=e104]:
                    - generic [ref=e105]:
                      - strong [ref=e106]: Delete team
                      - paragraph [ref=e107]: Remove this Team from active navigation; associated work is retained but unavailable.
                    - button "Delete team" [ref=e108] [cursor=pointer]:
                      - img [ref=e110]
                      - generic [ref=e112]: Delete team
                - region "Workflow states" [ref=e113]:
                  - paragraph [ref=e114]: Team workflow
                  - heading "Workflow states" [level=2] [ref=e115]
                  - article [ref=e117]:
                    - generic [ref=e120]:
                      - strong [ref=e121]: In progress
                      - generic [ref=e122]: Started
                    - button "Edit status In progress" [ref=e123] [cursor=pointer]:
                      - img [ref=e125]
                      - generic [ref=e127]: Edit
                  - generic [ref=e128]:
                    - generic [ref=e129]:
                      - text: Status name
                      - textbox "Status name" [ref=e130]
                    - generic [ref=e131]:
                      - text: Category
                      - combobox "Category" [ref=e132]:
                        - option "Backlog"
                        - option "Planned" [selected]
                        - option "Started"
                        - option "Completed"
                        - option "Canceled"
                    - group "Status color" [ref=e133]:
                      - generic [ref=e134]: Status color
                      - generic [ref=e135]:
                        - generic [ref=e136] [cursor=pointer]:
                          - radio "Neutral" [checked] [ref=e137]
                          - generic [ref=e139]: Neutral
                        - generic [ref=e140] [cursor=pointer]:
                          - radio "Blue" [ref=e141]
                          - generic [ref=e143]: Blue
                        - generic [ref=e144] [cursor=pointer]:
                          - radio "Green" [ref=e145]
                          - generic [ref=e147]: Green
                        - generic [ref=e148] [cursor=pointer]:
                          - radio "Amber" [ref=e149]
                          - generic [ref=e151]: Amber
                        - generic [ref=e152] [cursor=pointer]:
                          - radio "Red" [ref=e153]
                          - generic [ref=e155]: Red
                        - generic [ref=e156] [cursor=pointer]:
                          - radio "Custom" [ref=e157]
                          - generic [ref=e159]: Custom
                    - button "Create status" [ref=e160] [cursor=pointer]:
                      - img [ref=e162]
                      - generic [ref=e164]: Create status
              - region "Model service connections" [ref=e165]:
                - paragraph [ref=e166]: Agent workbench
                - heading "Model service connections" [level=2] [ref=e167]
                - paragraph [ref=e168]: Manage Chat Completions and Responses providers, credentials, and models.
                - link "Open connection settings" [ref=e169] [cursor=pointer]:
                  - /url: /settings/agent-workbench
```

# Test source

```ts
  861  |   await page.getByRole('tab', { name: 'Workspace' }).press('End')
  862  |   await expect(page.getByRole('tab', { name: 'Planning & Operations' })).toBeFocused()
  863  |   await expect(page).toHaveURL(`${webUrl}${routedOperationsUrl}`)
  864  |   expect(await page.evaluate(() => window.history.length)).toBe(initialLength + 2)
  865  | 
  866  |   await page.getByRole('tab', { name: 'Planning & Operations' }).press('End')
  867  |   expect(await page.evaluate(() => window.history.length)).toBe(initialLength + 2)
  868  |   await page.getByRole('tab', { name: 'Planning & Operations' }).press('Home')
  869  |   await expect(page.getByRole('tab', { name: 'Workspace' })).toBeFocused()
  870  |   expect(await page.evaluate(() => window.history.length)).toBe(initialLength + 3)
  871  |   await page.getByRole('tab', { name: 'Workspace' }).press('ArrowLeft')
  872  |   await expect(page.getByRole('tab', { name: 'Planning & Operations' })).toBeFocused()
  873  |   expect(await page.evaluate(() => window.history.length)).toBe(initialLength + 4)
  874  | 
  875  |   const localeControl = page.getByRole('button', { exact: true, name: 'EN' })
  876  |   await localeControl.focus()
  877  |   await page.goBack()
  878  |   await expect(page).toHaveURL(`${webUrl}/settings?team=team-1&opsQuery=Archived&x=keep#operations-templates`)
  879  |   await expect(page.getByRole('tab', { name: 'Workspace' })).toHaveAttribute('aria-selected', 'true')
  880  |   await expect(localeControl).toBeFocused()
  881  |   await page.goForward()
  882  |   await expect(page).toHaveURL(`${webUrl}${routedOperationsUrl}`)
  883  |   await expect(page.getByRole('tab', { name: 'Planning & Operations' })).toHaveAttribute('aria-selected', 'true')
  884  |   await expect(localeControl).toBeFocused()
  885  | 
  886  |   const geometry: Awaited<ReturnType<typeof measureSettingsGeometry>>[] = []
  887  |   const wide = await measureSettingsGeometry(page)
  888  |   geometry.push(wide)
  889  |   expect(wide.document.scrollWidth).toBe(wide.document.clientWidth)
  890  |   expect(wide.content.width / wide.main.width).toBeGreaterThanOrEqual(.85)
  891  |   expect(wide.content.width).toBeLessThanOrEqual(1480)
  892  |   expect(wide.panel.width / wide.contentInnerWidth).toBeGreaterThanOrEqual(.98)
  893  |   expect(wide.operationsRoot.width / wide.panel.width).toBeGreaterThanOrEqual(.98)
  894  |   const wideScreenshot = testInfo.outputPath('task-5.1-settings-wide-pass.png')
  895  |   await page.screenshot({ fullPage: true, path: wideScreenshot })
  896  |   await testInfo.attach('task-5.1-settings-wide-pass', { contentType: 'image/png', path: wideScreenshot })
  897  | 
  898  |   await page.setViewportSize({ width: 390, height: 844 })
  899  |   await page.goto(directUrl)
  900  |   const selector = page.getByRole('combobox', { name: 'Settings sections' })
  901  |   await expect(selector).toHaveValue('operations')
  902  |   await expect(page.getByRole('tablist')).toHaveCount(0)
  903  |   await expect(page.getByRole('tab')).toHaveCount(0)
  904  |   await expect(page.getByRole('tabpanel')).toHaveCount(1)
  905  |   await selector.focus()
  906  |   await selector.selectOption('workspace')
  907  |   await expect(selector).toBeFocused()
  908  |   await expect(page).toHaveURL(`${webUrl}/settings?team=team-1&opsQuery=Archived&x=keep#operations-templates`)
  909  |   expect(await page.evaluate(() => document.documentElement.scrollWidth)).toBe(390)
  910  | 
  911  |   await selector.selectOption('operations')
  912  |   await expect(selector).toBeFocused()
  913  |   const narrow = await measureSettingsGeometry(page)
  914  |   geometry.push(narrow)
  915  |   expect(narrow.document.scrollWidth).toBe(narrow.document.clientWidth)
  916  |   expect(narrow.content.width).toBeLessThanOrEqual(390)
  917  |   expect(narrow.panel.width / narrow.contentInnerWidth).toBeGreaterThanOrEqual(.98)
  918  |   const narrowScreenshot = testInfo.outputPath('task-5.1-settings-narrow-pass.png')
  919  |   await page.screenshot({ fullPage: true, path: narrowScreenshot })
  920  |   await testInfo.attach('task-5.1-settings-narrow-pass', { contentType: 'image/png', path: narrowScreenshot })
  921  | 
  922  |   const geometryPath = testInfo.outputPath('task-5.1-settings-geometry-pass.json')
  923  |   await writeFile(geometryPath, JSON.stringify(geometry, null, 2), 'utf8')
  924  |   await testInfo.attach('task-5.1-settings-geometry-pass', { contentType: 'application/json', path: geometryPath })
  925  | })
  926  | 
  927  | test('scopes Team resolution to Workspace with serial deep-link pagination and dense 390/1920 geometry', async ({ page }, testInfo) => {
  928  |   const requestLog: string[] = []
  929  |   const teamRequestSequence = () => requestLog
  930  |     .map(request => new URL(request))
  931  |     .filter(url => url.pathname === '/api/v1/teams' || /^\/api\/v1\/teams\/[^/]+\/states$/.test(url.pathname))
  932  |     .map(url => `${url.pathname}${url.search}`)
  933  |   const resolutionSequence = [
  934  |     '/api/v1/teams?limit=100',
  935  |     '/api/v1/teams?limit=100&cursor=teams-page-2',
  936  |     '/api/v1/teams/team-second-page/states?limit=100',
  937  |   ]
  938  |   await installOperationsRoutes(page, () => allOperationsFeatures, {
  939  |     requestLog,
  940  |     settingsTeamPages: {
  941  |       first: { items: [settingsTeamOne], nextCursor: 'teams-page-2' },
  942  |       'teams-page-2': { items: [settingsTeamTwo], nextCursor: null },
  943  |     },
  944  |     settingsStates: {
  945  |       [settingsTeamOne.id]: [{ id: 'state-runtime', name: 'Ready', category: 'planned', color: '#64748b', revision: 1 }],
  946  |       [settingsTeamTwo.id]: [{ id: 'state-platform', name: 'In progress', category: 'started', color: '#2563eb', revision: 1 }],
  947  |     },
  948  |   })
  949  | 
  950  |   await page.setViewportSize({ width: 1920, height: 1080 })
  951  |   await page.goto('/settings?team=team-second-page&x=keep#team-settings-heading')
  952  |   await expect(page).toHaveURL(`${webUrl}/settings?team=team-second-page&x=keep#team-settings-heading`)
  953  |   await expect.poll(() => ({ href: page.url(), sequence: teamRequestSequence() })).toEqual({
  954  |     href: `${webUrl}/settings?team=team-second-page&x=keep#team-settings-heading`,
  955  |     sequence: resolutionSequence,
  956  |   })
  957  |   await expect(page.getByRole('combobox', { name: 'Current team' })).toHaveValue('team-second-page')
  958  |   await expect(page.getByRole('heading', { name: 'Team details' })).toBeVisible()
  959  |   await expect(page.locator('input[name="name"][value="Platform"]')).toBeVisible()
  960  | 
> 961  |   await page.getByRole('tab', { name: 'Planning & Operations' }).click()
       |                                                                  ^ Error: locator.click: Test timeout of 30000ms exceeded.
  962  |   await expect(page.getByRole('tab', { name: 'Planning & Operations' })).toHaveAttribute('aria-selected', 'true')
  963  |   await expect(page.getByRole('combobox', { name: 'Current team' })).toHaveCount(0)
  964  |   await expect(page).toHaveURL(`${webUrl}/settings?team=team-second-page&x=keep&tab=operations#team-settings-heading`)
  965  |   const operationsRequestBoundary = teamRequestSequence().length
  966  |   await page.evaluate(() => new Promise<void>(resolve => {
  967  |     requestAnimationFrame(() => requestAnimationFrame(() => resolve()))
  968  |   }))
  969  |   expect(teamRequestSequence().slice(operationsRequestBoundary)).toEqual([])
  970  | 
  971  |   await page.getByRole('tab', { name: 'Workspace' }).click()
  972  |   await expect.poll(teamRequestSequence).toEqual([...resolutionSequence, ...resolutionSequence])
  973  |   await expect(page.getByRole('combobox', { name: 'Current team' })).toHaveValue('team-second-page')
  974  |   await expect(page).toHaveURL(`${webUrl}/settings?team=team-second-page&x=keep#team-settings-heading`)
  975  | 
  976  |   const geometry: Awaited<ReturnType<typeof measureWorkspaceSettingsGeometry>>[] = []
  977  |   const wide = await measureWorkspaceSettingsGeometry(page)
  978  |   geometry.push(wide)
  979  |   expect(wide.document.scrollWidth).toBe(wide.document.clientWidth)
  980  |   expect(wide.content.width / wide.main.width).toBeGreaterThanOrEqual(.85)
  981  |   expect(wide.content.width).toBeLessThanOrEqual(1480)
  982  |   expect(wide.panel.width / wide.contentInnerWidth).toBeGreaterThanOrEqual(.98)
  983  |   expect(wide.settingsGrid.width / wide.panel.width).toBeGreaterThanOrEqual(.98)
  984  |   expect(wide.selector.width).toBeGreaterThanOrEqual(120)
  985  |   expect(wide.selector.width).toBeLessThanOrEqual(260)
  986  |   expect(wide.selector.width / wide.main.width).toBeLessThan(.2)
  987  |   expect(await removeNextDevelopmentIndicatorForEvidence(page)).toBeGreaterThan(0)
  988  |   const wideScreenshot = testInfo.outputPath('task-5.2-settings-wide-pass.png')
  989  |   await page.screenshot({ fullPage: true, path: wideScreenshot })
  990  |   await testInfo.attach('task-5.2-settings-wide-pass', { contentType: 'image/png', path: wideScreenshot })
  991  | 
  992  |   await page.setViewportSize({ width: 390, height: 844 })
  993  |   const settingsSelector = page.getByRole('combobox', { name: 'Settings sections' })
  994  |   await expect(settingsSelector).toHaveValue('workspace')
  995  |   await settingsSelector.selectOption('operations')
  996  |   await expect(settingsSelector).toHaveValue('operations')
  997  |   await expect(page.getByRole('combobox', { name: 'Current team' })).toHaveCount(0)
  998  |   await expect(page).toHaveURL(`${webUrl}/settings?team=team-second-page&x=keep&tab=operations#team-settings-heading`)
  999  |   expect(await page.evaluate(() => document.documentElement.scrollWidth)).toBe(390)
  1000 | 
  1001 |   await settingsSelector.selectOption('workspace')
  1002 |   await expect(settingsSelector).toHaveValue('workspace')
  1003 |   await expect.poll(teamRequestSequence).toEqual([
  1004 |     ...resolutionSequence,
  1005 |     ...resolutionSequence,
  1006 |     ...resolutionSequence,
  1007 |   ])
  1008 |   await page.getByText('Menu', { exact: true }).click()
  1009 |   await expect(page.getByRole('combobox', { name: 'Current team' })).toHaveValue('team-second-page')
  1010 |   const narrow = await measureWorkspaceSettingsGeometry(page)
  1011 |   geometry.push(narrow)
  1012 |   expect(narrow.document.scrollWidth).toBe(narrow.document.clientWidth)
  1013 |   expect(narrow.content.width).toBeLessThanOrEqual(390)
  1014 |   expect(narrow.panel.width / narrow.contentInnerWidth).toBeGreaterThanOrEqual(.98)
  1015 |   expect(narrow.settingsGrid.width / narrow.panel.width).toBeGreaterThanOrEqual(.98)
  1016 |   await removeNextDevelopmentIndicatorForEvidence(page)
  1017 |   const narrowScreenshot = testInfo.outputPath('task-5.2-settings-narrow-pass.png')
  1018 |   await page.screenshot({ fullPage: true, path: narrowScreenshot })
  1019 |   await testInfo.attach('task-5.2-settings-narrow-pass', { contentType: 'image/png', path: narrowScreenshot })
  1020 | 
  1021 |   const geometryPath = testInfo.outputPath('task-5.2-settings-team-geometry-pass.json')
  1022 |   await writeFile(geometryPath, JSON.stringify(geometry, null, 2), 'utf8')
  1023 |   await testInfo.attach('task-5.2-settings-team-geometry-pass', { contentType: 'application/json', path: geometryPath })
  1024 |   const requestSequencePath = testInfo.outputPath('task-5.2-team-request-sequence-pass.json')
  1025 |   await writeFile(requestSequencePath, JSON.stringify({ sequence: teamRequestSequence() }, null, 2), 'utf8')
  1026 |   await testInfo.attach('task-5.2-team-request-sequence-pass', { contentType: 'application/json', path: requestSequencePath })
  1027 | })
  1028 | 
  1029 | test('keeps destructive retries revision-specific and contains long failure content at 390', async ({ page }, testInfo) => {
  1030 |   const longName = `Runtime ${'reliability-and-recovery '.repeat(55)}`.trim()
  1031 |   const longKey = `RUN-${'LONG-'.repeat(48)}`
  1032 |   let revision = 7
  1033 |   let deleteCount = 0
  1034 |   const privateKeys: string[] = []
  1035 |   const evidence: Array<{
  1036 |     bodyLength: number
  1037 |     count: number
  1038 |     idempotencyKeyPresent: boolean
  1039 |     ifMatch: string | undefined
  1040 |     path: string
  1041 |     sameAsFirst: boolean | null
  1042 |   }> = []
  1043 |   const target: SettingsTeamFixture = {
  1044 |     id: 'team/delete-target',
  1045 |     key: longKey,
  1046 |     name: longName,
  1047 |     get revision() { return revision },
  1048 |   }
  1049 |   const pages = {
  1050 |     get first(): SettingsTeamPageFixture { return { items: [target, settingsTeamTwo], nextCursor: null } },
  1051 |   }
  1052 |   await installOperationsRoutes(page, () => allOperationsFeatures, {
  1053 |     settingsDelete: request => {
  1054 |       deleteCount += 1
  1055 |       const key = request.headers()['idempotency-key'] ?? ''
  1056 |       privateKeys.push(key)
  1057 |       evidence.push({
  1058 |         bodyLength: request.postDataBuffer()?.byteLength ?? 0,
  1059 |         count: deleteCount,
  1060 |         idempotencyKeyPresent: key.length > 0,
  1061 |         ifMatch: request.headers()['if-match'],
```