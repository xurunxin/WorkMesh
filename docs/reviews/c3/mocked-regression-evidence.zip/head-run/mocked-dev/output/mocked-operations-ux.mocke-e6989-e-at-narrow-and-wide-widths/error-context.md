# Instructions

- Following Playwright test failed.
- Explain why, be concise, respect Playwright best practices.
- Provide a snippet of code with the fix, if possible.

# Test info

- Name: mocked\operations-ux.mocked.spec.ts >> keeps Recent runs semantic, linked, and locally scrollable at narrow and wide widths
- Location: e2e\mocked\operations-ux.mocked.spec.ts:1527:1

# Error details

```
Error: expect(received).not.toBe(expected) // Object.is equality

Expected: not "none"
```

# Page snapshot

```yaml
- generic [ref=e1]:
  - button "Open Next.js Dev Tools" [ref=e7] [cursor=pointer]:
    - img [ref=e8]
  - alert [ref=e11]
  - generic [ref=e12]:
    - link "Skip to content" [ref=e13] [cursor=pointer]:
      - /url: "#workmesh-main"
    - generic [ref=e14]:
      - banner [ref=e15]:
        - group [ref=e16]:
          - generic "Menu" [ref=e17] [cursor=pointer]
        - button "Search" [ref=e19] [cursor=pointer]:
          - img [ref=e21]
          - generic [ref=e24]: Search
      - main [ref=e25]:
        - generic [ref=e27]:
          - generic [ref=e28]:
            - generic [ref=e29]:
              - link "Back to work" [ref=e30] [cursor=pointer]:
                - /url: /
              - heading "Planning & Operations" [level=1] [ref=e31]
              - paragraph [ref=e32]: Durable planning, automation, health, and cost observability.
            - button "Refresh" [ref=e33] [cursor=pointer]:
              - generic [ref=e34]: Refresh
          - generic [ref=e35]:
            - generic [ref=e36]: Search loaded Operations records
            - searchbox "Search loaded Operations records" [ref=e37]
            - generic [ref=e38]: Filters only Operations records already loaded in this view. Load more to expand the searchable set.
          - navigation "Operations sections" [ref=e39]:
            - link "Usage and cost" [ref=e40] [cursor=pointer]:
              - /url: "#operations-metrics"
            - link "Cycles" [ref=e41] [cursor=pointer]:
              - /url: "#operations-cycles"
            - link "Initiatives" [ref=e42] [cursor=pointer]:
              - /url: "#operations-initiatives"
            - link "Automation rules" [ref=e43] [cursor=pointer]:
              - /url: "#operations-automation"
            - link "Loops" [ref=e44] [cursor=pointer]:
              - /url: "#operations-loops"
            - link "Recent runs" [ref=e45] [cursor=pointer]:
              - /url: "#operations-runs"
            - link "Templates & playbooks" [ref=e46] [cursor=pointer]:
              - /url: "#operations-templates"
          - region "Usage and cost" [ref=e47]:
            - list "Usage and cost" [ref=e48]:
              - listitem "Tokens" [ref=e49]:
                - generic [ref=e51]:
                  - term [ref=e52]: Tokens
                  - definition [ref=e53]:
                    - strong [ref=e54]: 1,500
              - listitem "Runtime" [ref=e55]:
                - generic [ref=e57]:
                  - term [ref=e58]: Runtime
                  - definition [ref=e59]:
                    - strong [ref=e60]: 45s
              - listitem "Tool calls" [ref=e61]:
                - generic [ref=e63]:
                  - term [ref=e64]: Tool calls
                  - definition [ref=e65]:
                    - strong [ref=e66]: "7"
              - listitem "Unknown cost" [ref=e67]:
                - generic [ref=e69]:
                  - term [ref=e70]: Unknown cost
                  - definition [ref=e71]:
                    - strong [ref=e72]: "0"
                    - text: records
              - listitem "Known cost" [ref=e73]:
                - generic [ref=e75]:
                  - term [ref=e76]: Known cost
                  - definition [ref=e77]: No known cost
          - generic [ref=e78]:
            - generic [ref=e79]:
              - heading "Cycles" [level=2] [ref=e80]
              - article [ref=e81]:
                - generic [ref=e82]:
                  - strong [ref=e83]: Nightly planning
                  - generic [ref=e84]: Current
                - paragraph [ref=e85]: 5/12 completed
                - generic [ref=e86]: 8/1/2026, 8:00:00 AM → 8/31/2026, 8:00:00 AM
              - article [ref=e87]:
                - generic [ref=e88]:
                  - strong [ref=e89]: Launch readiness
                  - generic [ref=e90]: Upcoming
                - paragraph [ref=e91]: 0/8 completed
                - generic [ref=e92]: 9/1/2026, 8:00:00 AM → 9/30/2026, 8:00:00 AM
              - article [ref=e93]:
                - generic [ref=e94]:
                  - strong [ref=e95]: Foundation review
                  - generic [ref=e96]: History
                - paragraph [ref=e97]: 10/10 completed
                - generic [ref=e98]: 7/1/2026, 8:00:00 AM → 7/31/2026, 8:00:00 AM
            - generic [ref=e99]:
              - heading "Initiatives" [level=2] [ref=e100]
              - article [ref=e101]:
                - generic [ref=e102]:
                  - strong [ref=e103]: Runtime reliability
                  - generic [ref=e104]: On track
                - paragraph [ref=e105]: Active · Urgent priority
              - article [ref=e106]:
                - generic [ref=e107]:
                  - strong [ref=e108]: Queue recovery
                  - generic [ref=e109]: At risk
                - paragraph [ref=e110]: Planned · High priority
              - article [ref=e111]:
                - generic [ref=e112]:
                  - strong [ref=e113]: Legacy retirement
                  - generic [ref=e114]: Off track
                - paragraph [ref=e115]: Paused · Medium priority
              - article [ref=e116]:
                - generic [ref=e117]:
                  - strong [ref=e118]: Documentation
                  - generic [ref=e119]: Unknown
                - paragraph [ref=e120]: Completed · Low priority
              - article [ref=e121]:
                - generic [ref=e122]:
                  - strong [ref=e123]: Discarded experiment
                  - generic [ref=e124]: Unknown
                - paragraph [ref=e125]: Canceled · None priority
            - generic [ref=e126]:
              - heading "Automation rules" [level=2] [ref=e127]
              - article [ref=e128]:
                - generic [ref=e129]:
                  - strong [ref=e130]: Webhook retry
                  - generic [ref=e131]: v1 · schedule 0 2 * * *
                - generic [ref=e132]: Disabled
                - button "Dry run" [ref=e133]
                - button "Resume" [ref=e134]
              - article [ref=e135]:
                - generic [ref=e136]:
                  - strong [ref=e137]: Rule 2
                  - generic [ref=e138]: v1 · event
                - generic [ref=e139]: Paused
                - button "Dry run" [ref=e140]
                - button "Resume" [ref=e141]
              - article [ref=e142]:
                - generic [ref=e143]:
                  - strong [ref=e144]: Rule 3
                  - generic [ref=e145]: v1 · event
                - generic [ref=e146]: Enabled
                - button "Dry run" [ref=e147]
                - button "Pause" [ref=e148]
              - article [ref=e149]:
                - generic [ref=e150]:
                  - strong [ref=e151]: Rule 4
                  - generic [ref=e152]: v1 · event
                - generic [ref=e153]: Enabled
                - button "Dry run" [ref=e154]
                - button "Pause" [ref=e155]
              - article [ref=e156]:
                - generic [ref=e157]:
                  - strong [ref=e158]: Rule 5
                  - generic [ref=e159]: v1 · event
                - generic [ref=e160]: Enabled
                - button "Dry run" [ref=e161]
                - button "Pause" [ref=e162]
              - article [ref=e163]:
                - generic [ref=e164]:
                  - strong [ref=e165]: Rule 6
                  - generic [ref=e166]: v1 · event
                - generic [ref=e167]: Enabled
                - button "Dry run" [ref=e168]
                - button "Pause" [ref=e169]
              - article [ref=e170]:
                - generic [ref=e171]:
                  - strong [ref=e172]: Rule 7
                  - generic [ref=e173]: v1 · event
                - generic [ref=e174]: Enabled
                - button "Dry run" [ref=e175]
                - button "Pause" [ref=e176]
              - article [ref=e177]:
                - generic [ref=e178]:
                  - strong [ref=e179]: Rule 8
                  - generic [ref=e180]: v1 · event
                - generic [ref=e181]: Enabled
                - button "Dry run" [ref=e182]
                - button "Pause" [ref=e183]
            - generic [ref=e184]:
              - heading "Loops" [level=2] [ref=e185]
              - article [ref=e186]:
                - generic [ref=e187]:
                  - strong [ref=e188]: Release guard
                  - generic [ref=e189]: "Next: 8/23/2026, 10:00:00 AM · No overlap"
                - generic [ref=e190]: Disabled
                - button "Resume" [ref=e191]
              - article [ref=e192]:
                - generic [ref=e193]:
                  - strong [ref=e194]: Loop 2
                  - generic [ref=e195]: "Next: 8/23/2026, 10:00:00 AM · No overlap"
                - generic [ref=e196]: Paused
                - button "Resume" [ref=e197]
              - article [ref=e198]:
                - generic [ref=e199]:
                  - strong [ref=e200]: Loop 3
                  - generic [ref=e201]: "Next: 8/23/2026, 10:00:00 AM · Overlap allowed"
                - generic [ref=e202]: Enabled
                - button "Pause" [ref=e203]
              - article [ref=e204]:
                - generic [ref=e205]:
                  - strong [ref=e206]: Loop 4
                  - generic [ref=e207]: "Next: 8/23/2026, 10:00:00 AM · No overlap"
                - generic [ref=e208]: Enabled
                - button "Pause" [ref=e209]
              - article [ref=e210]:
                - generic [ref=e211]:
                  - strong [ref=e212]: Loop 5
                  - generic [ref=e213]: "Next: 8/23/2026, 10:00:00 AM · No overlap"
                - generic [ref=e214]: Enabled
                - button "Pause" [ref=e215]
              - article [ref=e216]:
                - generic [ref=e217]:
                  - strong [ref=e218]: Loop 6
                  - generic [ref=e219]: "Next: 8/23/2026, 10:00:00 AM · No overlap"
                - generic [ref=e220]: Enabled
                - button "Pause" [ref=e221]
            - generic [ref=e222]:
              - heading "Recent runs" [level=2] [ref=e223]
              - region "Recent runs" [active] [ref=e224]:
                - table "Recent runs" [ref=e225]:
                  - caption [ref=e226]: Recent runs
                  - rowgroup [ref=e234]:
                    - row "Run Kind Status Attempts Session Created" [ref=e235]:
                      - columnheader "Run" [ref=e236]
                      - columnheader "Kind" [ref=e237]
                      - columnheader "Status" [ref=e238]
                      - columnheader "Attempts" [ref=e239]
                      - columnheader "Session" [ref=e240]
                      - columnheader "Created" [ref=e241]
                  - rowgroup [ref=e242]:
                    - 'row "run-0001 Rule Pending 1 / 3 Session: 11111111-1111-4111-8111-111111111111 8/23/2026, 9:00:00 AM" [ref=e243]':
                      - cell "run-0001" [ref=e244]:
                        - code [ref=e245]: run-0001
                      - cell "Rule" [ref=e246]
                      - cell "Pending" [ref=e247]:
                        - generic [ref=e248]: Pending
                      - cell "1 / 3" [ref=e249]
                      - 'cell "Session: 11111111-1111-4111-8111-111111111111" [ref=e250]':
                        - 'link "Session: 11111111-1111-4111-8111-111111111111" [ref=e251] [cursor=pointer]':
                          - /url: /agent-sessions/11111111-1111-4111-8111-111111111111
                          - code [ref=e252]: "11111111"
                      - cell "8/23/2026, 9:00:00 AM" [ref=e253]:
                        - time [ref=e254]: 8/23/2026, 9:00:00 AM
                    - row "run-0002 Rule Claimed 1 / 3 — 8/23/2026, 9:00:00 AM" [ref=e255]:
                      - cell "run-0002" [ref=e256]:
                        - code [ref=e257]: run-0002
                      - cell "Rule" [ref=e258]
                      - cell "Claimed" [ref=e259]:
                        - generic [ref=e260]: Claimed
                      - cell "1 / 3" [ref=e261]
                      - cell "—" [ref=e262]
                      - cell "8/23/2026, 9:00:00 AM" [ref=e263]:
                        - time [ref=e264]: 8/23/2026, 9:00:00 AM
                    - row "run-0003 Rule Running 1 / 3 — 8/23/2026, 9:00:00 AM" [ref=e265]:
                      - cell "run-0003" [ref=e266]:
                        - code [ref=e267]: run-0003
                      - cell "Rule" [ref=e268]
                      - cell "Running" [ref=e269]:
                        - generic [ref=e270]: Running
                      - cell "1 / 3" [ref=e271]
                      - cell "—" [ref=e272]
                      - cell "8/23/2026, 9:00:00 AM" [ref=e273]:
                        - time [ref=e274]: 8/23/2026, 9:00:00 AM
                    - row "run-0004 Rule Succeeded 1 / 3 — 8/23/2026, 9:00:00 AM" [ref=e275]:
                      - cell "run-0004" [ref=e276]:
                        - code [ref=e277]: run-0004
                      - cell "Rule" [ref=e278]
                      - cell "Succeeded" [ref=e279]:
                        - generic [ref=e280]: Succeeded
                      - cell "1 / 3" [ref=e281]
                      - cell "—" [ref=e282]
                      - cell "8/23/2026, 9:00:00 AM" [ref=e283]:
                        - time [ref=e284]: 8/23/2026, 9:00:00 AM
                    - row "run-0005 Rule Failed 3 / 3 — 8/23/2026, 9:00:00 AM" [ref=e285]:
                      - cell "run-0005" [ref=e286]:
                        - code [ref=e287]: run-0005
                      - cell "Rule" [ref=e288]
                      - cell "Failed" [ref=e289]:
                        - generic [ref=e290]: Failed
                      - cell "3 / 3" [ref=e291]
                      - cell "—" [ref=e292]
                      - cell "8/23/2026, 9:00:00 AM" [ref=e293]:
                        - time [ref=e294]: 8/23/2026, 9:00:00 AM
                    - row "Provider retry failed after the upstream execution service returned a deliberately long diagnostic summary that must wrap inside the local table without widening the page." [ref=e295]:
                      - cell "Provider retry failed after the upstream execution service returned a deliberately long diagnostic summary that must wrap inside the local table without widening the page." [ref=e296]:
                        - generic [ref=e297]: Provider retry failed after the upstream execution service returned a deliberately long diagnostic summary that must wrap inside the local table without widening the page.
                    - row "run-0006 Rule Dead 1 / 3 — 8/23/2026, 9:00:00 AM" [ref=e298]:
                      - cell "run-0006" [ref=e299]:
                        - code [ref=e300]: run-0006
                      - cell "Rule" [ref=e301]
                      - cell "Dead" [ref=e302]:
                        - generic [ref=e303]: Dead
                      - cell "1 / 3" [ref=e304]
                      - cell "—" [ref=e305]
                      - cell "8/23/2026, 9:00:00 AM" [ref=e306]:
                        - time [ref=e307]: 8/23/2026, 9:00:00 AM
                    - row "run-0007 Rule Canceled 1 / 3 — 8/23/2026, 9:00:00 AM" [ref=e308]:
                      - cell "run-0007" [ref=e309]:
                        - code [ref=e310]: run-0007
                      - cell "Rule" [ref=e311]
                      - cell "Canceled" [ref=e312]:
                        - generic [ref=e313]: Canceled
                      - cell "1 / 3" [ref=e314]
                      - cell "—" [ref=e315]
                      - cell "8/23/2026, 9:00:00 AM" [ref=e316]:
                        - time [ref=e317]: 8/23/2026, 9:00:00 AM
                    - row "run-0008 Dry run Dry run 1 / 3 — 8/23/2026, 9:00:00 AM" [ref=e318]:
                      - cell "run-0008" [ref=e319]:
                        - code [ref=e320]: run-0008
                      - cell "Dry run" [ref=e321]
                      - cell "Dry run" [ref=e322]:
                        - generic [ref=e323]: Dry run
                      - cell "1 / 3" [ref=e324]
                      - cell "—" [ref=e325]
                      - cell "8/23/2026, 9:00:00 AM" [ref=e326]:
                        - time [ref=e327]: 8/23/2026, 9:00:00 AM
            - generic [ref=e328]:
              - heading "Templates & playbooks" [level=2] [ref=e329]
              - generic [ref=e330]:
                - generic [ref=e331]:
                  - strong [ref=e332]: Issue starter
                  - generic [ref=e333]: Work item · v1 · Draft
                - generic [ref=e334]:
                  - strong [ref=e335]: Project launch
                  - generic [ref=e336]: Project · v2 · Active
                - generic [ref=e337]:
                  - strong [ref=e338]: Agent recovery
                  - generic [ref=e339]: Agent run · v3 · Archived
                - generic [ref=e340]:
                  - strong [ref=e341]: Incident handoff
                  - generic [ref=e342]: Handoff · v1 · Active
                - generic [ref=e343]:
                  - strong [ref=e344]: Automation bootstrap
                  - generic [ref=e345]: Automation · v1 · Draft
```

# Test source

```ts
  1481 |       panel: Locator,
  1482 |       noMatchHeading: string,
  1483 |       label: string,
  1484 |     ) => {
  1485 |       await search.fill(query)
  1486 |       await expect(item, `${label}: hidden raw field`).toHaveCount(0)
  1487 |       await expect(panel.getByRole('heading', { name: noMatchHeading }), `${label}: client no-match`).toBeVisible()
  1488 |     }
  1489 | 
  1490 |     await expectVisibleFor(cycleState, cycle, 'Cycle state')
  1491 |     await expectVisibleFor(cycleDate, cycle, 'Cycle date')
  1492 |     await expectHiddenFor('cycle-current', cycle, cyclePanel, 'No loaded Cycles match', 'Cycle full ID')
  1493 | 
  1494 |     await expectVisibleFor(initiativeHealth, initiative, 'Initiative health')
  1495 |     await expectVisibleFor(initiativeLine, initiative, 'Initiative status/priority')
  1496 |     await expectHiddenFor('on_track', initiative, initiativePanel, 'No loaded Initiatives match', 'Initiative raw health')
  1497 | 
  1498 |     await expectVisibleFor(ruleState, rule, 'Automation state')
  1499 |     await expectVisibleFor(ruleKind, rule, 'Automation trigger')
  1500 |     await expectHiddenFor('rule-1', rule, automationPanel, 'No loaded Automation rules match', 'Automation raw ID')
  1501 |     await expectHiddenFor('UTC', rule, automationPanel, 'No loaded Automation rules match', 'Automation undisplayed timezone')
  1502 | 
  1503 |     await expectVisibleFor(loopState, loop, 'Loop state')
  1504 |     await expectVisibleFor(loopSchedule, loop, 'Loop schedule')
  1505 |     await expectHiddenFor('no_overlap', loop, loopsPanel, 'No loaded Loops match', 'Loop raw overlap enum')
  1506 | 
  1507 |     await expectVisibleFor(failedRunKind, failedRun, 'Run kind')
  1508 |     await expectVisibleFor(failedRunState, failedRun, 'Run status')
  1509 |     await expectVisibleFor(failedRunDate, failedRun, 'Run date')
  1510 |     await expectVisibleFor(failedRunError, failedRun, 'Run historical error')
  1511 |     const dryRun = page.getByTestId('run-row-run-0008-record')
  1512 |     await expectHiddenFor('dry_run', dryRun, runsPanel, 'No loaded Recent runs match', 'Run raw status')
  1513 |     await expectHiddenFor('rule-5', failedRun, runsPanel, 'No loaded Recent runs match', 'Run undisplayed rule ID')
  1514 | 
  1515 |     await expectVisibleFor(templateLine, template, 'Template kind/status')
  1516 |     await expectHiddenFor('agent_run', template, templatesPanel, 'No loaded Templates & playbooks match', 'Template raw kind')
  1517 |     await expectHiddenFor('template-3', template, templatesPanel, 'No loaded Templates & playbooks match', 'Template raw ID')
  1518 | 
  1519 |     const collectionRequests = requestLog.filter(value => collectionPathSet.has(new URL(value).pathname))
  1520 |     expect(collectionRequests.length).toBeGreaterThan(0)
  1521 |     expect(collectionRequests.every(value => !new URL(value).searchParams.has('opsQuery'))).toBe(true)
  1522 |   } finally {
  1523 |     await page.close()
  1524 |   }
  1525 | })
  1526 | 
  1527 | test('keeps Recent runs semantic, linked, and locally scrollable at narrow and wide widths', async ({ page }, testInfo) => {
  1528 |   const geometry: Array<{
  1529 |     viewport: { width: number; height: number }
  1530 |     documentWidth: number
  1531 |     table: Awaited<ReturnType<typeof measureRunsTableGeometry>>
  1532 |   }> = []
  1533 |   await installOperationsRoutes(page, () => allOperationsFeatures)
  1534 | 
  1535 |   for (const viewport of [
  1536 |     { width: 390, height: 844 },
  1537 |     { width: 1920, height: 1080 },
  1538 |   ]) {
  1539 |     await page.setViewportSize(viewport)
  1540 |     await page.goto(`/operations?tableViewport=${viewport.width}#operations-runs`)
  1541 | 
  1542 |     const panel = page.getByTestId('runs-panel')
  1543 |     const table = panel.getByRole('table', { name: 'Recent runs' })
  1544 |     await expect(table).toBeVisible()
  1545 |     const headers = table.getByRole('columnheader')
  1546 |     await expect(headers).toHaveCount(6)
  1547 |     expect(await headers.evaluateAll(cells => cells.map(cell => cell.getAttribute('scope')))).toEqual(
  1548 |       Array.from({ length: 6 }, () => 'col'),
  1549 |     )
  1550 |     await expect(table.locator('thead')).toHaveCount(1)
  1551 |     await expect(table.locator('tbody')).toHaveCount(1)
  1552 | 
  1553 |     const failedRow = page.getByTestId('run-row-run-0005-record')
  1554 |     const historicalError = panel.getByText(/Provider retry failed after the upstream execution service/)
  1555 |     const errorId = await historicalError.getAttribute('id')
  1556 |     expect(errorId).toBe('run-error-run-0005-record')
  1557 |     await expect(failedRow).toHaveAttribute('aria-describedby', errorId ?? '')
  1558 |     await expect(historicalError.locator('xpath=ancestor::td')).toHaveAttribute('colspan', '6')
  1559 |     await expect(historicalError.locator('xpath=ancestor::tr')).not.toHaveAttribute('data-testid', 'run-row-run-0005-record')
  1560 |     await expect(panel.getByRole('alert')).toHaveCount(0)
  1561 | 
  1562 |     const noSessionRow = page.getByTestId('run-row-run-0002-record')
  1563 |     await expect(noSessionRow.getByText('—')).toBeVisible()
  1564 |     await expect(noSessionRow.getByRole('link')).toHaveCount(0)
  1565 |     await expect(page.getByTestId('run-row-run-0001-record').locator('time')).toHaveAttribute(
  1566 |       'datetime',
  1567 |       '2026-08-23T01:00:00Z',
  1568 |     )
  1569 | 
  1570 |     const tableScroll = page.getByTestId('operations-table-scroll')
  1571 |     await tableScroll.focus()
  1572 |     await expect(tableScroll).toBeFocused()
  1573 |     const measured = await measureRunsTableGeometry(page)
  1574 |     const documentWidth = await page.evaluate(() => document.documentElement.scrollWidth)
  1575 |     geometry.push({ viewport, documentWidth, table: measured })
  1576 | 
  1577 |     expect(documentWidth).toBe(viewport.width)
  1578 |     expect(measured.scrollHeight).toBeGreaterThan(measured.clientHeight)
  1579 |     expect(measured.scrollTopAfter).toBeGreaterThan(0)
  1580 |     expect(Math.abs(measured.stickyHeaderTopAfter - measured.wrapper.top)).toBeLessThanOrEqual(2)
> 1581 |     expect(measured.focusOutlineStyle).not.toBe('none')
       |                                            ^ Error: expect(received).not.toBe(expected) // Object.is equality
  1582 |     expect(Number.parseFloat(measured.focusOutlineWidth)).toBeGreaterThanOrEqual(2)
  1583 | 
  1584 |     if (viewport.width === 390) {
  1585 |       expect(measured.scrollWidth).toBeGreaterThan(measured.clientWidth)
  1586 |       expect(measured.scrollLeftAfter).toBeGreaterThan(0)
  1587 |       expect(measured.table.width).toBeGreaterThan(measured.wrapper.width)
  1588 |     } else {
  1589 |       expect(measured.scrollWidth).toBe(measured.clientWidth)
  1590 |       expect(measured.scrollLeftAfter).toBe(0)
  1591 |       expect(measured.table.width).toBeLessThanOrEqual(1121)
  1592 |       expect(Math.max(...measured.columnWidths)).toBeLessThanOrEqual(310)
  1593 |       expect(Math.min(...measured.columnWidths)).toBeGreaterThan(100)
  1594 |     }
  1595 | 
  1596 |     await tableScroll.evaluate(element => {
  1597 |       element.scrollLeft = 0
  1598 |       element.scrollTop = 0
  1599 |     })
  1600 |     const viewportName = viewport.width === 390 ? 'narrow' : 'wide'
  1601 |     const screenshotPath = testInfo.outputPath(`task-4.3-runs-table-${viewportName}-pass.png`)
  1602 |     await panel.screenshot({ path: screenshotPath })
  1603 |     await testInfo.attach(`task-4.3-runs-table-${viewportName}-pass`, {
  1604 |       contentType: 'image/png',
  1605 |       path: screenshotPath,
  1606 |     })
  1607 |   }
  1608 | 
  1609 |   const geometryPath = testInfo.outputPath('task-4.3-runs-table-geometry-pass.json')
  1610 |   await writeFile(geometryPath, JSON.stringify(geometry, null, 2), 'utf8')
  1611 |   await testInfo.attach('task-4.3-runs-table-geometry-pass', {
  1612 |     contentType: 'application/json',
  1613 |     path: geometryPath,
  1614 |   })
  1615 | 
  1616 |   const sessionLink = page.getByRole('link', { name: `Session: ${validRunSessionId}` })
  1617 |   await sessionLink.focus()
  1618 |   await expect(sessionLink).toBeFocused()
  1619 |   await page.keyboard.press('Enter')
  1620 |   await expect(page).toHaveURL(`/agent-sessions/${encodeURIComponent(validRunSessionId)}`)
  1621 |   await expect(page.getByTestId('agent-session-detail')).toBeVisible()
  1622 | })
  1623 | 
  1624 | test('projects precise aggregate metrics without charts at narrow and wide widths', async ({ page }, testInfo) => {
  1625 |   const geometry: Awaited<ReturnType<typeof measureUsageMetricsGeometry>>[] = []
  1626 |   await installOperationsRoutes(page, () => allOperationsFeatures, { usage: () => largeUsage })
  1627 | 
  1628 |   for (const viewport of [
  1629 |     { width: 390, height: 844 },
  1630 |     { width: 1920, height: 1080 },
  1631 |   ]) {
  1632 |     await page.setViewportSize(viewport)
  1633 |     await page.goto(`/operations?opsQuery=9%2C007%2C199%2C254%2C741%2C000&metricsViewport=${viewport.width}#operations-metrics`)
  1634 | 
  1635 |     const section = page.locator('#operations-metrics')
  1636 |     const metrics = section.getByRole('list', { name: 'Usage and cost' })
  1637 |     await expect(metrics).toBeVisible()
  1638 |     await expect(page.getByRole('searchbox', { name: 'Search loaded Operations records' })).toHaveValue('9,007,199,254,741,000')
  1639 |     await expect(section.getByText('9,007,199,254,741,000')).toBeVisible()
  1640 |     await expect(section.getByText('9,007,199,254,740,995')).toBeVisible()
  1641 |     await expect(section.getByText('1h 1m 1s')).toBeVisible()
  1642 |     await expect(section.getByRole('listitem', { name: 'USD' }).getByText('$90,071,992,547,409.93')).toBeVisible()
  1643 |     await expect(section.getByRole('listitem', { name: 'JPY' }).getByText('¥1,234')).toBeVisible()
  1644 |     await expect(section.getByRole('listitem', { name: 'KWD' }).getByText(/KWD\s*1\.234/)).toBeVisible()
  1645 |     const unsupported = section.getByRole('listitem', { name: 'ZZZ' })
  1646 |     await expect(unsupported.getByText('12,345,678,901,234,567,890')).toBeVisible()
  1647 |     await expect(unsupported.getByText('ZZZ minor units')).toBeVisible()
  1648 |     await expect(section.getByTestId('usage-currency-bucket')).toHaveCount(4)
  1649 |     await expect(section.locator('svg')).toHaveCount(0)
  1650 |     expect((await section.textContent()) ?? '').not.toMatch(/trend|over time|time[- ]?series|timeline/i)
  1651 |     await expect(page.getByTestId('cycles-panel').getByRole('heading', { name: 'No loaded Cycles match' })).toBeVisible()
  1652 | 
  1653 |     const measured = await measureUsageMetricsGeometry(page)
  1654 |     geometry.push(measured)
  1655 |     expect(measured.document.scrollWidth).toBe(measured.document.clientWidth)
  1656 |     expect(measured.section.left).toBeGreaterThanOrEqual(-1)
  1657 |     expect(measured.section.right).toBeLessThanOrEqual(measured.document.clientWidth + 1)
  1658 |     expect(measured.grid.width).toBeLessThanOrEqual(measured.section.width + 1)
  1659 |     expect(measured.overflowingCardCount).toBe(0)
  1660 |     expect(measured.svgCount).toBe(0)
  1661 |     expect(measured.cards.every(card =>
  1662 |       card.left >= measured.grid.left - 1 && card.right <= measured.grid.right + 1,
  1663 |     )).toBe(true)
  1664 | 
  1665 |     const cardWidths = measured.cards.map(card => card.width)
  1666 |     if (viewport.width === 390) {
  1667 |       expect(measured.rowCount).toBe(measured.cards.length)
  1668 |       expect(Math.min(...cardWidths)).toBeGreaterThan(300)
  1669 |       expect(Math.max(...cardWidths)).toBeLessThanOrEqual(measured.grid.width + 1)
  1670 |     } else {
  1671 |       expect(measured.rowCount).toBeGreaterThanOrEqual(2)
  1672 |       expect(measured.rowCount).toBeLessThanOrEqual(3)
  1673 |       expect(Math.min(...cardWidths)).toBeGreaterThanOrEqual(200)
  1674 |       expect(Math.max(...cardWidths)).toBeLessThanOrEqual(289)
  1675 |     }
  1676 | 
  1677 |     const viewportName = viewport.width === 390 ? 'narrow' : 'wide'
  1678 |     const screenshotPath = testInfo.outputPath(`task-4.4-usage-metrics-${viewportName}-pass.png`)
  1679 |     await section.screenshot({ path: screenshotPath })
  1680 |     await testInfo.attach(`task-4.4-usage-metrics-${viewportName}-pass`, {
  1681 |       contentType: 'image/png',
```