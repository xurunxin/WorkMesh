import hashlib, json, pathlib, subprocess, tarfile
root = pathlib.Path.cwd().resolve()
temp = root / '.tmp/c3-review'
refs = {'baseline': '8aee051c23eca1fc7653f688d6570c5808c0011d', 'head': subprocess.check_output(['git','rev-parse','HEAD'], text=True).strip()}
manifest = {'workspace': str(root), 'refs': refs, 'ports': [3240,3241], 'resources': [], 'source': {}}
for label, ref in refs.items():
    dest = temp / label
    dest.mkdir(exist_ok=True)
    archive = temp / (label + '.tar')
    manifest['resources'] += [str(dest), str(archive)]
    subprocess.run(['git','archive','--format=tar','-o',str(archive),ref], check=True)
    with tarfile.open(archive) as source:
        for member in source.getmembers():
            target = (dest / member.name).resolve()
            if not target.is_relative_to(dest) or member.issym() or member.islnk():
                raise ValueError(member.name)
        source.extractall(dest, filter='data')
    manifest['source'][label] = {}
    for file in dest.rglob('*'):
        if file.is_file() and not str(file.relative_to(dest)).startswith('docs'):
            data = file.read_bytes()
            manifest['source'][label][file.relative_to(dest).as_posix()] = {'bytes': len(data), 'sha256': hashlib.sha256(data).hexdigest()}
    patches = []
    names = ['apps/web/playwright.mocked.config.ts','apps/web/e2e/mocked/accessibility-fixtures.ts','apps/web/e2e/mocked/mock-control.ts']
    names += ['apps/web/e2e/mocked/' + name + '.mocked.spec.ts' for name in ['operations-ux','loading-states','overlay-contract','page-hotkeys','accessibility-keyboard']]
    for name in names:
        file = dest / name
        original = file.read_bytes()
        changed = original.replace(b'3200', b'3240').replace(b'3201', b'3241')
        if changed != original:
            file.write_bytes(changed)
            patches.append({'path': name, 'originalSha256': hashlib.sha256(original).hexdigest(), 'runSha256': hashlib.sha256(changed).hexdigest(), 'change': '仅端口 3200/3201 → 3240/3241；断言、超时、浏览器配置不变'})
    manifest['source'][label]['portPatches'] = patches
(temp / 'source.json').write_text(json.dumps(manifest,ensure_ascii=False,indent=2),encoding='utf8')
print(json.dumps({'refs': refs, 'resources': manifest['resources']},ensure_ascii=False))
