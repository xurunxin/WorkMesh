# Instructions

- Following Playwright test failed.
- Explain why, be concise, respect Playwright best practices.
- Provide a snippet of code with the fix, if possible.

# Test info

- Name: mocked\loading-states.mocked.spec.ts >> Task 6.4 Operations loading authority >> uses real pending owners, resolves independently, and retains focus through refresh failure
- Location: e2e\mocked\loading-states.mocked.spec.ts:690:3

# Error details

```
Error: expect(locator).toHaveCount(expected) failed

Locator:  locator('.operations-tab > .sr-only[role="status"]')
Expected: 1
Received: 0
Timeout:  10000ms

Call log:
  - Expect "toHaveCount" with timeout 10000ms
  - waiting for locator('.operations-tab > .sr-only[role="status"]')
    24 × locator resolved to 0 elements
       - unexpected value "0"

```

# Page snapshot

```yaml
- generic [ref=e1]:
  - button "Open Next.js Dev Tools" [ref=e7] [cursor=pointer]:
    - img [ref=e8]
  - alert [ref=e11]
  - generic [ref=e12]:
    - link "Skip to content" [ref=e13] [cursor=pointer]:
      - /url: "#workmesh-main"
    - complementary "Main navigation" [ref=e14]:
      - generic [ref=e15]:
        - strong [ref=e17]: WorkMesh
        - generic [ref=e18]: Alex Morgan
      - button "Collapse sidebar" [expanded] [ref=e19] [cursor=pointer]:
        - img [ref=e20]
        - generic [ref=e22]: Collapse sidebar
      - navigation "Workspace" [ref=e23]:
        - generic [ref=e24]:
          - paragraph [ref=e25]: Workbench
          - link "Workbench" [ref=e26] [cursor=pointer]:
            - /url: /workbench
            - img [ref=e28]
            - generic [ref=e30]: Workbench
          - link "My work" [ref=e31] [cursor=pointer]:
            - /url: /?view=home
            - img [ref=e33]
            - generic [ref=e35]: My work
          - link "Issues" [ref=e36] [cursor=pointer]:
            - /url: /?view=my-work
            - img [ref=e38]
            - generic [ref=e40]: Issues
          - link "Guidance" [ref=e41] [cursor=pointer]:
            - /url: /?view=guidance
            - img [ref=e43]
            - generic [ref=e45]: Guidance
        - generic [ref=e46]:
          - paragraph [ref=e47]: Governance
          - link "Needs You" [ref=e48] [cursor=pointer]:
            - /url: /?view=inbox
            - img [ref=e50]
            - generic [ref=e52]: Needs You
          - link "Session" [ref=e53] [cursor=pointer]:
            - /url: /?view=sessions
            - img [ref=e55]
            - generic [ref=e57]: Session
          - link "Recovery" [ref=e58] [cursor=pointer]:
            - /url: /?view=recovery
            - img [ref=e60]
            - generic [ref=e62]: Recovery
          - link "Projects" [ref=e63] [cursor=pointer]:
            - /url: /?view=projects
            - img [ref=e65]
            - generic [ref=e67]: Projects
          - link "Agents" [ref=e68] [cursor=pointer]:
            - /url: /agents
            - img [ref=e70]
            - generic [ref=e72]: Agents
        - generic [ref=e73]:
          - paragraph [ref=e74]: Operations
          - link "Operations" [ref=e75] [cursor=pointer]:
            - /url: /operations
            - img [ref=e77]
            - generic [ref=e79]: Operations
      - navigation "Administration" [ref=e80]:
        - link "Settings" [ref=e81] [cursor=pointer]:
          - /url: /settings
          - img [ref=e83]
          - generic [ref=e85]: Settings
      - generic [ref=e87]:
        - button "Sign out" [ref=e88] [cursor=pointer]:
          - img [ref=e90]
          - generic [ref=e92]: Sign out
        - generic [ref=e93]: v1.0.0 · build loading-state-fixture · schema 24
    - generic [ref=e94]:
      - banner [ref=e95]:
        - paragraph [ref=e96]:
          - generic [ref=e97]: Planning & Operations
        - button "Search" [ref=e99] [cursor=pointer]:
          - img [ref=e101]
          - generic [ref=e103]:
            - generic [ref=e104]: Search
            - generic [ref=e105]: Ctrl K
        - generic [ref=e106]:
          - button "Switch to the light theme" [ref=e107]:
            - img [ref=e108]
          - generic [ref=e110]:
            - group "Language" [ref=e111]:
              - button "中" [ref=e112]
              - button "EN" [pressed] [ref=e113]
            - generic "Reconnecting" [ref=e114]:
              - generic [ref=e115]: Reconnecting
      - main [ref=e116]:
        - generic [ref=e118]:
          - generic [ref=e119]:
            - generic [ref=e120]:
              - link "Back to work" [ref=e121] [cursor=pointer]:
                - /url: /
              - heading "Planning & Operations" [level=1] [ref=e122]
              - paragraph [ref=e123]: Durable planning, automation, health, and cost observability.
            - button "Refresh" [ref=e124] [cursor=pointer]:
              - generic [ref=e125]: Refresh
          - status [ref=e126]: Loading Operations
          - generic [ref=e127]:
            - generic [ref=e128]: Search loaded Operations records
            - searchbox "Search loaded Operations records" [ref=e129]
            - generic [ref=e130]: Filters only Operations records already loaded in this view. Load more to expand the searchable set.
          - navigation "Operations sections" [ref=e131]:
            - link "Usage and cost" [ref=e132] [cursor=pointer]:
              - /url: "#operations-metrics"
            - link "Cycles" [ref=e133] [cursor=pointer]:
              - /url: "#operations-cycles"
            - link "Initiatives" [ref=e134] [cursor=pointer]:
              - /url: "#operations-initiatives"
            - link "Automation rules" [ref=e135] [cursor=pointer]:
              - /url: "#operations-automation"
            - link "Loops" [ref=e136] [cursor=pointer]:
              - /url: "#operations-loops"
            - link "Recent runs" [ref=e137] [cursor=pointer]:
              - /url: "#operations-runs"
            - link "Templates & playbooks" [ref=e138] [cursor=pointer]:
              - /url: "#operations-templates"
          - region "Usage and cost" [ref=e139]:
            - list "Usage and cost" [ref=e140]:
              - listitem "Tokens" [ref=e141]:
                - generic [ref=e143]:
                  - term [ref=e144]: Tokens
                  - definition [ref=e145]:
                    - strong [ref=e146]: 1,500
              - listitem "Runtime" [ref=e147]:
                - generic [ref=e149]:
                  - term [ref=e150]: Runtime
                  - definition [ref=e151]:
                    - strong [ref=e152]: 45s
              - listitem "Tool calls" [ref=e153]:
                - generic [ref=e155]:
                  - term [ref=e156]: Tool calls
                  - definition [ref=e157]:
                    - strong [ref=e158]: "7"
              - listitem "Unknown cost" [ref=e159]:
                - generic [ref=e161]:
                  - term [ref=e162]: Unknown cost
                  - definition [ref=e163]:
                    - strong [ref=e164]: "0"
                    - text: records
              - listitem "Known cost" [ref=e165]:
                - generic [ref=e167]:
                  - term [ref=e168]: Known cost
                  - definition [ref=e169]: No known cost
          - generic [ref=e170]:
            - generic [ref=e171]:
              - heading "Cycles" [level=2] [ref=e172]
              - status [ref=e173]:
                - generic [ref=e175]:
                  - heading "No Cycles configured" [level=2] [ref=e176]
                  - paragraph [ref=e177]: Create a Cycle when a planning window is ready.
            - generic [ref=e178]:
              - heading "Initiatives" [level=2] [ref=e179]
              - status [ref=e180]:
                - generic [ref=e182]:
                  - heading "No Initiatives configured" [level=2] [ref=e183]
                  - paragraph [ref=e184]: Initiatives will appear here when the feature has durable data.
            - generic [ref=e185]:
              - heading "Automation rules" [level=2] [ref=e186]
              - article [ref=e187]:
                - generic [ref=e188]:
                  - strong [ref=e189]: Retained browser rule
                  - generic [ref=e190]: v1 · manual
                - generic [ref=e191]: Enabled
                - button "Dry run" [active] [ref=e192]
                - button "Pause" [ref=e193]
            - generic [ref=e194]:
              - heading "Loops" [level=2] [ref=e195]
              - status [ref=e196]:
                - generic [ref=e198]:
                  - heading "No Loops configured" [level=2] [ref=e199]
                  - paragraph [ref=e200]: Agent Loops will appear after they are created through an authorized command.
            - generic [ref=e201]:
              - heading "Recent runs" [level=2] [ref=e202]
              - region "Recent runs" [ref=e203]:
                - table "Recent runs" [ref=e204]:
                  - caption [ref=e205]: Recent runs
                  - rowgroup [ref=e213]:
                    - row "Run Kind Status Attempts Session Created" [ref=e214]:
                      - columnheader "Run" [ref=e215]
                      - columnheader "Kind" [ref=e216]
                      - columnheader "Status" [ref=e217]
                      - columnheader "Attempts" [ref=e218]
                      - columnheader "Session" [ref=e219]
                      - columnheader "Created" [ref=e220]
                  - rowgroup
              - status [ref=e221]:
                - generic [ref=e223]:
                  - heading "No run history yet" [level=2] [ref=e224]
                  - paragraph [ref=e225]: Durable run history will appear after an automation or loop executes.
            - generic [ref=e226]:
              - heading "Templates & playbooks" [level=2] [ref=e227]
              - status [ref=e228]:
                - generic [ref=e230]:
                  - heading "No Templates configured" [level=2] [ref=e231]
                  - paragraph [ref=e232]: Templates and playbooks will appear when they are available to this workspace.
```

# Test source

```ts
  643 |     const workflow = settings.locator('[aria-labelledby="workflow-settings-heading"]')
  644 |     await expect(workflow.locator('.skeleton-list')).toBeVisible()
  645 |     await expect(workflow).not.toHaveAttribute('aria-busy')
  646 |     await expect(workflow.locator('[aria-busy="true"]')).toHaveCount(1)
  647 | 
  648 |     const state = { category: 'backlog', color: '#a8a29e', id: 'state-backlog', name: 'Backlog', revision: 1 }
  649 |     const statesResponse = { body: { items: [state], nextCursor: null } } satisfies JsonResponse
  650 |     routes.setRequest('GET', statesPath, statesResponse)
  651 |     statesPending.resolve(statesResponse)
  652 |     const stateRow = workflow.locator('.workflow-state-list article').first()
  653 |     await expect(stateRow).toContainText('Backlog')
  654 | 
  655 |     const stateName = workflow.locator('input[name="name"]')
  656 |     await stateName.fill('Review')
  657 |     await stateName.evaluate(element => { element.dataset.loadingIdentity = 'retained-state-form' })
  658 |     const refreshPending = deferredResponse()
  659 |     const pagedStatesPath = `${statesPath}?limit=100`
  660 |     const priorRequests = routes.requests.filter(request => request === pagedStatesPath).length
  661 |     routes.setRequest('POST', statesPath, { body: { ...state, id: 'state-review', name: 'Review' } })
  662 |     routes.setRequest('GET', pagedStatesPath, refreshPending.promise)
  663 |     await workflow.locator('form').evaluate((form: HTMLFormElement) => form.requestSubmit())
  664 |     await routes.waitFor(pagedStatesPath, priorRequests + 1)
  665 |     await expect(workflow).toHaveAttribute('aria-busy', 'true')
  666 |     await expect(stateRow).toContainText('Backlog')
  667 |     await expect(stateName).toHaveAttribute('data-loading-identity', 'retained-state-form')
  668 |     await expect(stateName).toBeFocused()
  669 | 
  670 |     routes.setRequest('GET', pagedStatesPath, statesResponse)
  671 |     refreshPending.resolve({
  672 |       body: { error: { code: 'TEMPORARY_UNAVAILABLE', correlationId: 'safe-state-refresh', message: 'Please retry.' } },
  673 |       status: 500,
  674 |     })
  675 |     await expect(workflow).not.toHaveAttribute('aria-busy')
  676 |     await expect(stateRow).toContainText('Backlog')
  677 |     await expect(stateName).toHaveAttribute('data-loading-identity', 'retained-state-form')
  678 |     await expect(stateName).toBeFocused()
  679 |     await expect(workflow.locator('[role="status"]')).toHaveCount(0)
  680 |     await expect(page.locator('.settings-page [role="alert"]')).toContainText('Unable to load Settings.')
  681 |     await expect(page.getByRole('button', { name: 'Retry', exact: true })).toBeVisible()
  682 |     await expect(page.getByText('safe-state-refresh')).toHaveCount(0)
  683 |     expect(routes.unexpected).toEqual([])
  684 |   })
  685 | })
  686 | 
  687 | test.describe('Task 6.4 Operations loading authority', () => {
  688 |   test.use({ viewport: { height: 900, width: 1440 } })
  689 | 
  690 |   test('uses real pending owners, resolves independently, and retains focus through refresh failure', async ({ page }) => {
  691 |     const routes = new RouteScenarios()
  692 |     await routes.install(page)
  693 |     await page.context().addCookies([{ name: 'workmesh_locale', value: 'en', url: webUrl }])
  694 | 
  695 |     const featuresPending = deferredResponse()
  696 |     routes.set('/api/v1/features', featuresPending.promise)
  697 |     await page.goto('/operations', { waitUntil: 'domcontentloaded' })
  698 | 
  699 |     const featureStatus = page.getByRole('status', { name: 'Loading Operations' })
  700 |     await expect(featureStatus).toBeVisible()
  701 |     await expect(page.locator('.operations-loading')).not.toHaveAttribute('aria-busy')
  702 |     await expect(page.locator('.operations-loading [aria-busy="true"]')).toHaveCount(1)
  703 | 
  704 |     const pendingCollections = new Map<string, ReturnType<typeof deferredResponse>>()
  705 |     for (const path of Object.keys(collectionPayloads)) {
  706 |       const pending = deferredResponse()
  707 |       pendingCollections.set(path, pending)
  708 |       routes.set(path, pending.promise)
  709 |     }
  710 |     const usagePending = deferredResponse()
  711 |     routes.set('/api/v1/usage-summary', usagePending.promise)
  712 |     routes.set('/api/v1/features', allFeatures)
  713 |     featuresPending.resolve(allFeatures)
  714 | 
  715 |     await expect(page.locator('.operations-usage-loading .skeleton-list')).toBeVisible()
  716 |     await expect(page.locator('.operations-grid .skeleton-list')).toHaveCount(6)
  717 |     await expect(page.locator('.operations-grid section[aria-busy="true"]')).toHaveCount(0)
  718 |     await expect(page.locator('.operations-grid .skeleton-list[aria-busy="true"]')).toHaveCount(6)
  719 | 
  720 |     routes.set('/api/v1/usage-summary', usage)
  721 |     usagePending.resolve(usage)
  722 |     for (const [path, pending] of pendingCollections) {
  723 |       const response = collectionPayloads[path]!
  724 |       routes.set(path, response)
  725 |       pending.resolve(response)
  726 |     }
  727 | 
  728 |     const dryRun = page.getByRole('button', { name: 'Dry run' })
  729 |     await expect(dryRun).toBeVisible()
  730 |     await dryRun.focus()
  731 |     const automation = page.getByTestId('automation-panel')
  732 |     await dryRun.evaluate(element => { element.dataset.loadingIdentity = 'retained-rule-control' })
  733 | 
  734 |     const rulesFailure = deferredResponse()
  735 |     routes.set('/api/v1/automation-rules', rulesFailure.promise)
  736 |     const rulesPath = '/api/v1/automation-rules?limit=100'
  737 |     const priorRuleRequests = routes.requests.filter(request => request === rulesPath).length
  738 |     await page.getByRole('button', { name: 'Refresh' }).evaluate((button: HTMLButtonElement) => button.click())
  739 |     await routes.waitFor(rulesPath, priorRuleRequests + 1)
  740 |     await expect(automation).toHaveAttribute('aria-busy', 'true')
  741 |     await expect(dryRun).toHaveAttribute('data-loading-identity', 'retained-rule-control')
  742 |     await expect(dryRun).toBeFocused()
> 743 |     await expect(page.locator('.operations-tab > .sr-only[role="status"]')).toHaveCount(1)
      |                                                                             ^ Error: expect(locator).toHaveCount(expected) failed
  744 | 
  745 |     routes.set('/api/v1/automation-rules', collectionPayloads['/api/v1/automation-rules']!)
  746 |     rulesFailure.resolve({
  747 |       body: { error: { code: 'TEMPORARY_UNAVAILABLE', correlationId: 'safe-browser-diagnostic', message: 'Please retry.' } },
  748 |       status: 500,
  749 |     })
  750 |     await expect(automation).not.toHaveAttribute('aria-busy')
  751 |     await expect(dryRun).toHaveAttribute('data-loading-identity', 'retained-rule-control')
  752 |     await expect(dryRun).toBeFocused()
  753 |     await expect(page.getByText('Retained browser rule')).toBeVisible()
  754 |     await expect(automation.getByText('Unable to load Operations.')).toBeVisible()
  755 |     await expect(page.locator('.operations-tab > .sr-only[role="status"]')).toHaveCount(0)
  756 |     expect(routes.unexpected).toEqual([])
  757 |   })
  758 | })
  759 | 
  760 | const loadingViewports = [
  761 |   { height: 844, width: 390 },
  762 |   { height: 900, width: 1440 },
  763 |   { height: 1080, width: 1920 },
  764 | ] as const
  765 | 
  766 | for (const viewport of loadingViewports) {
  767 |   test.describe(`Task 6.4 loading geometry at ${viewport.width}px`, () => {
  768 |     test.use({ viewport })
  769 | 
  770 |     test('fills real Operations, Settings and Board panels without a narrow skeleton island', async ({ page }, testInfo) => {
  771 |       const routes = new RouteScenarios()
  772 |       await routes.install(page)
  773 |       await page.context().addCookies([{ name: 'workmesh_locale', value: 'en', url: webUrl }])
  774 |       await mkdir(evidenceRoot, { recursive: true })
  775 | 
  776 |       const featuresPending = deferredResponse()
  777 |       const usageGeometryPending = deferredResponse()
  778 |       routes.set('/api/v1/features', featuresPending.promise)
  779 |       routes.set('/api/v1/usage-summary', usageGeometryPending.promise)
  780 |       for (const [path, response] of Object.entries(collectionPayloads)) routes.set(path, response)
  781 |       await page.goto('/operations', { waitUntil: 'domcontentloaded' })
  782 |       const operationsHeader = page.locator('.operations-tab > .operations-header')
  783 |       await expect(operationsHeader).toBeVisible()
  784 |       await operationsHeader.evaluate(element => { element.dataset.loadingIdentity = 'stable-operations-header' })
  785 |       const operationsHeaderPending = (await measureRects(page, '.operations-tab > .operations-header'))[0]!
  786 |       const operationsPending = await measureSkeleton(page, '.operations-loading .skeleton-list', { panelSelector: '.operations-tab' })
  787 |       expectContainedSkeleton(operationsPending, viewport.width <= 960 ? 1 : 2)
  788 |       expect(operationsPending.busyOwners).toBe(1)
  789 |       await page.screenshot({ path: join(evidenceRoot, `loading-operations-pending-${viewport.width}x${viewport.height}.png`) })
  790 | 
  791 |       routes.set('/api/v1/features', allFeatures)
  792 |       featuresPending.resolve(allFeatures)
  793 |       await expect(page.locator('.operations-usage-loading .skeleton-list')).toBeVisible()
  794 |       await expect(page.locator('.operations-grid > .operations-panel')).toHaveCount(6)
  795 |       const usagePending = await measureSkeleton(page, '.operations-usage-loading .skeleton-list', { panelSelector: '.operations-metrics' })
  796 |       // Task 6.5 supersedes the original 1920px five-column snapshot: keeping
  797 |       // the metrics root at 85% of the workspace yields four readable columns
  798 |       // and two rows without changing the loading owner or pending/resolved seam.
  799 |       const expectedUsageColumns = viewport.width <= 560 ? 1 : viewport.width >= 1440 ? 4 : 5
  800 |       expectContainedSkeleton(usagePending, expectedUsageColumns)
  801 |       expect(usagePending.cells).toHaveLength(5)
  802 |       expect(usagePending.focusableCount).toBe(0)
  803 |       expect(usagePending.document.overflow).toBe(0)
  804 |       if (viewport.width === 1920) {
  805 |         expect(usagePending.root.width / usagePending.main.width).toBeGreaterThanOrEqual(.85)
  806 |         expect(new Set(usagePending.cells.map(cell => Math.round(cell.top))).size).toBe(2)
  807 |       }
  808 |       routes.set('/api/v1/usage-summary', usage)
  809 |       usageGeometryPending.resolve(usage)
  810 |       await expect(page.locator('.operations-metrics-grid > .operations-metric-card')).toHaveCount(5)
  811 |       const usageResolved = await measureResolvedGrid(page, '.operations-metrics-grid', ':scope > .operations-metric-card')
  812 |       expect(usageResolved.columns).toBe(usagePending.columns)
  813 |       expect(usageResolved.document.overflow).toBe(0)
  814 |       expect(Math.abs(usageResolved.root.width - usagePending.root.width)).toBeLessThanOrEqual(2)
  815 |       usageResolved.items.forEach((card, index) => expect(Math.abs(card.width - usagePending.cells[index]!.width)).toBeLessThanOrEqual(2))
  816 |       if (viewport.width === 1920)
  817 |         expect(new Set(usageResolved.items.map(card => Math.round(card.top))).size).toBe(2)
  818 |       const operationsResolved = await measureRects(page, '.operations-grid > .operations-panel')
  819 |       const operationsContainment = await measureResolvedContainment(page)
  820 |       const operationsHeaderResolved = (await measureRects(page, '.operations-tab > .operations-header'))[0]!
  821 |       expect(operationsContainment.document.overflow).toBe(0)
  822 |       await expect(operationsHeader).toHaveAttribute('data-loading-identity', 'stable-operations-header')
  823 |       expect(Math.abs(operationsHeaderPending.top - operationsHeaderResolved.top)).toBeLessThanOrEqual(2)
  824 |       expect(Math.abs(operationsPending.cells[0]!.width - operationsResolved[0]!.width)).toBeLessThanOrEqual(2)
  825 |       expect(Math.abs(operationsPending.cells[1]!.width - operationsResolved[1]!.width)).toBeLessThanOrEqual(2)
  826 |       expect(Math.abs(operationsPending.cells[2]!.width - operationsResolved[2]!.width)).toBeLessThanOrEqual(2)
  827 |       await persistEvidence(page, testInfo, `loading-operations-geometry-${viewport.width}x${viewport.height}`, {
  828 |         header: { pending: operationsHeaderPending, resolved: operationsHeaderResolved },
  829 |         pending: operationsPending,
  830 |         resolvedContainment: operationsContainment,
  831 |         resolvedPanels: operationsResolved,
  832 |         usage: { pending: usagePending, resolved: usageResolved },
  833 |       })
  834 | 
  835 |       const teamsPending = deferredResponse()
  836 |       const statesGeometryPending = deferredResponse()
  837 |       const statesPath = `/api/v1/teams/${team.id}/states`
  838 |       routes.setRequest('GET', '/api/v1/teams', teamsPending.promise)
  839 |       routes.setRequest('GET', statesPath, statesGeometryPending.promise)
  840 |       await page.goto('/settings?tab=workspace', { waitUntil: 'domcontentloaded' })
  841 |       const settingsHeader = page.locator('.settings-page > header').first()
  842 |       await settingsHeader.evaluate(element => { element.dataset.loadingIdentity = 'stable-settings-header' })
  843 |       const settingsHeaderPending = (await measureRects(page, '.settings-page > header'))[0]!
```