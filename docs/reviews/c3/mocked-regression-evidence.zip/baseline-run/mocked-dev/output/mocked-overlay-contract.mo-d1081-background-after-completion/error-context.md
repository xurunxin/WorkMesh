# Instructions

- Following Playwright test failed.
- Explain why, be concise, respect Playwright best practices.
- Provide a snippet of code with the fix, if possible.

# Test info

- Name: mocked\overlay-contract.mocked.spec.ts >> overlay contract at 1920x1080 >> keeps busy delete nondismissible and restores the exact background after completion
- Location: e2e\mocked\overlay-contract.mocked.spec.ts:423:5

# Error details

```
Error: expect(received).toBeGreaterThan(expected)

Expected: > 0
Received:   0
```

# Page snapshot

```yaml
- generic [active] [ref=e1]:
  - button "Open Next.js Dev Tools" [ref=e7] [cursor=pointer]:
    - img [ref=e8]
  - alert [ref=e11]
  - generic [ref=e12]:
    - link "跳到主要内容" [ref=e13] [cursor=pointer]:
      - /url: "#workmesh-main"
    - complementary "主导航" [ref=e14]:
      - generic [ref=e15]:
        - strong [ref=e17]: WorkMesh
        - generic [ref=e18]: Alex Morgan
      - button "收起导航栏" [expanded] [ref=e19] [cursor=pointer]:
        - img [ref=e20]
        - generic [ref=e22]: 收起导航栏
      - generic [ref=e24]:
        - text: 团队
        - combobox "当前团队" [ref=e25]:
          - option "无团队" [disabled]
          - option "Runtime Reliability (RUN)" [selected]
          - option "Platform (PLAT)"
      - navigation "工作区导航" [ref=e26]:
        - link "返回 Issues" [ref=e27] [cursor=pointer]:
          - /url: /?view=my-work
          - img [ref=e29]
          - generic [ref=e31]: 返回 Issues
      - navigation "管理导航" [ref=e32]:
        - link "设置" [ref=e33] [cursor=pointer]:
          - /url: /settings
          - img [ref=e35]
          - generic [ref=e37]: 设置
      - generic [ref=e39]:
        - button "退出登录" [ref=e40] [cursor=pointer]:
          - img [ref=e42]
          - generic [ref=e44]: 退出登录
        - generic [ref=e45]: v1.0.0 · 构建 project-work-preview · 数据库架构 24
    - generic [ref=e46]:
      - banner [ref=e47]:
        - paragraph [ref=e48]:
          - generic [ref=e49]: 工作区
        - button "搜索" [ref=e51] [cursor=pointer]:
          - img [ref=e53]
          - generic [ref=e55]:
            - generic [ref=e56]: 搜索
            - generic [ref=e57]: Ctrl K
        - generic [ref=e58]:
          - button "切换到浅色主题" [ref=e59]:
            - img [ref=e60]
          - group "语言" [ref=e63]:
            - button "中" [pressed] [ref=e64]
            - button "EN" [ref=e65]
      - main [ref=e66]:
        - generic [ref=e67]:
          - generic [ref=e69]:
            - heading "设置" [level=1] [ref=e70]
            - paragraph [ref=e71]: 工作区管理与日常规划保持分离。
          - generic [ref=e72]:
            - tablist "设置分区" [ref=e73]:
              - tab "工作区" [selected] [ref=e74]:
                - generic [ref=e75]: 工作区
            - tabpanel "工作区" [ref=e76]:
              - generic [ref=e77]:
                - region "团队" [ref=e78]:
                  - paragraph [ref=e79]: 工作区结构
                  - heading "团队" [level=2] [ref=e80]
                  - generic [ref=e81]:
                    - generic [ref=e82]:
                      - text: 团队名称
                      - textbox "团队名称" [ref=e83]
                    - generic [ref=e84]:
                      - text: 团队标识
                      - textbox "团队标识" [ref=e85]:
                        - /placeholder: ENG
                    - button "新建团队" [ref=e86] [cursor=pointer]:
                      - img [ref=e88]
                      - generic [ref=e90]: 新建团队
                - region "团队详情" [ref=e91]:
                  - paragraph [ref=e92]: 已选团队
                  - heading "团队详情" [level=2] [ref=e93]
                  - generic [ref=e94]:
                    - generic [ref=e95]:
                      - text: 团队名称
                      - textbox "团队名称" [ref=e96]: Runtime Reliability
                    - generic [ref=e97]:
                      - text: 团队标识
                      - textbox "团队标识" [ref=e98]: RUN
                    - button "保存更改" [ref=e99] [cursor=pointer]:
                      - img [ref=e101]
                      - generic [ref=e103]: 保存更改
                  - generic [ref=e104]:
                    - generic [ref=e105]:
                      - strong [ref=e106]: 删除团队
                      - paragraph [ref=e107]: 从活动导航中移除此团队；关联工作将保留，但不可用。
                    - button "删除团队" [ref=e108] [cursor=pointer]:
                      - img [ref=e110]
                      - generic [ref=e112]: 删除团队
                - region "工作流状态" [ref=e113]:
                  - paragraph [ref=e114]: 团队工作流
                  - heading "工作流状态" [level=2] [ref=e115]
                  - article [ref=e117]:
                    - generic [ref=e120]:
                      - strong [ref=e121]: Ready
                      - generic [ref=e122]: 已规划
                    - button "编辑状态 Ready" [ref=e123] [cursor=pointer]:
                      - img [ref=e125]
                      - generic [ref=e127]: 编辑
                  - generic [ref=e128]:
                    - generic [ref=e129]:
                      - text: 状态名称
                      - textbox "状态名称" [ref=e130]
                    - generic [ref=e131]:
                      - text: 分类
                      - combobox "分类" [ref=e132]:
                        - option "待办"
                        - option "已规划" [selected]
                        - option "进行中"
                        - option "已完成"
                        - option "已取消"
                    - group "状态颜色" [ref=e133]:
                      - generic [ref=e134]: 状态颜色
                      - generic [ref=e135]:
                        - generic [ref=e136] [cursor=pointer]:
                          - radio "中性" [checked] [ref=e137]
                          - generic [ref=e139]: 中性
                        - generic [ref=e140] [cursor=pointer]:
                          - radio "蓝色" [ref=e141]
                          - generic [ref=e143]: 蓝色
                        - generic [ref=e144] [cursor=pointer]:
                          - radio "绿色" [ref=e145]
                          - generic [ref=e147]: 绿色
                        - generic [ref=e148] [cursor=pointer]:
                          - radio "琥珀色" [ref=e149]
                          - generic [ref=e151]: 琥珀色
                        - generic [ref=e152] [cursor=pointer]:
                          - radio "红色" [ref=e153]
                          - generic [ref=e155]: 红色
                        - generic [ref=e156] [cursor=pointer]:
                          - radio "自定义" [ref=e157]
                          - generic [ref=e159]: 自定义
                    - button "新建状态" [ref=e160] [cursor=pointer]:
                      - img [ref=e162]
                      - generic [ref=e164]: 新建状态
              - region "模型服务接入" [ref=e165]:
                - paragraph [ref=e166]: Agent workbench
                - heading "模型服务接入" [level=2] [ref=e167]
                - paragraph [ref=e168]: 管理 Chat Completions 与 Responses 模型服务、凭据和模型目录。
                - link "打开接入设置" [ref=e169] [cursor=pointer]:
                  - /url: /settings/agent-workbench
```

# Test source

```ts
  68  |   bodyStyle: string | null
  69  |   htmlStyle: string | null
  70  |   main: Rect
  71  |   scrollX: number
  72  |   scrollY: number
  73  | }
  74  | 
  75  | function deferred(): { promise: Promise<void>; resolve: () => void } {
  76  |   let resolve: () => void = () => undefined
  77  |   const promise = new Promise<void>(done => { resolve = done })
  78  |   return { promise, resolve }
  79  | }
  80  | 
  81  | async function fulfillJson(route: Parameters<Parameters<Page['route']>[1]>[0], payload: unknown): Promise<void> {
  82  |   await route.fulfill({ status: 200, headers: responseHeaders, body: JSON.stringify(payload) })
  83  | }
  84  | 
  85  | async function installAgentFixtures(page: Page, requests: string[]): Promise<void> {
  86  |   await page.route(`${apiUrl}/api/v1/**`, async route => {
  87  |     const request = route.request()
  88  |     const url = new URL(request.url())
  89  |     requests.push(`${request.method()} ${url.pathname}`)
  90  |     if (request.method() === 'OPTIONS') return route.fulfill({ status: 204, headers: responseHeaders, body: '' })
  91  |     if (url.pathname === '/api/v1/features') return fulfillJson(route, {
  92  |       features: canonicalFeatures.map(key => ({ key, tier: key.includes('EXPERIMENTAL') ? 'experimental' : 'beta', enabled: key === 'WORKMESH_BETA_PLANNING' || key === 'WORKMESH_BETA_OPERATIONS_UI' })),
  93  |     })
  94  |     if (url.pathname === '/api/v1/agents') return fulfillJson(route, { items: [agent], nextCursor: null })
  95  |     if (url.pathname === '/api/v1/teams') return fulfillJson(route, { items: teams, nextCursor: null })
  96  |     if (url.pathname === '/api/v1/agent-sessions' || url.pathname === '/api/v1/actors/humans')
  97  |       return fulfillJson(route, { items: [], nextCursor: null })
  98  |     if (url.pathname === '/api/v1/approvals') return fulfillJson(route, { items: [], nextCursor: null })
  99  |     await route.continue()
  100 |   })
  101 | }
  102 | 
  103 | async function installSettingsFixtures(page: Page, requests: string[]) {
  104 |   const deletion = deferred()
  105 |   const target = { id: 'team/delete-overlay', name: 'Runtime Reliability', key: 'RUN', revision: 11 }
  106 |   const survivor = { id: 'team-survivor', name: 'Platform', key: 'PLAT', revision: 4 }
  107 |   let deleted = false
  108 |   let deleteCount = 0
  109 |   await page.route(`${apiUrl}/api/v1/**`, async route => {
  110 |     const request = route.request()
  111 |     const url = new URL(request.url())
  112 |     requests.push(`${request.method()} ${url.pathname}`)
  113 |     if (request.method() === 'OPTIONS') return route.fulfill({ status: 204, headers: responseHeaders, body: '' })
  114 |     if (url.pathname === '/api/v1/features') return fulfillJson(route, {
  115 |       features: canonicalFeatures.map(key => ({ key, tier: key.includes('EXPERIMENTAL') ? 'experimental' : 'beta', enabled: true })),
  116 |     })
  117 |     if (request.method() === 'DELETE' && url.pathname === '/api/v1/teams/team%2Fdelete-overlay') {
  118 |       deleteCount += 1
  119 |       await deletion.promise
  120 |       deleted = true
  121 |       return route.fulfill({ status: 204, headers: responseHeaders, body: '' })
  122 |     }
  123 |     if (url.pathname === '/api/v1/teams') return fulfillJson(route, {
  124 |       items: deleted ? [survivor] : [target, survivor],
  125 |       nextCursor: null,
  126 |     })
  127 |     const stateMatch = url.pathname.match(/^\/api\/v1\/teams\/([^/]+)\/states$/)
  128 |     if (stateMatch) return fulfillJson(route, {
  129 |       items: [{ id: `state-${decodeURIComponent(stateMatch[1]!)}`, name: 'Ready', category: 'planned', color: '#64748b', revision: 1 }],
  130 |       nextCursor: null,
  131 |     })
  132 |     await route.continue()
  133 |   })
  134 |   return {
  135 |     deleteCount: () => deleteCount,
  136 |     release: deletion.resolve,
  137 |     survivor,
  138 |     target,
  139 |   }
  140 | }
  141 | 
  142 | async function prepareScrollableBackground(page: Page): Promise<BackgroundSnapshot> {
  143 |   await page.evaluate(async () => {
  144 |     document.documentElement.style.setProperty('--task-6-2-html-preserved', '1')
  145 |     document.body.style.setProperty('--task-6-2-body-preserved', '1')
  146 |     const spacer = document.createElement('div')
  147 |     spacer.dataset.task62Spacer = 'true'
  148 |     spacer.style.height = '1800px'
  149 |     spacer.style.pointerEvents = 'none'
  150 |     spacer.style.width = '1px'
  151 |     document.body.append(spacer)
  152 |     await new Promise<void>(resolve => requestAnimationFrame(() => resolve()))
  153 |     window.scrollTo(0, 180)
  154 |     await new Promise<void>(resolve => requestAnimationFrame(() => resolve()))
  155 |   })
  156 |   const snapshot = await page.evaluate(() => {
  157 |     const main = document.querySelector<HTMLElement>('#workmesh-main')
  158 |     if (!main) throw new Error('Main landmark missing')
  159 |     const rect = main.getBoundingClientRect()
  160 |     return {
  161 |       bodyStyle: document.body.getAttribute('style'),
  162 |       htmlStyle: document.documentElement.getAttribute('style'),
  163 |       main: { bottom: rect.bottom, height: rect.height, left: rect.left, right: rect.right, top: rect.top, width: rect.width },
  164 |       scrollX: window.scrollX,
  165 |       scrollY: window.scrollY,
  166 |     }
  167 |   })
> 168 |   expect(snapshot.scrollY).toBeGreaterThan(0)
      |                            ^ Error: expect(received).toBeGreaterThan(expected)
  169 |   return snapshot
  170 | }
  171 | 
  172 | async function assertBackgroundRestored(page: Page, snapshot: BackgroundSnapshot): Promise<void> {
  173 |   await expect.poll(() => page.evaluate(() => window.scrollY)).toBe(snapshot.scrollY)
  174 |   const restored = await page.evaluate(() => ({
  175 |     bodyStyle: document.body.getAttribute('style'),
  176 |     htmlStyle: document.documentElement.getAttribute('style'),
  177 |     scrollX: window.scrollX,
  178 |   }))
  179 |   expect(restored).toEqual({ bodyStyle: snapshot.bodyStyle, htmlStyle: snapshot.htmlStyle, scrollX: snapshot.scrollX })
  180 | }
  181 | 
  182 | async function expectValidPostDeleteFocus(page: Page): Promise<{
  183 |   connected: boolean
  184 |   identity: string
  185 |   visible: boolean
  186 | }> {
  187 |   await expect.poll(() => page.evaluate(() => {
  188 |     const active = document.activeElement
  189 |     if (!(active instanceof HTMLElement)) return false
  190 |     return active.matches('.app-team-switcher select, #team-settings-heading, #workmesh-main')
  191 |   })).toBe(true)
  192 | 
  193 |   const evidence = await page.evaluate(() => {
  194 |     const active = document.activeElement
  195 |     if (!(active instanceof HTMLElement)) throw new Error('Post-delete focus is not an HTML element')
  196 |     const rect = active.getBoundingClientRect()
  197 |     const style = window.getComputedStyle(active)
  198 |     return {
  199 |       connected: active.isConnected,
  200 |       identity: active.id ? `#${active.id}` : `${active.tagName.toLowerCase()}${active.className ? `.${String(active.className).trim().replace(/\s+/g, '.')}` : ''}`,
  201 |       visible: style.display !== 'none'
  202 |         && style.visibility !== 'hidden'
  203 |         && active.getClientRects().length > 0
  204 |         && rect.width > 0
  205 |         && rect.height > 0,
  206 |     }
  207 |   })
  208 |   expect(evidence.connected).toBe(true)
  209 |   expect(evidence.visible).toBe(true)
  210 |   expect(evidence.identity).not.toBe('body')
  211 |   return evidence
  212 | }
  213 | 
  214 | async function measureOverlay(dialog: Locator, before: BackgroundSnapshot) {
  215 |   return dialog.evaluate((element, snapshot) => {
  216 |     if (!(element instanceof HTMLElement)) throw new Error('Overlay root missing')
  217 |     const main = document.querySelector<HTMLElement>('#workmesh-main')
  218 |     if (!main) throw new Error('Main landmark missing')
  219 |     const toRect = (target: HTMLElement) => {
  220 |       const rect = target.getBoundingClientRect()
  221 |       return { bottom: rect.bottom, height: rect.height, left: rect.left, right: rect.right, top: rect.top, width: rect.width }
  222 |     }
  223 |     const rect = toRect(element)
  224 |     const mainRect = toRect(main)
  225 |     return {
  226 |       activeInside: element.contains(document.activeElement),
  227 |       bodyPosition: document.body.style.position,
  228 |       bodyTop: document.body.style.top,
  229 |       centerDelta: Math.abs(rect.left - (window.innerWidth - rect.right)),
  230 |       dialog: rect,
  231 |       document: { clientWidth: document.documentElement.clientWidth, scrollWidth: document.documentElement.scrollWidth },
  232 |       htmlOverflow: document.documentElement.style.overflow,
  233 |       inertCount: document.querySelectorAll('[inert]').length,
  234 |       internalScroll: { clientHeight: element.clientHeight, scrollHeight: element.scrollHeight, scrollTop: element.scrollTop },
  235 |       main: mainRect,
  236 |       mainShift: { left: Math.abs(mainRect.left - snapshot.main.left), width: Math.abs(mainRect.width - snapshot.main.width) },
  237 |       scroll: { x: window.scrollX, y: window.scrollY },
  238 |       viewport: { height: window.innerHeight, width: window.innerWidth },
  239 |     }
  240 |   }, before)
  241 | }
  242 | 
  243 | function expectContained(evidence: Awaited<ReturnType<typeof measureOverlay>>, maxWidth: number): void {
  244 |   expect(evidence.dialog.width).toBeLessThanOrEqual(maxWidth + 0.5)
  245 |   expect(evidence.dialog.left).toBeGreaterThanOrEqual(-0.5)
  246 |   expect(evidence.dialog.top).toBeGreaterThanOrEqual(-0.5)
  247 |   expect(evidence.dialog.right).toBeLessThanOrEqual(evidence.viewport.width + 0.5)
  248 |   expect(evidence.dialog.bottom).toBeLessThanOrEqual(evidence.viewport.height + 0.5)
  249 |   expect(evidence.document.scrollWidth).toBe(evidence.document.clientWidth)
  250 |   expect(evidence.mainShift.left).toBeLessThanOrEqual(1)
  251 |   expect(evidence.mainShift.width).toBeLessThanOrEqual(1)
  252 |   expect(evidence.bodyPosition).toBe('fixed')
  253 |   expect(evidence.htmlOverflow).toBe('hidden')
  254 |   expect(evidence.inertCount).toBeGreaterThan(0)
  255 |   expect(evidence.activeInside).toBe(true)
  256 | }
  257 | 
  258 | async function persistEvidence(page: Page, testInfo: TestInfo, name: string, payload: unknown): Promise<void> {
  259 |   await mkdir(evidenceRoot, { recursive: true })
  260 |   await page.evaluate(() => { document.querySelectorAll('nextjs-portal').forEach(element => element.remove()) })
  261 |   const jsonPath = join(evidenceRoot, `${name}.json`)
  262 |   const screenshotPath = join(evidenceRoot, `${name}.png`)
  263 |   await writeFile(jsonPath, JSON.stringify(payload, null, 2), 'utf8')
  264 |   await page.screenshot({ path: screenshotPath })
  265 |   await testInfo.attach(name, { path: jsonPath, contentType: 'application/json' })
  266 |   await testInfo.attach(`${name}-screenshot`, { path: screenshotPath, contentType: 'image/png' })
  267 | }
  268 | 
```