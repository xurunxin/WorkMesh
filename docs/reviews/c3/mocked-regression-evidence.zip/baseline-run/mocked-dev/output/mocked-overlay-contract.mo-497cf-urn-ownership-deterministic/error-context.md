# Instructions

- Following Playwright test failed.
- Explain why, be concise, respect Playwright best practices.
- Provide a snippet of code with the fix, if possible.

# Test info

- Name: mocked\overlay-contract.mocked.spec.ts >> overlay contract at 1920x1080 >> keeps Agent Peek and Team Access focus, scroll, containment, and return ownership deterministic
- Location: e2e\mocked\overlay-contract.mocked.spec.ts:327:5

# Error details

```
Error: expect(locator).toBeVisible() failed

Locator: locator('[data-agent-roving-link="true"]').first()
Expected: visible
Timeout: 10000ms
Error: element(s) not found

Call log:
  - Expect "toBeVisible" with timeout 10000ms
  - waiting for locator('[data-agent-roving-link="true"]').first()

```

```yaml
- alert
- link "跳到主要内容":
  - /url: "#workmesh-main"
- complementary "主导航":
  - strong: WorkMesh
  - text: Alex Morgan
  - button "收起导航栏" [expanded]
  - navigation "工作区导航":
    - paragraph: 工作台
    - link "工作台":
      - /url: /workbench
    - link "我的工作":
      - /url: /?view=home
    - link "Issues":
      - /url: /?view=my-work
    - link "指南":
      - /url: /?view=guidance
    - paragraph: 治理
    - link "需要我处理":
      - /url: /?view=inbox
    - link "Session":
      - /url: /?view=sessions
    - link "恢复中心":
      - /url: /?view=recovery
    - link "项目":
      - /url: /?view=projects
    - link "智能体":
      - /url: /agents
    - paragraph: 运营
    - link "运营":
      - /url: /operations
  - navigation "管理导航":
    - link "设置":
      - /url: /settings
  - button "退出登录"
  - text: v1.0.0 · 构建 project-work-preview · 数据库架构 24
- banner:
  - paragraph: 人类控制面
  - button "搜索": 搜索 Ctrl K
  - button "切换到浅色主题"
  - group "语言":
    - button "中" [pressed]
    - button "EN"
  - text: 正在重新连接
- main:
  - paragraph: 人类控制面
  - heading "智能体" [level=1]
  - paragraph: 监控委派工作、处理审批，并在不接触凭据的情况下诊断连接。
  - button "刷新"
  - alert:
    - heading "智能体工作区需要关注" [level=2]
    - paragraph: "[ { \"code\": \"invalid_type\", \"expected\": \"string\", \"received\": \"undefined\", \"path\": [ \"icon\" ], \"message\": \"Required\" }, { \"code\": \"invalid_type\", \"expected\": \"string\", \"received\": \"undefined\", \"path\": [ \"endpoint_url\" ], \"message\": \"Required\" }, { \"received\": \"agent:session:start\", \"code\": \"invalid_enum_value\", \"options\": [ \"work:read\", \"work:write\", \"comment:write\", \"plan:write\", \"message:write\", \"artifact:write\", \"repo:read\", \"repo:write_branch\", \"repo:open_pr\", \"repo:merge\", \"ci:run\", \"deploy:staging\", \"deploy:production\", \"secrets:use\", \"automation:manage\", \"admin:*\", \"agent:delegate\" ], \"path\": [ \"requested_capabilities\", 2 ], \"message\": \"Invalid enum value. Expected 'work:read' | 'work:write' | 'comment:write' | 'plan:write' | 'message:write' | 'artifact:write' | 'repo:read' | 'repo:write_branch' | 'repo:open_pr' | 'repo:merge' | 'ci:run' | 'deploy:staging' | 'deploy:production' | 'secrets:use' | 'automation:manage' | 'admin:*' | 'agent:delegate', received 'agent:session:start'\" }, { \"code\": \"invalid_type\", \"expected\": \"array\", \"received\": \"undefined\", \"path\": [ \"output_artifact_types\" ], \"message\": \"Required\" }, { \"code\": \"invalid_type\", \"expected\": \"object\", \"received\": \"undefined\", \"path\": [ \"metadata\" ], \"message\": \"Required\" }, { \"expected\": \"'active' | 'archived'\", \"received\": \"undefined\", \"code\": \"invalid_type\", \"path\": [ \"lifecycle_status\" ], \"message\": \"Required\" }, { \"code\": \"invalid_type\", \"expected\": \"string\", \"received\": \"undefined\", \"path\": [ \"archived_at\" ], \"message\": \"Required\" }, { \"code\": \"invalid_type\", \"expected\": \"string\", \"received\": \"undefined\", \"path\": [ \"archived_by_actor_id\" ], \"message\": \"Required\" }, { \"code\": \"invalid_type\", \"expected\": \"string\", \"received\": \"undefined\", \"path\": [ \"archived_reason\" ], \"message\": \"Required\" }, { \"code\": \"invalid_type\", \"expected\": \"string\", \"received\": \"undefined\", \"path\": [ \"created_at\" ], \"message\": \"Required\" }, { \"code\": \"invalid_type\", \"expected\": \"string\", \"received\": \"undefined\", \"path\": [ \"updated_at\" ], \"message\": \"Required\" } ]"
    - button "重试"
  - tablist "智能体工作区分区":
    - tab "智能体" [selected]
    - tab "连接"
    - tab "自动接入策略"
    - tab "已归档"
  - tabpanel "智能体":
    - region "注册表":
      - paragraph: 注册表
      - heading "智能体" [level=2]
      - paragraph: 先检查定义；仅在需要审阅时展开团队权限。
      - button "全部"
      - button "活跃"
      - button "停用"
      - group "智能体筛选":
        - text: 名称
        - searchbox "名称"
        - text: 团队
        - combobox "团队":
          - option "全部团队" [selected]
          - option "Runtime Reliability"
          - option "Acceptance Team 2"
          - option "Acceptance Team 3"
          - option "Acceptance Team 4"
          - option "Acceptance Team 5"
          - option "Acceptance Team 6"
          - option "Acceptance Team 7"
          - option "Acceptance Team 8"
          - option "Acceptance Team 9"
          - option "Acceptance Team 10"
          - option "Acceptance Team 11"
          - option "Acceptance Team 12"
          - option "Acceptance Team 13"
          - option "Acceptance Team 14"
        - text: 能力
        - combobox "能力":
          - option "全部能力" [selected]
        - text: 状态
        - combobox "状态":
          - option "全部" [selected]
          - option "活跃"
          - option "停用"
```

# Test source

```ts
  232 |       htmlOverflow: document.documentElement.style.overflow,
  233 |       inertCount: document.querySelectorAll('[inert]').length,
  234 |       internalScroll: { clientHeight: element.clientHeight, scrollHeight: element.scrollHeight, scrollTop: element.scrollTop },
  235 |       main: mainRect,
  236 |       mainShift: { left: Math.abs(mainRect.left - snapshot.main.left), width: Math.abs(mainRect.width - snapshot.main.width) },
  237 |       scroll: { x: window.scrollX, y: window.scrollY },
  238 |       viewport: { height: window.innerHeight, width: window.innerWidth },
  239 |     }
  240 |   }, before)
  241 | }
  242 | 
  243 | function expectContained(evidence: Awaited<ReturnType<typeof measureOverlay>>, maxWidth: number): void {
  244 |   expect(evidence.dialog.width).toBeLessThanOrEqual(maxWidth + 0.5)
  245 |   expect(evidence.dialog.left).toBeGreaterThanOrEqual(-0.5)
  246 |   expect(evidence.dialog.top).toBeGreaterThanOrEqual(-0.5)
  247 |   expect(evidence.dialog.right).toBeLessThanOrEqual(evidence.viewport.width + 0.5)
  248 |   expect(evidence.dialog.bottom).toBeLessThanOrEqual(evidence.viewport.height + 0.5)
  249 |   expect(evidence.document.scrollWidth).toBe(evidence.document.clientWidth)
  250 |   expect(evidence.mainShift.left).toBeLessThanOrEqual(1)
  251 |   expect(evidence.mainShift.width).toBeLessThanOrEqual(1)
  252 |   expect(evidence.bodyPosition).toBe('fixed')
  253 |   expect(evidence.htmlOverflow).toBe('hidden')
  254 |   expect(evidence.inertCount).toBeGreaterThan(0)
  255 |   expect(evidence.activeInside).toBe(true)
  256 | }
  257 | 
  258 | async function persistEvidence(page: Page, testInfo: TestInfo, name: string, payload: unknown): Promise<void> {
  259 |   await mkdir(evidenceRoot, { recursive: true })
  260 |   await page.evaluate(() => { document.querySelectorAll('nextjs-portal').forEach(element => element.remove()) })
  261 |   const jsonPath = join(evidenceRoot, `${name}.json`)
  262 |   const screenshotPath = join(evidenceRoot, `${name}.png`)
  263 |   await writeFile(jsonPath, JSON.stringify(payload, null, 2), 'utf8')
  264 |   await page.screenshot({ path: screenshotPath })
  265 |   await testInfo.attach(name, { path: jsonPath, contentType: 'application/json' })
  266 |   await testInfo.attach(`${name}-screenshot`, { path: screenshotPath, contentType: 'image/png' })
  267 | }
  268 | 
  269 | async function rejectBackgroundFocus(dialog: Locator) {
  270 |   return dialog.evaluate(element => {
  271 |     const candidates = [...document.querySelectorAll<HTMLElement>('a, button, input, select, textarea, [tabindex]')]
  272 |       .filter(candidate => candidate.isConnected && !element.contains(candidate))
  273 |     const background = candidates.find(candidate => candidate.closest('[inert]'))
  274 |     if (!background) throw new Error('Background focus target missing')
  275 |     const inertAncestor = background.closest<HTMLElement>('[inert]')
  276 |     background.focus()
  277 |     background.dispatchEvent(new FocusEvent('focusin', { bubbles: true }))
  278 |     return {
  279 |       activeInside: element.contains(document.activeElement),
  280 |       inertAncestor: Boolean(inertAncestor),
  281 |       target: {
  282 |         ariaLabel: background.getAttribute('aria-label'),
  283 |         className: background.className,
  284 |         id: background.id,
  285 |         tagName: background.tagName,
  286 |       },
  287 |     }
  288 |   })
  289 | }
  290 | 
  291 | async function assertBackgroundWheelLocked(page: Page, dialog: Locator) {
  292 |   const before = await page.evaluate(() => window.scrollY)
  293 |   const box = await dialog.boundingBox()
  294 |   if (!box) throw new Error('Overlay geometry missing for wheel assertion')
  295 |   await page.mouse.move(box.x + Math.min(24, box.width / 2), box.y + Math.min(24, box.height / 2))
  296 |   await page.mouse.wheel(0, 500)
  297 |   await page.waitForTimeout(50)
  298 |   const after = await page.evaluate(() => window.scrollY)
  299 |   expect(after).toBe(before)
  300 |   return { after, before, delta: after - before }
  301 | }
  302 | 
  303 | async function dispatchOutsidePointerChain(dialog: Locator) {
  304 |   return dialog.evaluate(element => {
  305 |     const backdrop = element.parentElement
  306 |     if (!(backdrop instanceof HTMLElement)) throw new Error('Overlay backdrop missing')
  307 |     const pointerdown = new PointerEvent('pointerdown', { bubbles: true, button: 0, cancelable: true, pointerId: 1, pointerType: 'mouse' })
  308 |     const mousedown = new MouseEvent('mousedown', { bubbles: true, button: 0, cancelable: true })
  309 |     const click = new MouseEvent('click', { bubbles: true, button: 0, cancelable: true })
  310 |     backdrop.dispatchEvent(pointerdown)
  311 |     backdrop.dispatchEvent(mousedown)
  312 |     backdrop.dispatchEvent(click)
  313 |     return {
  314 |       clickPrevented: click.defaultPrevented,
  315 |       mousedownPrevented: mousedown.defaultPrevented,
  316 |       pointerdownPrevented: pointerdown.defaultPrevented,
  317 |     }
  318 |   })
  319 | }
  320 | 
  321 | const viewports = [{ width: 390, height: 844 }, { width: 1920, height: 1080 }] as const
  322 | 
  323 | for (const viewport of viewports) {
  324 |   test.describe(`overlay contract at ${viewport.width}x${viewport.height}`, () => {
  325 |     test.use({ viewport })
  326 | 
  327 |     test('keeps Agent Peek and Team Access focus, scroll, containment, and return ownership deterministic', async ({ page }, testInfo) => {
  328 |       const requests: string[] = []
  329 |       await installAgentFixtures(page, requests)
  330 |       await page.goto('/agents')
  331 |       const agentLink = page.locator('[data-agent-roving-link="true"]').first()
> 332 |       await expect(agentLink).toBeVisible()
      |                               ^ Error: expect(locator).toBeVisible() failed
  333 |       const background = await prepareScrollableBackground(page)
  334 | 
  335 |       await agentLink.evaluate(element => element.focus({ preventScroll: true }))
  336 |       await page.keyboard.press('Space')
  337 |       const peek = page.locator('.agent-peek')
  338 |       await expect(peek).toBeVisible()
  339 |       const firstPeekControl = peek.locator(':scope > header button').first()
  340 |       await expect(firstPeekControl).toBeFocused()
  341 |       await page.keyboard.press('Shift+Tab')
  342 |       expect(await peek.evaluate(element => element.contains(document.activeElement))).toBe(true)
  343 |       await page.keyboard.press('Tab')
  344 |       await expect(firstPeekControl).toBeFocused()
  345 |       await peek.dispatchEvent('mousedown')
  346 |       await expect(peek).toBeVisible()
  347 |       const peekFocusRejection = await rejectBackgroundFocus(peek)
  348 |       expect(peekFocusRejection.activeInside).toBe(true)
  349 |       expect(peekFocusRejection.inertAncestor).toBe(true)
  350 |       const peekWheelLock = await assertBackgroundWheelLocked(page, peek)
  351 |       const peekEvidence = await measureOverlay(peek, background)
  352 |       expectContained(peekEvidence, 620)
  353 |       expect(peekEvidence.bodyTop).toBe(`-${background.scrollY}px`)
  354 |       await persistEvidence(page, testInfo, `agent-peek-${viewport.width}x${viewport.height}`, {
  355 |         contractLimits: { delete: 560, dialog: 760, sheet: 620 },
  356 |         focusRejection: peekFocusRejection,
  357 |         geometry: peekEvidence,
  358 |         requests,
  359 |         url: page.url(),
  360 |         wheelLock: peekWheelLock,
  361 |       })
  362 |       const peekBackdropChain = await dispatchOutsidePointerChain(peek)
  363 |       await expect(peek).toHaveCount(0)
  364 |       await expect(agentLink).toBeFocused()
  365 |       await assertBackgroundRestored(page, background)
  366 | 
  367 |       await page.keyboard.press('Space')
  368 |       await expect(peek).toBeVisible()
  369 |       await page.keyboard.press('Escape')
  370 |       await expect(peek).toHaveCount(0)
  371 |       await expect(agentLink).toBeFocused()
  372 |       await assertBackgroundRestored(page, background)
  373 | 
  374 |       const card = page.getByTestId('agent-registry-agent/overlay')
  375 |       const manage = card.getByRole('button').first()
  376 |       await manage.evaluate(element => element.focus({ preventScroll: true }))
  377 |       await page.keyboard.press('Space')
  378 |       const accessSheet = page.getByRole('dialog').filter({ has: page.locator('.team-access-drawer') })
  379 |       await expect(accessSheet).toBeVisible()
  380 |       const accessFocusRejection = await rejectBackgroundFocus(accessSheet)
  381 |       expect(accessFocusRejection.activeInside).toBe(true)
  382 |       expect(accessFocusRejection.inertAncestor).toBe(true)
  383 |       const accessWheelLock = await assertBackgroundWheelLocked(page, accessSheet)
  384 |       const internalScroll = await accessSheet.evaluate(element => {
  385 |         const before = element.scrollTop
  386 |         element.scrollTop = element.scrollHeight
  387 |         return { after: element.scrollTop, before, clientHeight: element.clientHeight, scrollHeight: element.scrollHeight }
  388 |       })
  389 |       expect(internalScroll.scrollHeight).toBeGreaterThan(internalScroll.clientHeight)
  390 |       expect(internalScroll.after).toBeGreaterThan(internalScroll.before)
  391 |       const accessEvidence = await measureOverlay(accessSheet, background)
  392 |       expectContained(accessEvidence, 620)
  393 |       expect(accessEvidence.bodyTop).toBe(`-${background.scrollY}px`)
  394 |       await accessSheet.dispatchEvent('mousedown')
  395 |       await expect(accessSheet).toBeVisible()
  396 |       await persistEvidence(page, testInfo, `team-access-${viewport.width}x${viewport.height}`, {
  397 |         backdropChain: peekBackdropChain,
  398 |         contractLimits: { delete: 560, dialog: 760, sheet: 620 },
  399 |         focusRejection: accessFocusRejection,
  400 |         geometry: accessEvidence,
  401 |         internalScroll,
  402 |         requests,
  403 |         url: page.url(),
  404 |         wheelLock: accessWheelLock,
  405 |       })
  406 |       await page.keyboard.press('Escape')
  407 |       await expect(accessSheet).toHaveCount(0)
  408 |       await expect(manage).toBeFocused()
  409 |       await assertBackgroundRestored(page, background)
  410 | 
  411 |       if (viewport.width === 390) {
  412 |         const removedRoutes = ['/preview-issues', '/preview-round2', '/human-control-plane-preview', '/evidence/collaboration-faults']
  413 |         for (const removedRoute of removedRoutes) {
  414 |           const response = await page.goto(removedRoute)
  415 |           expect(response?.status(), `${removedRoute} returns 404`).toBe(404)
  416 |         }
  417 |         await persistEvidence(page, testInfo, 'removed-preview-routes-390x844', { routes: removedRoutes, status: 404 })
  418 |       }
  419 | 
  420 |       await page.evaluate(() => document.querySelector('[data-task62-spacer="true"]')?.remove())
  421 |     })
  422 | 
  423 |     test('keeps busy delete nondismissible and restores the exact background after completion', async ({ page }, testInfo) => {
  424 |       const requests: string[] = []
  425 |       const fixture = await installSettingsFixtures(page, requests)
  426 |       await page.goto(`/settings?team=${encodeURIComponent(fixture.target.id)}`)
  427 |       const deleteTeam = page.getByRole('button', { name: /^(Delete team|删除团队)$/ })
  428 |       await expect(deleteTeam).toBeVisible()
  429 |       const background = await prepareScrollableBackground(page)
  430 |       await deleteTeam.evaluate(element => element.focus({ preventScroll: true }))
  431 |       expect(await page.evaluate(() => window.scrollY)).toBe(background.scrollY)
  432 |       await page.keyboard.press('Enter')
```