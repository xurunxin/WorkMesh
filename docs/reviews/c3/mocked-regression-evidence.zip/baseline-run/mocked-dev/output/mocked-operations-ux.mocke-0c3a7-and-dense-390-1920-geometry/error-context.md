# Instructions

- Following Playwright test failed.
- Explain why, be concise, respect Playwright best practices.
- Provide a snippet of code with the fix, if possible.

# Test info

- Name: mocked\operations-ux.mocked.spec.ts >> scopes Team resolution to Workspace with serial deep-link pagination and dense 390/1920 geometry
- Location: e2e\mocked\operations-ux.mocked.spec.ts:926:1

# Error details

```
Test timeout of 30000ms exceeded.
```

```
Error: locator.click: Test timeout of 30000ms exceeded.
Call log:
  - waiting for getByRole('tab', { name: 'Planning & Operations' })

```

# Page snapshot

```yaml
- generic [active] [ref=e1]:
  - button "Open Next.js Dev Tools" [ref=e7] [cursor=pointer]:
    - img [ref=e8]
  - alert [ref=e11]
  - generic [ref=e12]:
    - link "Skip to content" [ref=e13] [cursor=pointer]:
      - /url: "#workmesh-main"
    - complementary "Main navigation" [ref=e14]:
      - generic [ref=e15]:
        - strong [ref=e17]: WorkMesh
        - generic [ref=e18]: Alex Morgan
      - button "Collapse sidebar" [expanded] [ref=e19] [cursor=pointer]:
        - img [ref=e20]
        - generic [ref=e22]: Collapse sidebar
      - generic [ref=e24]:
        - text: Team
        - combobox "Current team" [ref=e25]:
          - option "No team" [disabled]
          - option "Runtime (RUN)"
          - option "Platform (PLAT)" [selected]
      - navigation "Workspace navigation" [ref=e26]:
        - link "Back to Issues" [ref=e27] [cursor=pointer]:
          - /url: /?view=my-work
          - img [ref=e29]
          - generic [ref=e31]: Back to Issues
      - navigation "Administration navigation" [ref=e32]:
        - link "Settings" [ref=e33] [cursor=pointer]:
          - /url: /settings
          - img [ref=e35]
          - generic [ref=e37]: Settings
      - generic [ref=e39]:
        - button "Sign out" [ref=e40] [cursor=pointer]:
          - img [ref=e42]
          - generic [ref=e44]: Sign out
        - generic [ref=e45]: v1.0.0 · build project-work-preview · schema 24
    - generic [ref=e46]:
      - banner [ref=e47]:
        - paragraph [ref=e48]:
          - generic [ref=e49]: Workspace
        - button "Search" [ref=e51] [cursor=pointer]:
          - img [ref=e53]
          - generic [ref=e55]:
            - generic [ref=e56]: Search
            - generic [ref=e57]: Ctrl K
        - generic [ref=e58]:
          - button "Switch to the light theme" [ref=e59]:
            - img [ref=e60]
          - group "Language" [ref=e63]:
            - button "中" [ref=e64]
            - button "EN" [pressed] [ref=e65]
      - main [ref=e66]:
        - generic [ref=e67]:
          - generic [ref=e69]:
            - heading "Settings" [level=1] [ref=e70]
            - paragraph [ref=e71]: Workspace administration stays separate from daily planning.
          - generic [ref=e72]:
            - tablist "Settings sections" [ref=e73]:
              - tab "Workspace" [selected] [ref=e74]:
                - generic [ref=e75]: Workspace
            - tabpanel "Workspace" [ref=e76]:
              - generic [ref=e77]:
                - region "Teams" [ref=e78]:
                  - paragraph [ref=e79]: Workspace structure
                  - heading "Teams" [level=2] [ref=e80]
                  - generic [ref=e81]:
                    - generic [ref=e82]:
                      - text: Team name
                      - textbox "Team name" [ref=e83]
                    - generic [ref=e84]:
                      - text: Team key
                      - textbox "Team key" [ref=e85]:
                        - /placeholder: ENG
                    - button "Create team" [ref=e86] [cursor=pointer]:
                      - img [ref=e88]
                      - generic [ref=e90]: Create team
                - region "Team details" [ref=e91]:
                  - paragraph [ref=e92]: Selected team
                  - heading "Team details" [level=2] [ref=e93]
                  - generic [ref=e94]:
                    - generic [ref=e95]:
                      - text: Team name
                      - textbox "Team name" [ref=e96]: Platform
                    - generic [ref=e97]:
                      - text: Team key
                      - textbox "Team key" [ref=e98]: PLAT
                    - button "Save changes" [ref=e99] [cursor=pointer]:
                      - img [ref=e101]
                      - generic [ref=e103]: Save changes
                  - generic [ref=e104]:
                    - generic [ref=e105]:
                      - strong [ref=e106]: Delete team
                      - paragraph [ref=e107]: Remove this Team from active navigation; associated work is retained but unavailable.
                    - button "Delete team" [ref=e108] [cursor=pointer]:
                      - img [ref=e110]
                      - generic [ref=e112]: Delete team
                - region "Workflow states" [ref=e113]:
                  - paragraph [ref=e114]: Team workflow
                  - heading "Workflow states" [level=2] [ref=e115]
                  - article [ref=e117]:
                    - generic [ref=e120]:
                      - strong [ref=e121]: In progress
                      - generic [ref=e122]: Started
                    - button "Edit status In progress" [ref=e123] [cursor=pointer]:
                      - img [ref=e125]
                      - generic [ref=e127]: Edit
                  - generic [ref=e128]:
                    - generic [ref=e129]:
                      - text: Status name
                      - textbox "Status name" [ref=e130]
                    - generic [ref=e131]:
                      - text: Category
                      - combobox "Category" [ref=e132]:
                        - option "Backlog"
                        - option "Planned" [selected]
                        - option "Started"
                        - option "Completed"
                        - option "Canceled"
                    - group "Status color" [ref=e133]:
                      - generic [ref=e134]: Status color
                      - generic [ref=e135]:
                        - generic [ref=e136] [cursor=pointer]:
                          - radio "Neutral" [checked] [ref=e137]
                          - generic [ref=e139]: Neutral
                        - generic [ref=e140] [cursor=pointer]:
                          - radio "Blue" [ref=e141]
                          - generic [ref=e143]: Blue
                        - generic [ref=e144] [cursor=pointer]:
                          - radio "Green" [ref=e145]
                          - generic [ref=e147]: Green
                        - generic [ref=e148] [cursor=pointer]:
                          - radio "Amber" [ref=e149]
                          - generic [ref=e151]: Amber
                        - generic [ref=e152] [cursor=pointer]:
                          - radio "Red" [ref=e153]
                          - generic [ref=e155]: Red
                        - generic [ref=e156] [cursor=pointer]:
                          - radio "Custom" [ref=e157]
                          - generic [ref=e159]: Custom
                    - button "Create status" [ref=e160] [cursor=pointer]:
                      - img [ref=e162]
                      - generic [ref=e164]: Create status
              - region "Model service connections" [ref=e165]:
                - paragraph [ref=e166]: Agent workbench
                - heading "Model service connections" [level=2] [ref=e167]
                - paragraph [ref=e168]: Manage Chat Completions and Responses providers, credentials, and models.
                - link "Open connection settings" [ref=e169] [cursor=pointer]:
                  - /url: /settings/agent-workbench
```

# Test source

```ts
  860  |   await page.getByRole('tab', { name: 'Workspace' }).press('End')
  861  |   await expect(page.getByRole('tab', { name: 'Planning & Operations' })).toBeFocused()
  862  |   await expect(page).toHaveURL(`${webUrl}${routedOperationsUrl}`)
  863  |   expect(await page.evaluate(() => window.history.length)).toBe(initialLength + 2)
  864  | 
  865  |   await page.getByRole('tab', { name: 'Planning & Operations' }).press('End')
  866  |   expect(await page.evaluate(() => window.history.length)).toBe(initialLength + 2)
  867  |   await page.getByRole('tab', { name: 'Planning & Operations' }).press('Home')
  868  |   await expect(page.getByRole('tab', { name: 'Workspace' })).toBeFocused()
  869  |   expect(await page.evaluate(() => window.history.length)).toBe(initialLength + 3)
  870  |   await page.getByRole('tab', { name: 'Workspace' }).press('ArrowLeft')
  871  |   await expect(page.getByRole('tab', { name: 'Planning & Operations' })).toBeFocused()
  872  |   expect(await page.evaluate(() => window.history.length)).toBe(initialLength + 4)
  873  | 
  874  |   const localeControl = page.getByRole('button', { exact: true, name: 'EN' })
  875  |   await localeControl.focus()
  876  |   await page.goBack()
  877  |   await expect(page).toHaveURL(`${webUrl}/settings?team=team-1&opsQuery=Archived&x=keep#operations-templates`)
  878  |   await expect(page.getByRole('tab', { name: 'Workspace' })).toHaveAttribute('aria-selected', 'true')
  879  |   await expect(localeControl).toBeFocused()
  880  |   await page.goForward()
  881  |   await expect(page).toHaveURL(`${webUrl}${routedOperationsUrl}`)
  882  |   await expect(page.getByRole('tab', { name: 'Planning & Operations' })).toHaveAttribute('aria-selected', 'true')
  883  |   await expect(localeControl).toBeFocused()
  884  | 
  885  |   const geometry: Awaited<ReturnType<typeof measureSettingsGeometry>>[] = []
  886  |   const wide = await measureSettingsGeometry(page)
  887  |   geometry.push(wide)
  888  |   expect(wide.document.scrollWidth).toBe(wide.document.clientWidth)
  889  |   expect(wide.content.width / wide.main.width).toBeGreaterThanOrEqual(.85)
  890  |   expect(wide.content.width).toBeLessThanOrEqual(1480)
  891  |   expect(wide.panel.width / wide.contentInnerWidth).toBeGreaterThanOrEqual(.98)
  892  |   expect(wide.operationsRoot.width / wide.panel.width).toBeGreaterThanOrEqual(.98)
  893  |   const wideScreenshot = testInfo.outputPath('task-5.1-settings-wide-pass.png')
  894  |   await page.screenshot({ fullPage: true, path: wideScreenshot })
  895  |   await testInfo.attach('task-5.1-settings-wide-pass', { contentType: 'image/png', path: wideScreenshot })
  896  | 
  897  |   await page.setViewportSize({ width: 390, height: 844 })
  898  |   await page.goto(directUrl)
  899  |   const selector = page.getByRole('combobox', { name: 'Settings sections' })
  900  |   await expect(selector).toHaveValue('operations')
  901  |   await expect(page.getByRole('tablist')).toHaveCount(0)
  902  |   await expect(page.getByRole('tab')).toHaveCount(0)
  903  |   await expect(page.getByRole('tabpanel')).toHaveCount(1)
  904  |   await selector.focus()
  905  |   await selector.selectOption('workspace')
  906  |   await expect(selector).toBeFocused()
  907  |   await expect(page).toHaveURL(`${webUrl}/settings?team=team-1&opsQuery=Archived&x=keep#operations-templates`)
  908  |   expect(await page.evaluate(() => document.documentElement.scrollWidth)).toBe(390)
  909  | 
  910  |   await selector.selectOption('operations')
  911  |   await expect(selector).toBeFocused()
  912  |   const narrow = await measureSettingsGeometry(page)
  913  |   geometry.push(narrow)
  914  |   expect(narrow.document.scrollWidth).toBe(narrow.document.clientWidth)
  915  |   expect(narrow.content.width).toBeLessThanOrEqual(390)
  916  |   expect(narrow.panel.width / narrow.contentInnerWidth).toBeGreaterThanOrEqual(.98)
  917  |   const narrowScreenshot = testInfo.outputPath('task-5.1-settings-narrow-pass.png')
  918  |   await page.screenshot({ fullPage: true, path: narrowScreenshot })
  919  |   await testInfo.attach('task-5.1-settings-narrow-pass', { contentType: 'image/png', path: narrowScreenshot })
  920  | 
  921  |   const geometryPath = testInfo.outputPath('task-5.1-settings-geometry-pass.json')
  922  |   await writeFile(geometryPath, JSON.stringify(geometry, null, 2), 'utf8')
  923  |   await testInfo.attach('task-5.1-settings-geometry-pass', { contentType: 'application/json', path: geometryPath })
  924  | })
  925  | 
  926  | test('scopes Team resolution to Workspace with serial deep-link pagination and dense 390/1920 geometry', async ({ page }, testInfo) => {
  927  |   const requestLog: string[] = []
  928  |   const teamRequestSequence = () => requestLog
  929  |     .map(request => new URL(request))
  930  |     .filter(url => url.pathname === '/api/v1/teams' || /^\/api\/v1\/teams\/[^/]+\/states$/.test(url.pathname))
  931  |     .map(url => `${url.pathname}${url.search}`)
  932  |   const resolutionSequence = [
  933  |     '/api/v1/teams?limit=100',
  934  |     '/api/v1/teams?limit=100&cursor=teams-page-2',
  935  |     '/api/v1/teams/team-second-page/states?limit=100',
  936  |   ]
  937  |   await installOperationsRoutes(page, () => allOperationsFeatures, {
  938  |     requestLog,
  939  |     settingsTeamPages: {
  940  |       first: { items: [settingsTeamOne], nextCursor: 'teams-page-2' },
  941  |       'teams-page-2': { items: [settingsTeamTwo], nextCursor: null },
  942  |     },
  943  |     settingsStates: {
  944  |       [settingsTeamOne.id]: [{ id: 'state-runtime', name: 'Ready', category: 'planned', color: '#64748b', revision: 1 }],
  945  |       [settingsTeamTwo.id]: [{ id: 'state-platform', name: 'In progress', category: 'started', color: '#2563eb', revision: 1 }],
  946  |     },
  947  |   })
  948  | 
  949  |   await page.setViewportSize({ width: 1920, height: 1080 })
  950  |   await page.goto('/settings?team=team-second-page&x=keep#team-settings-heading')
  951  |   await expect(page).toHaveURL(`${webUrl}/settings?team=team-second-page&x=keep#team-settings-heading`)
  952  |   await expect.poll(() => ({ href: page.url(), sequence: teamRequestSequence() })).toEqual({
  953  |     href: `${webUrl}/settings?team=team-second-page&x=keep#team-settings-heading`,
  954  |     sequence: resolutionSequence,
  955  |   })
  956  |   await expect(page.getByRole('combobox', { name: 'Current team' })).toHaveValue('team-second-page')
  957  |   await expect(page.getByRole('heading', { name: 'Team details' })).toBeVisible()
  958  |   await expect(page.locator('input[name="name"][value="Platform"]')).toBeVisible()
  959  | 
> 960  |   await page.getByRole('tab', { name: 'Planning & Operations' }).click()
       |                                                                  ^ Error: locator.click: Test timeout of 30000ms exceeded.
  961  |   await expect(page.getByRole('tab', { name: 'Planning & Operations' })).toHaveAttribute('aria-selected', 'true')
  962  |   await expect(page.getByRole('combobox', { name: 'Current team' })).toHaveCount(0)
  963  |   await expect(page).toHaveURL(`${webUrl}/settings?team=team-second-page&x=keep&tab=operations#team-settings-heading`)
  964  |   const operationsRequestBoundary = teamRequestSequence().length
  965  |   await page.evaluate(() => new Promise<void>(resolve => {
  966  |     requestAnimationFrame(() => requestAnimationFrame(() => resolve()))
  967  |   }))
  968  |   expect(teamRequestSequence().slice(operationsRequestBoundary)).toEqual([])
  969  | 
  970  |   await page.getByRole('tab', { name: 'Workspace' }).click()
  971  |   await expect.poll(teamRequestSequence).toEqual([...resolutionSequence, ...resolutionSequence])
  972  |   await expect(page.getByRole('combobox', { name: 'Current team' })).toHaveValue('team-second-page')
  973  |   await expect(page).toHaveURL(`${webUrl}/settings?team=team-second-page&x=keep#team-settings-heading`)
  974  | 
  975  |   const geometry: Awaited<ReturnType<typeof measureWorkspaceSettingsGeometry>>[] = []
  976  |   const wide = await measureWorkspaceSettingsGeometry(page)
  977  |   geometry.push(wide)
  978  |   expect(wide.document.scrollWidth).toBe(wide.document.clientWidth)
  979  |   expect(wide.content.width / wide.main.width).toBeGreaterThanOrEqual(.85)
  980  |   expect(wide.content.width).toBeLessThanOrEqual(1480)
  981  |   expect(wide.panel.width / wide.contentInnerWidth).toBeGreaterThanOrEqual(.98)
  982  |   expect(wide.settingsGrid.width / wide.panel.width).toBeGreaterThanOrEqual(.98)
  983  |   expect(wide.selector.width).toBeGreaterThanOrEqual(120)
  984  |   expect(wide.selector.width).toBeLessThanOrEqual(260)
  985  |   expect(wide.selector.width / wide.main.width).toBeLessThan(.2)
  986  |   expect(await removeNextDevelopmentIndicatorForEvidence(page)).toBeGreaterThan(0)
  987  |   const wideScreenshot = testInfo.outputPath('task-5.2-settings-wide-pass.png')
  988  |   await page.screenshot({ fullPage: true, path: wideScreenshot })
  989  |   await testInfo.attach('task-5.2-settings-wide-pass', { contentType: 'image/png', path: wideScreenshot })
  990  | 
  991  |   await page.setViewportSize({ width: 390, height: 844 })
  992  |   const settingsSelector = page.getByRole('combobox', { name: 'Settings sections' })
  993  |   await expect(settingsSelector).toHaveValue('workspace')
  994  |   await settingsSelector.selectOption('operations')
  995  |   await expect(settingsSelector).toHaveValue('operations')
  996  |   await expect(page.getByRole('combobox', { name: 'Current team' })).toHaveCount(0)
  997  |   await expect(page).toHaveURL(`${webUrl}/settings?team=team-second-page&x=keep&tab=operations#team-settings-heading`)
  998  |   expect(await page.evaluate(() => document.documentElement.scrollWidth)).toBe(390)
  999  | 
  1000 |   await settingsSelector.selectOption('workspace')
  1001 |   await expect(settingsSelector).toHaveValue('workspace')
  1002 |   await expect.poll(teamRequestSequence).toEqual([
  1003 |     ...resolutionSequence,
  1004 |     ...resolutionSequence,
  1005 |     ...resolutionSequence,
  1006 |   ])
  1007 |   await page.getByText('Menu', { exact: true }).click()
  1008 |   await expect(page.getByRole('combobox', { name: 'Current team' })).toHaveValue('team-second-page')
  1009 |   const narrow = await measureWorkspaceSettingsGeometry(page)
  1010 |   geometry.push(narrow)
  1011 |   expect(narrow.document.scrollWidth).toBe(narrow.document.clientWidth)
  1012 |   expect(narrow.content.width).toBeLessThanOrEqual(390)
  1013 |   expect(narrow.panel.width / narrow.contentInnerWidth).toBeGreaterThanOrEqual(.98)
  1014 |   expect(narrow.settingsGrid.width / narrow.panel.width).toBeGreaterThanOrEqual(.98)
  1015 |   await removeNextDevelopmentIndicatorForEvidence(page)
  1016 |   const narrowScreenshot = testInfo.outputPath('task-5.2-settings-narrow-pass.png')
  1017 |   await page.screenshot({ fullPage: true, path: narrowScreenshot })
  1018 |   await testInfo.attach('task-5.2-settings-narrow-pass', { contentType: 'image/png', path: narrowScreenshot })
  1019 | 
  1020 |   const geometryPath = testInfo.outputPath('task-5.2-settings-team-geometry-pass.json')
  1021 |   await writeFile(geometryPath, JSON.stringify(geometry, null, 2), 'utf8')
  1022 |   await testInfo.attach('task-5.2-settings-team-geometry-pass', { contentType: 'application/json', path: geometryPath })
  1023 |   const requestSequencePath = testInfo.outputPath('task-5.2-team-request-sequence-pass.json')
  1024 |   await writeFile(requestSequencePath, JSON.stringify({ sequence: teamRequestSequence() }, null, 2), 'utf8')
  1025 |   await testInfo.attach('task-5.2-team-request-sequence-pass', { contentType: 'application/json', path: requestSequencePath })
  1026 | })
  1027 | 
  1028 | test('keeps destructive retries revision-specific and contains long failure content at 390', async ({ page }, testInfo) => {
  1029 |   const longName = `Runtime ${'reliability-and-recovery '.repeat(55)}`.trim()
  1030 |   const longKey = `RUN-${'LONG-'.repeat(48)}`
  1031 |   let revision = 7
  1032 |   let deleteCount = 0
  1033 |   const privateKeys: string[] = []
  1034 |   const evidence: Array<{
  1035 |     bodyLength: number
  1036 |     count: number
  1037 |     idempotencyKeyPresent: boolean
  1038 |     ifMatch: string | undefined
  1039 |     path: string
  1040 |     sameAsFirst: boolean | null
  1041 |   }> = []
  1042 |   const target: SettingsTeamFixture = {
  1043 |     id: 'team/delete-target',
  1044 |     key: longKey,
  1045 |     name: longName,
  1046 |     get revision() { return revision },
  1047 |   }
  1048 |   const pages = {
  1049 |     get first(): SettingsTeamPageFixture { return { items: [target, settingsTeamTwo], nextCursor: null } },
  1050 |   }
  1051 |   await installOperationsRoutes(page, () => allOperationsFeatures, {
  1052 |     settingsDelete: request => {
  1053 |       deleteCount += 1
  1054 |       const key = request.headers()['idempotency-key'] ?? ''
  1055 |       privateKeys.push(key)
  1056 |       evidence.push({
  1057 |         bodyLength: request.postDataBuffer()?.byteLength ?? 0,
  1058 |         count: deleteCount,
  1059 |         idempotencyKeyPresent: key.length > 0,
  1060 |         ifMatch: request.headers()['if-match'],
```