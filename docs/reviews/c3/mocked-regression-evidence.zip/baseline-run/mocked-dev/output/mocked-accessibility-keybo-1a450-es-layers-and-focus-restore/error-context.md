# Instructions

- Following Playwright test failed.
- Explain why, be concise, respect Playwright best practices.
- Provide a snippet of code with the fix, if possible.

# Test info

- Name: mocked\accessibility-keyboard.mocked.spec.ts >> Task 6.6 desktop English keyboard and semantic journey >> covers Home detail, Agents, Settings, Operations, tabs, tables, layers, and focus restore
- Location: e2e\mocked\accessibility-keyboard.mocked.spec.ts:368:3

# Error details

```
Error: expect(locator).toHaveCount(expected) failed

Locator:  locator('.agent-registry-card')
Expected: 2
Received: 0
Timeout:  10000ms

Call log:
  - Expect "toHaveCount" with timeout 10000ms
  - waiting for locator('.agent-registry-card')
    23 × locator resolved to 0 elements
       - unexpected value "0"

```

# Page snapshot

```yaml
- generic [active] [ref=e1]:
  - button "Open Next.js Dev Tools" [ref=e7] [cursor=pointer]:
    - img [ref=e8]
  - alert [ref=e11]
  - generic [ref=e12]:
    - link "Skip to content" [ref=e13] [cursor=pointer]:
      - /url: "#workmesh-main"
    - complementary "Main navigation" [ref=e14]:
      - generic [ref=e15]:
        - strong [ref=e17]: WorkMesh
        - generic [ref=e18]: Alex Morgan
      - button "Collapse sidebar" [expanded] [ref=e19] [cursor=pointer]:
        - img [ref=e20]
        - generic [ref=e22]: Collapse sidebar
      - navigation "Workspace navigation" [ref=e23]:
        - generic [ref=e24]:
          - paragraph [ref=e25]: Workbench
          - link "Workbench" [ref=e26] [cursor=pointer]:
            - /url: /workbench
            - img [ref=e28]
            - generic [ref=e30]: Workbench
          - link "My work" [ref=e31] [cursor=pointer]:
            - /url: /?view=home
            - img [ref=e33]
            - generic [ref=e35]: My work
          - link "Issues" [ref=e36] [cursor=pointer]:
            - /url: /?view=my-work
            - img [ref=e38]
            - generic [ref=e40]: Issues
          - link "Guidance" [ref=e41] [cursor=pointer]:
            - /url: /?view=guidance
            - img [ref=e43]
            - generic [ref=e45]: Guidance
        - generic [ref=e46]:
          - paragraph [ref=e47]: Governance
          - link "Needs You" [ref=e48] [cursor=pointer]:
            - /url: /?view=inbox
            - img [ref=e50]
            - generic [ref=e52]: Needs You
          - link "Session" [ref=e53] [cursor=pointer]:
            - /url: /?view=sessions
            - img [ref=e55]
            - generic [ref=e57]: Session
          - link "Recovery" [ref=e58] [cursor=pointer]:
            - /url: /?view=recovery
            - img [ref=e60]
            - generic [ref=e62]: Recovery
          - link "Projects" [ref=e63] [cursor=pointer]:
            - /url: /?view=projects
            - img [ref=e65]
            - generic [ref=e67]: Projects
          - link "Agents" [ref=e68] [cursor=pointer]:
            - /url: /agents
            - img [ref=e70]
            - generic [ref=e72]: Agents
        - generic [ref=e73]:
          - paragraph [ref=e74]: Operations
          - link "Operations" [ref=e75] [cursor=pointer]:
            - /url: /operations
            - img [ref=e77]
            - generic [ref=e79]: Operations
      - navigation "Administration navigation" [ref=e80]:
        - link "Settings" [ref=e81] [cursor=pointer]:
          - /url: /settings
          - img [ref=e83]
          - generic [ref=e85]: Settings
      - generic [ref=e87]:
        - button "Sign out" [ref=e88] [cursor=pointer]:
          - img [ref=e90]
          - generic [ref=e92]: Sign out
        - generic [ref=e93]: v1.0.0 · build accessibility-fixture · schema 24
    - generic [ref=e94]:
      - banner [ref=e95]:
        - paragraph [ref=e96]:
          - generic [ref=e97]: Human control plane
        - button "Search" [ref=e99] [cursor=pointer]:
          - img [ref=e101]
          - generic [ref=e103]:
            - generic [ref=e104]: Search
            - generic [ref=e105]: Ctrl K
        - generic [ref=e106]:
          - button "Switch to the light theme" [ref=e107]:
            - img [ref=e108]
          - generic [ref=e110]:
            - group "Language" [ref=e111]:
              - button "中" [ref=e112]
              - button "EN" [pressed] [ref=e113]
            - generic "Reconnecting" [ref=e114]:
              - generic [ref=e115]: Reconnecting
      - main [ref=e116]:
        - generic [ref=e117]:
          - generic [ref=e118]:
            - generic [ref=e119]:
              - paragraph [ref=e120]: Human control plane
              - heading "Agents" [level=1] [ref=e121]
              - paragraph [ref=e122]: Monitor delegated work, respond to approvals, and diagnose Connections without handling credentials.
            - button "Refresh" [ref=e123] [cursor=pointer]:
              - generic [ref=e124]: Refresh
          - alert [ref=e125]:
            - generic [ref=e127]:
              - heading "Agent workspace needs attention" [level=2] [ref=e128]
              - paragraph [ref=e129]: "[ { \"code\": \"invalid_type\", \"expected\": \"string\", \"received\": \"undefined\", \"path\": [ \"icon\" ], \"message\": \"Required\" }, { \"code\": \"invalid_type\", \"expected\": \"string\", \"received\": \"undefined\", \"path\": [ \"endpoint_url\" ], \"message\": \"Required\" }, { \"code\": \"invalid_type\", \"expected\": \"array\", \"received\": \"undefined\", \"path\": [ \"output_artifact_types\" ], \"message\": \"Required\" }, { \"code\": \"invalid_type\", \"expected\": \"object\", \"received\": \"undefined\", \"path\": [ \"metadata\" ], \"message\": \"Required\" }, { \"expected\": \"'active' | 'archived'\", \"received\": \"undefined\", \"code\": \"invalid_type\", \"path\": [ \"lifecycle_status\" ], \"message\": \"Required\" }, { \"code\": \"invalid_type\", \"expected\": \"string\", \"received\": \"undefined\", \"path\": [ \"archived_at\" ], \"message\": \"Required\" }, { \"code\": \"invalid_type\", \"expected\": \"string\", \"received\": \"undefined\", \"path\": [ \"archived_by_actor_id\" ], \"message\": \"Required\" }, { \"code\": \"invalid_type\", \"expected\": \"string\", \"received\": \"undefined\", \"path\": [ \"archived_reason\" ], \"message\": \"Required\" }, { \"code\": \"invalid_type\", \"expected\": \"string\", \"received\": \"undefined\", \"path\": [ \"created_at\" ], \"message\": \"Required\" }, { \"code\": \"invalid_type\", \"expected\": \"string\", \"received\": \"undefined\", \"path\": [ \"updated_at\" ], \"message\": \"Required\" } ]"
            - button "Retry" [ref=e130] [cursor=pointer]:
              - generic [ref=e131]: Retry
          - generic [ref=e132]:
            - tablist "Agent workspace sections" [ref=e133]:
              - tab "Agents" [selected] [ref=e134]:
                - generic [ref=e135]: Agents
              - tab "Connections" [ref=e136]:
                - generic [ref=e137]: Connections
              - tab "Auto enrollment" [ref=e138]:
                - generic [ref=e139]: Auto enrollment
              - tab "Archived" [ref=e140]:
                - generic [ref=e141]: Archived
            - tabpanel "Agents" [ref=e142]:
              - region "Registry" [ref=e143]:
                - generic [ref=e144]:
                  - generic [ref=e145]:
                    - paragraph [ref=e146]: Registry
                    - heading "Agents" [level=2] [ref=e147]
                    - paragraph [ref=e148]: Scan definitions first; expand Team authority only when it needs review.
                  - generic [ref=e149]:
                    - button "All" [ref=e150]
                    - button "Active" [ref=e151]
                    - button "Inactive" [ref=e152]
                - group "Agent filters" [ref=e153]:
                  - generic [ref=e154]:
                    - generic [ref=e155]: Name
                    - searchbox "Name" [ref=e156]
                  - generic [ref=e157]:
                    - generic [ref=e158]: Team
                    - combobox "Team" [ref=e159]:
                      - option "All teams" [selected]
                      - option "General"
                      - option "Operations"
                  - generic [ref=e160]:
                    - generic [ref=e161]: Capability
                    - combobox "Capability" [ref=e162]:
                      - option "All capabilities" [selected]
                  - generic [ref=e163]:
                    - generic [ref=e164]: Status
                    - combobox "Status" [ref=e165]:
                      - option "All" [selected]
                      - option "Active"
                      - option "Inactive"
```

# Test source

```ts
  310 |   expect.soft(geometry.contentRight, `${label}: content respects right padding`).toBeLessThanOrEqual(geometry.wrapperRight - geometry.paddingRight + tolerance)
  311 |   expect.soft(geometry.documentScrollWidth, `${label}: document remains contained`).toBe(geometry.documentClientWidth)
  312 |   return geometry
  313 | }
  314 | 
  315 | async function expectKeyboardLocalScroll(wrapper: Locator, label: string): Promise<Readonly<Record<string, number | boolean>>> {
  316 |   const page = wrapper.page()
  317 |   const reached = await tabUntilFocused(page, wrapper)
  318 |   expect.soft(reached, `${label}: wrapper is reachable with Tab`).toBe(true)
  319 |   const before = await wrapper.evaluate(element => {
  320 |     element.scrollLeft = 0
  321 |     return { clientWidth: element.clientWidth, scrollLeft: element.scrollLeft, scrollWidth: element.scrollWidth }
  322 |   })
  323 |   const focus = reached ? await expectVisibleFocus(wrapper, `${label} scroll wrapper`) : null
  324 |   expect.soft(before.scrollWidth, `${label}: local wrapper owns real horizontal overflow`).toBeGreaterThan(before.clientWidth)
  325 |   if (reached) {
  326 |     for (let index = 0; index < 5; index += 1) await page.keyboard.press('ArrowRight')
  327 |     await page.waitForTimeout(50)
  328 |   }
  329 |   const after = await wrapper.evaluate(element => ({ scrollLeft: element.scrollLeft }))
  330 |   expect.soft(after.scrollLeft, `${label}: ArrowRight changes local scrollLeft`).toBeGreaterThan(before.scrollLeft)
  331 |   const documentContained = await page.evaluate(() => document.documentElement.scrollWidth === document.documentElement.clientWidth)
  332 |   expect.soft(documentContained, `${label}: local overflow does not widen the document`).toBe(true)
  333 |   return { ...before, afterScrollLeft: after.scrollLeft, documentContained, focus: Boolean(focus), reached }
  334 | }
  335 | 
  336 | async function openTeamAccess(page: Page, compact: boolean): Promise<void> {
  337 |   const trigger = page.getByRole('button', { name: /Atlas Agent/i }).first()
  338 |   await expect(trigger).toBeVisible()
  339 |   const reached = await tabUntilFocused(page, trigger)
  340 |   expect.soft(reached, 'Team Access trigger is keyboard reachable').toBe(true)
  341 |   if (!reached) return
  342 |   await page.keyboard.press('Enter')
  343 |   const dialog = page.getByRole('dialog')
  344 |   await expect(dialog).toBeVisible()
  345 |   await expectSemanticIntegrity(page, 'Team Access layer')
  346 |   await expectTeamAccessTabs(dialog, compact)
  347 |   await expectSemanticIntegrity(page, 'Team Access selected panel')
  348 |   await page.keyboard.press('/')
  349 |   await page.keyboard.press('Control+K')
  350 |   await expect.soft(page.getByTestId('command-center'), 'A live Team Access layer suppresses command-center shortcuts').toHaveCount(0)
  351 |   await expect.soft(page.getByRole('dialog'), 'Shortcuts do not stack another dialog').toHaveCount(1)
  352 |   await page.keyboard.press('Escape')
  353 |   await expect(dialog).toHaveCount(0)
  354 |   await expect.soft(trigger, 'Closing Team Access restores its trigger focus').toBeFocused()
  355 | }
  356 | 
  357 | async function expectPublicShortcutBoundary(page: Page, label: string): Promise<void> {
  358 |   const before = page.url()
  359 |   await page.keyboard.press('/')
  360 |   await page.keyboard.press('Control+K')
  361 |   await expect.soft(page.getByTestId('command-center-trigger'), `${label}: public route mounts no command trigger`).toHaveCount(0)
  362 |   expect.soft(page.url(), `${label}: public shortcuts do not navigate`).toBe(before)
  363 | }
  364 | 
  365 | test.describe('Task 6.6 desktop English keyboard and semantic journey', () => {
  366 |   test.use({ viewport: { width: 1920, height: 1080 } })
  367 | 
  368 |   test('covers Home detail, Agents, Settings, Operations, tabs, tables, layers, and focus restore', async ({ page }, testInfo) => {
  369 |     test.setTimeout(120_000)
  370 |     const fixture = new AccessibilityFixture()
  371 |     await fixture.install(page)
  372 |     await useLocale(page, 'en')
  373 |     const evidence: Record<string, unknown> = {}
  374 | 
  375 |     await page.goto('/?view=my-work&layout=list')
  376 |     const workItemTrigger = page.locator(`[data-work-item-id="${accessibilityIds.workItem}"] .wm-work-item-title`)
  377 |     await expect(workItemTrigger).toBeVisible()
  378 |     evidence.homeSkip = await expectSkipJourney(page, 'Home', 'en')
  379 |     evidence.home = await expectSemanticPage(page, 'Home')
  380 |     await expect.soft(page.locator('nav[aria-label]:visible'), 'Home exposes labelled navigation landmarks').not.toHaveCount(0)
  381 |     await expect.soft(page.locator('[data-hotkey-filter="true"]'), 'Home exposes one named filter').toHaveCount(1)
  382 |     const workCard = page.locator(`[data-work-item-id="${accessibilityIds.workItem}"]`)
  383 |     await expect.soft(workCard.locator('.wm-work-item-title'), 'Work card exposes title separately').toHaveText('Keyboard acceptance issue')
  384 |     await expect.soft(workCard.locator('.wm-work-item-project'), 'Work card exposes project separately').toContainText('Runtime reliability')
  385 |     await expect.soft(workCard.locator('.wm-work-item-status-pill'), 'Work card exposes status separately').toContainText('In progress')
  386 | 
  387 |     await page.keyboard.press('/')
  388 |     const commandCenter = page.getByTestId('command-center')
  389 |     await expect(commandCenter).toBeVisible()
  390 |     await expectSemanticIntegrity(page, 'Command Center layer')
  391 |     await page.keyboard.press('/')
  392 |     await page.keyboard.press('Control+K')
  393 |     await expect.soft(page.getByTestId('command-center'), 'Command-center shortcuts never stack a second layer').toHaveCount(1)
  394 |     await page.keyboard.press('Escape')
  395 |     await expect(commandCenter).toHaveCount(0)
  396 |     await expect.soft(page.locator('#workmesh-main'), 'Command Center returns focus to the keyboard origin').toBeFocused()
  397 | 
  398 |     expect.soft(await tabUntilFocused(page, workItemTrigger), 'Work Item is reachable from main with Tab').toBe(true)
  399 |     await page.keyboard.press('Enter')
  400 |     const detailDialog = page.getByRole('dialog')
  401 |     await expect(detailDialog).toBeVisible()
  402 |     await expectSemanticIntegrity(page, 'Work Item detail layer')
  403 |     const detailTabs = detailDialog.locator('.work-item-detail-layout > .wm-tabs > .wm-tab-list')
  404 |     await exerciseTablist(detailTabs, 'Work Item detail tabs')
  405 |     await page.keyboard.press('Escape')
  406 |     await expect(detailDialog).toHaveCount(0)
  407 |     await expect.soft(workItemTrigger, 'Closing Work Item detail restores the row trigger').toBeFocused()
  408 | 
  409 |     await page.goto('/agents?tab=agents')
> 410 |     await expect(page.locator('.agent-registry-card')).toHaveCount(2)
      |                                                        ^ Error: expect(locator).toHaveCount(expected) failed
  411 |     evidence.agentsSkip = await expectSkipJourney(page, 'Agents', 'en')
  412 |     evidence.agents = await expectSemanticPage(page, 'Agents')
  413 |     const agentOuterTabs = page.locator('.agent-center > .wm-tabs > .wm-tab-list')
  414 |     await exerciseTablist(agentOuterTabs, 'Agents primary tabs')
  415 | 
  416 |     const firstAgent = page.locator('[data-agent-roving-link="true"]').nth(0)
  417 |     const secondAgent = page.locator('[data-agent-roving-link="true"]').nth(1)
  418 |     expect.soft(await tabUntilFocused(page, firstAgent), 'First Agent is keyboard reachable').toBe(true)
  419 |     await page.keyboard.press('j')
  420 |     await expect.soft(secondAgent, 'J moves Agent focus forward').toBeFocused()
  421 |     await page.keyboard.press('k')
  422 |     await expect.soft(firstAgent, 'K moves Agent focus backward').toBeFocused()
  423 |     await page.keyboard.press('Space')
  424 |     const peekDialog = page.getByRole('dialog')
  425 |     await expect(peekDialog).toBeVisible()
  426 |     await expectSemanticIntegrity(page, 'Agent Peek layer')
  427 |     await page.keyboard.press('/')
  428 |     await page.keyboard.press('Control+K')
  429 |     await expect.soft(page.getByTestId('command-center'), 'Agent Peek suppresses command-center shortcuts').toHaveCount(0)
  430 |     await page.keyboard.press('Escape')
  431 |     await expect(peekDialog).toHaveCount(0)
  432 |     await expect.soft(firstAgent, 'Closing Agent Peek restores its Agent link').toBeFocused()
  433 |     await openTeamAccess(page, false)
  434 | 
  435 |     const primaryTabs = page.locator('.agent-center > .wm-tabs > .wm-tab-list')
  436 |     const primaryApprovalTab = primaryTabs.getByRole('tab', { name: 'Approvals' })
  437 |     const selectedPrimaryTab = primaryTabs.locator('[role="tab"][aria-selected="true"]')
  438 |     const primaryReached = await tabUntilFocused(page, selectedPrimaryTab)
  439 |     expect.soft(primaryReached, 'Selected primary Agent tab is keyboard reachable').toBe(true)
  440 |     if (primaryReached) {
  441 |       await primaryApprovalTab.focus()
  442 |       await page.keyboard.press('Enter')
  443 |     }
  444 |     await expect.soft(primaryApprovalTab, 'Selecting Approvals activates the approval workspace').toHaveAttribute('aria-selected', 'true')
  445 |     const approvalTabs = page.locator('.approval-inbox .wm-tab-list')
  446 |     await expect(approvalTabs).toBeVisible()
  447 |     const pendingGrid = page.locator('.approval-grid')
  448 |     await expect(pendingGrid).toBeVisible()
  449 |     await expect(pendingGrid.getByRole('row')).toHaveCount(2)
  450 |     await expect(pendingGrid.getByTestId(`approval-row-${accessibilityIds.approvalPending}`).getByRole('button', { name: 'Approve' })).toBeVisible()
  451 |     await expect(pendingGrid.getByTestId(`approval-row-${accessibilityIds.approvalPending}`).getByRole('button', { name: 'Reject' })).toBeVisible()
  452 |     await expect(pendingGrid.getByTestId(`approval-row-${accessibilityIds.approvalPending}`).getByRole('button', { name: 'Other feedback' })).toBeVisible()
  453 |     await expectSemanticIntegrity(page, 'Pending approvals panel')
  454 |     await exerciseTablist(approvalTabs, 'Approval Pending and History tabs')
  455 |     const historyWrap = page.locator('.approval-history-table-wrap')
  456 |     const historyTab = approvalTabs.getByRole('tab').last()
  457 |     await page.keyboard.press('End')
  458 |     await expect.soft(historyTab, 'Approval History is selected with End').toHaveAttribute('aria-selected', 'true')
  459 |     await expect(historyWrap).toBeVisible()
  460 |     await expectNativeTable(historyWrap, 7, 'Approval history')
  461 |     await expectSemanticIntegrity(page, 'Approval History panel')
  462 | 
  463 |     await page.goto('/settings?tab=workspace')
  464 |     await expect(page.locator('.settings-page')).toBeVisible()
  465 |     evidence.settingsSkip = await expectSkipJourney(page, 'Settings', 'en')
  466 |     evidence.settings = await expectSemanticPage(page, 'Settings')
  467 |     const deleteTrigger = page.getByRole('button', { name: 'Delete Team' })
  468 |     expect.soft(await tabUntilFocused(page, deleteTrigger), 'Delete Team is keyboard reachable').toBe(true)
  469 |     if (await deleteTrigger.evaluate(element => element === document.activeElement)) await page.keyboard.press('Enter')
  470 |     const deleteDialog = page.getByRole('dialog')
  471 |     await expect(deleteDialog).toBeVisible()
  472 |     await expectSemanticIntegrity(page, 'Delete Team layer')
  473 |     await page.keyboard.press('/')
  474 |     await page.keyboard.press('Control+K')
  475 |     await expect.soft(page.getByTestId('command-center'), 'Delete dialog suppresses command-center shortcuts').toHaveCount(0)
  476 |     await page.keyboard.press('Escape')
  477 |     await expect(deleteDialog).toHaveCount(0)
  478 |     await expect.soft(deleteTrigger, 'Canceling delete restores the destructive trigger').toBeFocused()
  479 |     const settingsTabs = page.locator('.settings-page > .wm-tabs > .wm-tab-list')
  480 |     await exerciseTablist(settingsTabs, 'Settings tabs')
  481 |     await page.keyboard.press('End')
  482 |     await expect.soft(page.locator('.settings-page > header h1'), 'Embedded Operations retains Settings h1').toHaveCount(1)
  483 |     await expect.soft(page.locator('.settings-tab-heading > h2'), 'Embedded Operations owns h2').toHaveCount(1)
  484 |     await expectSemanticIntegrity(page, 'Embedded Operations panel')
  485 | 
  486 |     await page.goto('/operations#operations-runs')
  487 |     const runsWrap = page.getByTestId('operations-table-scroll')
  488 |     await expect(runsWrap).toBeVisible()
  489 |     evidence.operationsSkip = await expectSkipJourney(page, 'Standalone Operations', 'en')
  490 |     evidence.operations = await expectSemanticPage(page, 'Standalone Operations')
  491 |     evidence.operationsGeometry = await expectStandaloneOperationsGeometry(page, '1920 Standalone Operations', 24)
  492 |     await expectNativeTable(runsWrap, 6, 'Operations Runs')
  493 |     await expect.soft(runsWrap.locator('caption'), 'Runs has a native caption').toHaveCount(1)
  494 |     const runRow = page.getByTestId(`run-row-${accessibilityIds.run}`)
  495 |     await expect.soft(runRow, 'Runs fixture is non-empty').toBeVisible()
  496 |     const errorReference = await runRow.getAttribute('aria-describedby')
  497 |     expect.soft(errorReference, 'Failed Run describes its error row').toBeTruthy()
  498 |     if (errorReference) await expect.soft(page.locator(`#${errorReference}`), 'Run error description ID resolves').toContainText('deterministic provider')
  499 |     await expect.soft(runRow.getByRole('link'), 'Run Session uses a native link').toHaveAttribute('href', `/agent-sessions/${accessibilityIds.session}`)
  500 | 
  501 |     fixture.expectNoUnexpected()
  502 |     evidence.requests = fixture.requests
  503 |     await attachScreenshot(testInfo, page, 'accessibility-desktop-english')
  504 |     await attachJson(testInfo, 'accessibility-desktop-english', evidence)
  505 |   })
  506 | })
  507 | 
  508 | test.describe('Task 6.6 phone Chinese keyboard and semantic journey', () => {
  509 |   test.use({ viewport: { width: 390, height: 844 } })
  510 | 
```