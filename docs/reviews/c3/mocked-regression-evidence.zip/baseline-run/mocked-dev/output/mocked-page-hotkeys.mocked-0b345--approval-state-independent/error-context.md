# Instructions

- Following Playwright test failed.
- Explain why, be concise, respect Playwright best practices.
- Provide a snippet of code with the fix, if possible.

# Test info

- Name: mocked\page-hotkeys.mocked.spec.ts >> page hotkeys at 1920px >> wraps Agent links, preserves native controls and keeps focus, Peek and approval state independent
- Location: e2e\mocked\page-hotkeys.mocked.spec.ts:278:5

# Error details

```
Error: expect(locator).toHaveCount(expected) failed

Locator:  locator('[data-agent-roving-link="true"]')
Expected: 2
Received: 0
Timeout:  10000ms

Call log:
  - Expect "toHaveCount" with timeout 10000ms
  - waiting for locator('[data-agent-roving-link="true"]')
    24 × locator resolved to 0 elements
       - unexpected value "0"

```

# Page snapshot

```yaml
- generic [ref=e1]:
  - button "Open Next.js Dev Tools" [ref=e7] [cursor=pointer]:
    - img [ref=e8]
  - alert [ref=e11]
  - generic [ref=e12]:
    - link "跳到主要内容" [ref=e13] [cursor=pointer]:
      - /url: "#workmesh-main"
    - complementary "主导航" [ref=e14]:
      - generic [ref=e15]:
        - strong [ref=e17]: WorkMesh
        - generic [ref=e18]: Alex Morgan
      - button "收起导航栏" [expanded] [ref=e19] [cursor=pointer]:
        - img [ref=e20]
        - generic [ref=e22]: 收起导航栏
      - navigation "工作区导航" [ref=e23]:
        - generic [ref=e24]:
          - paragraph [ref=e25]: 工作台
          - link "工作台" [ref=e26] [cursor=pointer]:
            - /url: /workbench
            - img [ref=e28]
            - generic [ref=e30]: 工作台
          - link "我的工作" [ref=e31] [cursor=pointer]:
            - /url: /?view=home
            - img [ref=e33]
            - generic [ref=e35]: 我的工作
          - link "Issues" [ref=e36] [cursor=pointer]:
            - /url: /?view=my-work
            - img [ref=e38]
            - generic [ref=e40]: Issues
          - link "指南" [ref=e41] [cursor=pointer]:
            - /url: /?view=guidance
            - img [ref=e43]
            - generic [ref=e45]: 指南
        - generic [ref=e46]:
          - paragraph [ref=e47]: 治理
          - link "需要我处理" [ref=e48] [cursor=pointer]:
            - /url: /?view=inbox
            - img [ref=e50]
            - generic [ref=e52]: 需要我处理
          - link "Session" [ref=e53] [cursor=pointer]:
            - /url: /?view=sessions
            - img [ref=e55]
            - generic [ref=e57]: Session
          - link "恢复中心" [ref=e58] [cursor=pointer]:
            - /url: /?view=recovery
            - img [ref=e60]
            - generic [ref=e62]: 恢复中心
          - link "项目" [ref=e63] [cursor=pointer]:
            - /url: /?view=projects
            - img [ref=e65]
            - generic [ref=e67]: 项目
          - link "智能体" [ref=e68] [cursor=pointer]:
            - /url: /agents
            - img [ref=e70]
            - generic [ref=e72]: 智能体
        - generic [ref=e73]:
          - paragraph [ref=e74]: 运营
          - link "运营" [ref=e75] [cursor=pointer]:
            - /url: /operations
            - img [ref=e77]
            - generic [ref=e79]: 运营
      - navigation "管理导航" [ref=e80]:
        - link "设置" [ref=e81] [cursor=pointer]:
          - /url: /settings
          - img [ref=e83]
          - generic [ref=e85]: 设置
      - generic [ref=e87]:
        - button "退出登录" [ref=e88] [cursor=pointer]:
          - img [ref=e90]
          - generic [ref=e92]: 退出登录
        - generic [ref=e93]: v1.0.0 · 构建 project-work-preview · 数据库架构 24
    - generic [ref=e94]:
      - banner [ref=e95]:
        - paragraph [ref=e96]:
          - generic [ref=e97]: 人类控制面
        - button "搜索" [ref=e99] [cursor=pointer]:
          - img [ref=e101]
          - generic [ref=e103]:
            - generic [ref=e104]: 搜索
            - generic [ref=e105]: Ctrl K
        - generic [ref=e106]:
          - button "切换到浅色主题" [ref=e107]:
            - img [ref=e108]
          - generic [ref=e110]:
            - group "语言" [ref=e111]:
              - button "中" [pressed] [ref=e112]
              - button "EN" [ref=e113]
            - generic "正在重新连接" [ref=e114]:
              - generic [ref=e115]: 正在重新连接
      - main [ref=e116]:
        - generic [ref=e117]:
          - generic [ref=e118]:
            - generic [ref=e119]:
              - paragraph [ref=e120]: 人类控制面
              - heading "智能体" [level=1] [ref=e121]
              - paragraph [ref=e122]: 监控委派工作、处理审批，并在不接触凭据的情况下诊断连接。
            - button "刷新" [ref=e123] [cursor=pointer]:
              - generic [ref=e124]: 刷新
          - alert [ref=e125]:
            - generic [ref=e127]:
              - heading "智能体工作区需要关注" [level=2] [ref=e128]
              - paragraph [ref=e129]: "[ { \"code\": \"invalid_type\", \"expected\": \"string\", \"received\": \"undefined\", \"path\": [ \"icon\" ], \"message\": \"Required\" }, { \"code\": \"invalid_type\", \"expected\": \"string\", \"received\": \"undefined\", \"path\": [ \"endpoint_url\" ], \"message\": \"Required\" }, { \"code\": \"invalid_type\", \"expected\": \"array\", \"received\": \"undefined\", \"path\": [ \"output_artifact_types\" ], \"message\": \"Required\" }, { \"code\": \"invalid_type\", \"expected\": \"object\", \"received\": \"undefined\", \"path\": [ \"metadata\" ], \"message\": \"Required\" }, { \"expected\": \"'active' | 'archived'\", \"received\": \"undefined\", \"code\": \"invalid_type\", \"path\": [ \"lifecycle_status\" ], \"message\": \"Required\" }, { \"code\": \"invalid_type\", \"expected\": \"string\", \"received\": \"undefined\", \"path\": [ \"archived_at\" ], \"message\": \"Required\" }, { \"code\": \"invalid_type\", \"expected\": \"string\", \"received\": \"undefined\", \"path\": [ \"archived_by_actor_id\" ], \"message\": \"Required\" }, { \"code\": \"invalid_type\", \"expected\": \"string\", \"received\": \"undefined\", \"path\": [ \"archived_reason\" ], \"message\": \"Required\" }, { \"code\": \"invalid_type\", \"expected\": \"string\", \"received\": \"undefined\", \"path\": [ \"created_at\" ], \"message\": \"Required\" }, { \"code\": \"invalid_type\", \"expected\": \"string\", \"received\": \"undefined\", \"path\": [ \"updated_at\" ], \"message\": \"Required\" } ]"
            - button "重试" [ref=e130] [cursor=pointer]:
              - generic [ref=e131]: 重试
          - generic [ref=e132]:
            - tablist "智能体工作区分区" [ref=e133]:
              - tab "智能体" [selected] [ref=e134]:
                - generic [ref=e135]: 智能体
              - tab "连接" [ref=e136]:
                - generic [ref=e137]: 连接
              - tab "自动接入策略" [ref=e138]:
                - generic [ref=e139]: 自动接入策略
              - tab "已归档" [ref=e140]:
                - generic [ref=e141]: 已归档
            - tabpanel "智能体" [ref=e142]:
              - region "注册表" [ref=e143]:
                - generic [ref=e144]:
                  - generic [ref=e145]:
                    - paragraph [ref=e146]: 注册表
                    - heading "智能体" [level=2] [ref=e147]
                    - paragraph [ref=e148]: 先检查定义；仅在需要审阅时展开团队权限。
                  - generic [ref=e149]:
                    - button "全部" [ref=e150]
                    - button "活跃" [ref=e151]
                    - button "停用" [ref=e152]
                - group "智能体筛选" [ref=e153]:
                  - generic [ref=e154]:
                    - generic [ref=e155]: 名称
                    - searchbox "名称" [active] [ref=e156]
                  - generic [ref=e157]:
                    - generic [ref=e158]: 团队
                    - combobox "团队" [ref=e159]:
                      - option "全部团队" [selected]
                      - option "WorkMesh Product"
                  - generic [ref=e160]:
                    - generic [ref=e161]: 能力
                    - combobox "能力" [ref=e162]:
                      - option "全部能力" [selected]
                  - generic [ref=e163]:
                    - generic [ref=e164]: 状态
                    - combobox "状态" [ref=e165]:
                      - option "全部" [selected]
                      - option "活跃"
                      - option "停用"
```

# Test source

```ts
  187 |       await expect.poll(() => new URL(page.url()).searchParams.get('search')).toBeNull()
  188 |       await page.evaluate(() => (document.activeElement as HTMLElement | null)?.blur())
  189 | 
  190 |       const contextUrl = page.url()
  191 |       const select = page.locator('select:visible').first()
  192 |       await select.focus()
  193 |       await pressChord(page, 'a')
  194 |       await expect(select).toBeFocused()
  195 |       expect(page.url()).toBe(contextUrl)
  196 | 
  197 |       const button = page.getByTestId('command-center-trigger')
  198 |       await button.focus()
  199 |       await pressChord(page, 's')
  200 |       await expect(button).toBeFocused()
  201 |       expect(page.url()).toBe(contextUrl)
  202 | 
  203 |       const link = page.locator('a:visible').first()
  204 |       await link.focus()
  205 |       await pressChord(page, 'a')
  206 |       await expect(link).toBeFocused()
  207 |       expect(page.url()).toBe(contextUrl)
  208 | 
  209 |       await page.evaluate(() => {
  210 |         const editable = document.createElement('div')
  211 |         editable.contentEditable = 'plaintext-only'
  212 |         editable.dataset.hotkeyContext = 'contenteditable'
  213 |         editable.tabIndex = 0
  214 |         editable.textContent = 'Editable shortcut guard'
  215 |         document.body.append(editable)
  216 |       })
  217 |       const editable = page.locator('[data-hotkey-context="contenteditable"]')
  218 |       await editable.focus()
  219 |       await pressChord(page, 's')
  220 |       await expect(editable).toBeFocused()
  221 |       expect(page.url()).toBe(contextUrl)
  222 |       await editable.evaluate(element => element.remove())
  223 |       await page.evaluate(() => (document.activeElement as HTMLElement | null)?.blur())
  224 | 
  225 |       const stableHomeUrl = page.url()
  226 |       await page.keyboard.press('g')
  227 |       await page.keyboard.press('z')
  228 |       expect(page.url()).toBe(stableHomeUrl)
  229 |       await page.keyboard.press('g')
  230 |       await page.waitForTimeout(1_050)
  231 |       await page.keyboard.press('a')
  232 |       expect(page.url()).toBe(stableHomeUrl)
  233 | 
  234 |       await pressChord(page, 'a')
  235 |       await expect(page).toHaveURL(`${webUrl}/agents`)
  236 | 
  237 |       await page.goto('/?view=my-work')
  238 |       await page.keyboard.press('/')
  239 |       await expect(page.getByTestId('command-center')).toHaveCount(1)
  240 |       await page.evaluate(() => (document.activeElement as HTMLElement | null)?.blur())
  241 |       const modalUrl = page.url()
  242 |       await pressChord(page, 'a')
  243 |       expect(page.url()).toBe(modalUrl)
  244 |       await page.keyboard.press('f')
  245 |       expect(page.url()).toBe(modalUrl)
  246 |       await page.keyboard.press('/')
  247 |       await expect(page.getByTestId('command-center')).toHaveCount(1)
  248 |       await page.getByRole('button', { name: /关闭|Close/ }).click()
  249 |       await page.keyboard.press('Control+K')
  250 |       await expect(page.getByTestId('command-center')).toHaveCount(1)
  251 |       await page.getByRole('button', { name: /关闭|Close/ }).click()
  252 | 
  253 |       for (const path of ['/?view=inbox', '/?view=guidance', '/settings']) {
  254 |         await page.goto(path)
  255 |         await expect(page.locator('[data-hotkey-filter="true"]')).toHaveCount(0)
  256 |         const anchor = page.locator('a:visible').first()
  257 |         await anchor.focus()
  258 |         await page.keyboard.press('f')
  259 |         await expect(anchor).toBeFocused()
  260 |       }
  261 | 
  262 |       await page.goto('/operations')
  263 |       const operationsSearch = page.locator('[data-hotkey-filter="true"]')
  264 |       await expect(operationsSearch).toHaveCount(1)
  265 |       await page.keyboard.press('f')
  266 |       await expect(operationsSearch).toBeFocused()
  267 |       await attachGeometry(testInfo, `operations-filter-${viewport.width}`, operationsSearch)
  268 | 
  269 |       await page.evaluate(() => (document.activeElement as HTMLElement | null)?.blur())
  270 |       await pressChord(page, 's')
  271 |       await expect(page).toHaveURL(`${webUrl}/settings`)
  272 |       await page.waitForTimeout(300)
  273 |       await page.evaluate(() => (document.activeElement as HTMLElement | null)?.blur())
  274 |       await pressChord(page, 'i')
  275 |       await expect(page).toHaveURL(`${webUrl}/?view=my-work`)
  276 |     })
  277 | 
  278 |     test('wraps Agent links, preserves native controls and keeps focus, Peek and approval state independent', async ({ page }, testInfo) => {
  279 |       await installHotkeyFixtures(page)
  280 |       await page.goto('/agents')
  281 |       const links = page.locator('[data-agent-roving-link="true"]')
  282 |       const agentSearch = page.locator('[data-hotkey-filter="true"]')
  283 |       await expect(agentSearch).toHaveCount(1)
  284 |       await page.evaluate(() => (document.activeElement as HTMLElement | null)?.blur())
  285 |       await page.keyboard.press('f')
  286 |       await expect(agentSearch).toBeFocused()
> 287 |       await expect(links).toHaveCount(2)
      |                           ^ Error: expect(locator).toHaveCount(expected) failed
  288 |       await expect(links.nth(0)).toHaveAttribute('tabindex', '0')
  289 |       await expect(links.nth(1)).toHaveAttribute('tabindex', '-1')
  290 | 
  291 |       for (const tab of ['sessions', 'approvals'] as const) {
  292 |         await chooseAgentsTab(page, tab)
  293 |         await expect(page.locator('[data-hotkey-filter="true"]')).toHaveCount(0)
  294 |         await page.evaluate(() => (document.activeElement as HTMLElement | null)?.blur())
  295 |         await page.keyboard.press('f')
  296 |         expect(await page.evaluate(() => document.activeElement === document.body)).toBe(true)
  297 |       }
  298 |       await chooseAgentsTab(page, 'agents')
  299 | 
  300 |       await links.nth(0).focus()
  301 |       await page.keyboard.press('j')
  302 |       await expect(links.nth(1)).toBeFocused()
  303 |       await page.keyboard.press('ArrowDown')
  304 |       await expect(links.nth(0)).toBeFocused()
  305 |       await page.keyboard.press('k')
  306 |       await expect(links.nth(1)).toBeFocused()
  307 |       await page.keyboard.press('ArrowUp')
  308 |       await expect(links.nth(0)).toBeFocused()
  309 | 
  310 |       if (viewport.width === 1920) {
  311 |         await chooseAgentsTab(page, 'approvals')
  312 |         const approval = page.getByRole('checkbox').last()
  313 |         await approval.check()
  314 |         await chooseAgentsTab(page, 'agents')
  315 |         await links.nth(0).focus()
  316 |         await page.keyboard.press('Space')
  317 |         await expect(page.locator('.agent-peek')).toBeVisible()
  318 |         await page.keyboard.press('Escape')
  319 |         await expect(links.nth(0)).toBeFocused()
  320 |         await page.keyboard.press('Escape')
  321 |         await chooseAgentsTab(page, 'approvals')
  322 |         await expect(page.getByRole('checkbox').last()).not.toBeChecked()
  323 |         await chooseAgentsTab(page, 'agents')
  324 |       }
  325 | 
  326 |       await links.nth(0).focus()
  327 |       await page.keyboard.press('Space')
  328 |       await expect(page.locator('.agent-peek')).toBeVisible()
  329 |       await page.keyboard.press('/')
  330 |       await expect(page.getByTestId('command-center')).toHaveCount(0)
  331 |       await page.keyboard.press('Escape')
  332 |       await expect(links.nth(0)).toBeFocused()
  333 | 
  334 |       const firstCard = page.getByTestId('agent-registry-agent/one')
  335 |       const manage = firstCard.getByRole('button')
  336 |       await manage.focus()
  337 |       await page.keyboard.press('Space')
  338 |       await expect(page.locator('.team-access-drawer')).toBeVisible()
  339 |       await expect(page.locator('.agent-peek')).toHaveCount(0)
  340 |       await page.keyboard.press('Escape')
  341 |       await expect(manage).toBeFocused()
  342 | 
  343 |       const search = page.locator('[data-hotkey-filter="true"]')
  344 |       await search.fill('Percent')
  345 |       await expect(links).toHaveCount(1)
  346 |       await expect(links.first()).toHaveAttribute('data-agent-id', 'agent%two')
  347 |       await expect(links.first()).toHaveAttribute('tabindex', '0')
  348 |       await search.fill('no matching agent')
  349 |       await expect(links).toHaveCount(0)
  350 |       await search.fill('')
  351 |       await expect(links).toHaveCount(2)
  352 | 
  353 |       const targetIndex = viewport.width === 390 ? 0 : 1
  354 |       const target = links.nth(targetIndex)
  355 |       const expectedPath = targetIndex === 0 ? '/agents/agent%2Fone' : '/agents/agent%25two'
  356 |       await expect(target).toHaveAttribute('href', expectedPath)
  357 |       await target.focus()
  358 |       await attachGeometry(testInfo, `agent-roving-${viewport.width}`, target)
  359 |       await page.keyboard.press('Enter')
  360 |       await expect(page).toHaveURL(`${webUrl}${expectedPath}`)
  361 |     })
  362 |   })
  363 | }
  364 | 
```