# Instructions

- Following Playwright test failed.
- Explain why, be concise, respect Playwright best practices.
- Provide a snippet of code with the fix, if possible.

# Test info

- Name: mocked\operations-ux.mocked.spec.ts >> blocks busy destructive interaction and focuses a surviving context after committed deletion
- Location: e2e\mocked\operations-ux.mocked.spec.ts:1136:1

# Error details

```
Error: expect(received).toBe(expected) // Object.is equality

Expected: 0
Received: 3
```

# Page snapshot

```yaml
- generic [ref=e1]:
  - button "Open Next.js Dev Tools" [ref=e7] [cursor=pointer]:
    - img [ref=e8]
  - alert [ref=e11]
  - generic [ref=e12]:
    - link "Skip to content" [ref=e13] [cursor=pointer]:
      - /url: "#workmesh-main"
    - complementary "Main navigation" [ref=e14]:
      - generic [ref=e15]:
        - strong [ref=e17]: WorkMesh
        - generic [ref=e18]: Alex Morgan
      - button "Collapse sidebar" [expanded] [ref=e19] [cursor=pointer]:
        - img [ref=e20]
        - generic [ref=e22]: Collapse sidebar
      - generic [ref=e24]:
        - text: Team
        - combobox "Current team" [ref=e25]:
          - option "No team" [disabled]
          - option "Runtime Reliability (RUN)" [selected]
          - option "Platform (PLAT)"
      - navigation "Workspace navigation" [ref=e26]:
        - link "Back to Issues" [ref=e27] [cursor=pointer]:
          - /url: /?view=my-work
          - img [ref=e29]
          - generic [ref=e31]: Back to Issues
      - navigation "Administration navigation" [ref=e32]:
        - link "Settings" [ref=e33] [cursor=pointer]:
          - /url: /settings
          - img [ref=e35]
          - generic [ref=e37]: Settings
      - generic [ref=e39]:
        - button "Sign out" [ref=e40] [cursor=pointer]:
          - img [ref=e42]
          - generic [ref=e44]: Sign out
        - generic [ref=e45]: v1.0.0 · build project-work-preview · schema 24
    - generic [ref=e46]:
      - banner [ref=e47]:
        - paragraph [ref=e48]:
          - generic [ref=e49]: Workspace
        - button "Search" [ref=e51] [cursor=pointer]:
          - img [ref=e53]
          - generic [ref=e55]:
            - generic [ref=e56]: Search
            - generic [ref=e57]: Ctrl K
        - generic [ref=e58]:
          - button "Switch to the light theme" [ref=e59]:
            - img [ref=e60]
          - group "Language" [ref=e63]:
            - button "中" [ref=e64]
            - button "EN" [pressed] [ref=e65]
      - main [ref=e66]:
        - generic [ref=e67]:
          - generic [ref=e69]:
            - heading "Settings" [level=1] [ref=e70]
            - paragraph [ref=e71]: Workspace administration stays separate from daily planning.
          - generic [ref=e72]:
            - tablist "Settings sections" [ref=e73]:
              - tab "Workspace" [selected] [ref=e74]:
                - generic [ref=e75]: Workspace
            - tabpanel "Workspace" [ref=e76]:
              - generic [ref=e77]:
                - region "Teams" [ref=e78]:
                  - paragraph [ref=e79]: Workspace structure
                  - heading "Teams" [level=2] [ref=e80]
                  - generic [ref=e81]:
                    - generic [ref=e82]:
                      - text: Team name
                      - textbox "Team name" [ref=e83]
                    - generic [ref=e84]:
                      - text: Team key
                      - textbox "Team key" [ref=e85]:
                        - /placeholder: ENG
                    - button "Create team" [ref=e86] [cursor=pointer]:
                      - img [ref=e88]
                      - generic [ref=e90]: Create team
                - region "Team details" [ref=e91]:
                  - paragraph [ref=e92]: Selected team
                  - heading "Team details" [level=2] [ref=e93]
                  - generic [ref=e94]:
                    - generic [ref=e95]:
                      - text: Team name
                      - textbox "Team name" [ref=e96]: Runtime Reliability
                    - generic [ref=e97]:
                      - text: Team key
                      - textbox "Team key" [ref=e98]: RUN
                    - button "Save changes" [ref=e99] [cursor=pointer]:
                      - img [ref=e101]
                      - generic [ref=e103]: Save changes
                  - generic [ref=e104]:
                    - generic [ref=e105]:
                      - strong [ref=e106]: Delete team
                      - paragraph [ref=e107]: Remove this Team from active navigation; associated work is retained but unavailable.
                    - button "Delete team" [ref=e108] [cursor=pointer]:
                      - img [ref=e110]
                      - generic [ref=e112]: Delete team
                - region "Workflow states" [ref=e113]:
                  - paragraph [ref=e114]: Team workflow
                  - heading "Workflow states" [level=2] [ref=e115]
                  - article [ref=e117]:
                    - generic [ref=e120]:
                      - strong [ref=e121]: Ready
                      - generic [ref=e122]: Planned
                    - button "Edit status Ready" [ref=e123] [cursor=pointer]:
                      - img [ref=e125]
                      - generic [ref=e127]: Edit
                  - generic [ref=e128]:
                    - generic [ref=e129]:
                      - text: Status name
                      - textbox "Status name" [ref=e130]
                    - generic [ref=e131]:
                      - text: Category
                      - combobox "Category" [ref=e132]:
                        - option "Backlog"
                        - option "Planned" [selected]
                        - option "Started"
                        - option "Completed"
                        - option "Canceled"
                    - group "Status color" [ref=e133]:
                      - generic [ref=e134]: Status color
                      - generic [ref=e135]:
                        - generic [ref=e136] [cursor=pointer]:
                          - radio "Neutral" [checked] [ref=e137]
                          - generic [ref=e139]: Neutral
                        - generic [ref=e140] [cursor=pointer]:
                          - radio "Blue" [ref=e141]
                          - generic [ref=e143]: Blue
                        - generic [ref=e144] [cursor=pointer]:
                          - radio "Green" [ref=e145]
                          - generic [ref=e147]: Green
                        - generic [ref=e148] [cursor=pointer]:
                          - radio "Amber" [ref=e149]
                          - generic [ref=e151]: Amber
                        - generic [ref=e152] [cursor=pointer]:
                          - radio "Red" [ref=e153]
                          - generic [ref=e155]: Red
                        - generic [ref=e156] [cursor=pointer]:
                          - radio "Custom" [ref=e157]
                          - generic [ref=e159]: Custom
                    - button "Create status" [ref=e160] [cursor=pointer]:
                      - img [ref=e162]
                      - generic [ref=e164]: Create status
              - region "Model service connections" [ref=e165]:
                - paragraph [ref=e166]: Agent workbench
                - heading "Model service connections" [level=2] [ref=e167]
                - paragraph [ref=e168]: Manage Chat Completions and Responses providers, credentials, and models.
                - link "Open connection settings" [ref=e169] [cursor=pointer]:
                  - /url: /settings/agent-workbench
          - dialog "Delete Team" [ref=e171]:
            - generic [ref=e172]:
              - generic [ref=e173]:
                - heading "Delete Team" [level=2] [ref=e174]
                - paragraph [ref=e175]: This Team leaves active navigation; associated work is retained but unavailable.
              - button "Close Delete Team" [active] [ref=e176] [cursor=pointer]:
                - img [ref=e178]
                - generic [ref=e180]: Close
            - generic [ref=e182]:
              - generic [ref=e183]:
                - generic [ref=e184]:
                  - term [ref=e185]: Team name
                  - definition [ref=e186]: Runtime Reliability
                - generic [ref=e187]:
                  - term [ref=e188]: Team key
                  - definition [ref=e189]: RUN
              - paragraph [ref=e190]: At least one active Team must remain.
              - generic [ref=e191]:
                - button "Cancel" [ref=e192] [cursor=pointer]:
                  - generic [ref=e193]: Cancel
                - button "Delete Team Runtime Reliability" [ref=e194] [cursor=pointer]:
                  - generic [ref=e195]: Delete team
```

# Test source

```ts
  1098 | 
  1099 |   const dialogContent = dialog.locator('.ui-dialog-content')
  1100 |   await dialogContent.evaluate(element => { element.scrollTop = 0 })
  1101 |   const geometry = await measureDeleteTeamDialogGeometry(page)
  1102 |   expect(geometry.viewport).toEqual({ width: 390, height: 844 })
  1103 |   expect(geometry.document.scrollWidth).toBe(geometry.document.clientWidth)
  1104 |   expect(geometry.dialog.left).toBeGreaterThanOrEqual(-1)
  1105 |   expect(geometry.dialog.right).toBeLessThanOrEqual(391)
  1106 |   expect(geometry.dialog.height).toBe(844)
  1107 |   expect(geometry.contentScroll.scrollHeight).toBeGreaterThan(geometry.contentScroll.clientHeight)
  1108 |   await dialog.focus()
  1109 |   await removeNextDevelopmentIndicatorForEvidence(page)
  1110 |   const topScreenshotPath = testInfo.outputPath('task-5.4-delete-dialog-narrow-top-pass.png')
  1111 |   await page.screenshot({ path: topScreenshotPath })
  1112 |   await testInfo.attach('task-5.4-delete-dialog-narrow-top-pass', { contentType: 'image/png', path: topScreenshotPath })
  1113 |   const scrollMovement = await dialogContent.evaluate(element => {
  1114 |     const before = element.scrollTop
  1115 |     element.scrollTop = element.scrollHeight
  1116 |     return { after: element.scrollTop, before, maximum: element.scrollHeight - element.clientHeight }
  1117 |   })
  1118 |   expect(scrollMovement.before).toBe(0)
  1119 |   expect(scrollMovement.after).toBeGreaterThan(0)
  1120 |   expect(scrollMovement.after).toBe(scrollMovement.maximum)
  1121 |   await expect(dialog.getByRole('button', { name: 'Cancel' })).toBeInViewport()
  1122 |   expect(evidence).toEqual([
  1123 |     { bodyLength: 0, count: 1, idempotencyKeyPresent: true, ifMatch: '"revision-7"', path: '/api/v1/teams/team%2Fdelete-target', sameAsFirst: null },
  1124 |     { bodyLength: 0, count: 2, idempotencyKeyPresent: true, ifMatch: '"revision-7"', path: '/api/v1/teams/team%2Fdelete-target', sameAsFirst: true },
  1125 |     { bodyLength: 0, count: 3, idempotencyKeyPresent: true, ifMatch: '"revision-8"', path: '/api/v1/teams/team%2Fdelete-target', sameAsFirst: false },
  1126 |   ])
  1127 | 
  1128 |   const screenshotPath = testInfo.outputPath('task-5.4-delete-dialog-narrow-pass.png')
  1129 |   await page.screenshot({ path: screenshotPath })
  1130 |   await testInfo.attach('task-5.4-delete-dialog-narrow-pass', { contentType: 'image/png', path: screenshotPath })
  1131 |   const evidencePath = testInfo.outputPath('task-5.4-delete-dialog-retry-request-geometry-pass.json')
  1132 |   await writeFile(evidencePath, JSON.stringify({ geometry, requests: evidence, scrollMovement }, null, 2), 'utf8')
  1133 |   await testInfo.attach('task-5.4-delete-dialog-retry-request-geometry-pass', { contentType: 'application/json', path: evidencePath })
  1134 | })
  1135 | 
  1136 | test('blocks busy destructive interaction and focuses a surviving context after committed deletion', async ({ page }, testInfo) => {
  1137 |   const target = { id: 'team/delete-me', name: 'Runtime Reliability', key: 'RUN', revision: 11 } satisfies SettingsTeamFixture
  1138 |   const survivor = { id: 'team-survivor', name: 'Platform', key: 'PLAT', revision: 4 } satisfies SettingsTeamFixture
  1139 |   let deleted = false
  1140 |   let targetRevision = target.revision
  1141 |   let releaseDelete = deferred()
  1142 |   let lastPrivateKey = ''
  1143 |   const requestEvidence: Array<{
  1144 |     bodyLength: number
  1145 |     count: number
  1146 |     differentFromPrevious: boolean | null
  1147 |     idempotencyKeyPresent: boolean
  1148 |     ifMatch: string | undefined
  1149 |     path: string
  1150 |   }> = []
  1151 |   const statePaths: string[] = []
  1152 |   page.on('request', request => {
  1153 |     const path = new URL(request.url()).pathname
  1154 |     if (request.method() === 'GET' && /^\/api\/v1\/teams\/[^/]+\/states$/.test(path)) statePaths.push(path)
  1155 |   })
  1156 |   const dynamicTarget: SettingsTeamFixture = {
  1157 |     ...target,
  1158 |     get revision() { return targetRevision },
  1159 |   }
  1160 |   const pages = {
  1161 |     get first(): SettingsTeamPageFixture {
  1162 |       return { items: deleted ? [survivor] : [dynamicTarget, survivor], nextCursor: null }
  1163 |     },
  1164 |   }
  1165 |   await installOperationsRoutes(page, () => allOperationsFeatures, {
  1166 |     settingsDelete: async request => {
  1167 |       const key = request.headers()['idempotency-key'] ?? ''
  1168 |       requestEvidence.push({
  1169 |         bodyLength: request.postDataBuffer()?.byteLength ?? 0,
  1170 |         count: requestEvidence.length + 1,
  1171 |         differentFromPrevious: requestEvidence.length === 0 ? null : key !== lastPrivateKey,
  1172 |         idempotencyKeyPresent: key.length > 0,
  1173 |         ifMatch: request.headers()['if-match'],
  1174 |         path: new URL(request.url()).pathname,
  1175 |       })
  1176 |       lastPrivateKey = key
  1177 |       await releaseDelete.promise
  1178 |       deleted = true
  1179 |       return { status: 204 }
  1180 |     },
  1181 |     settingsStates: {
  1182 |       [target.id]: [{ id: 'state-target', name: 'Ready', category: 'planned', color: '#64748b', revision: 1 }],
  1183 |       [survivor.id]: [{ id: 'state-survivor', name: 'Ready', category: 'planned', color: '#64748b', revision: 1 }],
  1184 |     },
  1185 |     settingsTeamPages: pages,
  1186 |   })
  1187 | 
  1188 |   const geometries: Awaited<ReturnType<typeof measureDeleteTeamDialogGeometry>>[] = []
  1189 |   await page.setViewportSize({ width: 1920, height: 1080 })
  1190 |   await page.goto(`/settings?team=${encodeURIComponent(target.id)}&x=keep#team-settings-heading`)
  1191 |   await page.getByRole('button', { name: 'Delete team', exact: true }).click()
  1192 |   let dialog = page.getByRole('dialog', { name: 'Delete Team' })
  1193 |   const wideGeometry = await measureDeleteTeamDialogGeometry(page)
  1194 |   geometries.push(wideGeometry)
  1195 |   expect(wideGeometry.document.scrollWidth).toBe(wideGeometry.document.clientWidth)
  1196 |   expect(wideGeometry.dialog.width).toBeLessThanOrEqual(560)
  1197 |   expect(wideGeometry.centeredDelta).toBeLessThanOrEqual(2)
> 1198 |   expect(wideGeometry.overflowCount).toBe(0)
       |                                      ^ Error: expect(received).toBe(expected) // Object.is equality
  1199 |   await removeNextDevelopmentIndicatorForEvidence(page)
  1200 |   const wideScreenshotPath = testInfo.outputPath('task-5.4-delete-dialog-wide-pass.png')
  1201 |   await page.screenshot({ path: wideScreenshotPath })
  1202 |   await testInfo.attach('task-5.4-delete-dialog-wide-pass', { contentType: 'image/png', path: wideScreenshotPath })
  1203 | 
  1204 |   const confirm = dialog.getByRole('button', { name: 'Delete Team Runtime Reliability' })
  1205 |   await confirm.click()
  1206 |   await expect.poll(() => requestEvidence.length).toBe(1)
  1207 |   await expect(dialog.getByRole('status')).toHaveText('Deleting…')
  1208 |   await expect(dialog).toBeFocused()
  1209 |   await expect(dialog.getByRole('button', { name: 'Close Delete Team' })).toHaveCount(0)
  1210 |   await page.keyboard.press('Escape')
  1211 |   await expect(dialog).toBeVisible()
  1212 |   await dialog.locator('..').dispatchEvent('mousedown')
  1213 |   await expect(dialog).toBeVisible()
  1214 |   await page.keyboard.press('Tab')
  1215 |   await expect(dialog).toBeFocused()
  1216 |   await page.keyboard.press('Shift+Tab')
  1217 |   await expect(dialog).toBeFocused()
  1218 |   await confirm.evaluate(element => {
  1219 |     if (!(element instanceof HTMLButtonElement)) throw new Error('Delete confirmation button missing')
  1220 |     element.click()
  1221 |     element.dispatchEvent(new KeyboardEvent('keydown', { bubbles: true, key: 'Enter' }))
  1222 |     element.dispatchEvent(new KeyboardEvent('keydown', { bubbles: true, key: ' ' }))
  1223 |   })
  1224 |   expect(requestEvidence).toHaveLength(1)
  1225 | 
  1226 |   await page.evaluate(survivingTeamId => {
  1227 |     const selector = [...document.querySelectorAll<HTMLSelectElement>('.team-switcher select')]
  1228 |       .find(element => element.getBoundingClientRect().width > 0)
  1229 |     if (!selector) throw new Error('Visible Team selector missing')
  1230 |     selector.value = survivingTeamId
  1231 |     selector.dispatchEvent(new Event('change', { bubbles: true }))
  1232 |   }, survivor.id)
  1233 |   await expect(page).toHaveURL(new RegExp(`team=${survivor.id}`))
  1234 |   statePaths.length = 0
  1235 |   releaseDelete.resolve()
  1236 |   await expect(dialog).toHaveCount(0)
  1237 |   const desktopSelector = page.getByRole('combobox', { name: 'Current team' })
  1238 |   await expect(desktopSelector).toHaveValue(survivor.id)
  1239 |   await expect(desktopSelector).toBeFocused()
  1240 |   expect(statePaths).not.toContain('/api/v1/teams/team%2Fdelete-me/states')
  1241 |   await expect(page).toHaveURL(`${webUrl}/settings?team=${survivor.id}&x=keep#team-settings-heading`)
  1242 | 
  1243 |   deleted = false
  1244 |   targetRevision = 12
  1245 |   releaseDelete = deferred()
  1246 |   await page.setViewportSize({ width: 390, height: 844 })
  1247 |   await page.goto(`/settings?team=${encodeURIComponent(target.id)}&x=keep#team-settings-heading`)
  1248 |   await expect(page.locator('.mobile-navigation')).not.toHaveAttribute('open', '')
  1249 |   await page.getByRole('button', { name: 'Delete team', exact: true }).click()
  1250 |   dialog = page.getByRole('dialog', { name: 'Delete Team' })
  1251 |   const narrowGeometry = await measureDeleteTeamDialogGeometry(page)
  1252 |   geometries.push(narrowGeometry)
  1253 |   expect(narrowGeometry.document.scrollWidth).toBe(narrowGeometry.document.clientWidth)
  1254 |   expect(narrowGeometry.dialog.width).toBe(390)
  1255 |   await dialog.getByRole('button', { name: 'Delete Team Runtime Reliability' }).click()
  1256 |   await expect.poll(() => requestEvidence.length).toBe(2)
  1257 |   releaseDelete.resolve()
  1258 |   await expect(dialog).toHaveCount(0)
  1259 |   await expect(page).toHaveURL(`${webUrl}/settings?team=${survivor.id}&x=keep#team-settings-heading`)
  1260 |   const teamsHeading = page.getByRole('heading', { name: 'Teams' })
  1261 |   await expect(teamsHeading).toBeFocused()
  1262 |   await expect(page.locator('.mobile-navigation')).not.toHaveAttribute('open', '')
  1263 |   await expect(page.locator('.team-switcher select:focus')).toHaveCount(0)
  1264 | 
  1265 |   expect(requestEvidence).toEqual([
  1266 |     { bodyLength: 0, count: 1, differentFromPrevious: null, idempotencyKeyPresent: true, ifMatch: '"revision-11"', path: '/api/v1/teams/team%2Fdelete-me' },
  1267 |     { bodyLength: 0, count: 2, differentFromPrevious: true, idempotencyKeyPresent: true, ifMatch: '"revision-12"', path: '/api/v1/teams/team%2Fdelete-me' },
  1268 |   ])
  1269 |   const evidencePath = testInfo.outputPath('task-5.4-delete-dialog-success-request-geometry-pass.json')
  1270 |   await writeFile(evidencePath, JSON.stringify({ geometries, requests: requestEvidence }, null, 2), 'utf8')
  1271 |   await testInfo.attach('task-5.4-delete-dialog-success-request-geometry-pass', { contentType: 'application/json', path: evidencePath })
  1272 | })
  1273 | 
  1274 | test('keeps all-enabled navigation wide, sticky, focus-owned, and shared with Settings', async ({ page }) => {
  1275 |   test.info().annotations.push({ type: 'viewport', description: '1920x1080 wide-PC acceptance' })
  1276 |   await page.setViewportSize({ width: 1920, height: 1080 })
  1277 |   await installOperationsRoutes(page, () => allOperationsFeatures)
  1278 |   expect(canonicalFeatures).toHaveLength(11)
  1279 | 
  1280 |   await page.goto('/operations')
  1281 |   await expectWideNavigation(page)
  1282 | 
  1283 |   const standaloneNavigation = page.getByTestId('operations-section-navigation')
  1284 |   await standaloneNavigation.evaluate(element => element.scrollIntoView({ block: 'start' }))
  1285 |   await page.evaluate(() => window.scrollBy(0, 160))
  1286 |   await expect.poll(async () => Math.round((await standaloneNavigation.boundingBox())?.y ?? -1)).toBe(48)
  1287 | 
  1288 |   await page.goto('/settings?tab=operations')
  1289 |   await expectWideNavigation(page)
  1290 |   await expect(page).toHaveURL(/tab=operations.*#operations-runs$/)
  1291 | })
  1292 | 
  1293 | test('keeps a deferred collection in loading state until its first loaded page arrives', async ({ page }) => {
  1294 |   const cycles = deferred()
  1295 |   await installOperationsRoutes(page, () => allOperationsFeatures, {
  1296 |     collectionDeferred: { '/api/v1/cycles': cycles.promise },
  1297 |   })
  1298 |   await page.goto('/operations?opsQuery=Current')
```