# Instructions

- Following Playwright test failed.
- Explain why, be concise, respect Playwright best practices.
- Provide a snippet of code with the fix, if possible.

# Test info

- Name: mocked\loading-states.mocked.spec.ts >> Task 6.4 Settings loading authority >> separates Team and State initialization and retains the State surface through refresh failure
- Location: e2e\mocked\loading-states.mocked.spec.ts:621:3

# Error details

```
Error: expect(locator).toBeVisible() failed

Locator: locator('.settings-page').locator('.settings-loading-skeleton .skeleton-list')
Expected: visible
Timeout: 10000ms
Error: element(s) not found

Call log:
  - Expect "toBeVisible" with timeout 10000ms
  - waiting for locator('.settings-page').locator('.settings-loading-skeleton .skeleton-list')

```

```yaml
- alert
- main:
  - heading "Page not found" [level=1]
  - paragraph: The page you are looking for does not exist or has been moved.
  - link "Back to home":
    - /url: /
```

# Test source

```ts
  535 | test.describe('Task 6.4 Agent secondary surfaces', () => {
  536 |   test.use({ viewport: { height: 900, width: 1440 } })
  537 | 
  538 |   test('owns Sessions, Diagnostics, Connections and Approval states without stale actions', async ({ page }) => {
  539 |     const routes = new RouteScenarios()
  540 |     await routes.install(page)
  541 |     await page.context().addCookies([{ name: 'workmesh_locale', value: 'en', url: webUrl }])
  542 | 
  543 |     const sessionsPath = '/api/v1/agent-sessions?limit=100'
  544 |     const connectionsPath = '/api/v1/agent-connections?limit=50'
  545 |     const pendingPath = '/api/v1/approvals?status=pending&limit=100'
  546 |     const historyPath = '/api/v1/approvals?status=approved&limit=100'
  547 |     const sessionsPending = deferredResponse()
  548 |     const connectionsPending = deferredResponse()
  549 |     const attentionPending = deferredResponse()
  550 |     const pendingApprovals = deferredResponse()
  551 |     const historyPending = deferredResponse()
  552 |     routes.set('/api/v1/agents', { body: { items: [browserAgent], nextCursor: null } })
  553 |     routes.set(sessionsPath, sessionsPending.promise)
  554 |     routes.set(connectionsPath, connectionsPending.promise)
  555 |     routes.set('/api/v1/human-attention', attentionPending.promise)
  556 |     routes.set(pendingPath, pendingApprovals.promise)
  557 |     routes.set(historyPath, historyPending.promise)
  558 |     await page.goto('/agents?tab=sessions&approvalView=history&approvalStatus=approved', { waitUntil: 'domcontentloaded' })
  559 | 
  560 |     const sessions = page.getByRole('region', { name: 'Sessions', exact: true })
  561 |     const diagnostics = page.getByRole('region', { name: 'Diagnostics', exact: true })
  562 |     const connections = page.getByRole('region', { name: 'Connections', exact: true })
  563 |     await expect(sessions.locator('.skeleton-list')).toBeVisible()
  564 |     await expect(diagnostics.locator('.skeleton-list')).toBeVisible()
  565 |     await expect(connections.locator('.skeleton-list')).toBeVisible()
  566 |     await expect(sessions).not.toHaveAttribute('aria-busy')
  567 |     await expect(diagnostics).not.toHaveAttribute('aria-busy')
  568 |     await expect(connections).not.toHaveAttribute('aria-busy')
  569 | 
  570 |     const notFound = {
  571 |       body: { error: { code: 'NOT_FOUND', correlationId: 'safe-optional-404', message: 'Not found.' } },
  572 |       status: 404,
  573 |     } satisfies JsonResponse
  574 |     routes.set(sessionsPath, { body: { items: [], nextCursor: null } })
  575 |     sessionsPending.resolve(notFound)
  576 |     routes.set(connectionsPath, { body: { items: [], nextCursor: null } })
  577 |     connectionsPending.resolve({ body: { items: [], nextCursor: null } })
  578 |     routes.set('/api/v1/human-attention', { body: { items: [], nextCursor: null } })
  579 |     attentionPending.resolve({ body: { items: [], nextCursor: null } })
  580 |     await expect(sessions.locator('.skeleton-list')).toHaveCount(0)
  581 |     await expect(diagnostics.locator('.skeleton-list')).toHaveCount(0)
  582 |     await expect(connections.locator('.skeleton-list')).toHaveCount(0)
  583 |     await expect(connections.locator('.connection-empty')).toBeVisible()
  584 |     await page.getByRole('tab', { name: 'Approvals', exact: true }).click()
  585 |     await expect(page.locator('.approval-history .skeleton-list')).toBeVisible()
  586 |     routes.set(historyPath, { body: { items: [], nextCursor: null } })
  587 |     historyPending.resolve(notFound)
  588 |     await expect(page.locator('.approval-history .skeleton-list')).toHaveCount(0)
  589 |     await expect(page.getByText('safe-optional-404')).toHaveCount(0)
  590 | 
  591 |     await page.getByRole('tab', { name: 'Pending', exact: true }).click()
  592 |     const pendingProjection = page.locator('.approval-projection').filter({ has: page.locator('.skeleton-list') })
  593 |     await expect(pendingProjection.locator('.skeleton-list')).toBeVisible()
  594 |     await expect(pendingProjection).not.toHaveAttribute('aria-busy')
  595 |     const pendingResponse = { body: { items: [browserApproval], nextCursor: 'cursor-pending' } } satisfies JsonResponse
  596 |     routes.set(pendingPath, pendingResponse)
  597 |     pendingApprovals.resolve(pendingResponse)
  598 |     await expect(page.getByTestId(`approval-row-${browserApproval.id}`)).toBeVisible()
  599 |     await expect(page.getByTestId('load-more-approvals')).toBeVisible()
  600 | 
  601 |     const priorPendingRequests = routes.requests.filter(request => request === pendingPath).length
  602 |     routes.set(pendingPath, {
  603 |       body: { error: { code: 'RESOURCE_SCOPE_DENIED', correlationId: 'safe-pending-revoke', message: 'Denied.' } },
  604 |       status: 403,
  605 |     })
  606 |     await page.getByRole('button', { name: 'Refresh', exact: true }).evaluate((button: HTMLButtonElement) => button.click())
  607 |     await routes.waitFor(pendingPath, priorPendingRequests + 1)
  608 |     await expect(page.getByTestId(`approval-row-${browserApproval.id}`)).toHaveCount(0)
  609 |     await expect(page.getByTestId('load-more-approvals')).toHaveCount(0)
  610 |     await expect(page.getByRole('heading', { name: 'Agent workspace needs attention' })).toBeVisible()
  611 |     await expect(page.locator('.control-summary')).toHaveCount(0)
  612 |     await expect(page.locator('.approval-projection .empty')).toHaveCount(0)
  613 |     await expect(page.getByText('safe-pending-revoke')).toHaveCount(0)
  614 |     expect(routes.unexpected).toEqual([])
  615 |   })
  616 | })
  617 | 
  618 | test.describe('Task 6.4 Settings loading authority', () => {
  619 |   test.use({ viewport: { height: 900, width: 1440 } })
  620 | 
  621 |   test('separates Team and State initialization and retains the State surface through refresh failure', async ({ page }) => {
  622 |     const routes = new RouteScenarios()
  623 |     await routes.install(page)
  624 |     await page.context().addCookies([{ name: 'workmesh_locale', value: 'en', url: webUrl }])
  625 | 
  626 |     const teamsPending = deferredResponse()
  627 |     const statesPending = deferredResponse()
  628 |     const statesPath = `/api/v1/teams/${team.id}/states`
  629 |     routes.set('/api/v1/teams', teamsPending.promise)
  630 |     routes.setRequest('GET', statesPath, statesPending.promise)
  631 |     await page.goto('/settings?tab=workspace', { waitUntil: 'domcontentloaded' })
  632 | 
  633 |     const settings = page.locator('.settings-page')
  634 |     const initialSkeleton = settings.locator('.settings-loading-skeleton .skeleton-list')
> 635 |     await expect(initialSkeleton).toBeVisible()
      |                                   ^ Error: expect(locator).toBeVisible() failed
  636 |     await expect(settings).not.toHaveAttribute('aria-busy')
  637 |     await expect(settings.locator('[aria-busy="true"]')).toHaveCount(1)
  638 |     await expect(settings.getByText('No Team', { exact: true })).toHaveCount(0)
  639 | 
  640 |     const teamsResponse = { body: { items: [team], nextCursor: null } } satisfies JsonResponse
  641 |     routes.set('/api/v1/teams', teamsResponse)
  642 |     teamsPending.resolve(teamsResponse)
  643 |     const workflow = settings.locator('[aria-labelledby="workflow-settings-heading"]')
  644 |     await expect(workflow.locator('.skeleton-list')).toBeVisible()
  645 |     await expect(workflow).not.toHaveAttribute('aria-busy')
  646 |     await expect(workflow.locator('[aria-busy="true"]')).toHaveCount(1)
  647 | 
  648 |     const state = { category: 'backlog', color: '#a8a29e', id: 'state-backlog', name: 'Backlog', revision: 1 }
  649 |     const statesResponse = { body: { items: [state], nextCursor: null } } satisfies JsonResponse
  650 |     routes.setRequest('GET', statesPath, statesResponse)
  651 |     statesPending.resolve(statesResponse)
  652 |     const stateRow = workflow.locator('.workflow-state-list article').first()
  653 |     await expect(stateRow).toContainText('Backlog')
  654 | 
  655 |     const stateName = workflow.locator('input[name="name"]')
  656 |     await stateName.fill('Review')
  657 |     await stateName.evaluate(element => { element.dataset.loadingIdentity = 'retained-state-form' })
  658 |     const refreshPending = deferredResponse()
  659 |     const pagedStatesPath = `${statesPath}?limit=100`
  660 |     const priorRequests = routes.requests.filter(request => request === pagedStatesPath).length
  661 |     routes.setRequest('POST', statesPath, { body: { ...state, id: 'state-review', name: 'Review' } })
  662 |     routes.setRequest('GET', pagedStatesPath, refreshPending.promise)
  663 |     await workflow.locator('form').evaluate((form: HTMLFormElement) => form.requestSubmit())
  664 |     await routes.waitFor(pagedStatesPath, priorRequests + 1)
  665 |     await expect(workflow).toHaveAttribute('aria-busy', 'true')
  666 |     await expect(stateRow).toContainText('Backlog')
  667 |     await expect(stateName).toHaveAttribute('data-loading-identity', 'retained-state-form')
  668 |     await expect(stateName).toBeFocused()
  669 | 
  670 |     routes.setRequest('GET', pagedStatesPath, statesResponse)
  671 |     refreshPending.resolve({
  672 |       body: { error: { code: 'TEMPORARY_UNAVAILABLE', correlationId: 'safe-state-refresh', message: 'Please retry.' } },
  673 |       status: 500,
  674 |     })
  675 |     await expect(workflow).not.toHaveAttribute('aria-busy')
  676 |     await expect(stateRow).toContainText('Backlog')
  677 |     await expect(stateName).toHaveAttribute('data-loading-identity', 'retained-state-form')
  678 |     await expect(stateName).toBeFocused()
  679 |     await expect(workflow.locator('[role="status"]')).toHaveCount(0)
  680 |     await expect(page.locator('.settings-page [role="alert"]')).toContainText('Unable to load Settings.')
  681 |     await expect(page.getByRole('button', { name: 'Retry', exact: true })).toBeVisible()
  682 |     await expect(page.getByText('safe-state-refresh')).toHaveCount(0)
  683 |     expect(routes.unexpected).toEqual([])
  684 |   })
  685 | })
  686 | 
  687 | test.describe('Task 6.4 Operations loading authority', () => {
  688 |   test.use({ viewport: { height: 900, width: 1440 } })
  689 | 
  690 |   test('uses real pending owners, resolves independently, and retains focus through refresh failure', async ({ page }) => {
  691 |     const routes = new RouteScenarios()
  692 |     await routes.install(page)
  693 |     await page.context().addCookies([{ name: 'workmesh_locale', value: 'en', url: webUrl }])
  694 | 
  695 |     const featuresPending = deferredResponse()
  696 |     routes.set('/api/v1/features', featuresPending.promise)
  697 |     await page.goto('/operations', { waitUntil: 'domcontentloaded' })
  698 | 
  699 |     const featureStatus = page.getByRole('status', { name: 'Loading Operations' })
  700 |     await expect(featureStatus).toBeVisible()
  701 |     await expect(page.locator('.operations-loading')).not.toHaveAttribute('aria-busy')
  702 |     await expect(page.locator('.operations-loading [aria-busy="true"]')).toHaveCount(1)
  703 | 
  704 |     const pendingCollections = new Map<string, ReturnType<typeof deferredResponse>>()
  705 |     for (const path of Object.keys(collectionPayloads)) {
  706 |       const pending = deferredResponse()
  707 |       pendingCollections.set(path, pending)
  708 |       routes.set(path, pending.promise)
  709 |     }
  710 |     const usagePending = deferredResponse()
  711 |     routes.set('/api/v1/usage-summary', usagePending.promise)
  712 |     routes.set('/api/v1/features', allFeatures)
  713 |     featuresPending.resolve(allFeatures)
  714 | 
  715 |     await expect(page.locator('.operations-usage-loading .skeleton-list')).toBeVisible()
  716 |     await expect(page.locator('.operations-grid .skeleton-list')).toHaveCount(6)
  717 |     await expect(page.locator('.operations-grid section[aria-busy="true"]')).toHaveCount(0)
  718 |     await expect(page.locator('.operations-grid .skeleton-list[aria-busy="true"]')).toHaveCount(6)
  719 | 
  720 |     routes.set('/api/v1/usage-summary', usage)
  721 |     usagePending.resolve(usage)
  722 |     for (const [path, pending] of pendingCollections) {
  723 |       const response = collectionPayloads[path]!
  724 |       routes.set(path, response)
  725 |       pending.resolve(response)
  726 |     }
  727 | 
  728 |     const dryRun = page.getByRole('button', { name: 'Dry run' })
  729 |     await expect(dryRun).toBeVisible()
  730 |     await dryRun.focus()
  731 |     const automation = page.getByTestId('automation-panel')
  732 |     await dryRun.evaluate(element => { element.dataset.loadingIdentity = 'retained-rule-control' })
  733 | 
  734 |     const rulesFailure = deferredResponse()
  735 |     routes.set('/api/v1/automation-rules', rulesFailure.promise)
```