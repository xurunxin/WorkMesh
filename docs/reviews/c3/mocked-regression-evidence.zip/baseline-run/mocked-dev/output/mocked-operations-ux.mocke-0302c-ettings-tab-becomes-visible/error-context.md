# Instructions

- Following Playwright test failed.
- Explain why, be concise, respect Playwright best practices.
- Provide a snippet of code with the fix, if possible.

# Test info

- Name: mocked\operations-ux.mocked.spec.ts >> restores embedded current state without taking focus when the real Settings tab becomes visible
- Location: e2e\mocked\operations-ux.mocked.spec.ts:740:1

# Error details

```
Error: expect(locator).toHaveAttribute(expected) failed

Locator: getByRole('tab', { name: 'Workspace' })
Expected: "true"
Timeout: 10000ms
Error: element(s) not found

Call log:
  - Expect "toHaveAttribute" with timeout 10000ms
  - waiting for getByRole('tab', { name: 'Workspace' })

```

```yaml
- alert
- main:
  - heading "Page not found" [level=1]
  - paragraph: The page you are looking for does not exist or has been moved.
  - link "Back to home":
    - /url: /
```

# Test source

```ts
  644 |       const requestLog: string[] = []
  645 |       const label = `${scenario.name} / ${surface.name}`
  646 |       try {
  647 |         await installOperationsRoutes(scenarioPage, () => scenario.enabled, { requestLog })
  648 |         await scenarioPage.goto(surface.url)
  649 | 
  650 |         if (scenario.name === 'master-off') {
  651 |           await expect(scenarioPage.getByTestId('operations-disabled'), label).toBeVisible()
  652 |         } else if (scenario.name === 'Operations-only') {
  653 |           await expect(scenarioPage.getByTestId('operations-sections-empty'), label).toBeVisible()
  654 |         }
  655 | 
  656 |         const navigation = scenarioPage.getByTestId('operations-section-navigation')
  657 |         if (scenario.hrefs.length === 0) {
  658 |           await expect(navigation, `${label}: navigation`).toHaveCount(0)
  659 |         } else {
  660 |           await expect(navigation, `${label}: navigation`).toBeVisible()
  661 |           await expect.poll(
  662 |             () => navigationHrefs(scenarioPage),
  663 |             { message: `${label}: ordered anchors` },
  664 |           ).toEqual(scenario.hrefs)
  665 |         }
  666 | 
  667 |         const targets = scenarioPage.locator('.operations-section-target')
  668 |         await expect(targets, `${label}: target count`).toHaveCount(scenario.hrefs.length)
  669 |         expect(
  670 |           await targets.evaluateAll(elements => elements.map(element => `#${element.id}`)),
  671 |           `${label}: ordered targets`,
  672 |         ).toEqual(scenario.hrefs)
  673 |         for (const href of sectionHrefs) {
  674 |           await expect(
  675 |             scenarioPage.locator(href),
  676 |             `${label}: ${scenario.hrefs.includes(href) ? 'owned' : 'hidden'} target ${href}`,
  677 |           ).toHaveCount(scenario.hrefs.includes(href) ? 1 : 0)
  678 |         }
  679 | 
  680 |         await expect(
  681 |           scenarioPage.getByTestId('operations-search'),
  682 |           `${label}: search ${scenario.hasSearch ? 'present' : 'absent'}`,
  683 |         ).toHaveCount(scenario.hasSearch ? 1 : 0)
  684 | 
  685 |         await expect.poll(
  686 |           () => requestLog.some(value => new URL(value).pathname === '/api/v1/features'),
  687 |           { message: `${label}: feature registry request completed` },
  688 |         ).toBe(true)
  689 |         const expectedApiPaths = [...scenario.apiPaths].sort()
  690 |         const observedApiPaths = () => [...new Set(
  691 |           requestLog
  692 |             .map(value => new URL(value).pathname)
  693 |             .filter(path => relevantDataPathSet.has(path)),
  694 |         )].sort()
  695 |         if (expectedApiPaths.length > 0) {
  696 |           await expect.poll(
  697 |             observedApiPaths,
  698 |             { message: `${label}: relevant API presence and absence` },
  699 |           ).toEqual(expectedApiPaths)
  700 |         }
  701 |         await scenarioPage.evaluate(() => new Promise<void>(resolve => {
  702 |           requestAnimationFrame(() => requestAnimationFrame(() => resolve()))
  703 |         }))
  704 |         expect(observedApiPaths(), `${label}: zero unrelated Operations endpoints`).toEqual(expectedApiPaths)
  705 |       } finally {
  706 |         await scenarioPage.close()
  707 |       }
  708 |     }
  709 |   }
  710 | })
  711 | 
  712 | test('keeps real Operations controls in the initial viewport at supported widths', async ({ page }) => {
  713 |   await installOperationsRoutes(page, () => allOperationsFeatures)
  714 |   for (const viewport of [
  715 |     { width: 390, height: 844 },
  716 |     { width: 1440, height: 900 },
  717 |     { width: 1920, height: 1080 },
  718 |   ]) {
  719 |     await page.setViewportSize(viewport)
  720 |     await page.goto(`/operations?viewport=${viewport.width}`)
  721 |     const box = await page.getByTestId('operations-section-navigation').boundingBox()
  722 |     expect(box, `${viewport.width}x${viewport.height} navigation bounds`).not.toBeNull()
  723 |     expect(box?.y ?? viewport.height).toBeLessThan(viewport.height)
  724 |   }
  725 | })
  726 | 
  727 | test('scrolls an asynchronously mounted direct-hash target into view before focusing it', async ({ page }) => {
  728 |   await page.setViewportSize({ width: 1440, height: 900 })
  729 |   await installOperationsRoutes(page, () => allOperationsFeatures, { usageDelayMs: 250 })
  730 |   await page.goto('/operations#operations-runs')
  731 | 
  732 |   const navigation = page.getByTestId('operations-section-navigation')
  733 |   const runs = navigation.getByRole('link', { name: 'Recent runs' })
  734 |   const target = page.locator('#operations-runs')
  735 |   await expect(runs).toHaveAttribute('aria-current', 'location')
  736 |   await expect(target).toBeFocused()
  737 |   await expect.poll(async () => (await target.boundingBox())?.y ?? 900).toBeLessThan(900)
  738 | })
  739 | 
  740 | test('restores embedded current state without taking focus when the real Settings tab becomes visible', async ({ page }, testInfo) => {
  741 |   await installOperationsRoutes(page, () => allOperationsFeatures, settingsRouteFixtures)
  742 |   await page.goto('/settings?tab=workspace&team=team-1&opsQuery=Archived&x=keep#operations-runs')
  743 |   const workspaceTab = page.getByRole('tab', { name: 'Workspace' })
> 744 |   await expect(workspaceTab).toHaveAttribute('aria-selected', 'true')
      |                              ^ Error: expect(locator).toHaveAttribute(expected) failed
  745 | 
  746 |   const beforeMount = await page.evaluate(async () => {
  747 |     window.scrollTo(0, Math.min(120, document.documentElement.scrollHeight - window.innerHeight))
  748 |     await new Promise<void>(resolve => requestAnimationFrame(() => requestAnimationFrame(() => resolve())))
  749 |     return { scrollY: window.scrollY, viewportHeight: window.innerHeight }
  750 |   })
  751 |   expect(beforeMount.scrollY).toBeGreaterThan(0)
  752 |   const workspaceTabBox = await workspaceTab.boundingBox()
  753 |   expect(workspaceTabBox).not.toBeNull()
  754 |   expect(workspaceTabBox?.y ?? -1).toBeGreaterThanOrEqual(0)
  755 |   expect((workspaceTabBox?.y ?? beforeMount.viewportHeight) + (workspaceTabBox?.height ?? 0)).toBeLessThan(beforeMount.viewportHeight)
  756 | 
  757 |   const operationsTab = page.getByRole('tab', { name: 'Planning & Operations' })
  758 |   await operationsTab.click()
  759 |   const navigation = page.getByTestId('operations-section-navigation')
  760 |   await expect(navigation).toBeVisible()
  761 |   await expect(page).toHaveURL('/settings?tab=operations&team=team-1&opsQuery=Archived&x=keep#operations-runs')
  762 |   await expect(navigation.getByRole('link', { name: 'Recent runs' })).toHaveAttribute('aria-current', 'location')
  763 |   await expect(operationsTab).toBeFocused()
  764 |   const runsTarget = page.locator('#operations-runs')
  765 |   await expect(runsTarget).not.toBeFocused()
  766 |   const afterMount = await runsTarget.evaluate(element => ({
  767 |     scrollY: window.scrollY,
  768 |     targetTop: element.getBoundingClientRect().top,
  769 |     viewportHeight: window.innerHeight,
  770 |   }))
  771 |   expect(Math.abs(afterMount.scrollY - beforeMount.scrollY)).toBeLessThanOrEqual(1)
  772 |   expect(afterMount.targetTop).toBeGreaterThan(afterMount.viewportHeight)
  773 | 
  774 |   const localeControl = page.getByRole('button', { exact: true, name: 'EN' })
  775 |   await localeControl.focus()
  776 |   const templatesTarget = page.locator('#operations-templates')
  777 |   const beforeHash = await templatesTarget.evaluate(element => ({
  778 |     scrollY: window.scrollY,
  779 |     targetTop: element.getBoundingClientRect().top,
  780 |   }))
  781 |   await page.evaluate(() => {
  782 |     const url = new URL(window.location.href)
  783 |     url.hash = '#operations-templates'
  784 |     window.history.replaceState(window.history.state, '', url)
  785 |     window.dispatchEvent(new HashChangeEvent('hashchange'))
  786 |   })
  787 |   await expect(navigation.getByRole('link', { name: 'Templates' })).toHaveAttribute('aria-current', 'location')
  788 |   const afterHash = await templatesTarget.evaluate(element => ({
  789 |     scrollY: window.scrollY,
  790 |     targetTop: element.getBoundingClientRect().top,
  791 |   }))
  792 |   expect(Math.abs(afterHash.scrollY - beforeHash.scrollY)).toBeLessThanOrEqual(1)
  793 |   expect(Math.abs(afterHash.targetTop - beforeHash.targetTop)).toBeLessThanOrEqual(1)
  794 |   await expect(localeControl).toBeFocused()
  795 |   await expect(templatesTarget).not.toBeFocused()
  796 | 
  797 |   const beforePopstate = await runsTarget.evaluate(element => ({
  798 |     scrollY: window.scrollY,
  799 |     targetTop: element.getBoundingClientRect().top,
  800 |   }))
  801 |   await page.evaluate(() => {
  802 |     const url = new URL(window.location.href)
  803 |     url.hash = '#operations-runs'
  804 |     window.history.replaceState(window.history.state, '', url)
  805 |     window.dispatchEvent(new PopStateEvent('popstate', { state: window.history.state }))
  806 |   })
  807 |   await expect(navigation.getByRole('link', { name: 'Recent runs' })).toHaveAttribute('aria-current', 'location')
  808 |   const afterPopstate = await runsTarget.evaluate(element => ({
  809 |     scrollY: window.scrollY,
  810 |     targetTop: element.getBoundingClientRect().top,
  811 |   }))
  812 |   expect(Math.abs(afterPopstate.scrollY - beforePopstate.scrollY)).toBeLessThanOrEqual(1)
  813 |   expect(Math.abs(afterPopstate.targetTop - beforePopstate.targetTop)).toBeLessThanOrEqual(1)
  814 |   await expect(localeControl).toBeFocused()
  815 |   await expect(runsTarget).not.toBeFocused()
  816 | 
  817 |   const evidencePath = testInfo.outputPath('task-5.1-embedded-passive-scroll-pass.json')
  818 |   await writeFile(evidencePath, JSON.stringify({
  819 |     beforeMount,
  820 |     workspaceTabBox,
  821 |     afterMount,
  822 |     hashchange: { before: beforeHash, after: afterHash },
  823 |     popstate: { before: beforePopstate, after: afterPopstate },
  824 |   }, null, 2), 'utf8')
  825 |   await testInfo.attach('task-5.1-embedded-passive-scroll-pass', {
  826 |     contentType: 'application/json',
  827 |     path: evidencePath,
  828 |   })
  829 | })
  830 | 
  831 | test('keeps Settings route history, shared responsive semantics, and dense 390/1920 geometry', async ({ page }, testInfo) => {
  832 |   const directUrl = '/settings?tab=operations&team=team-1&opsQuery=Archived&x=keep#operations-templates'
  833 |   const routedOperationsUrl = '/settings?team=team-1&opsQuery=Archived&x=keep&tab=operations#operations-templates'
  834 |   await installOperationsRoutes(page, () => allOperationsFeatures, settingsRouteFixtures)
  835 | 
  836 |   await page.setViewportSize({ width: 1920, height: 1080 })
  837 |   await page.goto(directUrl)
  838 |   const operationsTab = page.getByRole('tab', { name: 'Planning & Operations' })
  839 |   const workspaceTab = page.getByRole('tab', { name: 'Workspace' })
  840 |   await expect(operationsTab).toHaveAttribute('aria-selected', 'true')
  841 |   await expect(page.getByRole('searchbox', { name: 'Search loaded Operations records' })).toHaveValue('Archived')
  842 |   await expect(page.getByRole('link', { name: 'Templates' })).toHaveAttribute('aria-current', 'location')
  843 |   await expect(page).toHaveURL(`${webUrl}${directUrl}`)
  844 | 
```