# Instructions

- Following Playwright test failed.
- Explain why, be concise, respect Playwright best practices.
- Provide a snippet of code with the fix, if possible.

# Test info

- Name: mocked\loading-states.mocked.spec.ts >> Task 6.4 Home loading authority >> distinguishes initial durable failure, real Team empty, and null downstream paths
- Location: e2e\mocked\loading-states.mocked.spec.ts:451:3

# Error details

```
Error: expect(locator).toHaveCount(expected) failed

Locator:  getByRole('option', { name: /No team/i })
Expected: 1
Received: 0
Timeout:  10000ms

Call log:
  - Expect "toHaveCount" with timeout 10000ms
  - waiting for getByRole('option', { name: /No team/i })
    23 × locator resolved to 0 elements
       - unexpected value "0"

```

# Page snapshot

```yaml
- generic [active] [ref=e1]:
  - button "Open Next.js Dev Tools" [ref=e7] [cursor=pointer]:
    - img [ref=e8]
  - alert [ref=e11]
  - main [ref=e12]:
    - generic [ref=e13]:
      - heading "Page not found" [level=1] [ref=e14]
      - paragraph [ref=e15]: The page you are looking for does not exist or has been moved.
      - link "Back to home" [ref=e16] [cursor=pointer]:
        - /url: /
```

# Test source

```ts
  378 |   revision: 1,
  379 |   risk_level: 'medium',
  380 |   session_id: 'session-loading-matrix',
  381 |   status: 'pending',
  382 | }
  383 | 
  384 | const workflowStates = [
  385 |   { category: 'backlog', color: '#a8a29e', id: 'state-backlog', name: 'Backlog', revision: 1 },
  386 |   { category: 'planned', color: '#7c3aed', id: 'state-planned', name: 'Planned', revision: 1 },
  387 |   { category: 'started', color: '#2563eb', id: 'state-started', name: 'In progress', revision: 1 },
  388 |   { category: 'completed', color: '#16a34a', id: 'state-completed', name: 'Completed', revision: 1 },
  389 |   { category: 'canceled', color: '#dc2626', id: 'state-canceled', name: 'Canceled', revision: 1 },
  390 | ] as const
  391 | 
  392 | test.describe('Task 6.4 Home loading authority', () => {
  393 |   test.use({ viewport: { height: 900, width: 1440 } })
  394 | 
  395 |   test('keeps one initial owner and isolates a late Work Item scope response', async ({ page }) => {
  396 |     const routes = new RouteScenarios()
  397 |     await routes.install(page)
  398 |     await page.context().addCookies([{ name: 'workmesh_locale', value: 'en', url: webUrl }])
  399 | 
  400 |     const teamsPending = deferredResponse()
  401 |     const workItemsPending = deferredResponse()
  402 |     routes.set('/api/v1/teams', teamsPending.promise)
  403 |     routes.set('/api/v1/work-items', workItemsPending.promise)
  404 |     await page.goto('/?view=my-work&layout=list', { waitUntil: 'domcontentloaded' })
  405 | 
  406 |     const content = page.locator('.content')
  407 |     await expect(content.locator('.skeleton-list')).toHaveCount(1)
  408 |     await expect(content.locator('[aria-busy="true"]')).toHaveCount(1)
  409 |     await expect(content.locator('.skeleton-list [tabindex], .skeleton-list button, .skeleton-list a, .skeleton-list input, .skeleton-list select')).toHaveCount(0)
  410 |     await expect(page.getByRole('option', { name: 'Loading Team' })).toHaveCount(1)
  411 |     await expect(page.getByRole('option', { name: 'No Team' })).toHaveCount(0)
  412 | 
  413 |     const teamsResponse = { body: { items: [team], nextCursor: null } } satisfies JsonResponse
  414 |     routes.set('/api/v1/teams', teamsResponse)
  415 |     teamsPending.resolve(teamsResponse)
  416 |     const workSurfaces = page.getByTestId('work-surfaces')
  417 |     await expect(workSurfaces.locator('.skeleton-list')).toBeVisible()
  418 |     await expect(workSurfaces).not.toHaveAttribute('aria-busy')
  419 |     await expect(workSurfaces.locator('[aria-busy="true"]')).toHaveCount(1)
  420 | 
  421 |     const initialItems = { body: { items: [browserWorkItem], nextCursor: null } } satisfies JsonResponse
  422 |     routes.set('/api/v1/work-items', initialItems)
  423 |     workItemsPending.resolve(initialItems)
  424 |     const retainedTitle = page.getByRole('button', { name: /Retained loading matrix item/ })
  425 |     await expect(retainedTitle).toBeVisible()
  426 | 
  427 |     const search = page.locator('[data-hotkey-filter="true"]')
  428 |     const oldPending = deferredResponse()
  429 |     const oldPath = `/api/v1/work-items?teamId=${team.id}&search=old-scope&limit=100`
  430 |     routes.set(oldPath, oldPending.promise)
  431 |     await search.fill('old-scope')
  432 |     await routes.waitFor(oldPath)
  433 |     await expect(retainedTitle).toHaveCount(0)
  434 |     await expect(workSurfaces.locator('.skeleton-list')).toBeVisible()
  435 | 
  436 |     const newItem = { ...browserWorkItem, id: 'work-new-scope', number: 65, title: 'New scope authority item' }
  437 |     const newPath = `/api/v1/work-items?teamId=${team.id}&search=new-scope&limit=100`
  438 |     routes.set(newPath, { body: { items: [newItem], nextCursor: null } })
  439 |     await search.fill('new-scope')
  440 |     await routes.waitFor(newPath)
  441 |     const newTitle = page.getByRole('button', { name: 'New scope authority item' })
  442 |     await expect(newTitle).toBeVisible()
  443 | 
  444 |     oldPending.resolve({ body: { items: [{ ...browserWorkItem, id: 'work-late-scope', title: 'Late stale scope item' }], nextCursor: null } })
  445 |     await page.waitForTimeout(100)
  446 |     await expect(newTitle).toBeVisible()
  447 |     await expect(page.getByText('Late stale scope item')).toHaveCount(0)
  448 |     expect(routes.unexpected).toEqual([])
  449 |   })
  450 | 
  451 |   test('distinguishes initial durable failure, real Team empty, and null downstream paths', async ({ page }) => {
  452 |     const routes = new RouteScenarios()
  453 |     await routes.install(page)
  454 |     await page.context().addCookies([{ name: 'workmesh_locale', value: 'en', url: webUrl }])
  455 |     const teamsPath = '/api/v1/teams?limit=100'
  456 |     routes.setRequest('GET', teamsPath, {
  457 |       body: { error: { code: 'TEMPORARY_UNAVAILABLE', correlationId: 'safe-team-initial', message: 'Unable to load Team.' } },
  458 |       status: 500,
  459 |     })
  460 |     await page.goto('/?view=my-work', { waitUntil: 'domcontentloaded' })
  461 |     const content = page.locator('.content')
  462 |     await expect(content.getByRole('alert')).toBeVisible()
  463 |     await expect(content.locator('.skeleton-list')).toHaveCount(0)
  464 |     await expect(page.getByTestId('work-surfaces')).toHaveCount(0)
  465 |     await expect(page.getByText('safe-team-initial')).toHaveCount(0)
  466 | 
  467 |     routes.setRequest('GET', teamsPath, { body: { items: [], nextCursor: null } })
  468 |     await page.reload({ waitUntil: 'domcontentloaded' })
  469 |     await expect(content.locator('.empty')).toContainText('No team')
  470 |     await expect(content.getByRole('alert')).toHaveCount(0)
  471 |     await expect(content.locator('.skeleton-list')).toHaveCount(0)
  472 |     await expect(page.getByTestId('work-surfaces')).toHaveCount(0)
  473 |     expect(routes.requests.some(request => request.startsWith('/api/v1/work-items'))).toBe(false)
  474 |     expect(routes.requests.some(request => request.includes('/states'))).toBe(false)
  475 | 
  476 |     await page.goto('/settings?tab=workspace', { waitUntil: 'domcontentloaded' })
  477 |     await expect(page.locator('.settings-loading-skeleton')).toHaveCount(0)
> 478 |     await expect(page.getByRole('option', { name: /No team/i })).toHaveCount(1)
      |                                                                  ^ Error: expect(locator).toHaveCount(expected) failed
  479 |     await expect(page.locator('[aria-labelledby="workflow-settings-heading"] .skeleton-list')).toHaveCount(0)
  480 |     expect(routes.requests.some(request => request.includes('/states'))).toBe(false)
  481 |     expect(routes.unexpected).toEqual([])
  482 |   })
  483 | })
  484 | 
  485 | test.describe('Task 6.4 Agents loading authority', () => {
  486 |   test.use({ viewport: { height: 900, width: 1440 } })
  487 | 
  488 |   test('keeps Registry authority and focus independent through a failed refresh', async ({ page }) => {
  489 |     const routes = new RouteScenarios()
  490 |     await routes.install(page)
  491 |     await page.context().addCookies([{ name: 'workmesh_locale', value: 'en', url: webUrl }])
  492 | 
  493 |     const agentsPending = deferredResponse()
  494 |     routes.set('/api/v1/agents', agentsPending.promise)
  495 |     await page.goto('/agents?tab=agents', { waitUntil: 'domcontentloaded' })
  496 | 
  497 |     const registry = page.locator('.agent-registry')
  498 |     await expect(registry.locator('.skeleton-list')).toBeVisible()
  499 |     await expect(registry).not.toHaveAttribute('aria-busy')
  500 |     await expect(registry.locator('[aria-busy="true"]')).toHaveCount(1)
  501 |     await expect(registry.locator('.skeleton-list button, .skeleton-list a, .skeleton-list input, .skeleton-list [tabindex]')).toHaveCount(0)
  502 | 
  503 |     const agentsResponse = { body: { items: [browserAgent], nextCursor: null } } satisfies JsonResponse
  504 |     routes.set('/api/v1/agents', agentsResponse)
  505 |     agentsPending.resolve(agentsResponse)
  506 |     const agentLink = page.locator('[data-agent-roving-link="true"]')
  507 |     await expect(agentLink).toHaveCount(1)
  508 |     await agentLink.focus()
  509 |     await agentLink.evaluate(element => { element.dataset.loadingIdentity = 'retained-agent-link' })
  510 | 
  511 |     const refreshPending = deferredResponse()
  512 |     const agentsPath = '/api/v1/agents?limit=100'
  513 |     const priorRequests = routes.requests.filter(request => request === agentsPath).length
  514 |     routes.set(agentsPath, refreshPending.promise)
  515 |     await page.getByRole('button', { name: 'Refresh', exact: true }).evaluate((button: HTMLButtonElement) => button.click())
  516 |     await routes.waitFor(agentsPath, priorRequests + 1)
  517 |     await expect(registry).toHaveAttribute('aria-busy', 'true')
  518 |     await expect(agentLink).toHaveAttribute('data-loading-identity', 'retained-agent-link')
  519 |     await expect(agentLink).toBeFocused()
  520 | 
  521 |     routes.set(agentsPath, agentsResponse)
  522 |     refreshPending.resolve({
  523 |       body: { error: { code: 'TEMPORARY_UNAVAILABLE', correlationId: 'safe-agent-refresh', message: 'Please retry.' } },
  524 |       status: 500,
  525 |     })
  526 |     await expect(registry).not.toHaveAttribute('aria-busy')
  527 |     await expect(agentLink).toHaveAttribute('data-loading-identity', 'retained-agent-link')
  528 |     await expect(agentLink).toBeFocused()
  529 |     await expect(page.getByText('Loading Matrix Agent')).toBeVisible()
  530 |     await expect(page.getByText('safe-agent-refresh')).toHaveCount(0)
  531 |     expect(routes.unexpected).toEqual([])
  532 |   })
  533 | })
  534 | 
  535 | test.describe('Task 6.4 Agent secondary surfaces', () => {
  536 |   test.use({ viewport: { height: 900, width: 1440 } })
  537 | 
  538 |   test('owns Sessions, Diagnostics, Connections and Approval states without stale actions', async ({ page }) => {
  539 |     const routes = new RouteScenarios()
  540 |     await routes.install(page)
  541 |     await page.context().addCookies([{ name: 'workmesh_locale', value: 'en', url: webUrl }])
  542 | 
  543 |     const sessionsPath = '/api/v1/agent-sessions?limit=100'
  544 |     const connectionsPath = '/api/v1/agent-connections?limit=50'
  545 |     const pendingPath = '/api/v1/approvals?status=pending&limit=100'
  546 |     const historyPath = '/api/v1/approvals?status=approved&limit=100'
  547 |     const sessionsPending = deferredResponse()
  548 |     const connectionsPending = deferredResponse()
  549 |     const attentionPending = deferredResponse()
  550 |     const pendingApprovals = deferredResponse()
  551 |     const historyPending = deferredResponse()
  552 |     routes.set('/api/v1/agents', { body: { items: [browserAgent], nextCursor: null } })
  553 |     routes.set(sessionsPath, sessionsPending.promise)
  554 |     routes.set(connectionsPath, connectionsPending.promise)
  555 |     routes.set('/api/v1/human-attention', attentionPending.promise)
  556 |     routes.set(pendingPath, pendingApprovals.promise)
  557 |     routes.set(historyPath, historyPending.promise)
  558 |     await page.goto('/agents?tab=sessions&approvalView=history&approvalStatus=approved', { waitUntil: 'domcontentloaded' })
  559 | 
  560 |     const sessions = page.getByRole('region', { name: 'Sessions', exact: true })
  561 |     const diagnostics = page.getByRole('region', { name: 'Diagnostics', exact: true })
  562 |     const connections = page.getByRole('region', { name: 'Connections', exact: true })
  563 |     await expect(sessions.locator('.skeleton-list')).toBeVisible()
  564 |     await expect(diagnostics.locator('.skeleton-list')).toBeVisible()
  565 |     await expect(connections.locator('.skeleton-list')).toBeVisible()
  566 |     await expect(sessions).not.toHaveAttribute('aria-busy')
  567 |     await expect(diagnostics).not.toHaveAttribute('aria-busy')
  568 |     await expect(connections).not.toHaveAttribute('aria-busy')
  569 | 
  570 |     const notFound = {
  571 |       body: { error: { code: 'NOT_FOUND', correlationId: 'safe-optional-404', message: 'Not found.' } },
  572 |       status: 404,
  573 |     } satisfies JsonResponse
  574 |     routes.set(sessionsPath, { body: { items: [], nextCursor: null } })
  575 |     sessionsPending.resolve(notFound)
  576 |     routes.set(connectionsPath, { body: { items: [], nextCursor: null } })
  577 |     connectionsPending.resolve({ body: { items: [], nextCursor: null } })
  578 |     routes.set('/api/v1/human-attention', { body: { items: [], nextCursor: null } })
```