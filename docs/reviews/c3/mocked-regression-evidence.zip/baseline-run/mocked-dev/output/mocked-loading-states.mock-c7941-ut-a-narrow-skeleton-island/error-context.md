# Instructions

- Following Playwright test failed.
- Explain why, be concise, respect Playwright best practices.
- Provide a snippet of code with the fix, if possible.

# Test info

- Name: mocked\loading-states.mocked.spec.ts >> Task 6.4 loading geometry at 1920px >> fills real Operations, Settings and Board panels without a narrow skeleton island
- Location: e2e\mocked\loading-states.mocked.spec.ts:770:5

# Error details

```
Error: expect(locator).toHaveCount(expected) failed

Locator:  locator('.operations-metrics-grid > .operations-metric-card')
Expected: 5
Received: 0
Timeout:  10000ms

Call log:
  - Expect "toHaveCount" with timeout 10000ms
  - waiting for locator('.operations-metrics-grid > .operations-metric-card')
    23 × locator resolved to 0 elements
       - unexpected value "0"

```

# Page snapshot

```yaml
- generic [active] [ref=e1]:
  - button "Open Next.js Dev Tools" [ref=e7] [cursor=pointer]:
    - img [ref=e8]
  - alert [ref=e11]
  - generic [ref=e12]:
    - link "Skip to content" [ref=e13] [cursor=pointer]:
      - /url: "#workmesh-main"
    - complementary "Main navigation" [ref=e14]:
      - generic [ref=e15]:
        - strong [ref=e17]: WorkMesh
        - generic [ref=e18]: Alex Morgan
      - button "Collapse sidebar" [expanded] [ref=e19] [cursor=pointer]:
        - img [ref=e20]
        - generic [ref=e22]: Collapse sidebar
      - navigation "Workspace" [ref=e23]:
        - generic [ref=e24]:
          - paragraph [ref=e25]: Workbench
          - link "Workbench" [ref=e26] [cursor=pointer]:
            - /url: /workbench
            - img [ref=e28]
            - generic [ref=e30]: Workbench
          - link "My work" [ref=e31] [cursor=pointer]:
            - /url: /?view=home
            - img [ref=e33]
            - generic [ref=e35]: My work
          - link "Issues" [ref=e36] [cursor=pointer]:
            - /url: /?view=my-work
            - img [ref=e38]
            - generic [ref=e40]: Issues
          - link "Guidance" [ref=e41] [cursor=pointer]:
            - /url: /?view=guidance
            - img [ref=e43]
            - generic [ref=e45]: Guidance
        - generic [ref=e46]:
          - paragraph [ref=e47]: Governance
          - link "Needs You" [ref=e48] [cursor=pointer]:
            - /url: /?view=inbox
            - img [ref=e50]
            - generic [ref=e52]: Needs You
          - link "Session" [ref=e53] [cursor=pointer]:
            - /url: /?view=sessions
            - img [ref=e55]
            - generic [ref=e57]: Session
          - link "Recovery" [ref=e58] [cursor=pointer]:
            - /url: /?view=recovery
            - img [ref=e60]
            - generic [ref=e62]: Recovery
          - link "Projects" [ref=e63] [cursor=pointer]:
            - /url: /?view=projects
            - img [ref=e65]
            - generic [ref=e67]: Projects
          - link "Agents" [ref=e68] [cursor=pointer]:
            - /url: /agents
            - img [ref=e70]
            - generic [ref=e72]: Agents
        - generic [ref=e73]:
          - paragraph [ref=e74]: Operations
          - link "Operations" [ref=e75] [cursor=pointer]:
            - /url: /operations
            - img [ref=e77]
            - generic [ref=e79]: Operations
      - navigation "Administration" [ref=e80]:
        - link "Settings" [ref=e81] [cursor=pointer]:
          - /url: /settings
          - img [ref=e83]
          - generic [ref=e85]: Settings
      - generic [ref=e87]:
        - button "Sign out" [ref=e88] [cursor=pointer]:
          - img [ref=e90]
          - generic [ref=e92]: Sign out
        - generic [ref=e93]: v1.0.0 · build loading-state-fixture · schema 24
    - generic [ref=e94]:
      - banner [ref=e95]:
        - paragraph [ref=e96]:
          - generic [ref=e97]: Planning & Operations
        - button "Search" [ref=e99] [cursor=pointer]:
          - img [ref=e101]
          - generic [ref=e103]:
            - generic [ref=e104]: Search
            - generic [ref=e105]: Ctrl K
        - generic [ref=e106]:
          - button "Switch to the light theme" [ref=e107]:
            - img [ref=e108]
          - generic [ref=e110]:
            - group "Language" [ref=e111]:
              - button "中" [ref=e112]
              - button "EN" [pressed] [ref=e113]
            - generic "Reconnecting" [ref=e114]:
              - generic [ref=e115]: Reconnecting
      - main [ref=e116]:
        - generic [ref=e118]:
          - generic [ref=e119]:
            - generic [ref=e120]:
              - link "Back to work" [ref=e121] [cursor=pointer]:
                - /url: /
              - heading "Planning & Operations" [level=1] [ref=e122]
              - paragraph [ref=e123]: Durable planning, automation, health, and cost observability.
            - button "Refresh" [ref=e124] [cursor=pointer]:
              - generic [ref=e125]: Refresh
          - generic [ref=e126]:
            - generic [ref=e127]: Search loaded Operations records
            - searchbox "Search loaded Operations records" [ref=e128]
            - generic [ref=e129]: Filters only Operations records already loaded in this view. Load more to expand the searchable set.
          - navigation "Operations sections" [ref=e130]:
            - link "Usage and cost" [ref=e131] [cursor=pointer]:
              - /url: "#operations-metrics"
            - link "Cycles" [ref=e132] [cursor=pointer]:
              - /url: "#operations-cycles"
            - link "Initiatives" [ref=e133] [cursor=pointer]:
              - /url: "#operations-initiatives"
            - link "Automation rules" [ref=e134] [cursor=pointer]:
              - /url: "#operations-automation"
            - link "Loops" [ref=e135] [cursor=pointer]:
              - /url: "#operations-loops"
            - link "Recent runs" [ref=e136] [cursor=pointer]:
              - /url: "#operations-runs"
            - link "Templates & playbooks" [ref=e137] [cursor=pointer]:
              - /url: "#operations-templates"
          - region "Usage and cost" [ref=e138]:
            - list "Usage and cost" [ref=e139]:
              - listitem "Tokens" [ref=e140]:
                - generic [ref=e142]:
                  - term [ref=e143]: Tokens
                  - definition [ref=e144]:
                    - strong [ref=e145]: 1,500
              - listitem "Runtime" [ref=e146]:
                - generic [ref=e148]:
                  - term [ref=e149]: Runtime
                  - definition [ref=e150]:
                    - strong [ref=e151]: 45s
              - listitem "Tool calls" [ref=e152]:
                - generic [ref=e154]:
                  - term [ref=e155]: Tool calls
                  - definition [ref=e156]:
                    - strong [ref=e157]: "7"
              - listitem "Unknown cost" [ref=e158]:
                - generic [ref=e160]:
                  - term [ref=e161]: Unknown cost
                  - definition [ref=e162]:
                    - strong [ref=e163]: "0"
                    - text: records
              - listitem "Known cost" [ref=e164]:
                - generic [ref=e166]:
                  - term [ref=e167]: Known cost
                  - definition [ref=e168]: No known cost
          - generic [ref=e169]:
            - generic [ref=e170]:
              - heading "Cycles" [level=2] [ref=e171]
              - status [ref=e172]:
                - generic [ref=e174]:
                  - heading "No Cycles configured" [level=2] [ref=e175]
                  - paragraph [ref=e176]: Create a Cycle when a planning window is ready.
            - generic [ref=e177]:
              - heading "Initiatives" [level=2] [ref=e178]
              - status [ref=e179]:
                - generic [ref=e181]:
                  - heading "No Initiatives configured" [level=2] [ref=e182]
                  - paragraph [ref=e183]: Initiatives will appear here when the feature has durable data.
            - generic [ref=e184]:
              - heading "Automation rules" [level=2] [ref=e185]
              - article [ref=e186]:
                - generic [ref=e187]:
                  - strong [ref=e188]: Retained browser rule
                  - generic [ref=e189]: v1 · manual
                - generic [ref=e190]: Enabled
                - button "Dry run" [ref=e191]
                - button "Pause" [ref=e192]
            - generic [ref=e193]:
              - heading "Loops" [level=2] [ref=e194]
              - status [ref=e195]:
                - generic [ref=e197]:
                  - heading "No Loops configured" [level=2] [ref=e198]
                  - paragraph [ref=e199]: Agent Loops will appear after they are created through an authorized command.
            - generic [ref=e200]:
              - heading "Recent runs" [level=2] [ref=e201]
              - region "Recent runs" [ref=e202]:
                - table "Recent runs" [ref=e203]:
                  - caption [ref=e204]: Recent runs
                  - rowgroup [ref=e212]:
                    - row "Run Kind Status Attempts Session Created" [ref=e213]:
                      - columnheader "Run" [ref=e214]
                      - columnheader "Kind" [ref=e215]
                      - columnheader "Status" [ref=e216]
                      - columnheader "Attempts" [ref=e217]
                      - columnheader "Session" [ref=e218]
                      - columnheader "Created" [ref=e219]
                  - rowgroup
              - status [ref=e220]:
                - generic [ref=e222]:
                  - heading "No run history yet" [level=2] [ref=e223]
                  - paragraph [ref=e224]: Durable run history will appear after an automation or loop executes.
            - generic [ref=e225]:
              - heading "Templates & playbooks" [level=2] [ref=e226]
              - status [ref=e227]:
                - generic [ref=e229]:
                  - heading "No Templates configured" [level=2] [ref=e230]
                  - paragraph [ref=e231]: Templates and playbooks will appear when they are available to this workspace.
```

# Test source

```ts
  710 |     const usagePending = deferredResponse()
  711 |     routes.set('/api/v1/usage-summary', usagePending.promise)
  712 |     routes.set('/api/v1/features', allFeatures)
  713 |     featuresPending.resolve(allFeatures)
  714 | 
  715 |     await expect(page.locator('.operations-usage-loading .skeleton-list')).toBeVisible()
  716 |     await expect(page.locator('.operations-grid .skeleton-list')).toHaveCount(6)
  717 |     await expect(page.locator('.operations-grid section[aria-busy="true"]')).toHaveCount(0)
  718 |     await expect(page.locator('.operations-grid .skeleton-list[aria-busy="true"]')).toHaveCount(6)
  719 | 
  720 |     routes.set('/api/v1/usage-summary', usage)
  721 |     usagePending.resolve(usage)
  722 |     for (const [path, pending] of pendingCollections) {
  723 |       const response = collectionPayloads[path]!
  724 |       routes.set(path, response)
  725 |       pending.resolve(response)
  726 |     }
  727 | 
  728 |     const dryRun = page.getByRole('button', { name: 'Dry run' })
  729 |     await expect(dryRun).toBeVisible()
  730 |     await dryRun.focus()
  731 |     const automation = page.getByTestId('automation-panel')
  732 |     await dryRun.evaluate(element => { element.dataset.loadingIdentity = 'retained-rule-control' })
  733 | 
  734 |     const rulesFailure = deferredResponse()
  735 |     routes.set('/api/v1/automation-rules', rulesFailure.promise)
  736 |     const rulesPath = '/api/v1/automation-rules?limit=100'
  737 |     const priorRuleRequests = routes.requests.filter(request => request === rulesPath).length
  738 |     await page.getByRole('button', { name: 'Refresh' }).evaluate((button: HTMLButtonElement) => button.click())
  739 |     await routes.waitFor(rulesPath, priorRuleRequests + 1)
  740 |     await expect(automation).toHaveAttribute('aria-busy', 'true')
  741 |     await expect(dryRun).toHaveAttribute('data-loading-identity', 'retained-rule-control')
  742 |     await expect(dryRun).toBeFocused()
  743 |     await expect(page.locator('.operations-tab > .sr-only[role="status"]')).toHaveCount(1)
  744 | 
  745 |     routes.set('/api/v1/automation-rules', collectionPayloads['/api/v1/automation-rules']!)
  746 |     rulesFailure.resolve({
  747 |       body: { error: { code: 'TEMPORARY_UNAVAILABLE', correlationId: 'safe-browser-diagnostic', message: 'Please retry.' } },
  748 |       status: 500,
  749 |     })
  750 |     await expect(automation).not.toHaveAttribute('aria-busy')
  751 |     await expect(dryRun).toHaveAttribute('data-loading-identity', 'retained-rule-control')
  752 |     await expect(dryRun).toBeFocused()
  753 |     await expect(page.getByText('Retained browser rule')).toBeVisible()
  754 |     await expect(automation.getByText('Unable to load Operations.')).toBeVisible()
  755 |     await expect(page.locator('.operations-tab > .sr-only[role="status"]')).toHaveCount(0)
  756 |     expect(routes.unexpected).toEqual([])
  757 |   })
  758 | })
  759 | 
  760 | const loadingViewports = [
  761 |   { height: 844, width: 390 },
  762 |   { height: 900, width: 1440 },
  763 |   { height: 1080, width: 1920 },
  764 | ] as const
  765 | 
  766 | for (const viewport of loadingViewports) {
  767 |   test.describe(`Task 6.4 loading geometry at ${viewport.width}px`, () => {
  768 |     test.use({ viewport })
  769 | 
  770 |     test('fills real Operations, Settings and Board panels without a narrow skeleton island', async ({ page }, testInfo) => {
  771 |       const routes = new RouteScenarios()
  772 |       await routes.install(page)
  773 |       await page.context().addCookies([{ name: 'workmesh_locale', value: 'en', url: webUrl }])
  774 |       await mkdir(evidenceRoot, { recursive: true })
  775 | 
  776 |       const featuresPending = deferredResponse()
  777 |       const usageGeometryPending = deferredResponse()
  778 |       routes.set('/api/v1/features', featuresPending.promise)
  779 |       routes.set('/api/v1/usage-summary', usageGeometryPending.promise)
  780 |       for (const [path, response] of Object.entries(collectionPayloads)) routes.set(path, response)
  781 |       await page.goto('/operations', { waitUntil: 'domcontentloaded' })
  782 |       const operationsHeader = page.locator('.operations-tab > .operations-header')
  783 |       await expect(operationsHeader).toBeVisible()
  784 |       await operationsHeader.evaluate(element => { element.dataset.loadingIdentity = 'stable-operations-header' })
  785 |       const operationsHeaderPending = (await measureRects(page, '.operations-tab > .operations-header'))[0]!
  786 |       const operationsPending = await measureSkeleton(page, '.operations-loading .skeleton-list', { panelSelector: '.operations-tab' })
  787 |       expectContainedSkeleton(operationsPending, viewport.width <= 960 ? 1 : 2)
  788 |       expect(operationsPending.busyOwners).toBe(1)
  789 |       await page.screenshot({ path: join(evidenceRoot, `loading-operations-pending-${viewport.width}x${viewport.height}.png`) })
  790 | 
  791 |       routes.set('/api/v1/features', allFeatures)
  792 |       featuresPending.resolve(allFeatures)
  793 |       await expect(page.locator('.operations-usage-loading .skeleton-list')).toBeVisible()
  794 |       await expect(page.locator('.operations-grid > .operations-panel')).toHaveCount(6)
  795 |       const usagePending = await measureSkeleton(page, '.operations-usage-loading .skeleton-list', { panelSelector: '.operations-metrics' })
  796 |       // Task 6.5 supersedes the original 1920px five-column snapshot: keeping
  797 |       // the metrics root at 85% of the workspace yields four readable columns
  798 |       // and two rows without changing the loading owner or pending/resolved seam.
  799 |       const expectedUsageColumns = viewport.width <= 560 ? 1 : viewport.width >= 1440 ? 4 : 5
  800 |       expectContainedSkeleton(usagePending, expectedUsageColumns)
  801 |       expect(usagePending.cells).toHaveLength(5)
  802 |       expect(usagePending.focusableCount).toBe(0)
  803 |       expect(usagePending.document.overflow).toBe(0)
  804 |       if (viewport.width === 1920) {
  805 |         expect(usagePending.root.width / usagePending.main.width).toBeGreaterThanOrEqual(.85)
  806 |         expect(new Set(usagePending.cells.map(cell => Math.round(cell.top))).size).toBe(2)
  807 |       }
  808 |       routes.set('/api/v1/usage-summary', usage)
  809 |       usageGeometryPending.resolve(usage)
> 810 |       await expect(page.locator('.operations-metrics-grid > .operations-metric-card')).toHaveCount(5)
      |                                                                                        ^ Error: expect(locator).toHaveCount(expected) failed
  811 |       const usageResolved = await measureResolvedGrid(page, '.operations-metrics-grid', ':scope > .operations-metric-card')
  812 |       expect(usageResolved.columns).toBe(usagePending.columns)
  813 |       expect(usageResolved.document.overflow).toBe(0)
  814 |       expect(Math.abs(usageResolved.root.width - usagePending.root.width)).toBeLessThanOrEqual(2)
  815 |       usageResolved.items.forEach((card, index) => expect(Math.abs(card.width - usagePending.cells[index]!.width)).toBeLessThanOrEqual(2))
  816 |       if (viewport.width === 1920)
  817 |         expect(new Set(usageResolved.items.map(card => Math.round(card.top))).size).toBe(2)
  818 |       const operationsResolved = await measureRects(page, '.operations-grid > .operations-panel')
  819 |       const operationsContainment = await measureResolvedContainment(page)
  820 |       const operationsHeaderResolved = (await measureRects(page, '.operations-tab > .operations-header'))[0]!
  821 |       expect(operationsContainment.document.overflow).toBe(0)
  822 |       await expect(operationsHeader).toHaveAttribute('data-loading-identity', 'stable-operations-header')
  823 |       expect(Math.abs(operationsHeaderPending.top - operationsHeaderResolved.top)).toBeLessThanOrEqual(2)
  824 |       expect(Math.abs(operationsPending.cells[0]!.width - operationsResolved[0]!.width)).toBeLessThanOrEqual(2)
  825 |       expect(Math.abs(operationsPending.cells[1]!.width - operationsResolved[1]!.width)).toBeLessThanOrEqual(2)
  826 |       expect(Math.abs(operationsPending.cells[2]!.width - operationsResolved[2]!.width)).toBeLessThanOrEqual(2)
  827 |       await persistEvidence(page, testInfo, `loading-operations-geometry-${viewport.width}x${viewport.height}`, {
  828 |         header: { pending: operationsHeaderPending, resolved: operationsHeaderResolved },
  829 |         pending: operationsPending,
  830 |         resolvedContainment: operationsContainment,
  831 |         resolvedPanels: operationsResolved,
  832 |         usage: { pending: usagePending, resolved: usageResolved },
  833 |       })
  834 | 
  835 |       const teamsPending = deferredResponse()
  836 |       const statesGeometryPending = deferredResponse()
  837 |       const statesPath = `/api/v1/teams/${team.id}/states`
  838 |       routes.setRequest('GET', '/api/v1/teams', teamsPending.promise)
  839 |       routes.setRequest('GET', statesPath, statesGeometryPending.promise)
  840 |       await page.goto('/settings?tab=workspace', { waitUntil: 'domcontentloaded' })
  841 |       const settingsHeader = page.locator('.settings-page > header').first()
  842 |       await settingsHeader.evaluate(element => { element.dataset.loadingIdentity = 'stable-settings-header' })
  843 |       const settingsHeaderPending = (await measureRects(page, '.settings-page > header'))[0]!
  844 |       const settingsPending = await measureSkeleton(page, '.settings-loading-skeleton .skeleton-list', { panelSelector: '.settings-grid' })
  845 |       expectContainedSkeleton(settingsPending, viewport.width <= 720 ? 1 : 2)
  846 |       expect(settingsPending.busyOwners).toBe(1)
  847 |       await page.screenshot({ path: join(evidenceRoot, `loading-settings-pending-${viewport.width}x${viewport.height}.png`) })
  848 | 
  849 |       const teamsResponse = { body: { items: [team], nextCursor: null } } satisfies JsonResponse
  850 |       routes.setRequest('GET', '/api/v1/teams', teamsResponse)
  851 |       teamsPending.resolve(teamsResponse)
  852 |       await expect(page.locator('.settings-states-loading .skeleton-list')).toBeVisible()
  853 |       const statesPending = await measureSkeleton(page, '.settings-states-loading .skeleton-list', { panelSelector: '.settings-card' })
  854 |       expectContainedSkeleton(statesPending, viewport.width <= 560 ? 1 : workflowStates.length)
  855 |       expect(statesPending.cells).toHaveLength(workflowStates.length)
  856 |       expect(statesPending.document.overflow).toBe(0)
  857 |       expect(statesPending.focusableCount).toBe(0)
  858 |       const statesResponse = { body: { items: workflowStates, nextCursor: null } } satisfies JsonResponse
  859 |       routes.setRequest('GET', statesPath, statesResponse)
  860 |       statesGeometryPending.resolve(statesResponse)
  861 |       await expect(page.locator('.settings-grid > .settings-card')).toHaveCount(3)
  862 |       await expect(page.locator('.workflow-state-list > article')).toHaveCount(workflowStates.length)
  863 |       const statesResolved = await measureResolvedGrid(page, '.workflow-state-list', ':scope > article')
  864 |       expect(statesResolved.columns).toBe(statesPending.columns)
  865 |       expect(statesResolved.document.overflow).toBe(0)
  866 |       expect(Math.abs(statesResolved.root.width - statesPending.root.width)).toBeLessThanOrEqual(2)
  867 |       statesResolved.items.forEach((card, index) => expect(Math.abs(card.width - statesPending.cells[index]!.width)).toBeLessThanOrEqual(2))
  868 |       const settingsResolved = await measureRects(page, '.settings-grid > .settings-card')
  869 |       const settingsContainment = await measureResolvedContainment(page)
  870 |       const settingsHeaderResolved = (await measureRects(page, '.settings-page > header'))[0]!
  871 |       expect(settingsContainment.document.overflow).toBe(0)
  872 |       await expect(settingsHeader).toHaveAttribute('data-loading-identity', 'stable-settings-header')
  873 |       expect(Math.abs(settingsHeaderPending.top - settingsHeaderResolved.top)).toBeLessThanOrEqual(2)
  874 |       for (const index of [0, 1, 2])
  875 |         expect(Math.abs(settingsPending.cells[index]!.width - settingsResolved[index]!.width)).toBeLessThanOrEqual(8)
  876 |       await persistEvidence(page, testInfo, `loading-settings-geometry-${viewport.width}x${viewport.height}`, {
  877 |         header: { pending: settingsHeaderPending, resolved: settingsHeaderResolved },
  878 |         pending: settingsPending,
  879 |         resolvedCards: settingsResolved,
  880 |         resolvedContainment: settingsContainment,
  881 |         states: { pending: statesPending, resolved: statesResolved },
  882 |       })
  883 | 
  884 |       const workItemsPending = deferredResponse()
  885 |       routes.setRequest('GET', `/api/v1/teams/${team.id}/states`, { body: { items: workflowStates, nextCursor: null } })
  886 |       routes.set('/api/v1/work-items', workItemsPending.promise)
  887 |       await page.goto('/?view=my-work&layout=board', { waitUntil: 'domcontentloaded' })
  888 |       const boardControls = page.locator('.work-surface-layout-toggle')
  889 |       await boardControls.evaluate(element => { element.dataset.loadingIdentity = 'stable-board-controls' })
  890 |       const boardControlsPending = (await measureRects(page, '.work-surface-layout-toggle'))[0]!
  891 |       const boardPending = await measureSkeleton(page, '.work-surfaces .skeleton-list', { panelSelector: '.work-surfaces' })
  892 |       expectContainedSkeleton(boardPending, viewport.width <= 560 ? 1 : workflowStates.length, viewport.width > 560)
  893 |       expect(boardPending.busyOwners).toBe(1)
  894 |       expect(boardPending.cells).toHaveLength(workflowStates.length)
  895 |       if (viewport.width > 560)
  896 |         expect(boardPending.cells.every(cell => Math.abs(cell.width - 320) <= 2)).toBe(true)
  897 |       await page.screenshot({ path: join(evidenceRoot, `loading-board-pending-${viewport.width}x${viewport.height}.png`) })
  898 | 
  899 |       const workItemsResponse = { body: { items: [browserWorkItem], nextCursor: null } } satisfies JsonResponse
  900 |       routes.set('/api/v1/work-items', workItemsResponse)
  901 |       workItemsPending.resolve(workItemsResponse)
  902 |       await expect(page.locator('.wm-work-item-column')).toHaveCount(workflowStates.length)
  903 |       const boardResolved = await measureRects(page, '.wm-work-item-column')
  904 |       const boardContainment = await measureResolvedContainment(page, '.wm-work-item-board-scroll')
  905 |       const boardControlsResolved = (await measureRects(page, '.work-surface-layout-toggle'))[0]!
  906 |       expect(boardContainment.document.overflow).toBe(0)
  907 |       await expect(boardControls).toHaveAttribute('data-loading-identity', 'stable-board-controls')
  908 |       expect(Math.abs(boardControlsPending.top - boardControlsResolved.top)).toBeLessThanOrEqual(2)
  909 |       if (viewport.width > 560)
  910 |         boardResolved.forEach((column, index) => expect(Math.abs(boardPending.cells[index]!.width - column.width)).toBeLessThanOrEqual(2))
```