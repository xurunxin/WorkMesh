# Instructions

- Following Playwright test failed.
- Explain why, be concise, respect Playwright best practices.
- Provide a snippet of code with the fix, if possible.

# Test info

- Name: mocked\operations-ux.mocked.spec.ts >> filters only loaded localized values, keeps metrics and pagination, and restores the same-tab URL
- Location: e2e\mocked\operations-ux.mocked.spec.ts:1344:1

# Error details

```
Error: expect(locator).toHaveValue(expected) failed

Locator: getByRole('searchbox', { name: 'Search loaded Operations records' })
Expected: "Agent run"
Timeout: 10000ms
Error: element(s) not found

Call log:
  - Expect "toHaveValue" with timeout 10000ms
  - waiting for getByRole('searchbox', { name: 'Search loaded Operations records' })

```

```yaml
- alert
- main:
  - heading "Page not found" [level=1]
  - paragraph: The page you are looking for does not exist or has been moved.
  - link "Back to home":
    - /url: /
```

# Test source

```ts
  1310 |   try {
  1311 |     await installOperationsRoutes(page, () => allOperationsFeatures, {
  1312 |       emptyCollections: collectionPaths,
  1313 |       requestLog,
  1314 |     })
  1315 |     await page.goto('/operations')
  1316 | 
  1317 |     const serverEmptyHeadings = [
  1318 |       ['cycles-panel', 'No Cycles configured'],
  1319 |       ['initiatives-panel', 'No Initiatives configured'],
  1320 |       ['automation-panel', 'No Rules configured'],
  1321 |       ['loops-panel', 'No Loops configured'],
  1322 |       ['runs-panel', 'No run history yet'],
  1323 |       ['templates-panel', 'No Templates configured'],
  1324 |     ] as const
  1325 |     for (const [panelId, heading] of serverEmptyHeadings) {
  1326 |       const panel = page.getByTestId(panelId)
  1327 |       await expect(panel.getByRole('heading', { name: heading }), `${panelId}: exhausted empty`).toBeVisible()
  1328 |       await expect(panel.getByRole('heading', { name: /^Loading / }), `${panelId}: not loading`).toHaveCount(0)
  1329 |       await expect(panel.getByRole('heading', { name: /^No loaded .* match$/ }), `${panelId}: not client no-match`).toHaveCount(0)
  1330 |     }
  1331 | 
  1332 |     const observedCollectionPaths = [...new Set(
  1333 |       requestLog
  1334 |         .map(value => new URL(value).pathname)
  1335 |         .filter(path => collectionPathSet.has(path)),
  1336 |     )].sort()
  1337 |     expect(observedCollectionPaths).toEqual([...collectionPaths].sort())
  1338 |     expect(requestLog.every(value => !new URL(value).searchParams.has('opsQuery'))).toBe(true)
  1339 |   } finally {
  1340 |     await page.close()
  1341 |   }
  1342 | })
  1343 | 
  1344 | test('filters only loaded localized values, keeps metrics and pagination, and restores the same-tab URL', async ({ page }) => {
  1345 |   const requestLog: string[] = []
  1346 |   await installOperationsRoutes(page, () => allOperationsFeatures, { paginatedRuns: true, requestLog })
  1347 |   await page.goto('/operations?context=keep#operations-runs')
  1348 |   const search = page.getByRole('searchbox', { name: 'Search loaded Operations records' })
  1349 |   await expect(search).toBeVisible()
  1350 |   await page.evaluate(() => window.history.replaceState({ ...window.history.state, task42: 'keep' }, '', window.location.href))
  1351 | 
  1352 |   await search.fill('Current')
  1353 |   await expect(page.getByTestId('cycles-panel').getByText('Nightly planning')).toBeVisible()
  1354 |   await expect(page.locator('#operations-metrics')).toBeVisible()
  1355 |   await expect(page.locator('#operations-metrics')).toContainText('Tokens')
  1356 |   expect(await page.evaluate(() => window.history.state.task42)).toBe('keep')
  1357 |   expect(new URL(page.url()).searchParams.get('context')).toBe('keep')
  1358 |   expect(new URL(page.url()).hash).toBe('#operations-runs')
  1359 | 
  1360 |   await search.fill('On track')
  1361 |   await expect(page.getByTestId('initiatives-panel').getByText('Runtime reliability')).toBeVisible()
  1362 |   await search.fill('on_track')
  1363 |   await expect(page.getByTestId('initiatives-panel').getByText('Runtime reliability')).toHaveCount(0)
  1364 | 
  1365 |   await search.fill('Webhook retry')
  1366 |   await expect(page.getByTestId('automation-panel').getByText('Webhook retry')).toBeVisible()
  1367 |   await expect(page.getByTestId('automation-panel')).toContainText('Disabled')
  1368 |   await search.fill('schedule 0 2 * * *')
  1369 |   await expect(page.getByTestId('automation-panel').getByText('Webhook retry')).toBeVisible()
  1370 |   await expect(page.getByTestId('automation-panel')).toContainText('v1 · schedule 0 2 * * *')
  1371 |   await search.fill('Release guard')
  1372 |   await expect(page.getByTestId('loops-panel').getByText('Release guard')).toBeVisible()
  1373 |   await expect(page.getByTestId('loops-panel')).toContainText('No overlap')
  1374 | 
  1375 |   await search.fill('Dry run')
  1376 |   await expect(page.getByTestId('runs-panel').getByText('run-0008')).toBeVisible()
  1377 |   await search.fill('dry_run')
  1378 |   await expect(page.getByTestId('runs-panel').getByText('run-0008')).toHaveCount(0)
  1379 | 
  1380 |   await search.fill('Agent run')
  1381 |   await expect(page.getByTestId('templates-panel').getByText('Agent recovery')).toBeVisible()
  1382 |   await search.fill('agent_run')
  1383 |   await expect(page.getByTestId('templates-panel').getByText('Agent recovery')).toHaveCount(0)
  1384 | 
  1385 |   await search.fill('Delayed retry queue exhausted')
  1386 |   await expect(page.getByTestId('runs-panel').getByRole('heading', { name: 'No loaded Recent runs match' })).toBeVisible()
  1387 |   await expect(page.locator('#operations-metrics')).toBeVisible()
  1388 |   await expect(page.locator('#operations-metrics')).toContainText('Tokens')
  1389 |   await page.getByRole('button', { name: 'Load more Recent runs' }).click()
  1390 |   await expect(page.getByTestId('runs-panel').getByText('Delayed retry queue exhausted')).toBeVisible()
  1391 | 
  1392 |   await page.reload()
  1393 |   await expect(search).toHaveValue('Delayed retry queue exhausted')
  1394 |   await expect(page.getByRole('button', { name: 'Load more Recent runs' })).toBeVisible()
  1395 |   await search.fill('Current')
  1396 |   await page.evaluate(() => {
  1397 |     const url = new URL(window.location.href)
  1398 |     url.searchParams.set('opsQuery', 'On track')
  1399 |     window.history.pushState({ ...window.history.state, task42: 'keep' }, '', url)
  1400 |     window.dispatchEvent(new PopStateEvent('popstate'))
  1401 |   })
  1402 |   await expect(search).toHaveValue('On track')
  1403 |   await page.goBack()
  1404 |   await expect(search).toHaveValue('Current')
  1405 |   await page.goForward()
  1406 |   await expect(search).toHaveValue('On track')
  1407 | 
  1408 |   await page.goto('/settings?tab=operations&context=keep&opsQuery=Agent+run#operations-templates')
  1409 |   const embeddedSearch = page.getByRole('searchbox', { name: 'Search loaded Operations records' })
> 1410 |   await expect(embeddedSearch).toHaveValue('Agent run')
       |                                ^ Error: expect(locator).toHaveValue(expected) failed
  1411 |   await embeddedSearch.fill('Archived')
  1412 |   const embeddedUrl = new URL(page.url())
  1413 |   expect(embeddedUrl.searchParams.get('tab')).toBe('operations')
  1414 |   expect(embeddedUrl.searchParams.get('context')).toBe('keep')
  1415 |   expect(embeddedUrl.searchParams.get('opsQuery')).toBe('Archived')
  1416 |   expect(embeddedUrl.hash).toBe('#operations-templates')
  1417 | 
  1418 |   const collectionRequests = requestLog.filter(value => isCollectionPath(new URL(value).pathname))
  1419 |   expect(collectionRequests.length).toBeGreaterThan(0)
  1420 |   expect(collectionRequests.some(value => new URL(value).searchParams.get('cursor') === 'runs-page-2')).toBe(true)
  1421 |   expect(collectionRequests.every(value => !new URL(value).searchParams.has('opsQuery'))).toBe(true)
  1422 | })
  1423 | 
  1424 | test('searches every collection by its exact display projection while excluding hidden raw fields', async ({ context }) => {
  1425 |   const page = await context.newPage()
  1426 |   const requestLog: string[] = []
  1427 |   const readText = async (locator: Locator, label: string) => {
  1428 |     const value = (await locator.textContent())?.trim() ?? ''
  1429 |     expect(value, label).not.toBe('')
  1430 |     return value
  1431 |   }
  1432 |   try {
  1433 |     await installOperationsRoutes(page, () => allOperationsFeatures, { requestLog })
  1434 |     await page.goto('/operations')
  1435 | 
  1436 |     const search = page.getByRole('searchbox', { name: 'Search loaded Operations records' })
  1437 |     await expect(search).toBeVisible()
  1438 | 
  1439 |     const cyclePanel = page.getByTestId('cycles-panel')
  1440 |     const cycle = cyclePanel.locator('article').filter({ hasText: 'Nightly planning' })
  1441 |     const cycleState = await readText(cycle.locator('.status'), 'Cycle localized state')
  1442 |     const cycleDate = await readText(cycle.locator('small'), 'Cycle localized date range')
  1443 | 
  1444 |     const initiativePanel = page.getByTestId('initiatives-panel')
  1445 |     const initiative = initiativePanel.locator('article').filter({ hasText: 'Runtime reliability' })
  1446 |     const initiativeHealth = await readText(initiative.locator('.health'), 'Initiative localized health')
  1447 |     const initiativeLine = await readText(initiative.locator('p'), 'Initiative localized status and priority')
  1448 | 
  1449 |     const automationPanel = page.getByTestId('automation-panel')
  1450 |     const rule = automationPanel.locator('article').filter({ hasText: 'Webhook retry' })
  1451 |     const ruleState = await readText(rule.locator('.status'), 'Automation localized state')
  1452 |     const ruleKind = await readText(rule.locator('small'), 'Automation rendered trigger kind')
  1453 | 
  1454 |     const loopsPanel = page.getByTestId('loops-panel')
  1455 |     const loop = loopsPanel.locator('article').filter({ hasText: 'Release guard' })
  1456 |     const loopState = await readText(loop.locator('.status'), 'Loop localized state')
  1457 |     const loopSchedule = await readText(loop.locator('small'), 'Loop localized schedule')
  1458 | 
  1459 |     const runsPanel = page.getByTestId('runs-panel')
  1460 |     const failedRun = page.getByTestId('run-row-run-0005-record')
  1461 |     const failedRunKind = await readText(failedRun.locator('td').nth(1), 'Run localized kind')
  1462 |     const failedRunState = await readText(failedRun.locator('.status'), 'Run localized state')
  1463 |     const failedRunDate = await readText(failedRun.locator('time'), 'Run localized date')
  1464 |     const failedRunError = await readText(
  1465 |       runsPanel.getByText(/Provider retry failed after the upstream execution service/),
  1466 |       'Run historical error',
  1467 |     )
  1468 | 
  1469 |     const templatesPanel = page.getByTestId('templates-panel')
  1470 |     const template = templatesPanel.locator('.template-list > span').filter({ hasText: 'Agent recovery' })
  1471 |     const templateLine = await readText(template.locator('small'), 'Template localized kind and status')
  1472 | 
  1473 |     const expectVisibleFor = async (query: string, item: Locator, label: string) => {
  1474 |       await search.fill(query)
  1475 |       await expect(item, `${label}: exact rendered query`).toBeVisible()
  1476 |     }
  1477 |     const expectHiddenFor = async (
  1478 |       query: string,
  1479 |       item: Locator,
  1480 |       panel: Locator,
  1481 |       noMatchHeading: string,
  1482 |       label: string,
  1483 |     ) => {
  1484 |       await search.fill(query)
  1485 |       await expect(item, `${label}: hidden raw field`).toHaveCount(0)
  1486 |       await expect(panel.getByRole('heading', { name: noMatchHeading }), `${label}: client no-match`).toBeVisible()
  1487 |     }
  1488 | 
  1489 |     await expectVisibleFor(cycleState, cycle, 'Cycle state')
  1490 |     await expectVisibleFor(cycleDate, cycle, 'Cycle date')
  1491 |     await expectHiddenFor('cycle-current', cycle, cyclePanel, 'No loaded Cycles match', 'Cycle full ID')
  1492 | 
  1493 |     await expectVisibleFor(initiativeHealth, initiative, 'Initiative health')
  1494 |     await expectVisibleFor(initiativeLine, initiative, 'Initiative status/priority')
  1495 |     await expectHiddenFor('on_track', initiative, initiativePanel, 'No loaded Initiatives match', 'Initiative raw health')
  1496 | 
  1497 |     await expectVisibleFor(ruleState, rule, 'Automation state')
  1498 |     await expectVisibleFor(ruleKind, rule, 'Automation trigger')
  1499 |     await expectHiddenFor('rule-1', rule, automationPanel, 'No loaded Automation rules match', 'Automation raw ID')
  1500 |     await expectHiddenFor('UTC', rule, automationPanel, 'No loaded Automation rules match', 'Automation undisplayed timezone')
  1501 | 
  1502 |     await expectVisibleFor(loopState, loop, 'Loop state')
  1503 |     await expectVisibleFor(loopSchedule, loop, 'Loop schedule')
  1504 |     await expectHiddenFor('no_overlap', loop, loopsPanel, 'No loaded Loops match', 'Loop raw overlap enum')
  1505 | 
  1506 |     await expectVisibleFor(failedRunKind, failedRun, 'Run kind')
  1507 |     await expectVisibleFor(failedRunState, failedRun, 'Run status')
  1508 |     await expectVisibleFor(failedRunDate, failedRun, 'Run date')
  1509 |     await expectVisibleFor(failedRunError, failedRun, 'Run historical error')
  1510 |     const dryRun = page.getByTestId('run-row-run-0008-record')
```