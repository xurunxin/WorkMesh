# Instructions

- Following Playwright test failed.
- Explain why, be concise, respect Playwright best practices.
- Provide a snippet of code with the fix, if possible.

# Test info

- Name: mocked\operations-ux.mocked.spec.ts >> keeps Settings route history, shared responsive semantics, and dense 390/1920 geometry
- Location: e2e\mocked\operations-ux.mocked.spec.ts:831:1

# Error details

```
Error: expect(locator).toHaveAttribute(expected) failed

Locator: getByRole('tab', { name: 'Planning & Operations' })
Expected: "true"
Timeout: 10000ms
Error: element(s) not found

Call log:
  - Expect "toHaveAttribute" with timeout 10000ms
  - waiting for getByRole('tab', { name: 'Planning & Operations' })

```

```yaml
- alert
- main:
  - heading "Page not found" [level=1]
  - paragraph: The page you are looking for does not exist or has been moved.
  - link "Back to home":
    - /url: /
```

# Test source

```ts
  740 | test('restores embedded current state without taking focus when the real Settings tab becomes visible', async ({ page }, testInfo) => {
  741 |   await installOperationsRoutes(page, () => allOperationsFeatures, settingsRouteFixtures)
  742 |   await page.goto('/settings?tab=workspace&team=team-1&opsQuery=Archived&x=keep#operations-runs')
  743 |   const workspaceTab = page.getByRole('tab', { name: 'Workspace' })
  744 |   await expect(workspaceTab).toHaveAttribute('aria-selected', 'true')
  745 | 
  746 |   const beforeMount = await page.evaluate(async () => {
  747 |     window.scrollTo(0, Math.min(120, document.documentElement.scrollHeight - window.innerHeight))
  748 |     await new Promise<void>(resolve => requestAnimationFrame(() => requestAnimationFrame(() => resolve())))
  749 |     return { scrollY: window.scrollY, viewportHeight: window.innerHeight }
  750 |   })
  751 |   expect(beforeMount.scrollY).toBeGreaterThan(0)
  752 |   const workspaceTabBox = await workspaceTab.boundingBox()
  753 |   expect(workspaceTabBox).not.toBeNull()
  754 |   expect(workspaceTabBox?.y ?? -1).toBeGreaterThanOrEqual(0)
  755 |   expect((workspaceTabBox?.y ?? beforeMount.viewportHeight) + (workspaceTabBox?.height ?? 0)).toBeLessThan(beforeMount.viewportHeight)
  756 | 
  757 |   const operationsTab = page.getByRole('tab', { name: 'Planning & Operations' })
  758 |   await operationsTab.click()
  759 |   const navigation = page.getByTestId('operations-section-navigation')
  760 |   await expect(navigation).toBeVisible()
  761 |   await expect(page).toHaveURL('/settings?tab=operations&team=team-1&opsQuery=Archived&x=keep#operations-runs')
  762 |   await expect(navigation.getByRole('link', { name: 'Recent runs' })).toHaveAttribute('aria-current', 'location')
  763 |   await expect(operationsTab).toBeFocused()
  764 |   const runsTarget = page.locator('#operations-runs')
  765 |   await expect(runsTarget).not.toBeFocused()
  766 |   const afterMount = await runsTarget.evaluate(element => ({
  767 |     scrollY: window.scrollY,
  768 |     targetTop: element.getBoundingClientRect().top,
  769 |     viewportHeight: window.innerHeight,
  770 |   }))
  771 |   expect(Math.abs(afterMount.scrollY - beforeMount.scrollY)).toBeLessThanOrEqual(1)
  772 |   expect(afterMount.targetTop).toBeGreaterThan(afterMount.viewportHeight)
  773 | 
  774 |   const localeControl = page.getByRole('button', { exact: true, name: 'EN' })
  775 |   await localeControl.focus()
  776 |   const templatesTarget = page.locator('#operations-templates')
  777 |   const beforeHash = await templatesTarget.evaluate(element => ({
  778 |     scrollY: window.scrollY,
  779 |     targetTop: element.getBoundingClientRect().top,
  780 |   }))
  781 |   await page.evaluate(() => {
  782 |     const url = new URL(window.location.href)
  783 |     url.hash = '#operations-templates'
  784 |     window.history.replaceState(window.history.state, '', url)
  785 |     window.dispatchEvent(new HashChangeEvent('hashchange'))
  786 |   })
  787 |   await expect(navigation.getByRole('link', { name: 'Templates' })).toHaveAttribute('aria-current', 'location')
  788 |   const afterHash = await templatesTarget.evaluate(element => ({
  789 |     scrollY: window.scrollY,
  790 |     targetTop: element.getBoundingClientRect().top,
  791 |   }))
  792 |   expect(Math.abs(afterHash.scrollY - beforeHash.scrollY)).toBeLessThanOrEqual(1)
  793 |   expect(Math.abs(afterHash.targetTop - beforeHash.targetTop)).toBeLessThanOrEqual(1)
  794 |   await expect(localeControl).toBeFocused()
  795 |   await expect(templatesTarget).not.toBeFocused()
  796 | 
  797 |   const beforePopstate = await runsTarget.evaluate(element => ({
  798 |     scrollY: window.scrollY,
  799 |     targetTop: element.getBoundingClientRect().top,
  800 |   }))
  801 |   await page.evaluate(() => {
  802 |     const url = new URL(window.location.href)
  803 |     url.hash = '#operations-runs'
  804 |     window.history.replaceState(window.history.state, '', url)
  805 |     window.dispatchEvent(new PopStateEvent('popstate', { state: window.history.state }))
  806 |   })
  807 |   await expect(navigation.getByRole('link', { name: 'Recent runs' })).toHaveAttribute('aria-current', 'location')
  808 |   const afterPopstate = await runsTarget.evaluate(element => ({
  809 |     scrollY: window.scrollY,
  810 |     targetTop: element.getBoundingClientRect().top,
  811 |   }))
  812 |   expect(Math.abs(afterPopstate.scrollY - beforePopstate.scrollY)).toBeLessThanOrEqual(1)
  813 |   expect(Math.abs(afterPopstate.targetTop - beforePopstate.targetTop)).toBeLessThanOrEqual(1)
  814 |   await expect(localeControl).toBeFocused()
  815 |   await expect(runsTarget).not.toBeFocused()
  816 | 
  817 |   const evidencePath = testInfo.outputPath('task-5.1-embedded-passive-scroll-pass.json')
  818 |   await writeFile(evidencePath, JSON.stringify({
  819 |     beforeMount,
  820 |     workspaceTabBox,
  821 |     afterMount,
  822 |     hashchange: { before: beforeHash, after: afterHash },
  823 |     popstate: { before: beforePopstate, after: afterPopstate },
  824 |   }, null, 2), 'utf8')
  825 |   await testInfo.attach('task-5.1-embedded-passive-scroll-pass', {
  826 |     contentType: 'application/json',
  827 |     path: evidencePath,
  828 |   })
  829 | })
  830 | 
  831 | test('keeps Settings route history, shared responsive semantics, and dense 390/1920 geometry', async ({ page }, testInfo) => {
  832 |   const directUrl = '/settings?tab=operations&team=team-1&opsQuery=Archived&x=keep#operations-templates'
  833 |   const routedOperationsUrl = '/settings?team=team-1&opsQuery=Archived&x=keep&tab=operations#operations-templates'
  834 |   await installOperationsRoutes(page, () => allOperationsFeatures, settingsRouteFixtures)
  835 | 
  836 |   await page.setViewportSize({ width: 1920, height: 1080 })
  837 |   await page.goto(directUrl)
  838 |   const operationsTab = page.getByRole('tab', { name: 'Planning & Operations' })
  839 |   const workspaceTab = page.getByRole('tab', { name: 'Workspace' })
> 840 |   await expect(operationsTab).toHaveAttribute('aria-selected', 'true')
      |                               ^ Error: expect(locator).toHaveAttribute(expected) failed
  841 |   await expect(page.getByRole('searchbox', { name: 'Search loaded Operations records' })).toHaveValue('Archived')
  842 |   await expect(page.getByRole('link', { name: 'Templates' })).toHaveAttribute('aria-current', 'location')
  843 |   await expect(page).toHaveURL(`${webUrl}${directUrl}`)
  844 | 
  845 |   await page.reload()
  846 |   await expect(page.getByRole('tab', { name: 'Planning & Operations' })).toHaveAttribute('aria-selected', 'true')
  847 |   await expect(page.getByRole('link', { name: 'Templates' })).toHaveAttribute('aria-current', 'location')
  848 |   await expect(page).toHaveURL(`${webUrl}${directUrl}`)
  849 |   await page.evaluate(() => window.history.replaceState({ ...window.history.state, task51: 'kept' }, '', window.location.href))
  850 | 
  851 |   const initialLength = await page.evaluate(() => window.history.length)
  852 |   await page.getByRole('tab', { name: 'Workspace' }).click()
  853 |   await expect(page).toHaveURL(`${webUrl}/settings?team=team-1&opsQuery=Archived&x=keep#operations-templates`)
  854 |   expect(await page.evaluate(() => window.history.length)).toBe(initialLength + 1)
  855 |   expect(await page.evaluate(() => window.history.state.task51)).toBe('kept')
  856 | 
  857 |   await page.getByRole('tab', { name: 'Workspace' }).click()
  858 |   expect(await page.evaluate(() => window.history.length)).toBe(initialLength + 1)
  859 | 
  860 |   await page.getByRole('tab', { name: 'Workspace' }).press('End')
  861 |   await expect(page.getByRole('tab', { name: 'Planning & Operations' })).toBeFocused()
  862 |   await expect(page).toHaveURL(`${webUrl}${routedOperationsUrl}`)
  863 |   expect(await page.evaluate(() => window.history.length)).toBe(initialLength + 2)
  864 | 
  865 |   await page.getByRole('tab', { name: 'Planning & Operations' }).press('End')
  866 |   expect(await page.evaluate(() => window.history.length)).toBe(initialLength + 2)
  867 |   await page.getByRole('tab', { name: 'Planning & Operations' }).press('Home')
  868 |   await expect(page.getByRole('tab', { name: 'Workspace' })).toBeFocused()
  869 |   expect(await page.evaluate(() => window.history.length)).toBe(initialLength + 3)
  870 |   await page.getByRole('tab', { name: 'Workspace' }).press('ArrowLeft')
  871 |   await expect(page.getByRole('tab', { name: 'Planning & Operations' })).toBeFocused()
  872 |   expect(await page.evaluate(() => window.history.length)).toBe(initialLength + 4)
  873 | 
  874 |   const localeControl = page.getByRole('button', { exact: true, name: 'EN' })
  875 |   await localeControl.focus()
  876 |   await page.goBack()
  877 |   await expect(page).toHaveURL(`${webUrl}/settings?team=team-1&opsQuery=Archived&x=keep#operations-templates`)
  878 |   await expect(page.getByRole('tab', { name: 'Workspace' })).toHaveAttribute('aria-selected', 'true')
  879 |   await expect(localeControl).toBeFocused()
  880 |   await page.goForward()
  881 |   await expect(page).toHaveURL(`${webUrl}${routedOperationsUrl}`)
  882 |   await expect(page.getByRole('tab', { name: 'Planning & Operations' })).toHaveAttribute('aria-selected', 'true')
  883 |   await expect(localeControl).toBeFocused()
  884 | 
  885 |   const geometry: Awaited<ReturnType<typeof measureSettingsGeometry>>[] = []
  886 |   const wide = await measureSettingsGeometry(page)
  887 |   geometry.push(wide)
  888 |   expect(wide.document.scrollWidth).toBe(wide.document.clientWidth)
  889 |   expect(wide.content.width / wide.main.width).toBeGreaterThanOrEqual(.85)
  890 |   expect(wide.content.width).toBeLessThanOrEqual(1480)
  891 |   expect(wide.panel.width / wide.contentInnerWidth).toBeGreaterThanOrEqual(.98)
  892 |   expect(wide.operationsRoot.width / wide.panel.width).toBeGreaterThanOrEqual(.98)
  893 |   const wideScreenshot = testInfo.outputPath('task-5.1-settings-wide-pass.png')
  894 |   await page.screenshot({ fullPage: true, path: wideScreenshot })
  895 |   await testInfo.attach('task-5.1-settings-wide-pass', { contentType: 'image/png', path: wideScreenshot })
  896 | 
  897 |   await page.setViewportSize({ width: 390, height: 844 })
  898 |   await page.goto(directUrl)
  899 |   const selector = page.getByRole('combobox', { name: 'Settings sections' })
  900 |   await expect(selector).toHaveValue('operations')
  901 |   await expect(page.getByRole('tablist')).toHaveCount(0)
  902 |   await expect(page.getByRole('tab')).toHaveCount(0)
  903 |   await expect(page.getByRole('tabpanel')).toHaveCount(1)
  904 |   await selector.focus()
  905 |   await selector.selectOption('workspace')
  906 |   await expect(selector).toBeFocused()
  907 |   await expect(page).toHaveURL(`${webUrl}/settings?team=team-1&opsQuery=Archived&x=keep#operations-templates`)
  908 |   expect(await page.evaluate(() => document.documentElement.scrollWidth)).toBe(390)
  909 | 
  910 |   await selector.selectOption('operations')
  911 |   await expect(selector).toBeFocused()
  912 |   const narrow = await measureSettingsGeometry(page)
  913 |   geometry.push(narrow)
  914 |   expect(narrow.document.scrollWidth).toBe(narrow.document.clientWidth)
  915 |   expect(narrow.content.width).toBeLessThanOrEqual(390)
  916 |   expect(narrow.panel.width / narrow.contentInnerWidth).toBeGreaterThanOrEqual(.98)
  917 |   const narrowScreenshot = testInfo.outputPath('task-5.1-settings-narrow-pass.png')
  918 |   await page.screenshot({ fullPage: true, path: narrowScreenshot })
  919 |   await testInfo.attach('task-5.1-settings-narrow-pass', { contentType: 'image/png', path: narrowScreenshot })
  920 | 
  921 |   const geometryPath = testInfo.outputPath('task-5.1-settings-geometry-pass.json')
  922 |   await writeFile(geometryPath, JSON.stringify(geometry, null, 2), 'utf8')
  923 |   await testInfo.attach('task-5.1-settings-geometry-pass', { contentType: 'application/json', path: geometryPath })
  924 | })
  925 | 
  926 | test('scopes Team resolution to Workspace with serial deep-link pagination and dense 390/1920 geometry', async ({ page }, testInfo) => {
  927 |   const requestLog: string[] = []
  928 |   const teamRequestSequence = () => requestLog
  929 |     .map(request => new URL(request))
  930 |     .filter(url => url.pathname === '/api/v1/teams' || /^\/api\/v1\/teams\/[^/]+\/states$/.test(url.pathname))
  931 |     .map(url => `${url.pathname}${url.search}`)
  932 |   const resolutionSequence = [
  933 |     '/api/v1/teams?limit=100',
  934 |     '/api/v1/teams?limit=100&cursor=teams-page-2',
  935 |     '/api/v1/teams/team-second-page/states?limit=100',
  936 |   ]
  937 |   await installOperationsRoutes(page, () => allOperationsFeatures, {
  938 |     requestLog,
  939 |     settingsTeamPages: {
  940 |       first: { items: [settingsTeamOne], nextCursor: 'teams-page-2' },
```