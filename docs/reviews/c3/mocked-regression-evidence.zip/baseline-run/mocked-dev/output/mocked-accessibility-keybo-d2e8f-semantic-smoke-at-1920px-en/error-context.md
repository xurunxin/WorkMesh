# Instructions

- Following Playwright test failed.
- Explain why, be concise, respect Playwright best practices.
- Provide a snippet of code with the fix, if possible.

# Test info

- Name: mocked\accessibility-keyboard.mocked.spec.ts >> Agent and Session deep-link semantic smoke at 1920px en
- Location: e2e\mocked\accessibility-keyboard.mocked.spec.ts:623:3

# Error details

```
Error: expect(locator).toBeVisible() failed

Locator: locator('.agent-detail-panel')
Expected: visible
Timeout: 10000ms
Error: element(s) not found

Call log:
  - Expect "toBeVisible" with timeout 10000ms
  - waiting for locator('.agent-detail-panel')

```

```yaml
- alert
- link "Skip to content":
  - /url: "#workmesh-main"
- complementary "Main navigation":
  - strong: WorkMesh
  - text: Alex Morgan
  - button "Collapse sidebar" [expanded]
  - navigation "Workspace navigation":
    - paragraph: Workbench
    - link "Workbench":
      - /url: /workbench
    - link "My work":
      - /url: /?view=home
    - link "Issues":
      - /url: /?view=my-work
    - link "Guidance":
      - /url: /?view=guidance
    - paragraph: Governance
    - link "Needs You":
      - /url: /?view=inbox
    - link "Session":
      - /url: /?view=sessions
    - link "Recovery":
      - /url: /?view=recovery
    - link "Projects":
      - /url: /?view=projects
    - link "Agents":
      - /url: /agents
    - paragraph: Operations
    - link "Operations":
      - /url: /operations
  - navigation "Administration navigation":
    - link "Settings":
      - /url: /settings
  - button "Sign out"
  - text: v1.0.0 · build accessibility-fixture · schema 24
- banner:
  - paragraph: Human control plane
  - button "Search": Search Ctrl K
  - button "Switch to the light theme"
  - group "Language":
    - button "中"
    - button "EN" [pressed]
  - text: Reconnecting
- main:
  - paragraph: Agent definition
  - heading "Agents" [level=1]
  - paragraph: Review stable identity, runtime contracts, and capability facts. Team authority is managed from the registry’s authoritative aggregate.
  - link "Back to Agent registry":
    - /url: /agents?tab=agents
  - alert:
    - heading "Could not load Agent details" [level=2]
    - paragraph: "[ { \"code\": \"invalid_type\", \"expected\": \"string\", \"received\": \"undefined\", \"path\": [ \"icon\" ], \"message\": \"Required\" }, { \"code\": \"invalid_type\", \"expected\": \"string\", \"received\": \"undefined\", \"path\": [ \"endpoint_url\" ], \"message\": \"Required\" }, { \"code\": \"invalid_type\", \"expected\": \"array\", \"received\": \"undefined\", \"path\": [ \"output_artifact_types\" ], \"message\": \"Required\" }, { \"code\": \"invalid_type\", \"expected\": \"object\", \"received\": \"undefined\", \"path\": [ \"metadata\" ], \"message\": \"Required\" }, { \"expected\": \"'active' | 'archived'\", \"received\": \"undefined\", \"code\": \"invalid_type\", \"path\": [ \"lifecycle_status\" ], \"message\": \"Required\" }, { \"code\": \"invalid_type\", \"expected\": \"string\", \"received\": \"undefined\", \"path\": [ \"archived_at\" ], \"message\": \"Required\" }, { \"code\": \"invalid_type\", \"expected\": \"string\", \"received\": \"undefined\", \"path\": [ \"archived_by_actor_id\" ], \"message\": \"Required\" }, { \"code\": \"invalid_type\", \"expected\": \"string\", \"received\": \"undefined\", \"path\": [ \"archived_reason\" ], \"message\": \"Required\" }, { \"code\": \"invalid_type\", \"expected\": \"string\", \"received\": \"undefined\", \"path\": [ \"created_at\" ], \"message\": \"Required\" }, { \"code\": \"invalid_type\", \"expected\": \"string\", \"received\": \"undefined\", \"path\": [ \"updated_at\" ], \"message\": \"Required\" } ]"
    - button "Retry"
```

# Test source

```ts
  532 |     evidence.homeSkip = await expectSkipJourney(page, '390 Home', 'zh-CN')
  533 |     evidence.home = await expectSemanticPage(page, '390 Home')
  534 |     const workItemTrigger = page.locator(`[data-work-item-id="${accessibilityIds.workItem}"] .wm-work-item-title`)
  535 |     expect.soft(await tabUntilFocused(page, workItemTrigger), '390 Work Item is keyboard reachable').toBe(true)
  536 |     if (await workItemTrigger.evaluate(element => element === document.activeElement)) await page.keyboard.press('Enter')
  537 |     const detailDialog = page.getByRole('dialog')
  538 |     await expect(detailDialog).toBeVisible()
  539 |     await expectSemanticIntegrity(page, '390 Work Item detail layer')
  540 |     await expectCompactTabs(detailDialog.locator('.work-item-detail-layout > .wm-tabs'), '390 Work Item detail')
  541 |     await page.keyboard.press('Escape')
  542 |     await expect(detailDialog).toHaveCount(0)
  543 |     await expect.soft(workItemTrigger, '390 closing Work Item detail restores focus').toBeFocused()
  544 | 
  545 |     await page.goto('/agents?tab=agents')
  546 |     await expect(page.locator('.agent-registry-card')).toHaveCount(2)
  547 |     evidence.agents = await expectSemanticPage(page, '390 Agents')
  548 |     const agentTabs = page.locator('.agent-center > .wm-tabs')
  549 |     await expectCompactTabs(agentTabs, '390 Agents primary tabs')
  550 |     const agentSelector = agentTabs.locator(':scope > .wm-tab-list-compact select.wm-tab-select')
  551 |     expect.soft(await tabUntilFocused(page, agentSelector), '390 Agents selector is keyboard reachable').toBe(true)
  552 |     await agentSelector.selectOption('approvals')
  553 |     const approvalTabs = page.locator('.approval-inbox > .wm-tabs')
  554 |     await expectCompactTabs(approvalTabs, '390 Approval views')
  555 |     const pendingGrid = page.locator('.approval-grid')
  556 |     await expect(pendingGrid).toBeVisible()
  557 |     await expect(pendingGrid.getByRole('row')).toHaveCount(2)
  558 |     const pendingRow = pendingGrid.getByTestId(`approval-row-${accessibilityIds.approvalPending}`)
  559 |     await expect(pendingRow.getByRole('button', { name: 'Approve' })).toBeVisible()
  560 |     await expect(pendingRow.getByRole('button', { name: 'Reject' })).toBeVisible()
  561 |     await expect(pendingRow.getByRole('button', { name: 'Other feedback' })).toBeVisible()
  562 |     await expectSemanticIntegrity(page, '390 Pending approvals panel')
  563 |     evidence.pendingApprovalCard = await pendingRow.evaluate(element => {
  564 |       const actions = element.querySelector<HTMLElement>('.approval-row-actions')
  565 |       const bounds = actions?.getBoundingClientRect()
  566 |       return {
  567 |         actionBottom: bounds?.bottom ?? null,
  568 |         actionLeft: bounds?.left ?? null,
  569 |         actionRight: bounds?.right ?? null,
  570 |         documentClientWidth: document.documentElement.clientWidth,
  571 |         documentScrollWidth: document.documentElement.scrollWidth,
  572 |         gridClientWidth: element.parentElement?.clientWidth ?? null,
  573 |         gridScrollWidth: element.parentElement?.scrollWidth ?? null,
  574 |       }
  575 |     })
  576 |     expect(evidence.pendingApprovalCard).toMatchObject({ documentScrollWidth: 390, documentClientWidth: 390, gridScrollWidth: 390, gridClientWidth: 390 })
  577 |     const approvalSelector = approvalTabs.locator(':scope > .wm-tab-list-compact select.wm-tab-select')
  578 |     expect.soft(await tabUntilFocused(page, approvalSelector), '390 Approval selector is keyboard reachable').toBe(true)
  579 |     await approvalSelector.selectOption('history')
  580 |     const historyWrap = page.locator('.approval-history-table-wrap')
  581 |     await expect(historyWrap).toBeVisible()
  582 |     await expectNativeTable(historyWrap, 7, '390 Approval history')
  583 |     await expectSemanticIntegrity(page, '390 Approval History panel')
  584 |     evidence.historyScroll = await expectKeyboardLocalScroll(historyWrap, '390 Approval history')
  585 |     expect.soft(await tabUntilFocused(page, agentSelector), '390 Agents selector can return to Registry').toBe(true)
  586 |     if (await agentSelector.evaluate(element => element === document.activeElement)) await page.keyboard.press('Home')
  587 |     await expect(page.locator('.agent-registry-card')).toHaveCount(2)
  588 |     await openTeamAccess(page, true)
  589 | 
  590 |     await page.goto('/settings?tab=workspace')
  591 |     await expect(page.locator('.settings-page')).toBeVisible()
  592 |     evidence.settings = await expectSemanticPage(page, '390 Settings')
  593 |     const settingsTabs = page.locator('.settings-page > .wm-tabs')
  594 |     await expectCompactTabs(settingsTabs, '390 Settings tabs')
  595 |     const settingsSelector = settingsTabs.locator(':scope > .wm-tab-list-compact select.wm-tab-select')
  596 |     expect.soft(await tabUntilFocused(page, settingsSelector), '390 Settings selector is keyboard reachable').toBe(true)
  597 |     if (await settingsSelector.evaluate(element => element === document.activeElement)) await page.keyboard.press('End')
  598 |     await expect.soft(page.locator('.settings-tab-heading > h2'), '390 embedded Operations remains h2').toHaveCount(1)
  599 |     await expectSemanticIntegrity(page, '390 Embedded Operations panel')
  600 | 
  601 |     await page.goto('/operations#operations-runs')
  602 |     const runsWrap = page.getByTestId('operations-table-scroll')
  603 |     await expect(runsWrap).toBeVisible()
  604 |     evidence.operationsSkip = await expectSkipJourney(page, '390 Standalone Operations', 'zh-CN')
  605 |     evidence.operations = await expectSemanticPage(page, '390 Standalone Operations')
  606 |     evidence.operationsGeometry = await expectStandaloneOperationsGeometry(page, '390 Standalone Operations', 14)
  607 |     await expectNativeTable(runsWrap, 6, '390 Operations Runs')
  608 |     evidence.runsScroll = await expectKeyboardLocalScroll(runsWrap, '390 Operations Runs')
  609 | 
  610 |     fixture.expectNoUnexpected()
  611 |     evidence.requests = fixture.requests
  612 |     await attachScreenshot(testInfo, page, 'accessibility-phone-chinese')
  613 |     await attachJson(testInfo, 'accessibility-phone-chinese', evidence)
  614 |   })
  615 | })
  616 | 
  617 | const deepLinkCases = [
  618 |   { locale: 'en' as const, viewport: { width: 1920, height: 1080 } },
  619 |   { locale: 'zh-CN' as const, viewport: { width: 390, height: 844 } },
  620 | ]
  621 | 
  622 | for (const entry of deepLinkCases) {
  623 |   test(`Agent and Session deep-link semantic smoke at ${entry.viewport.width}px ${entry.locale}`, async ({ page }, testInfo) => {
  624 |     test.setTimeout(60_000)
  625 |     await page.setViewportSize(entry.viewport)
  626 |     const fixture = new AccessibilityFixture()
  627 |     await fixture.install(page)
  628 |     await useLocale(page, entry.locale)
  629 |     const evidence: Record<string, unknown> = {}
  630 | 
  631 |     await page.goto(`/agents/${accessibilityIds.agentOne}`)
> 632 |     await expect(page.locator('.agent-detail-panel')).toBeVisible()
      |                                                       ^ Error: expect(locator).toBeVisible() failed
  633 |     evidence.agentSkip = await expectSkipJourney(page, `${entry.viewport.width} Agent detail`, entry.locale)
  634 |     evidence.agent = await expectSemanticPage(page, `${entry.viewport.width} Agent detail`)
  635 |     const teamAccessLink = page.locator(`a[href*="teamAccessAgent=${accessibilityIds.agentOne}"]`)
  636 |     await expect.soft(teamAccessLink, 'Agent detail exposes one Team Access deep link').toHaveCount(1)
  637 |     await expect.soft(teamAccessLink, 'Agent detail Team Access deep link has an accessible name').toHaveAccessibleName(/\S/)
  638 |     await expect.soft(teamAccessLink, 'Agent detail Team Access deep link preserves the exact agent identity').toHaveAttribute('href', new RegExp(`teamAccessAgent=${accessibilityIds.agentOne}`))
  639 | 
  640 |     await page.goto(`/agent-sessions/${accessibilityIds.session}`)
  641 |     await expect(page.getByTestId('agent-session-detail')).toBeVisible()
  642 |     evidence.sessionSkip = await expectSkipJourney(page, `${entry.viewport.width} Session detail`, entry.locale)
  643 |     evidence.session = await expectSemanticPage(page, `${entry.viewport.width} Session detail`)
  644 |     await expect.soft(page.locator('.session-facts dt'), 'Session detail exposes native fact terms').not.toHaveCount(0)
  645 | 
  646 |     fixture.expectNoUnexpected()
  647 |     evidence.requests = fixture.requests
  648 |     await attachJson(testInfo, `accessibility-deep-links-${entry.viewport.width}-${entry.locale}`, evidence)
  649 |   })
  650 | }
  651 | 
  652 | const publicCases = [
  653 |   { locale: 'en' as const, viewport: { width: 1920, height: 1080 } },
  654 |   { locale: 'zh-CN' as const, viewport: { width: 390, height: 844 } },
  655 | ]
  656 | 
  657 | for (const entry of publicCases) {
  658 |   test(`Login Install and Connect public semantic boundary at ${entry.viewport.width}px ${entry.locale}`, async ({ page }, testInfo) => {
  659 |     test.setTimeout(60_000)
  660 |     await page.setViewportSize(entry.viewport)
  661 |     const fixture = new AccessibilityFixture()
  662 |     await fixture.install(page)
  663 |     await useLocale(page, entry.locale)
  664 |     const evidence: Record<string, unknown> = {}
  665 | 
  666 |     fixture.installed = true
  667 |     await page.goto('/login')
  668 |     await expect(page.getByTestId('login-form')).toBeVisible()
  669 |     evidence.loginSkip = await expectSkipJourney(page, `${entry.viewport.width} Login`, entry.locale)
  670 |     evidence.login = await expectSemanticPage(page, `${entry.viewport.width} Login`)
  671 |     await expectPublicShortcutBoundary(page, 'Login')
  672 | 
  673 |     fixture.installed = false
  674 |     await page.goto('/install')
  675 |     await expect(page.getByTestId('install-form')).toBeVisible()
  676 |     evidence.installSkip = await expectSkipJourney(page, `${entry.viewport.width} Install`, entry.locale)
  677 |     evidence.install = await expectSemanticPage(page, `${entry.viewport.width} Install`)
  678 |     await expectPublicShortcutBoundary(page, 'Install')
  679 | 
  680 |     await page.goto('/connect#fixture')
  681 |     const configRegion = page.locator('.config-preview')
  682 |     await expect(configRegion).toBeVisible()
  683 |     evidence.connectSkip = await expectSkipJourney(page, `${entry.viewport.width} Connect`, entry.locale)
  684 |     evidence.connect = await expectSemanticPage(page, `${entry.viewport.width} Connect`)
  685 |     const clientPicker = page.getByRole('radiogroup')
  686 |     await expect.soft(clientPicker, 'Connect exposes one client picker').toHaveCount(1)
  687 |     if (await clientPicker.count() === 1) await expect.soft(clientPicker, 'Connect client picker has an accessible name').toHaveAccessibleName(/\S/)
  688 |     expect.soft(await page.getByRole('radio').count(), 'Connect advertises at least one selectable client').toBeGreaterThan(0)
  689 |     await expect.soft(configRegion, 'Connect configuration region has an accessible name').toHaveAccessibleName(/\S/)
  690 |     await expectPublicShortcutBoundary(page, 'Connect')
  691 | 
  692 |     const authenticatedPaths = ['/api/v1/auth/me', '/api/v1/teams', '/api/v1/projects', '/api/v1/work-items', '/api/v1/agents', '/api/v1/agent-sessions', '/api/v1/approvals']
  693 |     expect.soft(fixture.requests.filter(request => authenticatedPaths.includes(new URL(request.path, accessibilityWebUrl).pathname)), 'Public routes make no authenticated resource requests').toEqual([])
  694 |     fixture.expectNoUnexpected()
  695 |     evidence.requests = fixture.requests
  696 |     await attachJson(testInfo, `accessibility-public-${entry.viewport.width}-${entry.locale}`, evidence)
  697 |   })
  698 | }
  699 | 
```