# Instructions

- Following Playwright test failed.
- Explain why, be concise, respect Playwright best practices.
- Provide a snippet of code with the fix, if possible.

# Test info

- Name: mocked\operations-ux.mocked.spec.ts >> proves all eight feature sets on standalone and embedded surfaces without unrelated Operations requests
- Location: e2e\mocked\operations-ux.mocked.spec.ts:578:1

# Error details

```
Error: master-off / embedded

expect(locator).toBeVisible() failed

Locator: getByTestId('operations-disabled')
Expected: visible
Timeout: 10000ms
Error: element(s) not found

Call log:
  - master-off / embedded with timeout 10000ms
  - waiting for getByTestId('operations-disabled')

```

```yaml
- alert
- main:
  - heading "Page not found" [level=1]
  - paragraph: The page you are looking for does not exist or has been moved.
  - link "Back to home":
    - /url: /
```

# Test source

```ts
  551 |   await expect(page.getByTestId('operations-section-navigation')).toHaveCount(0)
  552 | 
  553 |   enabled = [operations]
  554 |   await page.reload()
  555 |   await expect(page.getByTestId('operations-sections-empty')).toContainText('No Operations modules are available')
  556 |   await expect(page.getByTestId('operations-section-navigation')).toHaveCount(0)
  557 |   await expect(page.locator('.operations-grid')).toHaveCount(0)
  558 | })
  559 | 
  560 | test('matches each child feature to only its owned anchors', async ({ page }) => {
  561 |   let enabled: readonly FeatureKey[] = [operations, 'WORKMESH_BETA_COSTS']
  562 |   await installOperationsRoutes(page, () => enabled)
  563 |   const matrix: Array<readonly [FeatureKey, readonly string[]]> = [
  564 |     ['WORKMESH_BETA_COSTS', ['#operations-metrics']],
  565 |     ['WORKMESH_BETA_PLANNING', ['#operations-cycles', '#operations-initiatives']],
  566 |     ['WORKMESH_EXPERIMENTAL_AUTOMATION', ['#operations-automation', '#operations-runs']],
  567 |     ['WORKMESH_EXPERIMENTAL_AGENT_LOOPS', ['#operations-loops']],
  568 |     ['WORKMESH_BETA_TEMPLATES', ['#operations-templates']],
  569 |   ]
  570 | 
  571 |   for (const [feature, expected] of matrix) {
  572 |     enabled = [operations, feature]
  573 |     await page.goto(`/operations?feature=${encodeURIComponent(feature)}`)
  574 |     await expect.poll(() => navigationHrefs(page)).toEqual(expected)
  575 |   }
  576 | })
  577 | 
  578 | test('proves all eight feature sets on standalone and embedded surfaces without unrelated Operations requests', async ({ context }) => {
  579 |   test.slow()
  580 |   expect(canonicalFeatures).toHaveLength(11)
  581 | 
  582 |   const relevantDataPaths = ['/api/v1/usage-summary', ...collectionPaths] as const
  583 |   const relevantDataPathSet = new Set<string>(relevantDataPaths)
  584 |   const scenarios: Array<Readonly<{
  585 |     name: string
  586 |     enabled: readonly FeatureKey[]
  587 |     hrefs: readonly string[]
  588 |     apiPaths: readonly string[]
  589 |     hasSearch: boolean
  590 |   }>> = [
  591 |     { name: 'master-off', enabled: [], hrefs: [], apiPaths: [], hasSearch: false },
  592 |     { name: 'Operations-only', enabled: [operations], hrefs: [], apiPaths: [], hasSearch: false },
  593 |     {
  594 |       name: 'Planning-only',
  595 |       enabled: [operations, 'WORKMESH_BETA_PLANNING'],
  596 |       hrefs: ['#operations-cycles', '#operations-initiatives'],
  597 |       apiPaths: ['/api/v1/cycles', '/api/v1/initiatives'],
  598 |       hasSearch: true,
  599 |     },
  600 |     {
  601 |       name: 'Costs-only',
  602 |       enabled: [operations, 'WORKMESH_BETA_COSTS'],
  603 |       hrefs: ['#operations-metrics'],
  604 |       apiPaths: ['/api/v1/usage-summary'],
  605 |       hasSearch: false,
  606 |     },
  607 |     {
  608 |       name: 'Automation-only',
  609 |       enabled: [operations, 'WORKMESH_EXPERIMENTAL_AUTOMATION'],
  610 |       hrefs: ['#operations-automation', '#operations-runs'],
  611 |       apiPaths: ['/api/v1/automation-rules', '/api/v1/automation-runs'],
  612 |       hasSearch: true,
  613 |     },
  614 |     {
  615 |       name: 'Loops-only',
  616 |       enabled: [operations, 'WORKMESH_EXPERIMENTAL_AGENT_LOOPS'],
  617 |       hrefs: ['#operations-loops'],
  618 |       apiPaths: ['/api/v1/loops'],
  619 |       hasSearch: true,
  620 |     },
  621 |     {
  622 |       name: 'Templates-only',
  623 |       enabled: [operations, 'WORKMESH_BETA_TEMPLATES'],
  624 |       hrefs: ['#operations-templates'],
  625 |       apiPaths: ['/api/v1/templates'],
  626 |       hasSearch: true,
  627 |     },
  628 |     {
  629 |       name: 'all-enabled',
  630 |       enabled: allOperationsFeatures,
  631 |       hrefs: sectionHrefs,
  632 |       apiPaths: relevantDataPaths,
  633 |       hasSearch: true,
  634 |     },
  635 |   ]
  636 |   const surfaces = [
  637 |     { name: 'standalone', url: '/operations' },
  638 |     { name: 'embedded', url: '/settings?tab=operations' },
  639 |   ] as const
  640 | 
  641 |   for (const scenario of scenarios) {
  642 |     for (const surface of surfaces) {
  643 |       const scenarioPage = await context.newPage()
  644 |       const requestLog: string[] = []
  645 |       const label = `${scenario.name} / ${surface.name}`
  646 |       try {
  647 |         await installOperationsRoutes(scenarioPage, () => scenario.enabled, { requestLog })
  648 |         await scenarioPage.goto(surface.url)
  649 | 
  650 |         if (scenario.name === 'master-off') {
> 651 |           await expect(scenarioPage.getByTestId('operations-disabled'), label).toBeVisible()
      |                                                                                ^ Error: master-off / embedded
  652 |         } else if (scenario.name === 'Operations-only') {
  653 |           await expect(scenarioPage.getByTestId('operations-sections-empty'), label).toBeVisible()
  654 |         }
  655 | 
  656 |         const navigation = scenarioPage.getByTestId('operations-section-navigation')
  657 |         if (scenario.hrefs.length === 0) {
  658 |           await expect(navigation, `${label}: navigation`).toHaveCount(0)
  659 |         } else {
  660 |           await expect(navigation, `${label}: navigation`).toBeVisible()
  661 |           await expect.poll(
  662 |             () => navigationHrefs(scenarioPage),
  663 |             { message: `${label}: ordered anchors` },
  664 |           ).toEqual(scenario.hrefs)
  665 |         }
  666 | 
  667 |         const targets = scenarioPage.locator('.operations-section-target')
  668 |         await expect(targets, `${label}: target count`).toHaveCount(scenario.hrefs.length)
  669 |         expect(
  670 |           await targets.evaluateAll(elements => elements.map(element => `#${element.id}`)),
  671 |           `${label}: ordered targets`,
  672 |         ).toEqual(scenario.hrefs)
  673 |         for (const href of sectionHrefs) {
  674 |           await expect(
  675 |             scenarioPage.locator(href),
  676 |             `${label}: ${scenario.hrefs.includes(href) ? 'owned' : 'hidden'} target ${href}`,
  677 |           ).toHaveCount(scenario.hrefs.includes(href) ? 1 : 0)
  678 |         }
  679 | 
  680 |         await expect(
  681 |           scenarioPage.getByTestId('operations-search'),
  682 |           `${label}: search ${scenario.hasSearch ? 'present' : 'absent'}`,
  683 |         ).toHaveCount(scenario.hasSearch ? 1 : 0)
  684 | 
  685 |         await expect.poll(
  686 |           () => requestLog.some(value => new URL(value).pathname === '/api/v1/features'),
  687 |           { message: `${label}: feature registry request completed` },
  688 |         ).toBe(true)
  689 |         const expectedApiPaths = [...scenario.apiPaths].sort()
  690 |         const observedApiPaths = () => [...new Set(
  691 |           requestLog
  692 |             .map(value => new URL(value).pathname)
  693 |             .filter(path => relevantDataPathSet.has(path)),
  694 |         )].sort()
  695 |         if (expectedApiPaths.length > 0) {
  696 |           await expect.poll(
  697 |             observedApiPaths,
  698 |             { message: `${label}: relevant API presence and absence` },
  699 |           ).toEqual(expectedApiPaths)
  700 |         }
  701 |         await scenarioPage.evaluate(() => new Promise<void>(resolve => {
  702 |           requestAnimationFrame(() => requestAnimationFrame(() => resolve()))
  703 |         }))
  704 |         expect(observedApiPaths(), `${label}: zero unrelated Operations endpoints`).toEqual(expectedApiPaths)
  705 |       } finally {
  706 |         await scenarioPage.close()
  707 |       }
  708 |     }
  709 |   }
  710 | })
  711 | 
  712 | test('keeps real Operations controls in the initial viewport at supported widths', async ({ page }) => {
  713 |   await installOperationsRoutes(page, () => allOperationsFeatures)
  714 |   for (const viewport of [
  715 |     { width: 390, height: 844 },
  716 |     { width: 1440, height: 900 },
  717 |     { width: 1920, height: 1080 },
  718 |   ]) {
  719 |     await page.setViewportSize(viewport)
  720 |     await page.goto(`/operations?viewport=${viewport.width}`)
  721 |     const box = await page.getByTestId('operations-section-navigation').boundingBox()
  722 |     expect(box, `${viewport.width}x${viewport.height} navigation bounds`).not.toBeNull()
  723 |     expect(box?.y ?? viewport.height).toBeLessThan(viewport.height)
  724 |   }
  725 | })
  726 | 
  727 | test('scrolls an asynchronously mounted direct-hash target into view before focusing it', async ({ page }) => {
  728 |   await page.setViewportSize({ width: 1440, height: 900 })
  729 |   await installOperationsRoutes(page, () => allOperationsFeatures, { usageDelayMs: 250 })
  730 |   await page.goto('/operations#operations-runs')
  731 | 
  732 |   const navigation = page.getByTestId('operations-section-navigation')
  733 |   const runs = navigation.getByRole('link', { name: 'Recent runs' })
  734 |   const target = page.locator('#operations-runs')
  735 |   await expect(runs).toHaveAttribute('aria-current', 'location')
  736 |   await expect(target).toBeFocused()
  737 |   await expect.poll(async () => (await target.boundingBox())?.y ?? 900).toBeLessThan(900)
  738 | })
  739 | 
  740 | test('restores embedded current state without taking focus when the real Settings tab becomes visible', async ({ page }, testInfo) => {
  741 |   await installOperationsRoutes(page, () => allOperationsFeatures, settingsRouteFixtures)
  742 |   await page.goto('/settings?tab=workspace&team=team-1&opsQuery=Archived&x=keep#operations-runs')
  743 |   const workspaceTab = page.getByRole('tab', { name: 'Workspace' })
  744 |   await expect(workspaceTab).toHaveAttribute('aria-selected', 'true')
  745 | 
  746 |   const beforeMount = await page.evaluate(async () => {
  747 |     window.scrollTo(0, Math.min(120, document.documentElement.scrollHeight - window.innerHeight))
  748 |     await new Promise<void>(resolve => requestAnimationFrame(() => requestAnimationFrame(() => resolve())))
  749 |     return { scrollY: window.scrollY, viewportHeight: window.innerHeight }
  750 |   })
  751 |   expect(beforeMount.scrollY).toBeGreaterThan(0)
```