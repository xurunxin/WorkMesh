# Instructions

- Following Playwright test failed.
- Explain why, be concise, respect Playwright best practices.
- Provide a snippet of code with the fix, if possible.

# Test info

- Name: mocked\page-hotkeys.mocked.spec.ts >> page hotkeys at 390px >> keeps global navigation, one visible filter, no-filter surfaces and command-center ownership deterministic
- Location: e2e\mocked\page-hotkeys.mocked.spec.ts:165:5

# Error details

```
Error: expect(received).toBe(expected) // Object.is equality

Expected: "ga"
Received: null
```

# Page snapshot

```yaml
- generic [ref=e1]:
  - generic [ref=e6] [cursor=pointer]:
    - button "Open Next.js Dev Tools" [ref=e7]:
      - img [ref=e8]
    - generic [ref=e11]:
      - button "Open issues overlay" [ref=e12]:
        - generic [ref=e13]:
          - generic [ref=e14]: "0"
          - generic [ref=e15]: "1"
        - generic [ref=e16]: Issue
      - button "Collapse issues badge" [ref=e17]:
        - img [ref=e18]
  - alert [ref=e20]
  - generic [ref=e21]:
    - link "跳到主要内容" [ref=e22] [cursor=pointer]:
      - /url: "#workmesh-main"
    - generic [ref=e23]:
      - banner [ref=e24]:
        - group [ref=e25]:
          - generic "菜单" [ref=e26] [cursor=pointer]
          - option "无团队" [disabled]
          - option "WorkMesh Product (WM)" [selected]
        - button "搜索" [ref=e28] [cursor=pointer]:
          - img [ref=e30]
          - generic [ref=e33]: 搜索
      - main [ref=e34]:
        - generic [ref=e35]:
          - generic [ref=e36]:
            - heading "Issues" [level=1] [ref=e38]
            - button "新建 Issue" [ref=e40] [cursor=pointer]:
              - img [ref=e42]
              - generic [ref=e44]: 新建 Issue
          - region "工作项视图" [ref=e45]:
            - region "Issue 筛选器" [ref=e46]:
              - generic [ref=e47]:
                - generic [ref=e48]:
                  - text: 搜索
                  - textbox "搜索" [active] [ref=e49]:
                    - /placeholder: 搜索 Issue 标题或编号
                    - text: ga
                - generic [ref=e50]:
                  - text: 状态
                  - combobox "状态" [ref=e51]:
                    - option "全部状态" [selected]
                    - option "Backlog"
                    - option "Ready"
                    - option "In Progress"
                    - option "Review"
                    - option "Done"
                - generic [ref=e52]:
                  - text: 优先级
                  - combobox "优先级" [ref=e53]:
                    - option "全部优先级" [selected]
                    - option "无优先级"
                    - option "紧急"
                    - option "高"
                    - option "中"
                    - option "低"
                - generic [ref=e54]:
                  - text: 负责人
                  - combobox "负责人" [ref=e55]:
                    - option "全部负责人" [selected]
                    - option "Alex Morgan"
                - generic [ref=e56]:
                  - text: 项目
                  - combobox "项目" [ref=e57]:
                    - option "全部项目" [selected]
                    - option "Kaneo UI Adoption"
                - button "更多筛选" [ref=e58] [cursor=pointer]:
                  - generic [ref=e59]: 更多筛选
                - button "清除筛选" [ref=e60] [cursor=pointer]:
                  - img [ref=e62]
                  - generic [ref=e64]: 清除筛选
              - generic [ref=e66]:
                - generic [ref=e67]: 保存视图名称
                - textbox "保存视图名称" [ref=e68]:
                  - /placeholder: 保存视图
                - button "保存视图" [ref=e69] [cursor=pointer]:
                  - img [ref=e71]
                  - generic [ref=e73]: 保存视图
            - generic "Issue 视图布局" [ref=e74]:
              - button "列表视图" [pressed] [ref=e75] [cursor=pointer]:
                - img [ref=e77]
                - generic [ref=e79]: 列表视图
              - button "看板视图" [ref=e80] [cursor=pointer]:
                - img [ref=e82]
                - generic [ref=e84]: 看板视图
              - button "Issue 密度" [ref=e85] [cursor=pointer]:
                - generic [ref=e86]: 紧凑
            - status [ref=e87]:
              - generic [ref=e89]:
                - heading "没有 Issue" [level=2] [ref=e90]
                - paragraph [ref=e91]: 当前筛选条件下没有可访问的 Issue。
```

# Test source

```ts
  85  | async function attachGeometry(testInfo: TestInfo, name: string, target: Locator): Promise<void> {
  86  |   const evidence = await target.evaluate(element => {
  87  |     const rect = element.getBoundingClientRect()
  88  |     const style = getComputedStyle(element)
  89  |     return {
  90  |       activeTag: document.activeElement?.tagName ?? null,
  91  |       boxShadow: style.boxShadow,
  92  |       documentClientWidth: document.documentElement.clientWidth,
  93  |       documentScrollWidth: document.documentElement.scrollWidth,
  94  |       outlineStyle: style.outlineStyle,
  95  |       outlineWidth: style.outlineWidth,
  96  |       rect: { bottom: rect.bottom, height: rect.height, left: rect.left, right: rect.right, top: rect.top, width: rect.width },
  97  |       url: `${location.pathname}${location.search}${location.hash}`,
  98  |       viewport: { height: innerHeight, width: innerWidth },
  99  |     }
  100 |   })
  101 |   expect(evidence.rect.left).toBeGreaterThanOrEqual(0)
  102 |   expect(evidence.rect.top).toBeGreaterThanOrEqual(0)
  103 |   expect(evidence.rect.right).toBeLessThanOrEqual(evidence.viewport.width)
  104 |   expect(evidence.rect.bottom).toBeLessThanOrEqual(evidence.viewport.height)
  105 |   expect(evidence.documentScrollWidth).toBe(evidence.documentClientWidth)
  106 |   expect(evidence.outlineStyle !== 'none' || evidence.boxShadow !== 'none').toBe(true)
  107 |   console.info('TASK_6_1_MOCKED_GEOMETRY', JSON.stringify({ name, evidence }))
  108 |   const jsonPath = testInfo.outputPath(`${name}.json`)
  109 |   const screenshotPath = testInfo.outputPath(`${name}.png`)
  110 |   await writeFile(jsonPath, JSON.stringify(evidence, null, 2), 'utf8')
  111 |   await target.page().screenshot({ path: screenshotPath })
  112 |   await testInfo.attach(name, { path: jsonPath, contentType: 'application/json' })
  113 |   await testInfo.attach(`${name}-screenshot`, { path: screenshotPath, contentType: 'image/png' })
  114 | }
  115 | 
  116 | const hotkeyViewports = [{ width: 390, height: 844 }, { width: 1920, height: 1080 }] as const
  117 | 
  118 | for (const viewport of hotkeyViewports) {
  119 |   test.describe(`public and unknown route shortcut boundary at ${viewport.width}px`, () => {
  120 |     test.use({ viewport })
  121 | 
  122 |     test('makes zero authenticated requests and mounts no command center or page chord', async ({ page }, testInfo) => {
  123 |       const authenticatedRequests: string[] = []
  124 |       const publicPaths = new Set([
  125 |         '/.well-known/workmesh-agent',
  126 |         '/api/v1/auth/install',
  127 |         '/api/v1/auth/login',
  128 |         '/api/v1/info',
  129 |         '/api/v1/install-status',
  130 |       ])
  131 |       page.on('request', request => {
  132 |         const url = new URL(request.url())
  133 |         if (url.origin === apiUrl && !publicPaths.has(url.pathname))
  134 |           authenticatedRequests.push(`${request.method()} ${url.pathname}`)
  135 |       })
  136 | 
  137 |       const evidence: Array<{ requested: string; settled: string; authenticatedRequests: readonly string[] }> = []
  138 |       for (const path of ['/login', '/install', '/connect', '/future-unknown-route']) {
  139 |         authenticatedRequests.length = 0
  140 |         await page.goto(path)
  141 |         await page.waitForLoadState('domcontentloaded')
  142 |         await page.waitForTimeout(300)
  143 |         const settled = new URL(page.url()).pathname
  144 |         const before = page.url()
  145 |         await page.keyboard.press('/')
  146 |         await page.keyboard.press('Control+K')
  147 |         await pressChord(page, 'a')
  148 |         await page.waitForTimeout(100)
  149 |         expect(page.url()).toBe(before)
  150 |         await expect(page.getByTestId('command-center-trigger')).toHaveCount(0)
  151 |         expect(authenticatedRequests).toEqual([])
  152 |         evidence.push({ requested: path, settled, authenticatedRequests: [...authenticatedRequests] })
  153 |       }
  154 |       const evidencePath = testInfo.outputPath(`public-zero-auth-requests-${viewport.width}.json`)
  155 |       await writeFile(evidencePath, JSON.stringify(evidence, null, 2), 'utf8')
  156 |       await testInfo.attach(`public-zero-auth-requests-${viewport.width}`, { path: evidencePath, contentType: 'application/json' })
  157 |     })
  158 |   })
  159 | }
  160 | 
  161 | for (const viewport of hotkeyViewports) {
  162 |   test.describe(`page hotkeys at ${viewport.width}px`, () => {
  163 |     test.use({ viewport })
  164 | 
  165 |     test('keeps global navigation, one visible filter, no-filter surfaces and command-center ownership deterministic', async ({ page }, testInfo) => {
  166 |       await installHotkeyFixtures(page)
  167 |       await page.goto('/?view=my-work')
  168 |       const issueSearch = page.locator('[data-hotkey-filter="true"]')
  169 |       await expect(issueSearch).toHaveCount(1)
  170 |       await page.keyboard.press('f')
  171 |       await expect(issueSearch).toBeFocused()
  172 |       await attachGeometry(testInfo, `home-filter-${viewport.width}`, issueSearch)
  173 |       await page.evaluate(() => (document.activeElement as HTMLElement | null)?.blur())
  174 | 
  175 |       const historyLength = await page.evaluate(() => history.length)
  176 |       await pressChord(page, 'i')
  177 |       await expect(page).toHaveURL(`${webUrl}/?view=my-work`)
  178 |       expect(await page.evaluate(() => history.length)).toBe(historyLength)
  179 | 
  180 |       await issueSearch.focus()
  181 |       await pressChord(page, 'a')
  182 |       await expect(issueSearch).toBeFocused()
  183 |       expect(new URL(page.url()).pathname).toBe('/')
  184 |       expect(new URL(page.url()).searchParams.get('view')).toBe('my-work')
> 185 |       expect(new URL(page.url()).searchParams.get('search')).toBe('ga')
      |                                                              ^ Error: expect(received).toBe(expected) // Object.is equality
  186 |       await issueSearch.fill('')
  187 |       await expect.poll(() => new URL(page.url()).searchParams.get('search')).toBeNull()
  188 |       await page.evaluate(() => (document.activeElement as HTMLElement | null)?.blur())
  189 | 
  190 |       const contextUrl = page.url()
  191 |       const select = page.locator('select:visible').first()
  192 |       await select.focus()
  193 |       await pressChord(page, 'a')
  194 |       await expect(select).toBeFocused()
  195 |       expect(page.url()).toBe(contextUrl)
  196 | 
  197 |       const button = page.getByTestId('command-center-trigger')
  198 |       await button.focus()
  199 |       await pressChord(page, 's')
  200 |       await expect(button).toBeFocused()
  201 |       expect(page.url()).toBe(contextUrl)
  202 | 
  203 |       const link = page.locator('a:visible').first()
  204 |       await link.focus()
  205 |       await pressChord(page, 'a')
  206 |       await expect(link).toBeFocused()
  207 |       expect(page.url()).toBe(contextUrl)
  208 | 
  209 |       await page.evaluate(() => {
  210 |         const editable = document.createElement('div')
  211 |         editable.contentEditable = 'plaintext-only'
  212 |         editable.dataset.hotkeyContext = 'contenteditable'
  213 |         editable.tabIndex = 0
  214 |         editable.textContent = 'Editable shortcut guard'
  215 |         document.body.append(editable)
  216 |       })
  217 |       const editable = page.locator('[data-hotkey-context="contenteditable"]')
  218 |       await editable.focus()
  219 |       await pressChord(page, 's')
  220 |       await expect(editable).toBeFocused()
  221 |       expect(page.url()).toBe(contextUrl)
  222 |       await editable.evaluate(element => element.remove())
  223 |       await page.evaluate(() => (document.activeElement as HTMLElement | null)?.blur())
  224 | 
  225 |       const stableHomeUrl = page.url()
  226 |       await page.keyboard.press('g')
  227 |       await page.keyboard.press('z')
  228 |       expect(page.url()).toBe(stableHomeUrl)
  229 |       await page.keyboard.press('g')
  230 |       await page.waitForTimeout(1_050)
  231 |       await page.keyboard.press('a')
  232 |       expect(page.url()).toBe(stableHomeUrl)
  233 | 
  234 |       await pressChord(page, 'a')
  235 |       await expect(page).toHaveURL(`${webUrl}/agents`)
  236 | 
  237 |       await page.goto('/?view=my-work')
  238 |       await page.keyboard.press('/')
  239 |       await expect(page.getByTestId('command-center')).toHaveCount(1)
  240 |       await page.evaluate(() => (document.activeElement as HTMLElement | null)?.blur())
  241 |       const modalUrl = page.url()
  242 |       await pressChord(page, 'a')
  243 |       expect(page.url()).toBe(modalUrl)
  244 |       await page.keyboard.press('f')
  245 |       expect(page.url()).toBe(modalUrl)
  246 |       await page.keyboard.press('/')
  247 |       await expect(page.getByTestId('command-center')).toHaveCount(1)
  248 |       await page.getByRole('button', { name: /关闭|Close/ }).click()
  249 |       await page.keyboard.press('Control+K')
  250 |       await expect(page.getByTestId('command-center')).toHaveCount(1)
  251 |       await page.getByRole('button', { name: /关闭|Close/ }).click()
  252 | 
  253 |       for (const path of ['/?view=inbox', '/?view=guidance', '/settings']) {
  254 |         await page.goto(path)
  255 |         await expect(page.locator('[data-hotkey-filter="true"]')).toHaveCount(0)
  256 |         const anchor = page.locator('a:visible').first()
  257 |         await anchor.focus()
  258 |         await page.keyboard.press('f')
  259 |         await expect(anchor).toBeFocused()
  260 |       }
  261 | 
  262 |       await page.goto('/operations')
  263 |       const operationsSearch = page.locator('[data-hotkey-filter="true"]')
  264 |       await expect(operationsSearch).toHaveCount(1)
  265 |       await page.keyboard.press('f')
  266 |       await expect(operationsSearch).toBeFocused()
  267 |       await attachGeometry(testInfo, `operations-filter-${viewport.width}`, operationsSearch)
  268 | 
  269 |       await page.evaluate(() => (document.activeElement as HTMLElement | null)?.blur())
  270 |       await pressChord(page, 's')
  271 |       await expect(page).toHaveURL(`${webUrl}/settings`)
  272 |       await page.waitForTimeout(300)
  273 |       await page.evaluate(() => (document.activeElement as HTMLElement | null)?.blur())
  274 |       await pressChord(page, 'i')
  275 |       await expect(page).toHaveURL(`${webUrl}/?view=my-work`)
  276 |     })
  277 | 
  278 |     test('wraps Agent links, preserves native controls and keeps focus, Peek and approval state independent', async ({ page }, testInfo) => {
  279 |       await installHotkeyFixtures(page)
  280 |       await page.goto('/agents')
  281 |       const links = page.locator('[data-agent-roving-link="true"]')
  282 |       const agentSearch = page.locator('[data-hotkey-filter="true"]')
  283 |       await expect(agentSearch).toHaveCount(1)
  284 |       await page.evaluate(() => (document.activeElement as HTMLElement | null)?.blur())
  285 |       await page.keyboard.press('f')
```