# Instructions

- Following Playwright test failed.
- Explain why, be concise, respect Playwright best practices.
- Provide a snippet of code with the fix, if possible.

# Test info

- Name: mocked\loading-states.mocked.spec.ts >> Task 6.4 Agent secondary surfaces >> owns Sessions, Diagnostics, Connections and Approval states without stale actions
- Location: e2e\mocked\loading-states.mocked.spec.ts:538:3

# Error details

```
Error: expect(locator).toBeVisible() failed

Locator: getByRole('region', { name: 'Connections', exact: true }).locator('.skeleton-list')
Expected: visible
Timeout: 10000ms
Error: element(s) not found

Call log:
  - Expect "toBeVisible" with timeout 10000ms
  - waiting for getByRole('region', { name: 'Connections', exact: true }).locator('.skeleton-list')

```

```yaml
- alert
- link "Skip to content":
  - /url: "#workmesh-main"
- complementary "Main navigation":
  - strong: WorkMesh
  - text: Alex Morgan
  - button "Collapse sidebar" [expanded]
  - navigation "Workspace navigation":
    - paragraph: Workbench
    - link "Workbench":
      - /url: /workbench
    - link "My work":
      - /url: /?view=home
    - link "Issues":
      - /url: /?view=my-work
    - link "Guidance":
      - /url: /?view=guidance
    - paragraph: Governance
    - link "Needs You":
      - /url: /?view=inbox
    - link "Session":
      - /url: /?view=sessions
    - link "Recovery":
      - /url: /?view=recovery
    - link "Projects":
      - /url: /?view=projects
    - link "Agents":
      - /url: /agents
    - paragraph: Operations
    - link "Operations":
      - /url: /operations
  - navigation "Administration navigation":
    - link "Settings":
      - /url: /settings
  - button "Sign out"
  - text: v1.0.0 · build loading-state-fixture · schema 24
- banner:
  - paragraph: Human control plane
  - button "Search": Search Ctrl K
  - button "Switch to the light theme"
  - group "Language":
    - button "中"
    - button "EN" [pressed]
  - text: Reconnecting
- main:
  - paragraph: Human control plane
  - heading "Agents" [level=1]
  - paragraph: Monitor delegated work, respond to approvals, and diagnose Connections without handling credentials.
  - button "Refresh"
  - alert:
    - heading "Agent workspace needs attention" [level=2]
    - paragraph: "[ { \"code\": \"invalid_type\", \"expected\": \"string\", \"received\": \"undefined\", \"path\": [ \"icon\" ], \"message\": \"Required\" }, { \"code\": \"invalid_type\", \"expected\": \"string\", \"received\": \"undefined\", \"path\": [ \"endpoint_url\" ], \"message\": \"Required\" }, { \"code\": \"invalid_type\", \"expected\": \"array\", \"received\": \"undefined\", \"path\": [ \"output_artifact_types\" ], \"message\": \"Required\" }, { \"code\": \"invalid_type\", \"expected\": \"object\", \"received\": \"undefined\", \"path\": [ \"metadata\" ], \"message\": \"Required\" }, { \"expected\": \"'active' | 'archived'\", \"received\": \"undefined\", \"code\": \"invalid_type\", \"path\": [ \"lifecycle_status\" ], \"message\": \"Required\" }, { \"code\": \"invalid_type\", \"expected\": \"string\", \"received\": \"undefined\", \"path\": [ \"archived_at\" ], \"message\": \"Required\" }, { \"code\": \"invalid_type\", \"expected\": \"string\", \"received\": \"undefined\", \"path\": [ \"archived_by_actor_id\" ], \"message\": \"Required\" }, { \"code\": \"invalid_type\", \"expected\": \"string\", \"received\": \"undefined\", \"path\": [ \"archived_reason\" ], \"message\": \"Required\" }, { \"code\": \"invalid_type\", \"expected\": \"string\", \"received\": \"undefined\", \"path\": [ \"created_at\" ], \"message\": \"Required\" }, { \"code\": \"invalid_type\", \"expected\": \"string\", \"received\": \"undefined\", \"path\": [ \"updated_at\" ], \"message\": \"Required\" } ]"
    - button "Retry"
  - tablist "Agent workspace sections":
    - tab "Agents"
    - tab "Sessions" [selected]
    - tab "Connections"
    - tab "Auto enrollment"
    - tab "Archived"
  - tabpanel "Sessions":
    - region "Sessions":
      - paragraph: Execution
      - heading "Sessions" [level=2]
      - status "Loading Agent workspace"
    - region "Diagnostics":
      - paragraph: Durable state
      - heading "Diagnostics" [level=2]
      - status "Loading Agent workspace"
```

# Test source

```ts
  465 |     await expect(page.getByText('safe-team-initial')).toHaveCount(0)
  466 | 
  467 |     routes.setRequest('GET', teamsPath, { body: { items: [], nextCursor: null } })
  468 |     await page.reload({ waitUntil: 'domcontentloaded' })
  469 |     await expect(content.locator('.empty')).toContainText('No team')
  470 |     await expect(content.getByRole('alert')).toHaveCount(0)
  471 |     await expect(content.locator('.skeleton-list')).toHaveCount(0)
  472 |     await expect(page.getByTestId('work-surfaces')).toHaveCount(0)
  473 |     expect(routes.requests.some(request => request.startsWith('/api/v1/work-items'))).toBe(false)
  474 |     expect(routes.requests.some(request => request.includes('/states'))).toBe(false)
  475 | 
  476 |     await page.goto('/settings?tab=workspace', { waitUntil: 'domcontentloaded' })
  477 |     await expect(page.locator('.settings-loading-skeleton')).toHaveCount(0)
  478 |     await expect(page.getByRole('option', { name: /No team/i })).toHaveCount(1)
  479 |     await expect(page.locator('[aria-labelledby="workflow-settings-heading"] .skeleton-list')).toHaveCount(0)
  480 |     expect(routes.requests.some(request => request.includes('/states'))).toBe(false)
  481 |     expect(routes.unexpected).toEqual([])
  482 |   })
  483 | })
  484 | 
  485 | test.describe('Task 6.4 Agents loading authority', () => {
  486 |   test.use({ viewport: { height: 900, width: 1440 } })
  487 | 
  488 |   test('keeps Registry authority and focus independent through a failed refresh', async ({ page }) => {
  489 |     const routes = new RouteScenarios()
  490 |     await routes.install(page)
  491 |     await page.context().addCookies([{ name: 'workmesh_locale', value: 'en', url: webUrl }])
  492 | 
  493 |     const agentsPending = deferredResponse()
  494 |     routes.set('/api/v1/agents', agentsPending.promise)
  495 |     await page.goto('/agents?tab=agents', { waitUntil: 'domcontentloaded' })
  496 | 
  497 |     const registry = page.locator('.agent-registry')
  498 |     await expect(registry.locator('.skeleton-list')).toBeVisible()
  499 |     await expect(registry).not.toHaveAttribute('aria-busy')
  500 |     await expect(registry.locator('[aria-busy="true"]')).toHaveCount(1)
  501 |     await expect(registry.locator('.skeleton-list button, .skeleton-list a, .skeleton-list input, .skeleton-list [tabindex]')).toHaveCount(0)
  502 | 
  503 |     const agentsResponse = { body: { items: [browserAgent], nextCursor: null } } satisfies JsonResponse
  504 |     routes.set('/api/v1/agents', agentsResponse)
  505 |     agentsPending.resolve(agentsResponse)
  506 |     const agentLink = page.locator('[data-agent-roving-link="true"]')
  507 |     await expect(agentLink).toHaveCount(1)
  508 |     await agentLink.focus()
  509 |     await agentLink.evaluate(element => { element.dataset.loadingIdentity = 'retained-agent-link' })
  510 | 
  511 |     const refreshPending = deferredResponse()
  512 |     const agentsPath = '/api/v1/agents?limit=100'
  513 |     const priorRequests = routes.requests.filter(request => request === agentsPath).length
  514 |     routes.set(agentsPath, refreshPending.promise)
  515 |     await page.getByRole('button', { name: 'Refresh', exact: true }).evaluate((button: HTMLButtonElement) => button.click())
  516 |     await routes.waitFor(agentsPath, priorRequests + 1)
  517 |     await expect(registry).toHaveAttribute('aria-busy', 'true')
  518 |     await expect(agentLink).toHaveAttribute('data-loading-identity', 'retained-agent-link')
  519 |     await expect(agentLink).toBeFocused()
  520 | 
  521 |     routes.set(agentsPath, agentsResponse)
  522 |     refreshPending.resolve({
  523 |       body: { error: { code: 'TEMPORARY_UNAVAILABLE', correlationId: 'safe-agent-refresh', message: 'Please retry.' } },
  524 |       status: 500,
  525 |     })
  526 |     await expect(registry).not.toHaveAttribute('aria-busy')
  527 |     await expect(agentLink).toHaveAttribute('data-loading-identity', 'retained-agent-link')
  528 |     await expect(agentLink).toBeFocused()
  529 |     await expect(page.getByText('Loading Matrix Agent')).toBeVisible()
  530 |     await expect(page.getByText('safe-agent-refresh')).toHaveCount(0)
  531 |     expect(routes.unexpected).toEqual([])
  532 |   })
  533 | })
  534 | 
  535 | test.describe('Task 6.4 Agent secondary surfaces', () => {
  536 |   test.use({ viewport: { height: 900, width: 1440 } })
  537 | 
  538 |   test('owns Sessions, Diagnostics, Connections and Approval states without stale actions', async ({ page }) => {
  539 |     const routes = new RouteScenarios()
  540 |     await routes.install(page)
  541 |     await page.context().addCookies([{ name: 'workmesh_locale', value: 'en', url: webUrl }])
  542 | 
  543 |     const sessionsPath = '/api/v1/agent-sessions?limit=100'
  544 |     const connectionsPath = '/api/v1/agent-connections?limit=50'
  545 |     const pendingPath = '/api/v1/approvals?status=pending&limit=100'
  546 |     const historyPath = '/api/v1/approvals?status=approved&limit=100'
  547 |     const sessionsPending = deferredResponse()
  548 |     const connectionsPending = deferredResponse()
  549 |     const attentionPending = deferredResponse()
  550 |     const pendingApprovals = deferredResponse()
  551 |     const historyPending = deferredResponse()
  552 |     routes.set('/api/v1/agents', { body: { items: [browserAgent], nextCursor: null } })
  553 |     routes.set(sessionsPath, sessionsPending.promise)
  554 |     routes.set(connectionsPath, connectionsPending.promise)
  555 |     routes.set('/api/v1/human-attention', attentionPending.promise)
  556 |     routes.set(pendingPath, pendingApprovals.promise)
  557 |     routes.set(historyPath, historyPending.promise)
  558 |     await page.goto('/agents?tab=sessions&approvalView=history&approvalStatus=approved', { waitUntil: 'domcontentloaded' })
  559 | 
  560 |     const sessions = page.getByRole('region', { name: 'Sessions', exact: true })
  561 |     const diagnostics = page.getByRole('region', { name: 'Diagnostics', exact: true })
  562 |     const connections = page.getByRole('region', { name: 'Connections', exact: true })
  563 |     await expect(sessions.locator('.skeleton-list')).toBeVisible()
  564 |     await expect(diagnostics.locator('.skeleton-list')).toBeVisible()
> 565 |     await expect(connections.locator('.skeleton-list')).toBeVisible()
      |                                                         ^ Error: expect(locator).toBeVisible() failed
  566 |     await expect(sessions).not.toHaveAttribute('aria-busy')
  567 |     await expect(diagnostics).not.toHaveAttribute('aria-busy')
  568 |     await expect(connections).not.toHaveAttribute('aria-busy')
  569 | 
  570 |     const notFound = {
  571 |       body: { error: { code: 'NOT_FOUND', correlationId: 'safe-optional-404', message: 'Not found.' } },
  572 |       status: 404,
  573 |     } satisfies JsonResponse
  574 |     routes.set(sessionsPath, { body: { items: [], nextCursor: null } })
  575 |     sessionsPending.resolve(notFound)
  576 |     routes.set(connectionsPath, { body: { items: [], nextCursor: null } })
  577 |     connectionsPending.resolve({ body: { items: [], nextCursor: null } })
  578 |     routes.set('/api/v1/human-attention', { body: { items: [], nextCursor: null } })
  579 |     attentionPending.resolve({ body: { items: [], nextCursor: null } })
  580 |     await expect(sessions.locator('.skeleton-list')).toHaveCount(0)
  581 |     await expect(diagnostics.locator('.skeleton-list')).toHaveCount(0)
  582 |     await expect(connections.locator('.skeleton-list')).toHaveCount(0)
  583 |     await expect(connections.locator('.connection-empty')).toBeVisible()
  584 |     await page.getByRole('tab', { name: 'Approvals', exact: true }).click()
  585 |     await expect(page.locator('.approval-history .skeleton-list')).toBeVisible()
  586 |     routes.set(historyPath, { body: { items: [], nextCursor: null } })
  587 |     historyPending.resolve(notFound)
  588 |     await expect(page.locator('.approval-history .skeleton-list')).toHaveCount(0)
  589 |     await expect(page.getByText('safe-optional-404')).toHaveCount(0)
  590 | 
  591 |     await page.getByRole('tab', { name: 'Pending', exact: true }).click()
  592 |     const pendingProjection = page.locator('.approval-projection').filter({ has: page.locator('.skeleton-list') })
  593 |     await expect(pendingProjection.locator('.skeleton-list')).toBeVisible()
  594 |     await expect(pendingProjection).not.toHaveAttribute('aria-busy')
  595 |     const pendingResponse = { body: { items: [browserApproval], nextCursor: 'cursor-pending' } } satisfies JsonResponse
  596 |     routes.set(pendingPath, pendingResponse)
  597 |     pendingApprovals.resolve(pendingResponse)
  598 |     await expect(page.getByTestId(`approval-row-${browserApproval.id}`)).toBeVisible()
  599 |     await expect(page.getByTestId('load-more-approvals')).toBeVisible()
  600 | 
  601 |     const priorPendingRequests = routes.requests.filter(request => request === pendingPath).length
  602 |     routes.set(pendingPath, {
  603 |       body: { error: { code: 'RESOURCE_SCOPE_DENIED', correlationId: 'safe-pending-revoke', message: 'Denied.' } },
  604 |       status: 403,
  605 |     })
  606 |     await page.getByRole('button', { name: 'Refresh', exact: true }).evaluate((button: HTMLButtonElement) => button.click())
  607 |     await routes.waitFor(pendingPath, priorPendingRequests + 1)
  608 |     await expect(page.getByTestId(`approval-row-${browserApproval.id}`)).toHaveCount(0)
  609 |     await expect(page.getByTestId('load-more-approvals')).toHaveCount(0)
  610 |     await expect(page.getByRole('heading', { name: 'Agent workspace needs attention' })).toBeVisible()
  611 |     await expect(page.locator('.control-summary')).toHaveCount(0)
  612 |     await expect(page.locator('.approval-projection .empty')).toHaveCount(0)
  613 |     await expect(page.getByText('safe-pending-revoke')).toHaveCount(0)
  614 |     expect(routes.unexpected).toEqual([])
  615 |   })
  616 | })
  617 | 
  618 | test.describe('Task 6.4 Settings loading authority', () => {
  619 |   test.use({ viewport: { height: 900, width: 1440 } })
  620 | 
  621 |   test('separates Team and State initialization and retains the State surface through refresh failure', async ({ page }) => {
  622 |     const routes = new RouteScenarios()
  623 |     await routes.install(page)
  624 |     await page.context().addCookies([{ name: 'workmesh_locale', value: 'en', url: webUrl }])
  625 | 
  626 |     const teamsPending = deferredResponse()
  627 |     const statesPending = deferredResponse()
  628 |     const statesPath = `/api/v1/teams/${team.id}/states`
  629 |     routes.set('/api/v1/teams', teamsPending.promise)
  630 |     routes.setRequest('GET', statesPath, statesPending.promise)
  631 |     await page.goto('/settings?tab=workspace', { waitUntil: 'domcontentloaded' })
  632 | 
  633 |     const settings = page.locator('.settings-page')
  634 |     const initialSkeleton = settings.locator('.settings-loading-skeleton .skeleton-list')
  635 |     await expect(initialSkeleton).toBeVisible()
  636 |     await expect(settings).not.toHaveAttribute('aria-busy')
  637 |     await expect(settings.locator('[aria-busy="true"]')).toHaveCount(1)
  638 |     await expect(settings.getByText('No Team', { exact: true })).toHaveCount(0)
  639 | 
  640 |     const teamsResponse = { body: { items: [team], nextCursor: null } } satisfies JsonResponse
  641 |     routes.set('/api/v1/teams', teamsResponse)
  642 |     teamsPending.resolve(teamsResponse)
  643 |     const workflow = settings.locator('[aria-labelledby="workflow-settings-heading"]')
  644 |     await expect(workflow.locator('.skeleton-list')).toBeVisible()
  645 |     await expect(workflow).not.toHaveAttribute('aria-busy')
  646 |     await expect(workflow.locator('[aria-busy="true"]')).toHaveCount(1)
  647 | 
  648 |     const state = { category: 'backlog', color: '#a8a29e', id: 'state-backlog', name: 'Backlog', revision: 1 }
  649 |     const statesResponse = { body: { items: [state], nextCursor: null } } satisfies JsonResponse
  650 |     routes.setRequest('GET', statesPath, statesResponse)
  651 |     statesPending.resolve(statesResponse)
  652 |     const stateRow = workflow.locator('.workflow-state-list article').first()
  653 |     await expect(stateRow).toContainText('Backlog')
  654 | 
  655 |     const stateName = workflow.locator('input[name="name"]')
  656 |     await stateName.fill('Review')
  657 |     await stateName.evaluate(element => { element.dataset.loadingIdentity = 'retained-state-form' })
  658 |     const refreshPending = deferredResponse()
  659 |     const pagedStatesPath = `${statesPath}?limit=100`
  660 |     const priorRequests = routes.requests.filter(request => request === pagedStatesPath).length
  661 |     routes.setRequest('POST', statesPath, { body: { ...state, id: 'state-review', name: 'Review' } })
  662 |     routes.setRequest('GET', pagedStatesPath, refreshPending.promise)
  663 |     await workflow.locator('form').evaluate((form: HTMLFormElement) => form.requestSubmit())
  664 |     await routes.waitFor(pagedStatesPath, priorRequests + 1)
  665 |     await expect(workflow).toHaveAttribute('aria-busy', 'true')
```