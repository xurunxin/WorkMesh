# Instructions

- Following Playwright test failed.
- Explain why, be concise, respect Playwright best practices.
- Provide a snippet of code with the fix, if possible.

# Test info

- Name: mocked\loading-states.mocked.spec.ts >> Task 6.4 loading geometry at 1440px >> matches real Registry, Sessions and Connections grids without focusable placeholders
- Location: e2e\mocked\loading-states.mocked.spec.ts:915:5

# Error details

```
Error: expect(locator).toHaveCount(expected) failed

Locator:  locator('.registry-list > article')
Expected: 4
Received: 0
Timeout:  10000ms

Call log:
  - Expect "toHaveCount" with timeout 10000ms
  - waiting for locator('.registry-list > article')
    23 × locator resolved to 0 elements
       - unexpected value "0"

```

# Page snapshot

```yaml
- generic [active] [ref=e1]:
  - button "Open Next.js Dev Tools" [ref=e7] [cursor=pointer]:
    - img [ref=e8]
  - alert [ref=e11]
  - generic [ref=e12]:
    - link "Skip to content" [ref=e13] [cursor=pointer]:
      - /url: "#workmesh-main"
    - complementary "Main navigation" [ref=e14]:
      - generic [ref=e15]:
        - strong [ref=e17]: WorkMesh
        - generic [ref=e18]: Alex Morgan
      - button "Collapse sidebar" [expanded] [ref=e19] [cursor=pointer]:
        - img [ref=e20]
        - generic [ref=e22]: Collapse sidebar
      - navigation "Workspace navigation" [ref=e23]:
        - generic [ref=e24]:
          - paragraph [ref=e25]: Workbench
          - link "Workbench" [ref=e26] [cursor=pointer]:
            - /url: /workbench
            - img [ref=e28]
            - generic [ref=e30]: Workbench
          - link "My work" [ref=e31] [cursor=pointer]:
            - /url: /?view=home
            - img [ref=e33]
            - generic [ref=e35]: My work
          - link "Issues" [ref=e36] [cursor=pointer]:
            - /url: /?view=my-work
            - img [ref=e38]
            - generic [ref=e40]: Issues
          - link "Guidance" [ref=e41] [cursor=pointer]:
            - /url: /?view=guidance
            - img [ref=e43]
            - generic [ref=e45]: Guidance
        - generic [ref=e46]:
          - paragraph [ref=e47]: Governance
          - link "Needs You" [ref=e48] [cursor=pointer]:
            - /url: /?view=inbox
            - img [ref=e50]
            - generic [ref=e52]: Needs You
          - link "Session" [ref=e53] [cursor=pointer]:
            - /url: /?view=sessions
            - img [ref=e55]
            - generic [ref=e57]: Session
          - link "Recovery" [ref=e58] [cursor=pointer]:
            - /url: /?view=recovery
            - img [ref=e60]
            - generic [ref=e62]: Recovery
          - link "Projects" [ref=e63] [cursor=pointer]:
            - /url: /?view=projects
            - img [ref=e65]
            - generic [ref=e67]: Projects
          - link "Agents" [ref=e68] [cursor=pointer]:
            - /url: /agents
            - img [ref=e70]
            - generic [ref=e72]: Agents
        - generic [ref=e73]:
          - paragraph [ref=e74]: Operations
          - link "Operations" [ref=e75] [cursor=pointer]:
            - /url: /operations
            - img [ref=e77]
            - generic [ref=e79]: Operations
      - navigation "Administration navigation" [ref=e80]:
        - link "Settings" [ref=e81] [cursor=pointer]:
          - /url: /settings
          - img [ref=e83]
          - generic [ref=e85]: Settings
      - generic [ref=e87]:
        - button "Sign out" [ref=e88] [cursor=pointer]:
          - img [ref=e90]
          - generic [ref=e92]: Sign out
        - generic [ref=e93]: v1.0.0 · build loading-state-fixture · schema 24
    - generic [ref=e94]:
      - banner [ref=e95]:
        - paragraph [ref=e96]:
          - generic [ref=e97]: Human control plane
        - button "Search" [ref=e99] [cursor=pointer]:
          - img [ref=e101]
          - generic [ref=e103]:
            - generic [ref=e104]: Search
            - generic [ref=e105]: Ctrl K
        - generic [ref=e106]:
          - button "Switch to the light theme" [ref=e107]:
            - img [ref=e108]
          - generic [ref=e110]:
            - group "Language" [ref=e111]:
              - button "中" [ref=e112]
              - button "EN" [pressed] [ref=e113]
            - generic "Reconnecting" [ref=e114]:
              - generic [ref=e115]: Reconnecting
      - main [ref=e116]:
        - generic [ref=e117]:
          - generic [ref=e118]:
            - generic [ref=e119]:
              - paragraph [ref=e120]: Human control plane
              - heading "Agents" [level=1] [ref=e121]
              - paragraph [ref=e122]: Monitor delegated work, respond to approvals, and diagnose Connections without handling credentials.
            - button "Refresh" [ref=e123] [cursor=pointer]:
              - generic [ref=e124]: Refresh
          - alert [ref=e125]:
            - generic [ref=e127]:
              - heading "Agent workspace needs attention" [level=2] [ref=e128]
              - paragraph [ref=e129]: "[ { \"code\": \"invalid_type\", \"expected\": \"string\", \"received\": \"undefined\", \"path\": [ \"icon\" ], \"message\": \"Required\" }, { \"code\": \"invalid_type\", \"expected\": \"string\", \"received\": \"undefined\", \"path\": [ \"endpoint_url\" ], \"message\": \"Required\" }, { \"code\": \"invalid_type\", \"expected\": \"array\", \"received\": \"undefined\", \"path\": [ \"output_artifact_types\" ], \"message\": \"Required\" }, { \"code\": \"invalid_type\", \"expected\": \"object\", \"received\": \"undefined\", \"path\": [ \"metadata\" ], \"message\": \"Required\" }, { \"expected\": \"'active' | 'archived'\", \"received\": \"undefined\", \"code\": \"invalid_type\", \"path\": [ \"lifecycle_status\" ], \"message\": \"Required\" }, { \"code\": \"invalid_type\", \"expected\": \"string\", \"received\": \"undefined\", \"path\": [ \"archived_at\" ], \"message\": \"Required\" }, { \"code\": \"invalid_type\", \"expected\": \"string\", \"received\": \"undefined\", \"path\": [ \"archived_by_actor_id\" ], \"message\": \"Required\" }, { \"code\": \"invalid_type\", \"expected\": \"string\", \"received\": \"undefined\", \"path\": [ \"archived_reason\" ], \"message\": \"Required\" }, { \"code\": \"invalid_type\", \"expected\": \"string\", \"received\": \"undefined\", \"path\": [ \"created_at\" ], \"message\": \"Required\" }, { \"code\": \"invalid_type\", \"expected\": \"string\", \"received\": \"undefined\", \"path\": [ \"updated_at\" ], \"message\": \"Required\" } ]"
            - button "Retry" [ref=e130] [cursor=pointer]:
              - generic [ref=e131]: Retry
          - generic [ref=e132]:
            - tablist "Agent workspace sections" [ref=e133]:
              - tab "Agents" [selected] [ref=e134]:
                - generic [ref=e135]: Agents
              - tab "Connections" [ref=e136]:
                - generic [ref=e137]: Connections
              - tab "Auto enrollment" [ref=e138]:
                - generic [ref=e139]: Auto enrollment
              - tab "Archived" [ref=e140]:
                - generic [ref=e141]: Archived
            - tabpanel "Agents" [ref=e142]:
              - region "Registry" [ref=e143]:
                - generic [ref=e144]:
                  - generic [ref=e145]:
                    - paragraph [ref=e146]: Registry
                    - heading "Agents" [level=2] [ref=e147]
                    - paragraph [ref=e148]: Scan definitions first; expand Team authority only when it needs review.
                  - generic [ref=e149]:
                    - button "All" [ref=e150]
                    - button "Active" [ref=e151]
                    - button "Inactive" [ref=e152]
                - group "Agent filters" [ref=e153]:
                  - generic [ref=e154]:
                    - generic [ref=e155]: Name
                    - searchbox "Name" [ref=e156]
                  - generic [ref=e157]:
                    - generic [ref=e158]: Team
                    - combobox "Team" [ref=e159]:
                      - option "All teams" [selected]
                      - option "General"
                  - generic [ref=e160]:
                    - generic [ref=e161]: Capability
                    - combobox "Capability" [ref=e162]:
                      - option "All capabilities" [selected]
                  - generic [ref=e163]:
                    - generic [ref=e164]: Status
                    - combobox "Status" [ref=e165]:
                      - option "All" [selected]
                      - option "Active"
                      - option "Inactive"
```

# Test source

```ts
  834  | 
  835  |       const teamsPending = deferredResponse()
  836  |       const statesGeometryPending = deferredResponse()
  837  |       const statesPath = `/api/v1/teams/${team.id}/states`
  838  |       routes.setRequest('GET', '/api/v1/teams', teamsPending.promise)
  839  |       routes.setRequest('GET', statesPath, statesGeometryPending.promise)
  840  |       await page.goto('/settings?tab=workspace', { waitUntil: 'domcontentloaded' })
  841  |       const settingsHeader = page.locator('.settings-page > header').first()
  842  |       await settingsHeader.evaluate(element => { element.dataset.loadingIdentity = 'stable-settings-header' })
  843  |       const settingsHeaderPending = (await measureRects(page, '.settings-page > header'))[0]!
  844  |       const settingsPending = await measureSkeleton(page, '.settings-loading-skeleton .skeleton-list', { panelSelector: '.settings-grid' })
  845  |       expectContainedSkeleton(settingsPending, viewport.width <= 720 ? 1 : 2)
  846  |       expect(settingsPending.busyOwners).toBe(1)
  847  |       await page.screenshot({ path: join(evidenceRoot, `loading-settings-pending-${viewport.width}x${viewport.height}.png`) })
  848  | 
  849  |       const teamsResponse = { body: { items: [team], nextCursor: null } } satisfies JsonResponse
  850  |       routes.setRequest('GET', '/api/v1/teams', teamsResponse)
  851  |       teamsPending.resolve(teamsResponse)
  852  |       await expect(page.locator('.settings-states-loading .skeleton-list')).toBeVisible()
  853  |       const statesPending = await measureSkeleton(page, '.settings-states-loading .skeleton-list', { panelSelector: '.settings-card' })
  854  |       expectContainedSkeleton(statesPending, viewport.width <= 560 ? 1 : workflowStates.length)
  855  |       expect(statesPending.cells).toHaveLength(workflowStates.length)
  856  |       expect(statesPending.document.overflow).toBe(0)
  857  |       expect(statesPending.focusableCount).toBe(0)
  858  |       const statesResponse = { body: { items: workflowStates, nextCursor: null } } satisfies JsonResponse
  859  |       routes.setRequest('GET', statesPath, statesResponse)
  860  |       statesGeometryPending.resolve(statesResponse)
  861  |       await expect(page.locator('.settings-grid > .settings-card')).toHaveCount(3)
  862  |       await expect(page.locator('.workflow-state-list > article')).toHaveCount(workflowStates.length)
  863  |       const statesResolved = await measureResolvedGrid(page, '.workflow-state-list', ':scope > article')
  864  |       expect(statesResolved.columns).toBe(statesPending.columns)
  865  |       expect(statesResolved.document.overflow).toBe(0)
  866  |       expect(Math.abs(statesResolved.root.width - statesPending.root.width)).toBeLessThanOrEqual(2)
  867  |       statesResolved.items.forEach((card, index) => expect(Math.abs(card.width - statesPending.cells[index]!.width)).toBeLessThanOrEqual(2))
  868  |       const settingsResolved = await measureRects(page, '.settings-grid > .settings-card')
  869  |       const settingsContainment = await measureResolvedContainment(page)
  870  |       const settingsHeaderResolved = (await measureRects(page, '.settings-page > header'))[0]!
  871  |       expect(settingsContainment.document.overflow).toBe(0)
  872  |       await expect(settingsHeader).toHaveAttribute('data-loading-identity', 'stable-settings-header')
  873  |       expect(Math.abs(settingsHeaderPending.top - settingsHeaderResolved.top)).toBeLessThanOrEqual(2)
  874  |       for (const index of [0, 1, 2])
  875  |         expect(Math.abs(settingsPending.cells[index]!.width - settingsResolved[index]!.width)).toBeLessThanOrEqual(8)
  876  |       await persistEvidence(page, testInfo, `loading-settings-geometry-${viewport.width}x${viewport.height}`, {
  877  |         header: { pending: settingsHeaderPending, resolved: settingsHeaderResolved },
  878  |         pending: settingsPending,
  879  |         resolvedCards: settingsResolved,
  880  |         resolvedContainment: settingsContainment,
  881  |         states: { pending: statesPending, resolved: statesResolved },
  882  |       })
  883  | 
  884  |       const workItemsPending = deferredResponse()
  885  |       routes.setRequest('GET', `/api/v1/teams/${team.id}/states`, { body: { items: workflowStates, nextCursor: null } })
  886  |       routes.set('/api/v1/work-items', workItemsPending.promise)
  887  |       await page.goto('/?view=my-work&layout=board', { waitUntil: 'domcontentloaded' })
  888  |       const boardControls = page.locator('.work-surface-layout-toggle')
  889  |       await boardControls.evaluate(element => { element.dataset.loadingIdentity = 'stable-board-controls' })
  890  |       const boardControlsPending = (await measureRects(page, '.work-surface-layout-toggle'))[0]!
  891  |       const boardPending = await measureSkeleton(page, '.work-surfaces .skeleton-list', { panelSelector: '.work-surfaces' })
  892  |       expectContainedSkeleton(boardPending, viewport.width <= 560 ? 1 : workflowStates.length, viewport.width > 560)
  893  |       expect(boardPending.busyOwners).toBe(1)
  894  |       expect(boardPending.cells).toHaveLength(workflowStates.length)
  895  |       if (viewport.width > 560)
  896  |         expect(boardPending.cells.every(cell => Math.abs(cell.width - 320) <= 2)).toBe(true)
  897  |       await page.screenshot({ path: join(evidenceRoot, `loading-board-pending-${viewport.width}x${viewport.height}.png`) })
  898  | 
  899  |       const workItemsResponse = { body: { items: [browserWorkItem], nextCursor: null } } satisfies JsonResponse
  900  |       routes.set('/api/v1/work-items', workItemsResponse)
  901  |       workItemsPending.resolve(workItemsResponse)
  902  |       await expect(page.locator('.wm-work-item-column')).toHaveCount(workflowStates.length)
  903  |       const boardResolved = await measureRects(page, '.wm-work-item-column')
  904  |       const boardContainment = await measureResolvedContainment(page, '.wm-work-item-board-scroll')
  905  |       const boardControlsResolved = (await measureRects(page, '.work-surface-layout-toggle'))[0]!
  906  |       expect(boardContainment.document.overflow).toBe(0)
  907  |       await expect(boardControls).toHaveAttribute('data-loading-identity', 'stable-board-controls')
  908  |       expect(Math.abs(boardControlsPending.top - boardControlsResolved.top)).toBeLessThanOrEqual(2)
  909  |       if (viewport.width > 560)
  910  |         boardResolved.forEach((column, index) => expect(Math.abs(boardPending.cells[index]!.width - column.width)).toBeLessThanOrEqual(2))
  911  |       await persistEvidence(page, testInfo, `loading-board-geometry-${viewport.width}x${viewport.height}`, { controls: { pending: boardControlsPending, resolved: boardControlsResolved }, pending: boardPending, resolvedColumns: boardResolved, resolvedContainment: boardContainment })
  912  |       expect(routes.unexpected).toEqual([])
  913  |     })
  914  | 
  915  |     test('matches real Registry, Sessions and Connections grids without focusable placeholders', async ({ page }, testInfo) => {
  916  |       const routes = new RouteScenarios()
  917  |       await routes.install(page)
  918  |       await page.context().addCookies([{ name: 'workmesh_locale', value: 'en', url: webUrl }])
  919  | 
  920  |       const registryPendingResponse = deferredResponse()
  921  |       routes.set('/api/v1/agents', registryPendingResponse.promise)
  922  |       await page.goto('/agents?tab=agents', { waitUntil: 'domcontentloaded' })
  923  |       const registryHeader = page.locator('.agent-registry > .surface-header')
  924  |       await registryHeader.evaluate(element => { element.dataset.loadingIdentity = 'stable-registry-header' })
  925  |       const registryHeaderPending = (await measureRects(page, '.agent-registry > .surface-header'))[0]!
  926  |       const registryPending = await measureSkeleton(page, '.agent-registry > .skeleton-list', { panelSelector: '.agent-registry' })
  927  |       expectContainedSkeleton(registryPending, 1)
  928  |       expect(registryPending.busyOwners).toBe(1)
  929  |       await page.screenshot({ path: join(evidenceRoot, `loading-agents-registry-pending-${viewport.width}x${viewport.height}.png`) })
  930  | 
  931  |       const agentsResponse = { body: { items: browserAgents, nextCursor: null } } satisfies JsonResponse
  932  |       routes.set('/api/v1/agents', agentsResponse)
  933  |       registryPendingResponse.resolve(agentsResponse)
> 934  |       await expect(page.locator('.registry-list > article')).toHaveCount(browserAgents.length)
       |                                                              ^ Error: expect(locator).toHaveCount(expected) failed
  935  |       const registryResolved = await measureResolvedGrid(page, '.registry-list', ':scope > article')
  936  |       const registryHeaderResolved = (await measureRects(page, '.agent-registry > .surface-header'))[0]!
  937  |       expect(registryResolved.columns).toBe(1)
  938  |       expect(registryResolved.document.overflow).toBe(0)
  939  |       expect(Math.abs(registryResolved.root.width - registryPending.root.width)).toBeLessThanOrEqual(2)
  940  |       expect(Math.abs(registryResolved.items[0]!.width - registryPending.cells[0]!.width)).toBeLessThanOrEqual(2)
  941  |       expect(Math.abs(registryHeaderPending.top - registryHeaderResolved.top)).toBeLessThanOrEqual(2)
  942  |       await expect(registryHeader).toHaveAttribute('data-loading-identity', 'stable-registry-header')
  943  |       await persistEvidence(page, testInfo, `loading-agents-registry-geometry-${viewport.width}x${viewport.height}`, {
  944  |         header: { pending: registryHeaderPending, resolved: registryHeaderResolved },
  945  |         pending: registryPending,
  946  |         resolved: registryResolved,
  947  |       })
  948  | 
  949  |       const sessionsPath = '/api/v1/agent-sessions?limit=100'
  950  |       const connectionsPath = '/api/v1/agent-connections?limit=50'
  951  |       const sessionsPendingResponse = deferredResponse()
  952  |       const connectionsPendingResponse = deferredResponse()
  953  |       routes.set(sessionsPath, sessionsPendingResponse.promise)
  954  |       routes.set(connectionsPath, connectionsPendingResponse.promise)
  955  |       await page.goto('/agents?tab=sessions', { waitUntil: 'domcontentloaded' })
  956  |       const sessionsRegion = page.getByRole('region', { name: 'Sessions', exact: true })
  957  |       const connectionsRegion = page.getByRole('region', { name: 'Connections', exact: true })
  958  |       const sessionsHeader = sessionsRegion.locator('.surface-header')
  959  |       const connectionsHeader = connectionsRegion.locator('.surface-header')
  960  |       await sessionsHeader.evaluate(element => { element.dataset.loadingIdentity = 'stable-sessions-header' })
  961  |       await connectionsHeader.evaluate(element => { element.dataset.loadingIdentity = 'stable-connections-header' })
  962  |       const sessionsHeaderPending = (await measureRects(page, '[aria-label="Sessions"] > .surface-header'))[0]!
  963  |       const connectionsHeaderPending = (await measureRects(page, '.connection-panel > .surface-header'))[0]!
  964  |       const sessionsPending = await measureSkeleton(page, '.agent-sessions-loading .skeleton-list', { panelSelector: '.surface-panel' })
  965  |       const connectionsPending = await measureSkeleton(page, '.agent-connections-loading .skeleton-list', { panelSelector: '.connection-panel' })
  966  |       const expectedCardColumns = viewport.width <= 560 ? 1 : browserSessions.length
  967  |       expectContainedSkeleton(sessionsPending, expectedCardColumns)
  968  |       expectContainedSkeleton(connectionsPending, expectedCardColumns)
  969  |       expect(sessionsPending.busyOwners).toBe(1)
  970  |       expect(connectionsPending.busyOwners).toBe(1)
  971  |       if (viewport.width > 560) {
  972  |         expect(sessionsPending.cells.every(cell => cell.width > 224)).toBe(true)
  973  |         expect(connectionsPending.cells.every(cell => cell.width > 224)).toBe(true)
  974  |       }
  975  |       await page.screenshot({ path: join(evidenceRoot, `loading-agents-secondary-pending-${viewport.width}x${viewport.height}.png`) })
  976  | 
  977  |       const sessionsResponse = { body: { items: browserSessions, nextCursor: null } } satisfies JsonResponse
  978  |       const connectionsResponse = { body: { items: browserConnections, nextCursor: null } } satisfies JsonResponse
  979  |       routes.set(sessionsPath, sessionsResponse)
  980  |       sessionsPendingResponse.resolve(sessionsResponse)
  981  |       await expect(page.locator('.session-card-list > .session-card')).toHaveCount(browserSessions.length)
  982  |       const sessionsResolved = await measureResolvedGrid(page, '.session-card-list', ':scope > .session-card')
  983  |       const sessionsHeaderResolved = (await measureRects(page, '[aria-label="Sessions"] > .surface-header'))[0]!
  984  |       routes.set(connectionsPath, connectionsResponse)
  985  |       connectionsPendingResponse.resolve(connectionsResponse)
  986  |       await expect(page.locator('.connection-list > button')).toHaveCount(browserConnections.length)
  987  |       const connectionsResolved = await measureResolvedGrid(page, '.connection-list', ':scope > button')
  988  |       const connectionsHeaderResolved = (await measureRects(page, '.connection-panel > .surface-header'))[0]!
  989  |       expect(sessionsResolved.columns).toBe(sessionsPending.columns)
  990  |       expect(connectionsResolved.columns).toBe(connectionsPending.columns)
  991  |       expect(sessionsResolved.document.overflow).toBe(0)
  992  |       expect(connectionsResolved.document.overflow).toBe(0)
  993  |       expect(Math.abs(sessionsResolved.root.width - sessionsPending.root.width)).toBeLessThanOrEqual(2)
  994  |       expect(Math.abs(connectionsResolved.root.width - connectionsPending.root.width)).toBeLessThanOrEqual(2)
  995  |       sessionsResolved.items.forEach((card, index) => expect(Math.abs(card.width - sessionsPending.cells[index]!.width)).toBeLessThanOrEqual(2))
  996  |       connectionsResolved.items.forEach((card, index) => expect(Math.abs(card.width - connectionsPending.cells[index]!.width)).toBeLessThanOrEqual(2))
  997  |       expect(Math.abs(sessionsHeaderPending.top - sessionsHeaderResolved.top)).toBeLessThanOrEqual(2)
  998  |       expect(Math.abs(connectionsHeaderPending.top - connectionsHeaderResolved.top)).toBeLessThanOrEqual(2)
  999  |       await expect(sessionsHeader).toHaveAttribute('data-loading-identity', 'stable-sessions-header')
  1000 |       await expect(connectionsHeader).toHaveAttribute('data-loading-identity', 'stable-connections-header')
  1001 |       await persistEvidence(page, testInfo, `loading-agents-secondary-geometry-${viewport.width}x${viewport.height}`, {
  1002 |         connections: { header: { pending: connectionsHeaderPending, resolved: connectionsHeaderResolved }, pending: connectionsPending, resolved: connectionsResolved },
  1003 |         sessions: { header: { pending: sessionsHeaderPending, resolved: sessionsHeaderResolved }, pending: sessionsPending, resolved: sessionsResolved },
  1004 |       })
  1005 |       expect(routes.unexpected).toEqual([])
  1006 |     })
  1007 |   })
  1008 | }
  1009 | 
```