# Instructions

- Following Playwright test failed.
- Explain why, be concise, respect Playwright best practices.
- Provide a snippet of code with the fix, if possible.

# Test info

- Name: mocked\operations-ux.mocked.spec.ts >> filters only loaded localized values, keeps metrics and pagination, and restores the same-tab URL
- Location: e2e\mocked\operations-ux.mocked.spec.ts:1345:1

# Error details

```
Error: expect(locator).toHaveValue(expected) failed

Locator: getByRole('searchbox', { name: 'Search loaded Operations records' })
Expected: "Agent run"
Timeout: 10000ms
Error: element(s) not found

Call log:
  - Expect "toHaveValue" with timeout 10000ms
  - waiting for getByRole('searchbox', { name: 'Search loaded Operations records' })

```

```yaml
- alert
- main:
  - heading "Page not found" [level=1]
  - paragraph: The page you are looking for does not exist or has been moved.
  - link "Back to home":
    - /url: /
```

# Test source

```ts
  1311 |   try {
  1312 |     await installOperationsRoutes(page, () => allOperationsFeatures, {
  1313 |       emptyCollections: collectionPaths,
  1314 |       requestLog,
  1315 |     })
  1316 |     await page.goto('/operations')
  1317 | 
  1318 |     const serverEmptyHeadings = [
  1319 |       ['cycles-panel', 'No Cycles configured'],
  1320 |       ['initiatives-panel', 'No Initiatives configured'],
  1321 |       ['automation-panel', 'No Rules configured'],
  1322 |       ['loops-panel', 'No Loops configured'],
  1323 |       ['runs-panel', 'No run history yet'],
  1324 |       ['templates-panel', 'No Templates configured'],
  1325 |     ] as const
  1326 |     for (const [panelId, heading] of serverEmptyHeadings) {
  1327 |       const panel = page.getByTestId(panelId)
  1328 |       await expect(panel.getByRole('heading', { name: heading }), `${panelId}: exhausted empty`).toBeVisible()
  1329 |       await expect(panel.getByRole('heading', { name: /^Loading / }), `${panelId}: not loading`).toHaveCount(0)
  1330 |       await expect(panel.getByRole('heading', { name: /^No loaded .* match$/ }), `${panelId}: not client no-match`).toHaveCount(0)
  1331 |     }
  1332 | 
  1333 |     const observedCollectionPaths = [...new Set(
  1334 |       requestLog
  1335 |         .map(value => new URL(value).pathname)
  1336 |         .filter(path => collectionPathSet.has(path)),
  1337 |     )].sort()
  1338 |     expect(observedCollectionPaths).toEqual([...collectionPaths].sort())
  1339 |     expect(requestLog.every(value => !new URL(value).searchParams.has('opsQuery'))).toBe(true)
  1340 |   } finally {
  1341 |     await page.close()
  1342 |   }
  1343 | })
  1344 | 
  1345 | test('filters only loaded localized values, keeps metrics and pagination, and restores the same-tab URL', async ({ page }) => {
  1346 |   const requestLog: string[] = []
  1347 |   await installOperationsRoutes(page, () => allOperationsFeatures, { paginatedRuns: true, requestLog })
  1348 |   await page.goto('/operations?context=keep#operations-runs')
  1349 |   const search = page.getByRole('searchbox', { name: 'Search loaded Operations records' })
  1350 |   await expect(search).toBeVisible()
  1351 |   await page.evaluate(() => window.history.replaceState({ ...window.history.state, task42: 'keep' }, '', window.location.href))
  1352 | 
  1353 |   await search.fill('Current')
  1354 |   await expect(page.getByTestId('cycles-panel').getByText('Nightly planning')).toBeVisible()
  1355 |   await expect(page.locator('#operations-metrics')).toBeVisible()
  1356 |   await expect(page.locator('#operations-metrics')).toContainText('Tokens')
  1357 |   expect(await page.evaluate(() => window.history.state.task42)).toBe('keep')
  1358 |   expect(new URL(page.url()).searchParams.get('context')).toBe('keep')
  1359 |   expect(new URL(page.url()).hash).toBe('#operations-runs')
  1360 | 
  1361 |   await search.fill('On track')
  1362 |   await expect(page.getByTestId('initiatives-panel').getByText('Runtime reliability')).toBeVisible()
  1363 |   await search.fill('on_track')
  1364 |   await expect(page.getByTestId('initiatives-panel').getByText('Runtime reliability')).toHaveCount(0)
  1365 | 
  1366 |   await search.fill('Webhook retry')
  1367 |   await expect(page.getByTestId('automation-panel').getByText('Webhook retry')).toBeVisible()
  1368 |   await expect(page.getByTestId('automation-panel')).toContainText('Disabled')
  1369 |   await search.fill('schedule 0 2 * * *')
  1370 |   await expect(page.getByTestId('automation-panel').getByText('Webhook retry')).toBeVisible()
  1371 |   await expect(page.getByTestId('automation-panel')).toContainText('v1 · schedule 0 2 * * *')
  1372 |   await search.fill('Release guard')
  1373 |   await expect(page.getByTestId('loops-panel').getByText('Release guard')).toBeVisible()
  1374 |   await expect(page.getByTestId('loops-panel')).toContainText('No overlap')
  1375 | 
  1376 |   await search.fill('Dry run')
  1377 |   await expect(page.getByTestId('runs-panel').getByText('run-0008')).toBeVisible()
  1378 |   await search.fill('dry_run')
  1379 |   await expect(page.getByTestId('runs-panel').getByText('run-0008')).toHaveCount(0)
  1380 | 
  1381 |   await search.fill('Agent run')
  1382 |   await expect(page.getByTestId('templates-panel').getByText('Agent recovery')).toBeVisible()
  1383 |   await search.fill('agent_run')
  1384 |   await expect(page.getByTestId('templates-panel').getByText('Agent recovery')).toHaveCount(0)
  1385 | 
  1386 |   await search.fill('Delayed retry queue exhausted')
  1387 |   await expect(page.getByTestId('runs-panel').getByRole('heading', { name: 'No loaded Recent runs match' })).toBeVisible()
  1388 |   await expect(page.locator('#operations-metrics')).toBeVisible()
  1389 |   await expect(page.locator('#operations-metrics')).toContainText('Tokens')
  1390 |   await page.getByRole('button', { name: 'Load more Recent runs' }).click()
  1391 |   await expect(page.getByTestId('runs-panel').getByText('Delayed retry queue exhausted')).toBeVisible()
  1392 | 
  1393 |   await page.reload()
  1394 |   await expect(search).toHaveValue('Delayed retry queue exhausted')
  1395 |   await expect(page.getByRole('button', { name: 'Load more Recent runs' })).toBeVisible()
  1396 |   await search.fill('Current')
  1397 |   await page.evaluate(() => {
  1398 |     const url = new URL(window.location.href)
  1399 |     url.searchParams.set('opsQuery', 'On track')
  1400 |     window.history.pushState({ ...window.history.state, task42: 'keep' }, '', url)
  1401 |     window.dispatchEvent(new PopStateEvent('popstate'))
  1402 |   })
  1403 |   await expect(search).toHaveValue('On track')
  1404 |   await page.goBack()
  1405 |   await expect(search).toHaveValue('Current')
  1406 |   await page.goForward()
  1407 |   await expect(search).toHaveValue('On track')
  1408 | 
  1409 |   await page.goto('/settings?tab=operations&context=keep&opsQuery=Agent+run#operations-templates')
  1410 |   const embeddedSearch = page.getByRole('searchbox', { name: 'Search loaded Operations records' })
> 1411 |   await expect(embeddedSearch).toHaveValue('Agent run')
       |                                ^ Error: expect(locator).toHaveValue(expected) failed
  1412 |   await embeddedSearch.fill('Archived')
  1413 |   const embeddedUrl = new URL(page.url())
  1414 |   expect(embeddedUrl.searchParams.get('tab')).toBe('operations')
  1415 |   expect(embeddedUrl.searchParams.get('context')).toBe('keep')
  1416 |   expect(embeddedUrl.searchParams.get('opsQuery')).toBe('Archived')
  1417 |   expect(embeddedUrl.hash).toBe('#operations-templates')
  1418 | 
  1419 |   const collectionRequests = requestLog.filter(value => isCollectionPath(new URL(value).pathname))
  1420 |   expect(collectionRequests.length).toBeGreaterThan(0)
  1421 |   expect(collectionRequests.some(value => new URL(value).searchParams.get('cursor') === 'runs-page-2')).toBe(true)
  1422 |   expect(collectionRequests.every(value => !new URL(value).searchParams.has('opsQuery'))).toBe(true)
  1423 | })
  1424 | 
  1425 | test('searches every collection by its exact display projection while excluding hidden raw fields', async ({ context }) => {
  1426 |   const page = await context.newPage()
  1427 |   const requestLog: string[] = []
  1428 |   const readText = async (locator: Locator, label: string) => {
  1429 |     const value = (await locator.textContent())?.trim() ?? ''
  1430 |     expect(value, label).not.toBe('')
  1431 |     return value
  1432 |   }
  1433 |   try {
  1434 |     await installOperationsRoutes(page, () => allOperationsFeatures, { requestLog })
  1435 |     await page.goto('/operations')
  1436 | 
  1437 |     const search = page.getByRole('searchbox', { name: 'Search loaded Operations records' })
  1438 |     await expect(search).toBeVisible()
  1439 | 
  1440 |     const cyclePanel = page.getByTestId('cycles-panel')
  1441 |     const cycle = cyclePanel.locator('article').filter({ hasText: 'Nightly planning' })
  1442 |     const cycleState = await readText(cycle.locator('.status'), 'Cycle localized state')
  1443 |     const cycleDate = await readText(cycle.locator('small'), 'Cycle localized date range')
  1444 | 
  1445 |     const initiativePanel = page.getByTestId('initiatives-panel')
  1446 |     const initiative = initiativePanel.locator('article').filter({ hasText: 'Runtime reliability' })
  1447 |     const initiativeHealth = await readText(initiative.locator('.health'), 'Initiative localized health')
  1448 |     const initiativeLine = await readText(initiative.locator('p'), 'Initiative localized status and priority')
  1449 | 
  1450 |     const automationPanel = page.getByTestId('automation-panel')
  1451 |     const rule = automationPanel.locator('article').filter({ hasText: 'Webhook retry' })
  1452 |     const ruleState = await readText(rule.locator('.status'), 'Automation localized state')
  1453 |     const ruleKind = await readText(rule.locator('small'), 'Automation rendered trigger kind')
  1454 | 
  1455 |     const loopsPanel = page.getByTestId('loops-panel')
  1456 |     const loop = loopsPanel.locator('article').filter({ hasText: 'Release guard' })
  1457 |     const loopState = await readText(loop.locator('.status'), 'Loop localized state')
  1458 |     const loopSchedule = await readText(loop.locator('small'), 'Loop localized schedule')
  1459 | 
  1460 |     const runsPanel = page.getByTestId('runs-panel')
  1461 |     const failedRun = page.getByTestId('run-row-run-0005-record')
  1462 |     const failedRunKind = await readText(failedRun.locator('td').nth(1), 'Run localized kind')
  1463 |     const failedRunState = await readText(failedRun.locator('.status'), 'Run localized state')
  1464 |     const failedRunDate = await readText(failedRun.locator('time'), 'Run localized date')
  1465 |     const failedRunError = await readText(
  1466 |       runsPanel.getByText(/Provider retry failed after the upstream execution service/),
  1467 |       'Run historical error',
  1468 |     )
  1469 | 
  1470 |     const templatesPanel = page.getByTestId('templates-panel')
  1471 |     const template = templatesPanel.locator('.template-list > span').filter({ hasText: 'Agent recovery' })
  1472 |     const templateLine = await readText(template.locator('small'), 'Template localized kind and status')
  1473 | 
  1474 |     const expectVisibleFor = async (query: string, item: Locator, label: string) => {
  1475 |       await search.fill(query)
  1476 |       await expect(item, `${label}: exact rendered query`).toBeVisible()
  1477 |     }
  1478 |     const expectHiddenFor = async (
  1479 |       query: string,
  1480 |       item: Locator,
  1481 |       panel: Locator,
  1482 |       noMatchHeading: string,
  1483 |       label: string,
  1484 |     ) => {
  1485 |       await search.fill(query)
  1486 |       await expect(item, `${label}: hidden raw field`).toHaveCount(0)
  1487 |       await expect(panel.getByRole('heading', { name: noMatchHeading }), `${label}: client no-match`).toBeVisible()
  1488 |     }
  1489 | 
  1490 |     await expectVisibleFor(cycleState, cycle, 'Cycle state')
  1491 |     await expectVisibleFor(cycleDate, cycle, 'Cycle date')
  1492 |     await expectHiddenFor('cycle-current', cycle, cyclePanel, 'No loaded Cycles match', 'Cycle full ID')
  1493 | 
  1494 |     await expectVisibleFor(initiativeHealth, initiative, 'Initiative health')
  1495 |     await expectVisibleFor(initiativeLine, initiative, 'Initiative status/priority')
  1496 |     await expectHiddenFor('on_track', initiative, initiativePanel, 'No loaded Initiatives match', 'Initiative raw health')
  1497 | 
  1498 |     await expectVisibleFor(ruleState, rule, 'Automation state')
  1499 |     await expectVisibleFor(ruleKind, rule, 'Automation trigger')
  1500 |     await expectHiddenFor('rule-1', rule, automationPanel, 'No loaded Automation rules match', 'Automation raw ID')
  1501 |     await expectHiddenFor('UTC', rule, automationPanel, 'No loaded Automation rules match', 'Automation undisplayed timezone')
  1502 | 
  1503 |     await expectVisibleFor(loopState, loop, 'Loop state')
  1504 |     await expectVisibleFor(loopSchedule, loop, 'Loop schedule')
  1505 |     await expectHiddenFor('no_overlap', loop, loopsPanel, 'No loaded Loops match', 'Loop raw overlap enum')
  1506 | 
  1507 |     await expectVisibleFor(failedRunKind, failedRun, 'Run kind')
  1508 |     await expectVisibleFor(failedRunState, failedRun, 'Run status')
  1509 |     await expectVisibleFor(failedRunDate, failedRun, 'Run date')
  1510 |     await expectVisibleFor(failedRunError, failedRun, 'Run historical error')
  1511 |     const dryRun = page.getByTestId('run-row-run-0008-record')
```