# Instructions

- Following Playwright test failed.
- Explain why, be concise, respect Playwright best practices.
- Provide a snippet of code with the fix, if possible.

# Test info

- Name: mocked\operations-ux.mocked.spec.ts >> keeps all-enabled navigation wide, sticky, focus-owned, and shared with Settings
- Location: e2e\mocked\operations-ux.mocked.spec.ts:1275:1

# Error details

```
Error: expect(received).toBe(expected) // Object.is equality

Expected: 48
Received: -160

Call Log:
- Timeout 10000ms exceeded while waiting on the predicate
```

# Page snapshot

```yaml
- generic [ref=e1]:
  - button "Open Next.js Dev Tools" [ref=e7] [cursor=pointer]:
    - img [ref=e8]
  - alert [ref=e11]
  - generic [ref=e12]:
    - link "Skip to content" [ref=e13] [cursor=pointer]:
      - /url: "#workmesh-main"
    - complementary "Main navigation" [ref=e14]:
      - generic [ref=e15]:
        - strong [ref=e17]: WorkMesh
        - generic [ref=e18]: Alex Morgan
      - button "Collapse sidebar" [expanded] [ref=e19] [cursor=pointer]:
        - img [ref=e20]
        - generic [ref=e22]: Collapse sidebar
      - navigation "Workspace" [ref=e23]:
        - generic [ref=e24]:
          - paragraph [ref=e25]: Workbench
          - link "Workbench" [ref=e26] [cursor=pointer]:
            - /url: /workbench
            - img [ref=e28]
            - generic [ref=e30]: Workbench
          - link "My work" [ref=e31] [cursor=pointer]:
            - /url: /?view=home
            - img [ref=e33]
            - generic [ref=e35]: My work
          - link "Issues" [ref=e36] [cursor=pointer]:
            - /url: /?view=my-work
            - img [ref=e38]
            - generic [ref=e40]: Issues
          - link "Guidance" [ref=e41] [cursor=pointer]:
            - /url: /?view=guidance
            - img [ref=e43]
            - generic [ref=e45]: Guidance
        - generic [ref=e46]:
          - paragraph [ref=e47]: Governance
          - link "Needs You" [ref=e48] [cursor=pointer]:
            - /url: /?view=inbox
            - img [ref=e50]
            - generic [ref=e52]: Needs You
          - link "Session" [ref=e53] [cursor=pointer]:
            - /url: /?view=sessions
            - img [ref=e55]
            - generic [ref=e57]: Session
          - link "Recovery" [ref=e58] [cursor=pointer]:
            - /url: /?view=recovery
            - img [ref=e60]
            - generic [ref=e62]: Recovery
          - link "Projects" [ref=e63] [cursor=pointer]:
            - /url: /?view=projects
            - img [ref=e65]
            - generic [ref=e67]: Projects
          - link "Agents" [ref=e68] [cursor=pointer]:
            - /url: /agents
            - img [ref=e70]
            - generic [ref=e72]: Agents
        - generic [ref=e73]:
          - paragraph [ref=e74]: Operations
          - link "Operations" [ref=e75] [cursor=pointer]:
            - /url: /operations
            - img [ref=e77]
            - generic [ref=e79]: Operations
      - navigation "Administration" [ref=e80]:
        - link "Settings" [ref=e81] [cursor=pointer]:
          - /url: /settings
          - img [ref=e83]
          - generic [ref=e85]: Settings
      - generic [ref=e87]:
        - button "Sign out" [ref=e88] [cursor=pointer]:
          - img [ref=e90]
          - generic [ref=e92]: Sign out
        - generic [ref=e93]: v1.0.0 · build project-work-preview · schema 24
    - generic [ref=e94]:
      - banner [ref=e95]:
        - paragraph [ref=e96]:
          - generic [ref=e97]: Planning & Operations
        - button "Search" [ref=e99] [cursor=pointer]:
          - img [ref=e101]
          - generic [ref=e103]:
            - generic [ref=e104]: Search
            - generic [ref=e105]: Ctrl K
        - generic [ref=e106]:
          - button "Switch to the light theme" [ref=e107]:
            - img [ref=e108]
          - generic [ref=e110]:
            - group "Language" [ref=e111]:
              - button "中" [ref=e112]
              - button "EN" [pressed] [ref=e113]
            - generic "Reconnecting" [ref=e114]:
              - generic [ref=e115]: Reconnecting
      - main [ref=e116]:
        - generic [ref=e118]:
          - generic [ref=e119]:
            - generic [ref=e120]:
              - link "Back to work" [ref=e121] [cursor=pointer]:
                - /url: /
              - heading "Planning & Operations" [level=1] [ref=e122]
              - paragraph [ref=e123]: Durable planning, automation, health, and cost observability.
            - button "Refresh" [ref=e124] [cursor=pointer]:
              - generic [ref=e125]: Refresh
          - generic [ref=e126]:
            - generic [ref=e127]: Search loaded Operations records
            - searchbox "Search loaded Operations records" [ref=e128]
            - generic [ref=e129]: Filters only Operations records already loaded in this view. Load more to expand the searchable set.
          - navigation "Operations sections" [ref=e130]:
            - link "Usage and cost" [ref=e131] [cursor=pointer]:
              - /url: "#operations-metrics"
            - link "Cycles" [ref=e132] [cursor=pointer]:
              - /url: "#operations-cycles"
            - link "Initiatives" [ref=e133] [cursor=pointer]:
              - /url: "#operations-initiatives"
            - link "Automation rules" [ref=e134] [cursor=pointer]:
              - /url: "#operations-automation"
            - link "Loops" [ref=e135] [cursor=pointer]:
              - /url: "#operations-loops"
            - link "Recent runs" [ref=e136] [cursor=pointer]:
              - /url: "#operations-runs"
            - link "Templates & playbooks" [ref=e137] [cursor=pointer]:
              - /url: "#operations-templates"
          - region "Usage and cost" [ref=e138]:
            - list "Usage and cost" [ref=e139]:
              - listitem "Tokens" [ref=e140]:
                - generic [ref=e142]:
                  - term [ref=e143]: Tokens
                  - definition [ref=e144]:
                    - strong [ref=e145]: 1,500
              - listitem "Runtime" [ref=e146]:
                - generic [ref=e148]:
                  - term [ref=e149]: Runtime
                  - definition [ref=e150]:
                    - strong [ref=e151]: 45s
              - listitem "Tool calls" [ref=e152]:
                - generic [ref=e154]:
                  - term [ref=e155]: Tool calls
                  - definition [ref=e156]:
                    - strong [ref=e157]: "7"
              - listitem "Unknown cost" [ref=e158]:
                - generic [ref=e160]:
                  - term [ref=e161]: Unknown cost
                  - definition [ref=e162]:
                    - strong [ref=e163]: "0"
                    - text: records
              - listitem "Known cost" [ref=e164]:
                - generic [ref=e166]:
                  - term [ref=e167]: Known cost
                  - definition [ref=e168]: No known cost
          - generic [ref=e169]:
            - generic [ref=e170]:
              - heading "Cycles" [level=2] [ref=e171]
              - article [ref=e172]:
                - generic [ref=e173]:
                  - strong [ref=e174]: Nightly planning
                  - generic [ref=e175]: Current
                - paragraph [ref=e176]: 5/12 completed
                - generic [ref=e177]: 8/1/2026, 8:00:00 AM → 8/31/2026, 8:00:00 AM
              - article [ref=e178]:
                - generic [ref=e179]:
                  - strong [ref=e180]: Launch readiness
                  - generic [ref=e181]: Upcoming
                - paragraph [ref=e182]: 0/8 completed
                - generic [ref=e183]: 9/1/2026, 8:00:00 AM → 9/30/2026, 8:00:00 AM
              - article [ref=e184]:
                - generic [ref=e185]:
                  - strong [ref=e186]: Foundation review
                  - generic [ref=e187]: History
                - paragraph [ref=e188]: 10/10 completed
                - generic [ref=e189]: 7/1/2026, 8:00:00 AM → 7/31/2026, 8:00:00 AM
            - generic [ref=e190]:
              - heading "Initiatives" [level=2] [ref=e191]
              - article [ref=e192]:
                - generic [ref=e193]:
                  - strong [ref=e194]: Runtime reliability
                  - generic [ref=e195]: On track
                - paragraph [ref=e196]: Active · Urgent priority
              - article [ref=e197]:
                - generic [ref=e198]:
                  - strong [ref=e199]: Queue recovery
                  - generic [ref=e200]: At risk
                - paragraph [ref=e201]: Planned · High priority
              - article [ref=e202]:
                - generic [ref=e203]:
                  - strong [ref=e204]: Legacy retirement
                  - generic [ref=e205]: Off track
                - paragraph [ref=e206]: Paused · Medium priority
              - article [ref=e207]:
                - generic [ref=e208]:
                  - strong [ref=e209]: Documentation
                  - generic [ref=e210]: Unknown
                - paragraph [ref=e211]: Completed · Low priority
              - article [ref=e212]:
                - generic [ref=e213]:
                  - strong [ref=e214]: Discarded experiment
                  - generic [ref=e215]: Unknown
                - paragraph [ref=e216]: Canceled · None priority
            - generic [ref=e217]:
              - heading "Automation rules" [level=2] [ref=e218]
              - article [ref=e219]:
                - generic [ref=e220]:
                  - strong [ref=e221]: Webhook retry
                  - generic [ref=e222]: v1 · schedule 0 2 * * *
                - generic [ref=e223]: Disabled
                - button "Dry run" [ref=e224]
                - button "Resume" [ref=e225]
              - article [ref=e226]:
                - generic [ref=e227]:
                  - strong [ref=e228]: Rule 2
                  - generic [ref=e229]: v1 · event
                - generic [ref=e230]: Paused
                - button "Dry run" [ref=e231]
                - button "Resume" [ref=e232]
              - article [ref=e233]:
                - generic [ref=e234]:
                  - strong [ref=e235]: Rule 3
                  - generic [ref=e236]: v1 · event
                - generic [ref=e237]: Enabled
                - button "Dry run" [ref=e238]
                - button "Pause" [ref=e239]
              - article [ref=e240]:
                - generic [ref=e241]:
                  - strong [ref=e242]: Rule 4
                  - generic [ref=e243]: v1 · event
                - generic [ref=e244]: Enabled
                - button "Dry run" [ref=e245]
                - button "Pause" [ref=e246]
              - article [ref=e247]:
                - generic [ref=e248]:
                  - strong [ref=e249]: Rule 5
                  - generic [ref=e250]: v1 · event
                - generic [ref=e251]: Enabled
                - button "Dry run" [ref=e252]
                - button "Pause" [ref=e253]
              - article [ref=e254]:
                - generic [ref=e255]:
                  - strong [ref=e256]: Rule 6
                  - generic [ref=e257]: v1 · event
                - generic [ref=e258]: Enabled
                - button "Dry run" [ref=e259]
                - button "Pause" [ref=e260]
              - article [ref=e261]:
                - generic [ref=e262]:
                  - strong [ref=e263]: Rule 7
                  - generic [ref=e264]: v1 · event
                - generic [ref=e265]: Enabled
                - button "Dry run" [ref=e266]
                - button "Pause" [ref=e267]
              - article [ref=e268]:
                - generic [ref=e269]:
                  - strong [ref=e270]: Rule 8
                  - generic [ref=e271]: v1 · event
                - generic [ref=e272]: Enabled
                - button "Dry run" [ref=e273]
                - button "Pause" [ref=e274]
            - generic [ref=e275]:
              - heading "Loops" [level=2] [ref=e276]
              - article [ref=e277]:
                - generic [ref=e278]:
                  - strong [ref=e279]: Release guard
                  - generic [ref=e280]: "Next: 8/23/2026, 10:00:00 AM · No overlap"
                - generic [ref=e281]: Disabled
                - button "Resume" [ref=e282]
              - article [ref=e283]:
                - generic [ref=e284]:
                  - strong [ref=e285]: Loop 2
                  - generic [ref=e286]: "Next: 8/23/2026, 10:00:00 AM · No overlap"
                - generic [ref=e287]: Paused
                - button "Resume" [ref=e288]
              - article [ref=e289]:
                - generic [ref=e290]:
                  - strong [ref=e291]: Loop 3
                  - generic [ref=e292]: "Next: 8/23/2026, 10:00:00 AM · Overlap allowed"
                - generic [ref=e293]: Enabled
                - button "Pause" [ref=e294]
              - article [ref=e295]:
                - generic [ref=e296]:
                  - strong [ref=e297]: Loop 4
                  - generic [ref=e298]: "Next: 8/23/2026, 10:00:00 AM · No overlap"
                - generic [ref=e299]: Enabled
                - button "Pause" [ref=e300]
              - article [ref=e301]:
                - generic [ref=e302]:
                  - strong [ref=e303]: Loop 5
                  - generic [ref=e304]: "Next: 8/23/2026, 10:00:00 AM · No overlap"
                - generic [ref=e305]: Enabled
                - button "Pause" [ref=e306]
              - article [ref=e307]:
                - generic [ref=e308]:
                  - strong [ref=e309]: Loop 6
                  - generic [ref=e310]: "Next: 8/23/2026, 10:00:00 AM · No overlap"
                - generic [ref=e311]: Enabled
                - button "Pause" [ref=e312]
            - generic [active] [ref=e313]:
              - heading "Recent runs" [level=2] [ref=e314]
              - region "Recent runs" [ref=e315]:
                - table "Recent runs" [ref=e316]:
                  - caption [ref=e317]: Recent runs
                  - rowgroup [ref=e325]:
                    - row "Run Kind Status Attempts Session Created" [ref=e326]:
                      - columnheader "Run" [ref=e327]
                      - columnheader "Kind" [ref=e328]
                      - columnheader "Status" [ref=e329]
                      - columnheader "Attempts" [ref=e330]
                      - columnheader "Session" [ref=e331]
                      - columnheader "Created" [ref=e332]
                  - rowgroup [ref=e333]:
                    - 'row "run-0001 Rule Pending 1 / 3 Session: 11111111-1111-4111-8111-111111111111 8/23/2026, 9:00:00 AM" [ref=e334]':
                      - cell "run-0001" [ref=e335]:
                        - code [ref=e336]: run-0001
                      - cell "Rule" [ref=e337]
                      - cell "Pending" [ref=e338]:
                        - generic [ref=e339]: Pending
                      - cell "1 / 3" [ref=e340]
                      - 'cell "Session: 11111111-1111-4111-8111-111111111111" [ref=e341]':
                        - 'link "Session: 11111111-1111-4111-8111-111111111111" [ref=e342] [cursor=pointer]':
                          - /url: /agent-sessions/11111111-1111-4111-8111-111111111111
                          - code [ref=e343]: "11111111"
                      - cell "8/23/2026, 9:00:00 AM" [ref=e344]:
                        - time [ref=e345]: 8/23/2026, 9:00:00 AM
                    - row "run-0002 Rule Claimed 1 / 3 — 8/23/2026, 9:00:00 AM" [ref=e346]:
                      - cell "run-0002" [ref=e347]:
                        - code [ref=e348]: run-0002
                      - cell "Rule" [ref=e349]
                      - cell "Claimed" [ref=e350]:
                        - generic [ref=e351]: Claimed
                      - cell "1 / 3" [ref=e352]
                      - cell "—" [ref=e353]
                      - cell "8/23/2026, 9:00:00 AM" [ref=e354]:
                        - time [ref=e355]: 8/23/2026, 9:00:00 AM
                    - row "run-0003 Rule Running 1 / 3 — 8/23/2026, 9:00:00 AM" [ref=e356]:
                      - cell "run-0003" [ref=e357]:
                        - code [ref=e358]: run-0003
                      - cell "Rule" [ref=e359]
                      - cell "Running" [ref=e360]:
                        - generic [ref=e361]: Running
                      - cell "1 / 3" [ref=e362]
                      - cell "—" [ref=e363]
                      - cell "8/23/2026, 9:00:00 AM" [ref=e364]:
                        - time [ref=e365]: 8/23/2026, 9:00:00 AM
                    - row "run-0004 Rule Succeeded 1 / 3 — 8/23/2026, 9:00:00 AM" [ref=e366]:
                      - cell "run-0004" [ref=e367]:
                        - code [ref=e368]: run-0004
                      - cell "Rule" [ref=e369]
                      - cell "Succeeded" [ref=e370]:
                        - generic [ref=e371]: Succeeded
                      - cell "1 / 3" [ref=e372]
                      - cell "—" [ref=e373]
                      - cell "8/23/2026, 9:00:00 AM" [ref=e374]:
                        - time [ref=e375]: 8/23/2026, 9:00:00 AM
                    - row "run-0005 Rule Failed 3 / 3 — 8/23/2026, 9:00:00 AM" [ref=e376]:
                      - cell "run-0005" [ref=e377]:
                        - code [ref=e378]: run-0005
                      - cell "Rule" [ref=e379]
                      - cell "Failed" [ref=e380]:
                        - generic [ref=e381]: Failed
                      - cell "3 / 3" [ref=e382]
                      - cell "—" [ref=e383]
                      - cell "8/23/2026, 9:00:00 AM" [ref=e384]:
                        - time [ref=e385]: 8/23/2026, 9:00:00 AM
                    - row "Provider retry failed after the upstream execution service returned a deliberately long diagnostic summary that must wrap inside the local table without widening the page." [ref=e386]:
                      - cell "Provider retry failed after the upstream execution service returned a deliberately long diagnostic summary that must wrap inside the local table without widening the page." [ref=e387]:
                        - generic [ref=e388]: Provider retry failed after the upstream execution service returned a deliberately long diagnostic summary that must wrap inside the local table without widening the page.
                    - row "run-0006 Rule Dead 1 / 3 — 8/23/2026, 9:00:00 AM" [ref=e389]:
                      - cell "run-0006" [ref=e390]:
                        - code [ref=e391]: run-0006
                      - cell "Rule" [ref=e392]
                      - cell "Dead" [ref=e393]:
                        - generic [ref=e394]: Dead
                      - cell "1 / 3" [ref=e395]
                      - cell "—" [ref=e396]
                      - cell "8/23/2026, 9:00:00 AM" [ref=e397]:
                        - time [ref=e398]: 8/23/2026, 9:00:00 AM
                    - row "run-0007 Rule Canceled 1 / 3 — 8/23/2026, 9:00:00 AM" [ref=e399]:
                      - cell "run-0007" [ref=e400]:
                        - code [ref=e401]: run-0007
                      - cell "Rule" [ref=e402]
                      - cell "Canceled" [ref=e403]:
                        - generic [ref=e404]: Canceled
                      - cell "1 / 3" [ref=e405]
                      - cell "—" [ref=e406]
                      - cell "8/23/2026, 9:00:00 AM" [ref=e407]:
                        - time [ref=e408]: 8/23/2026, 9:00:00 AM
                    - row "run-0008 Dry run Dry run 1 / 3 — 8/23/2026, 9:00:00 AM" [ref=e409]:
                      - cell "run-0008" [ref=e410]:
                        - code [ref=e411]: run-0008
                      - cell "Dry run" [ref=e412]
                      - cell "Dry run" [ref=e413]:
                        - generic [ref=e414]: Dry run
                      - cell "1 / 3" [ref=e415]
                      - cell "—" [ref=e416]
                      - cell "8/23/2026, 9:00:00 AM" [ref=e417]:
                        - time [ref=e418]: 8/23/2026, 9:00:00 AM
            - generic [ref=e419]:
              - heading "Templates & playbooks" [level=2] [ref=e420]
              - generic [ref=e421]:
                - generic [ref=e422]:
                  - strong [ref=e423]: Issue starter
                  - generic [ref=e424]: Work item · v1 · Draft
                - generic [ref=e425]:
                  - strong [ref=e426]: Project launch
                  - generic [ref=e427]: Project · v2 · Active
                - generic [ref=e428]:
                  - strong [ref=e429]: Agent recovery
                  - generic [ref=e430]: Agent run · v3 · Archived
                - generic [ref=e431]:
                  - strong [ref=e432]: Incident handoff
                  - generic [ref=e433]: Handoff · v1 · Active
                - generic [ref=e434]:
                  - strong [ref=e435]: Automation bootstrap
                  - generic [ref=e436]: Automation · v1 · Draft
```

# Test source

```ts
  1187 |   })
  1188 | 
  1189 |   const geometries: Awaited<ReturnType<typeof measureDeleteTeamDialogGeometry>>[] = []
  1190 |   await page.setViewportSize({ width: 1920, height: 1080 })
  1191 |   await page.goto(`/settings?team=${encodeURIComponent(target.id)}&x=keep#team-settings-heading`)
  1192 |   await page.getByRole('button', { name: 'Delete team', exact: true }).click()
  1193 |   let dialog = page.getByRole('dialog', { name: 'Delete Team' })
  1194 |   const wideGeometry = await measureDeleteTeamDialogGeometry(page)
  1195 |   geometries.push(wideGeometry)
  1196 |   expect(wideGeometry.document.scrollWidth).toBe(wideGeometry.document.clientWidth)
  1197 |   expect(wideGeometry.dialog.width).toBeLessThanOrEqual(560)
  1198 |   expect(wideGeometry.centeredDelta).toBeLessThanOrEqual(2)
  1199 |   expect(wideGeometry.overflowCount).toBe(0)
  1200 |   await removeNextDevelopmentIndicatorForEvidence(page)
  1201 |   const wideScreenshotPath = testInfo.outputPath('task-5.4-delete-dialog-wide-pass.png')
  1202 |   await page.screenshot({ path: wideScreenshotPath })
  1203 |   await testInfo.attach('task-5.4-delete-dialog-wide-pass', { contentType: 'image/png', path: wideScreenshotPath })
  1204 | 
  1205 |   const confirm = dialog.getByRole('button', { name: 'Delete Team Runtime Reliability' })
  1206 |   await confirm.click()
  1207 |   await expect.poll(() => requestEvidence.length).toBe(1)
  1208 |   await expect(dialog.getByRole('status')).toHaveText('Deleting…')
  1209 |   await expect(dialog).toBeFocused()
  1210 |   await expect(dialog.getByRole('button', { name: 'Close Delete Team' })).toHaveCount(0)
  1211 |   await page.keyboard.press('Escape')
  1212 |   await expect(dialog).toBeVisible()
  1213 |   await dialog.locator('..').dispatchEvent('mousedown')
  1214 |   await expect(dialog).toBeVisible()
  1215 |   await page.keyboard.press('Tab')
  1216 |   await expect(dialog).toBeFocused()
  1217 |   await page.keyboard.press('Shift+Tab')
  1218 |   await expect(dialog).toBeFocused()
  1219 |   await confirm.evaluate(element => {
  1220 |     if (!(element instanceof HTMLButtonElement)) throw new Error('Delete confirmation button missing')
  1221 |     element.click()
  1222 |     element.dispatchEvent(new KeyboardEvent('keydown', { bubbles: true, key: 'Enter' }))
  1223 |     element.dispatchEvent(new KeyboardEvent('keydown', { bubbles: true, key: ' ' }))
  1224 |   })
  1225 |   expect(requestEvidence).toHaveLength(1)
  1226 | 
  1227 |   await page.evaluate(survivingTeamId => {
  1228 |     const selector = [...document.querySelectorAll<HTMLSelectElement>('.team-switcher select')]
  1229 |       .find(element => element.getBoundingClientRect().width > 0)
  1230 |     if (!selector) throw new Error('Visible Team selector missing')
  1231 |     selector.value = survivingTeamId
  1232 |     selector.dispatchEvent(new Event('change', { bubbles: true }))
  1233 |   }, survivor.id)
  1234 |   await expect(page).toHaveURL(new RegExp(`team=${survivor.id}`))
  1235 |   statePaths.length = 0
  1236 |   releaseDelete.resolve()
  1237 |   await expect(dialog).toHaveCount(0)
  1238 |   const desktopSelector = page.getByRole('combobox', { name: 'Current team' })
  1239 |   await expect(desktopSelector).toHaveValue(survivor.id)
  1240 |   await expect(desktopSelector).toBeFocused()
  1241 |   expect(statePaths).not.toContain('/api/v1/teams/team%2Fdelete-me/states')
  1242 |   await expect(page).toHaveURL(`${webUrl}/settings?team=${survivor.id}&x=keep#team-settings-heading`)
  1243 | 
  1244 |   deleted = false
  1245 |   targetRevision = 12
  1246 |   releaseDelete = deferred()
  1247 |   await page.setViewportSize({ width: 390, height: 844 })
  1248 |   await page.goto(`/settings?team=${encodeURIComponent(target.id)}&x=keep#team-settings-heading`)
  1249 |   await expect(page.locator('.mobile-navigation')).not.toHaveAttribute('open', '')
  1250 |   await page.getByRole('button', { name: 'Delete team', exact: true }).click()
  1251 |   dialog = page.getByRole('dialog', { name: 'Delete Team' })
  1252 |   const narrowGeometry = await measureDeleteTeamDialogGeometry(page)
  1253 |   geometries.push(narrowGeometry)
  1254 |   expect(narrowGeometry.document.scrollWidth).toBe(narrowGeometry.document.clientWidth)
  1255 |   expect(narrowGeometry.dialog.width).toBe(390)
  1256 |   await dialog.getByRole('button', { name: 'Delete Team Runtime Reliability' }).click()
  1257 |   await expect.poll(() => requestEvidence.length).toBe(2)
  1258 |   releaseDelete.resolve()
  1259 |   await expect(dialog).toHaveCount(0)
  1260 |   await expect(page).toHaveURL(`${webUrl}/settings?team=${survivor.id}&x=keep#team-settings-heading`)
  1261 |   const teamsHeading = page.getByRole('heading', { name: 'Teams' })
  1262 |   await expect(teamsHeading).toBeFocused()
  1263 |   await expect(page.locator('.mobile-navigation')).not.toHaveAttribute('open', '')
  1264 |   await expect(page.locator('.team-switcher select:focus')).toHaveCount(0)
  1265 | 
  1266 |   expect(requestEvidence).toEqual([
  1267 |     { bodyLength: 0, count: 1, differentFromPrevious: null, idempotencyKeyPresent: true, ifMatch: '"revision-11"', path: '/api/v1/teams/team%2Fdelete-me' },
  1268 |     { bodyLength: 0, count: 2, differentFromPrevious: true, idempotencyKeyPresent: true, ifMatch: '"revision-12"', path: '/api/v1/teams/team%2Fdelete-me' },
  1269 |   ])
  1270 |   const evidencePath = testInfo.outputPath('task-5.4-delete-dialog-success-request-geometry-pass.json')
  1271 |   await writeFile(evidencePath, JSON.stringify({ geometries, requests: requestEvidence }, null, 2), 'utf8')
  1272 |   await testInfo.attach('task-5.4-delete-dialog-success-request-geometry-pass', { contentType: 'application/json', path: evidencePath })
  1273 | })
  1274 | 
  1275 | test('keeps all-enabled navigation wide, sticky, focus-owned, and shared with Settings', async ({ page }) => {
  1276 |   test.info().annotations.push({ type: 'viewport', description: '1920x1080 wide-PC acceptance' })
  1277 |   await page.setViewportSize({ width: 1920, height: 1080 })
  1278 |   await installOperationsRoutes(page, () => allOperationsFeatures)
  1279 |   expect(canonicalFeatures).toHaveLength(12)
  1280 | 
  1281 |   await page.goto('/operations')
  1282 |   await expectWideNavigation(page)
  1283 | 
  1284 |   const standaloneNavigation = page.getByTestId('operations-section-navigation')
  1285 |   await standaloneNavigation.evaluate(element => element.scrollIntoView({ block: 'start' }))
  1286 |   await page.evaluate(() => window.scrollBy(0, 160))
> 1287 |   await expect.poll(async () => Math.round((await standaloneNavigation.boundingBox())?.y ?? -1)).toBe(48)
       |                                                                                                  ^ Error: expect(received).toBe(expected) // Object.is equality
  1288 | 
  1289 |   await page.goto('/settings?tab=operations')
  1290 |   await expectWideNavigation(page)
  1291 |   await expect(page).toHaveURL(/tab=operations.*#operations-runs$/)
  1292 | })
  1293 | 
  1294 | test('keeps a deferred collection in loading state until its first loaded page arrives', async ({ page }) => {
  1295 |   const cycles = deferred()
  1296 |   await installOperationsRoutes(page, () => allOperationsFeatures, {
  1297 |     collectionDeferred: { '/api/v1/cycles': cycles.promise },
  1298 |   })
  1299 |   await page.goto('/operations?opsQuery=Current')
  1300 | 
  1301 |   const panel = page.getByTestId('cycles-panel')
  1302 |   await expect(panel.getByRole('status', { name: 'Loading Cycles' })).toBeVisible()
  1303 |   await expect(panel.getByRole('heading', { name: 'No Cycles configured' })).toHaveCount(0)
  1304 |   cycles.resolve()
  1305 |   await expect(panel.getByText('Nightly planning')).toBeVisible()
  1306 | })
  1307 | 
  1308 | test('renders successful exhausted collections as server-empty rather than loading or client no-match', async ({ context }) => {
  1309 |   const page = await context.newPage()
  1310 |   const requestLog: string[] = []
  1311 |   try {
  1312 |     await installOperationsRoutes(page, () => allOperationsFeatures, {
  1313 |       emptyCollections: collectionPaths,
  1314 |       requestLog,
  1315 |     })
  1316 |     await page.goto('/operations')
  1317 | 
  1318 |     const serverEmptyHeadings = [
  1319 |       ['cycles-panel', 'No Cycles configured'],
  1320 |       ['initiatives-panel', 'No Initiatives configured'],
  1321 |       ['automation-panel', 'No Rules configured'],
  1322 |       ['loops-panel', 'No Loops configured'],
  1323 |       ['runs-panel', 'No run history yet'],
  1324 |       ['templates-panel', 'No Templates configured'],
  1325 |     ] as const
  1326 |     for (const [panelId, heading] of serverEmptyHeadings) {
  1327 |       const panel = page.getByTestId(panelId)
  1328 |       await expect(panel.getByRole('heading', { name: heading }), `${panelId}: exhausted empty`).toBeVisible()
  1329 |       await expect(panel.getByRole('heading', { name: /^Loading / }), `${panelId}: not loading`).toHaveCount(0)
  1330 |       await expect(panel.getByRole('heading', { name: /^No loaded .* match$/ }), `${panelId}: not client no-match`).toHaveCount(0)
  1331 |     }
  1332 | 
  1333 |     const observedCollectionPaths = [...new Set(
  1334 |       requestLog
  1335 |         .map(value => new URL(value).pathname)
  1336 |         .filter(path => collectionPathSet.has(path)),
  1337 |     )].sort()
  1338 |     expect(observedCollectionPaths).toEqual([...collectionPaths].sort())
  1339 |     expect(requestLog.every(value => !new URL(value).searchParams.has('opsQuery'))).toBe(true)
  1340 |   } finally {
  1341 |     await page.close()
  1342 |   }
  1343 | })
  1344 | 
  1345 | test('filters only loaded localized values, keeps metrics and pagination, and restores the same-tab URL', async ({ page }) => {
  1346 |   const requestLog: string[] = []
  1347 |   await installOperationsRoutes(page, () => allOperationsFeatures, { paginatedRuns: true, requestLog })
  1348 |   await page.goto('/operations?context=keep#operations-runs')
  1349 |   const search = page.getByRole('searchbox', { name: 'Search loaded Operations records' })
  1350 |   await expect(search).toBeVisible()
  1351 |   await page.evaluate(() => window.history.replaceState({ ...window.history.state, task42: 'keep' }, '', window.location.href))
  1352 | 
  1353 |   await search.fill('Current')
  1354 |   await expect(page.getByTestId('cycles-panel').getByText('Nightly planning')).toBeVisible()
  1355 |   await expect(page.locator('#operations-metrics')).toBeVisible()
  1356 |   await expect(page.locator('#operations-metrics')).toContainText('Tokens')
  1357 |   expect(await page.evaluate(() => window.history.state.task42)).toBe('keep')
  1358 |   expect(new URL(page.url()).searchParams.get('context')).toBe('keep')
  1359 |   expect(new URL(page.url()).hash).toBe('#operations-runs')
  1360 | 
  1361 |   await search.fill('On track')
  1362 |   await expect(page.getByTestId('initiatives-panel').getByText('Runtime reliability')).toBeVisible()
  1363 |   await search.fill('on_track')
  1364 |   await expect(page.getByTestId('initiatives-panel').getByText('Runtime reliability')).toHaveCount(0)
  1365 | 
  1366 |   await search.fill('Webhook retry')
  1367 |   await expect(page.getByTestId('automation-panel').getByText('Webhook retry')).toBeVisible()
  1368 |   await expect(page.getByTestId('automation-panel')).toContainText('Disabled')
  1369 |   await search.fill('schedule 0 2 * * *')
  1370 |   await expect(page.getByTestId('automation-panel').getByText('Webhook retry')).toBeVisible()
  1371 |   await expect(page.getByTestId('automation-panel')).toContainText('v1 · schedule 0 2 * * *')
  1372 |   await search.fill('Release guard')
  1373 |   await expect(page.getByTestId('loops-panel').getByText('Release guard')).toBeVisible()
  1374 |   await expect(page.getByTestId('loops-panel')).toContainText('No overlap')
  1375 | 
  1376 |   await search.fill('Dry run')
  1377 |   await expect(page.getByTestId('runs-panel').getByText('run-0008')).toBeVisible()
  1378 |   await search.fill('dry_run')
  1379 |   await expect(page.getByTestId('runs-panel').getByText('run-0008')).toHaveCount(0)
  1380 | 
  1381 |   await search.fill('Agent run')
  1382 |   await expect(page.getByTestId('templates-panel').getByText('Agent recovery')).toBeVisible()
  1383 |   await search.fill('agent_run')
  1384 |   await expect(page.getByTestId('templates-panel').getByText('Agent recovery')).toHaveCount(0)
  1385 | 
  1386 |   await search.fill('Delayed retry queue exhausted')
  1387 |   await expect(page.getByTestId('runs-panel').getByRole('heading', { name: 'No loaded Recent runs match' })).toBeVisible()
```