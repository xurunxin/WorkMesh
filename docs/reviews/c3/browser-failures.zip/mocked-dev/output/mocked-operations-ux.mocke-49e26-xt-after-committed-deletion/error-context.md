# Instructions

- Following Playwright test failed.
- Explain why, be concise, respect Playwright best practices.
- Provide a snippet of code with the fix, if possible.

# Test info

- Name: mocked\operations-ux.mocked.spec.ts >> blocks busy destructive interaction and focuses a surviving context after committed deletion
- Location: e2e\mocked\operations-ux.mocked.spec.ts:1137:1

# Error details

```
Error: expect(received).toBe(expected) // Object.is equality

Expected: 0
Received: 3
```

# Page snapshot

```yaml
- generic [ref=e1]:
  - button "Open Next.js Dev Tools" [ref=e7] [cursor=pointer]:
    - img [ref=e8]
  - alert [ref=e11]
  - generic [ref=e12]:
    - link "Skip to content" [ref=e13] [cursor=pointer]:
      - /url: "#workmesh-main"
    - complementary "Main navigation" [ref=e14]:
      - generic [ref=e15]:
        - strong [ref=e17]: WorkMesh
        - generic [ref=e18]: Alex Morgan
      - button "Collapse sidebar" [expanded] [ref=e19] [cursor=pointer]:
        - img [ref=e20]
        - generic [ref=e22]: Collapse sidebar
      - generic [ref=e24]:
        - text: Team
        - combobox "Current team" [ref=e25]:
          - option "No team" [disabled]
          - option "Runtime Reliability (RUN)" [selected]
          - option "Platform (PLAT)"
      - navigation "Workspace navigation" [ref=e26]:
        - link "Back to Issues" [ref=e27] [cursor=pointer]:
          - /url: /?view=my-work
          - img [ref=e29]
          - generic [ref=e31]: Back to Issues
      - navigation "Administration navigation" [ref=e32]:
        - link "Settings" [ref=e33] [cursor=pointer]:
          - /url: /settings
          - img [ref=e35]
          - generic [ref=e37]: Settings
      - generic [ref=e39]:
        - button "Sign out" [ref=e40] [cursor=pointer]:
          - img [ref=e42]
          - generic [ref=e44]: Sign out
        - generic [ref=e45]: v1.0.0 · build project-work-preview · schema 24
    - generic [ref=e46]:
      - banner [ref=e47]:
        - paragraph [ref=e48]:
          - generic [ref=e49]: Workspace
        - button "Search" [ref=e51] [cursor=pointer]:
          - img [ref=e53]
          - generic [ref=e55]:
            - generic [ref=e56]: Search
            - generic [ref=e57]: Ctrl K
        - generic [ref=e58]:
          - button "Switch to the light theme" [ref=e59]:
            - img [ref=e60]
          - group "Language" [ref=e63]:
            - button "中" [ref=e64]
            - button "EN" [pressed] [ref=e65]
      - main [ref=e66]:
        - generic [ref=e67]:
          - generic [ref=e69]:
            - heading "Settings" [level=1] [ref=e70]
            - paragraph [ref=e71]: Workspace administration stays separate from daily planning.
          - generic [ref=e72]:
            - tablist "Settings sections" [ref=e73]:
              - tab "Workspace" [selected] [ref=e74]:
                - generic [ref=e75]: Workspace
            - tabpanel "Workspace" [ref=e76]:
              - generic [ref=e77]:
                - region "Teams" [ref=e78]:
                  - paragraph [ref=e79]: Workspace structure
                  - heading "Teams" [level=2] [ref=e80]
                  - generic [ref=e81]:
                    - generic [ref=e82]:
                      - text: Team name
                      - textbox "Team name" [ref=e83]
                    - generic [ref=e84]:
                      - text: Team key
                      - textbox "Team key" [ref=e85]:
                        - /placeholder: ENG
                    - button "Create team" [ref=e86] [cursor=pointer]:
                      - img [ref=e88]
                      - generic [ref=e90]: Create team
                - region "Team details" [ref=e91]:
                  - paragraph [ref=e92]: Selected team
                  - heading "Team details" [level=2] [ref=e93]
                  - generic [ref=e94]:
                    - generic [ref=e95]:
                      - text: Team name
                      - textbox "Team name" [ref=e96]: Runtime Reliability
                    - generic [ref=e97]:
                      - text: Team key
                      - textbox "Team key" [ref=e98]: RUN
                    - button "Save changes" [ref=e99] [cursor=pointer]:
                      - img [ref=e101]
                      - generic [ref=e103]: Save changes
                  - generic [ref=e104]:
                    - generic [ref=e105]:
                      - strong [ref=e106]: Delete team
                      - paragraph [ref=e107]: Remove this Team from active navigation; associated work is retained but unavailable.
                    - button "Delete team" [ref=e108] [cursor=pointer]:
                      - img [ref=e110]
                      - generic [ref=e112]: Delete team
                - region "Workflow states" [ref=e113]:
                  - paragraph [ref=e114]: Team workflow
                  - heading "Workflow states" [level=2] [ref=e115]
                  - article [ref=e117]:
                    - generic [ref=e120]:
                      - strong [ref=e121]: Ready
                      - generic [ref=e122]: Planned
                    - button "Edit status Ready" [ref=e123] [cursor=pointer]:
                      - img [ref=e125]
                      - generic [ref=e127]: Edit
                  - generic [ref=e128]:
                    - generic [ref=e129]:
                      - text: Status name
                      - textbox "Status name" [ref=e130]
                    - generic [ref=e131]:
                      - text: Category
                      - combobox "Category" [ref=e132]:
                        - option "Backlog"
                        - option "Planned" [selected]
                        - option "Started"
                        - option "Completed"
                        - option "Canceled"
                    - group "Status color" [ref=e133]:
                      - generic [ref=e134]: Status color
                      - generic [ref=e135]:
                        - generic [ref=e136] [cursor=pointer]:
                          - radio "Neutral" [checked] [ref=e137]
                          - generic [ref=e139]: Neutral
                        - generic [ref=e140] [cursor=pointer]:
                          - radio "Blue" [ref=e141]
                          - generic [ref=e143]: Blue
                        - generic [ref=e144] [cursor=pointer]:
                          - radio "Green" [ref=e145]
                          - generic [ref=e147]: Green
                        - generic [ref=e148] [cursor=pointer]:
                          - radio "Amber" [ref=e149]
                          - generic [ref=e151]: Amber
                        - generic [ref=e152] [cursor=pointer]:
                          - radio "Red" [ref=e153]
                          - generic [ref=e155]: Red
                        - generic [ref=e156] [cursor=pointer]:
                          - radio "Custom" [ref=e157]
                          - generic [ref=e159]: Custom
                    - button "Create status" [ref=e160] [cursor=pointer]:
                      - img [ref=e162]
                      - generic [ref=e164]: Create status
              - region "Model service connections" [ref=e165]:
                - paragraph [ref=e166]: Agent workbench
                - heading "Model service connections" [level=2] [ref=e167]
                - paragraph [ref=e168]: Manage Chat Completions and Responses providers, credentials, and models.
                - link "Open connection settings" [ref=e169] [cursor=pointer]:
                  - /url: /settings/agent-workbench
          - dialog "Delete Team" [ref=e171]:
            - generic [ref=e172]:
              - generic [ref=e173]:
                - heading "Delete Team" [level=2] [ref=e174]
                - paragraph [ref=e175]: This Team leaves active navigation; associated work is retained but unavailable.
              - button "Close Delete Team" [active] [ref=e176] [cursor=pointer]:
                - img [ref=e178]
                - generic [ref=e180]: Close
            - generic [ref=e182]:
              - generic [ref=e183]:
                - generic [ref=e184]:
                  - term [ref=e185]: Team name
                  - definition [ref=e186]: Runtime Reliability
                - generic [ref=e187]:
                  - term [ref=e188]: Team key
                  - definition [ref=e189]: RUN
              - paragraph [ref=e190]: At least one active Team must remain.
              - generic [ref=e191]:
                - button "Cancel" [ref=e192] [cursor=pointer]:
                  - generic [ref=e193]: Cancel
                - button "Delete Team Runtime Reliability" [ref=e194] [cursor=pointer]:
                  - generic [ref=e195]: Delete team
```

# Test source

```ts
  1099 | 
  1100 |   const dialogContent = dialog.locator('.ui-dialog-content')
  1101 |   await dialogContent.evaluate(element => { element.scrollTop = 0 })
  1102 |   const geometry = await measureDeleteTeamDialogGeometry(page)
  1103 |   expect(geometry.viewport).toEqual({ width: 390, height: 844 })
  1104 |   expect(geometry.document.scrollWidth).toBe(geometry.document.clientWidth)
  1105 |   expect(geometry.dialog.left).toBeGreaterThanOrEqual(-1)
  1106 |   expect(geometry.dialog.right).toBeLessThanOrEqual(391)
  1107 |   expect(geometry.dialog.height).toBe(844)
  1108 |   expect(geometry.contentScroll.scrollHeight).toBeGreaterThan(geometry.contentScroll.clientHeight)
  1109 |   await dialog.focus()
  1110 |   await removeNextDevelopmentIndicatorForEvidence(page)
  1111 |   const topScreenshotPath = testInfo.outputPath('task-5.4-delete-dialog-narrow-top-pass.png')
  1112 |   await page.screenshot({ path: topScreenshotPath })
  1113 |   await testInfo.attach('task-5.4-delete-dialog-narrow-top-pass', { contentType: 'image/png', path: topScreenshotPath })
  1114 |   const scrollMovement = await dialogContent.evaluate(element => {
  1115 |     const before = element.scrollTop
  1116 |     element.scrollTop = element.scrollHeight
  1117 |     return { after: element.scrollTop, before, maximum: element.scrollHeight - element.clientHeight }
  1118 |   })
  1119 |   expect(scrollMovement.before).toBe(0)
  1120 |   expect(scrollMovement.after).toBeGreaterThan(0)
  1121 |   expect(scrollMovement.after).toBe(scrollMovement.maximum)
  1122 |   await expect(dialog.getByRole('button', { name: 'Cancel' })).toBeInViewport()
  1123 |   expect(evidence).toEqual([
  1124 |     { bodyLength: 0, count: 1, idempotencyKeyPresent: true, ifMatch: '"revision-7"', path: '/api/v1/teams/team%2Fdelete-target', sameAsFirst: null },
  1125 |     { bodyLength: 0, count: 2, idempotencyKeyPresent: true, ifMatch: '"revision-7"', path: '/api/v1/teams/team%2Fdelete-target', sameAsFirst: true },
  1126 |     { bodyLength: 0, count: 3, idempotencyKeyPresent: true, ifMatch: '"revision-8"', path: '/api/v1/teams/team%2Fdelete-target', sameAsFirst: false },
  1127 |   ])
  1128 | 
  1129 |   const screenshotPath = testInfo.outputPath('task-5.4-delete-dialog-narrow-pass.png')
  1130 |   await page.screenshot({ path: screenshotPath })
  1131 |   await testInfo.attach('task-5.4-delete-dialog-narrow-pass', { contentType: 'image/png', path: screenshotPath })
  1132 |   const evidencePath = testInfo.outputPath('task-5.4-delete-dialog-retry-request-geometry-pass.json')
  1133 |   await writeFile(evidencePath, JSON.stringify({ geometry, requests: evidence, scrollMovement }, null, 2), 'utf8')
  1134 |   await testInfo.attach('task-5.4-delete-dialog-retry-request-geometry-pass', { contentType: 'application/json', path: evidencePath })
  1135 | })
  1136 | 
  1137 | test('blocks busy destructive interaction and focuses a surviving context after committed deletion', async ({ page }, testInfo) => {
  1138 |   const target = { id: 'team/delete-me', name: 'Runtime Reliability', key: 'RUN', revision: 11 } satisfies SettingsTeamFixture
  1139 |   const survivor = { id: 'team-survivor', name: 'Platform', key: 'PLAT', revision: 4 } satisfies SettingsTeamFixture
  1140 |   let deleted = false
  1141 |   let targetRevision = target.revision
  1142 |   let releaseDelete = deferred()
  1143 |   let lastPrivateKey = ''
  1144 |   const requestEvidence: Array<{
  1145 |     bodyLength: number
  1146 |     count: number
  1147 |     differentFromPrevious: boolean | null
  1148 |     idempotencyKeyPresent: boolean
  1149 |     ifMatch: string | undefined
  1150 |     path: string
  1151 |   }> = []
  1152 |   const statePaths: string[] = []
  1153 |   page.on('request', request => {
  1154 |     const path = new URL(request.url()).pathname
  1155 |     if (request.method() === 'GET' && /^\/api\/v1\/teams\/[^/]+\/states$/.test(path)) statePaths.push(path)
  1156 |   })
  1157 |   const dynamicTarget: SettingsTeamFixture = {
  1158 |     ...target,
  1159 |     get revision() { return targetRevision },
  1160 |   }
  1161 |   const pages = {
  1162 |     get first(): SettingsTeamPageFixture {
  1163 |       return { items: deleted ? [survivor] : [dynamicTarget, survivor], nextCursor: null }
  1164 |     },
  1165 |   }
  1166 |   await installOperationsRoutes(page, () => allOperationsFeatures, {
  1167 |     settingsDelete: async request => {
  1168 |       const key = request.headers()['idempotency-key'] ?? ''
  1169 |       requestEvidence.push({
  1170 |         bodyLength: request.postDataBuffer()?.byteLength ?? 0,
  1171 |         count: requestEvidence.length + 1,
  1172 |         differentFromPrevious: requestEvidence.length === 0 ? null : key !== lastPrivateKey,
  1173 |         idempotencyKeyPresent: key.length > 0,
  1174 |         ifMatch: request.headers()['if-match'],
  1175 |         path: new URL(request.url()).pathname,
  1176 |       })
  1177 |       lastPrivateKey = key
  1178 |       await releaseDelete.promise
  1179 |       deleted = true
  1180 |       return { status: 204 }
  1181 |     },
  1182 |     settingsStates: {
  1183 |       [target.id]: [{ id: 'state-target', name: 'Ready', category: 'planned', color: '#64748b', revision: 1 }],
  1184 |       [survivor.id]: [{ id: 'state-survivor', name: 'Ready', category: 'planned', color: '#64748b', revision: 1 }],
  1185 |     },
  1186 |     settingsTeamPages: pages,
  1187 |   })
  1188 | 
  1189 |   const geometries: Awaited<ReturnType<typeof measureDeleteTeamDialogGeometry>>[] = []
  1190 |   await page.setViewportSize({ width: 1920, height: 1080 })
  1191 |   await page.goto(`/settings?team=${encodeURIComponent(target.id)}&x=keep#team-settings-heading`)
  1192 |   await page.getByRole('button', { name: 'Delete team', exact: true }).click()
  1193 |   let dialog = page.getByRole('dialog', { name: 'Delete Team' })
  1194 |   const wideGeometry = await measureDeleteTeamDialogGeometry(page)
  1195 |   geometries.push(wideGeometry)
  1196 |   expect(wideGeometry.document.scrollWidth).toBe(wideGeometry.document.clientWidth)
  1197 |   expect(wideGeometry.dialog.width).toBeLessThanOrEqual(560)
  1198 |   expect(wideGeometry.centeredDelta).toBeLessThanOrEqual(2)
> 1199 |   expect(wideGeometry.overflowCount).toBe(0)
       |                                      ^ Error: expect(received).toBe(expected) // Object.is equality
  1200 |   await removeNextDevelopmentIndicatorForEvidence(page)
  1201 |   const wideScreenshotPath = testInfo.outputPath('task-5.4-delete-dialog-wide-pass.png')
  1202 |   await page.screenshot({ path: wideScreenshotPath })
  1203 |   await testInfo.attach('task-5.4-delete-dialog-wide-pass', { contentType: 'image/png', path: wideScreenshotPath })
  1204 | 
  1205 |   const confirm = dialog.getByRole('button', { name: 'Delete Team Runtime Reliability' })
  1206 |   await confirm.click()
  1207 |   await expect.poll(() => requestEvidence.length).toBe(1)
  1208 |   await expect(dialog.getByRole('status')).toHaveText('Deleting…')
  1209 |   await expect(dialog).toBeFocused()
  1210 |   await expect(dialog.getByRole('button', { name: 'Close Delete Team' })).toHaveCount(0)
  1211 |   await page.keyboard.press('Escape')
  1212 |   await expect(dialog).toBeVisible()
  1213 |   await dialog.locator('..').dispatchEvent('mousedown')
  1214 |   await expect(dialog).toBeVisible()
  1215 |   await page.keyboard.press('Tab')
  1216 |   await expect(dialog).toBeFocused()
  1217 |   await page.keyboard.press('Shift+Tab')
  1218 |   await expect(dialog).toBeFocused()
  1219 |   await confirm.evaluate(element => {
  1220 |     if (!(element instanceof HTMLButtonElement)) throw new Error('Delete confirmation button missing')
  1221 |     element.click()
  1222 |     element.dispatchEvent(new KeyboardEvent('keydown', { bubbles: true, key: 'Enter' }))
  1223 |     element.dispatchEvent(new KeyboardEvent('keydown', { bubbles: true, key: ' ' }))
  1224 |   })
  1225 |   expect(requestEvidence).toHaveLength(1)
  1226 | 
  1227 |   await page.evaluate(survivingTeamId => {
  1228 |     const selector = [...document.querySelectorAll<HTMLSelectElement>('.team-switcher select')]
  1229 |       .find(element => element.getBoundingClientRect().width > 0)
  1230 |     if (!selector) throw new Error('Visible Team selector missing')
  1231 |     selector.value = survivingTeamId
  1232 |     selector.dispatchEvent(new Event('change', { bubbles: true }))
  1233 |   }, survivor.id)
  1234 |   await expect(page).toHaveURL(new RegExp(`team=${survivor.id}`))
  1235 |   statePaths.length = 0
  1236 |   releaseDelete.resolve()
  1237 |   await expect(dialog).toHaveCount(0)
  1238 |   const desktopSelector = page.getByRole('combobox', { name: 'Current team' })
  1239 |   await expect(desktopSelector).toHaveValue(survivor.id)
  1240 |   await expect(desktopSelector).toBeFocused()
  1241 |   expect(statePaths).not.toContain('/api/v1/teams/team%2Fdelete-me/states')
  1242 |   await expect(page).toHaveURL(`${webUrl}/settings?team=${survivor.id}&x=keep#team-settings-heading`)
  1243 | 
  1244 |   deleted = false
  1245 |   targetRevision = 12
  1246 |   releaseDelete = deferred()
  1247 |   await page.setViewportSize({ width: 390, height: 844 })
  1248 |   await page.goto(`/settings?team=${encodeURIComponent(target.id)}&x=keep#team-settings-heading`)
  1249 |   await expect(page.locator('.mobile-navigation')).not.toHaveAttribute('open', '')
  1250 |   await page.getByRole('button', { name: 'Delete team', exact: true }).click()
  1251 |   dialog = page.getByRole('dialog', { name: 'Delete Team' })
  1252 |   const narrowGeometry = await measureDeleteTeamDialogGeometry(page)
  1253 |   geometries.push(narrowGeometry)
  1254 |   expect(narrowGeometry.document.scrollWidth).toBe(narrowGeometry.document.clientWidth)
  1255 |   expect(narrowGeometry.dialog.width).toBe(390)
  1256 |   await dialog.getByRole('button', { name: 'Delete Team Runtime Reliability' }).click()
  1257 |   await expect.poll(() => requestEvidence.length).toBe(2)
  1258 |   releaseDelete.resolve()
  1259 |   await expect(dialog).toHaveCount(0)
  1260 |   await expect(page).toHaveURL(`${webUrl}/settings?team=${survivor.id}&x=keep#team-settings-heading`)
  1261 |   const teamsHeading = page.getByRole('heading', { name: 'Teams' })
  1262 |   await expect(teamsHeading).toBeFocused()
  1263 |   await expect(page.locator('.mobile-navigation')).not.toHaveAttribute('open', '')
  1264 |   await expect(page.locator('.team-switcher select:focus')).toHaveCount(0)
  1265 | 
  1266 |   expect(requestEvidence).toEqual([
  1267 |     { bodyLength: 0, count: 1, differentFromPrevious: null, idempotencyKeyPresent: true, ifMatch: '"revision-11"', path: '/api/v1/teams/team%2Fdelete-me' },
  1268 |     { bodyLength: 0, count: 2, differentFromPrevious: true, idempotencyKeyPresent: true, ifMatch: '"revision-12"', path: '/api/v1/teams/team%2Fdelete-me' },
  1269 |   ])
  1270 |   const evidencePath = testInfo.outputPath('task-5.4-delete-dialog-success-request-geometry-pass.json')
  1271 |   await writeFile(evidencePath, JSON.stringify({ geometries, requests: requestEvidence }, null, 2), 'utf8')
  1272 |   await testInfo.attach('task-5.4-delete-dialog-success-request-geometry-pass', { contentType: 'application/json', path: evidencePath })
  1273 | })
  1274 | 
  1275 | test('keeps all-enabled navigation wide, sticky, focus-owned, and shared with Settings', async ({ page }) => {
  1276 |   test.info().annotations.push({ type: 'viewport', description: '1920x1080 wide-PC acceptance' })
  1277 |   await page.setViewportSize({ width: 1920, height: 1080 })
  1278 |   await installOperationsRoutes(page, () => allOperationsFeatures)
  1279 |   expect(canonicalFeatures).toHaveLength(12)
  1280 | 
  1281 |   await page.goto('/operations')
  1282 |   await expectWideNavigation(page)
  1283 | 
  1284 |   const standaloneNavigation = page.getByTestId('operations-section-navigation')
  1285 |   await standaloneNavigation.evaluate(element => element.scrollIntoView({ block: 'start' }))
  1286 |   await page.evaluate(() => window.scrollBy(0, 160))
  1287 |   await expect.poll(async () => Math.round((await standaloneNavigation.boundingBox())?.y ?? -1)).toBe(48)
  1288 | 
  1289 |   await page.goto('/settings?tab=operations')
  1290 |   await expectWideNavigation(page)
  1291 |   await expect(page).toHaveURL(/tab=operations.*#operations-runs$/)
  1292 | })
  1293 | 
  1294 | test('keeps a deferred collection in loading state until its first loaded page arrives', async ({ page }) => {
  1295 |   const cycles = deferred()
  1296 |   await installOperationsRoutes(page, () => allOperationsFeatures, {
  1297 |     collectionDeferred: { '/api/v1/cycles': cycles.promise },
  1298 |   })
  1299 |   await page.goto('/operations?opsQuery=Current')
```