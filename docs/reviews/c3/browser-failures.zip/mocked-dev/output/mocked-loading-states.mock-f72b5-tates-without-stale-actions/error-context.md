# Instructions

- Following Playwright test failed.
- Explain why, be concise, respect Playwright best practices.
- Provide a snippet of code with the fix, if possible.

# Test info

- Name: mocked\loading-states.mocked.spec.ts >> Task 6.4 Agent secondary surfaces >> owns Sessions, Diagnostics, Connections and Approval states without stale actions
- Location: e2e\mocked\loading-states.mocked.spec.ts:539:3

# Error details

```
Error: expect(locator).toBeVisible() failed

Locator: getByRole('region', { name: 'Connections', exact: true }).locator('.skeleton-list')
Expected: visible
Timeout: 10000ms
Error: element(s) not found

Call log:
  - Expect "toBeVisible" with timeout 10000ms
  - waiting for getByRole('region', { name: 'Connections', exact: true }).locator('.skeleton-list')

```

```yaml
- alert
- link "Skip to content":
  - /url: "#workmesh-main"
- complementary "Main navigation":
  - strong: WorkMesh
  - text: Alex Morgan
  - button "Collapse sidebar" [expanded]
  - navigation "Workspace navigation":
    - paragraph: Workbench
    - link "Workbench":
      - /url: /workbench
    - link "My work":
      - /url: /?view=home
    - link "Issues":
      - /url: /?view=my-work
    - link "Guidance":
      - /url: /?view=guidance
    - paragraph: Governance
    - link "Needs You":
      - /url: /?view=inbox
    - link "Session":
      - /url: /?view=sessions
    - link "Recovery":
      - /url: /?view=recovery
    - link "Projects":
      - /url: /?view=projects
    - link "Agents":
      - /url: /agents
    - paragraph: Operations
    - link "Operations":
      - /url: /operations
  - navigation "Administration navigation":
    - link "Settings":
      - /url: /settings
  - button "Sign out"
  - text: v1.0.0 · build loading-state-fixture · schema 24
- banner:
  - paragraph: Human control plane
  - button "Search": Search Ctrl K
  - button "Switch to the light theme"
  - group "Language":
    - button "中"
    - button "EN" [pressed]
  - text: Reconnecting
- main:
  - paragraph: Human control plane
  - heading "Agents" [level=1]
  - paragraph: Monitor delegated work, respond to approvals, and diagnose Connections without handling credentials.
  - button "Refresh"
  - alert:
    - heading "Agent workspace needs attention" [level=2]
    - paragraph: "[ { \"code\": \"invalid_type\", \"expected\": \"string\", \"received\": \"undefined\", \"path\": [ \"icon\" ], \"message\": \"Required\" }, { \"code\": \"invalid_type\", \"expected\": \"string\", \"received\": \"undefined\", \"path\": [ \"endpoint_url\" ], \"message\": \"Required\" }, { \"code\": \"invalid_type\", \"expected\": \"array\", \"received\": \"undefined\", \"path\": [ \"output_artifact_types\" ], \"message\": \"Required\" }, { \"code\": \"invalid_type\", \"expected\": \"object\", \"received\": \"undefined\", \"path\": [ \"metadata\" ], \"message\": \"Required\" }, { \"expected\": \"'active' | 'archived'\", \"received\": \"undefined\", \"code\": \"invalid_type\", \"path\": [ \"lifecycle_status\" ], \"message\": \"Required\" }, { \"code\": \"invalid_type\", \"expected\": \"string\", \"received\": \"undefined\", \"path\": [ \"archived_at\" ], \"message\": \"Required\" }, { \"code\": \"invalid_type\", \"expected\": \"string\", \"received\": \"undefined\", \"path\": [ \"archived_by_actor_id\" ], \"message\": \"Required\" }, { \"code\": \"invalid_type\", \"expected\": \"string\", \"received\": \"undefined\", \"path\": [ \"archived_reason\" ], \"message\": \"Required\" }, { \"code\": \"invalid_type\", \"expected\": \"string\", \"received\": \"undefined\", \"path\": [ \"created_at\" ], \"message\": \"Required\" }, { \"code\": \"invalid_type\", \"expected\": \"string\", \"received\": \"undefined\", \"path\": [ \"updated_at\" ], \"message\": \"Required\" } ]"
    - button "Retry"
  - tablist "Agent workspace sections":
    - tab "Agents"
    - tab "Sessions" [selected]
    - tab "Connections"
    - tab "Auto enrollment"
    - tab "Archived"
  - tabpanel "Sessions":
    - region "Sessions":
      - paragraph: Execution
      - heading "Sessions" [level=2]
      - status "Loading Agent workspace"
    - region "Diagnostics":
      - paragraph: Durable state
      - heading "Diagnostics" [level=2]
      - status "Loading Agent workspace"
```

# Test source

```ts
  466 |     await expect(page.getByText('safe-team-initial')).toHaveCount(0)
  467 | 
  468 |     routes.setRequest('GET', teamsPath, { body: { items: [], nextCursor: null } })
  469 |     await page.reload({ waitUntil: 'domcontentloaded' })
  470 |     await expect(content.locator('.empty')).toContainText('No team')
  471 |     await expect(content.getByRole('alert')).toHaveCount(0)
  472 |     await expect(content.locator('.skeleton-list')).toHaveCount(0)
  473 |     await expect(page.getByTestId('work-surfaces')).toHaveCount(0)
  474 |     expect(routes.requests.some(request => request.startsWith('/api/v1/work-items'))).toBe(false)
  475 |     expect(routes.requests.some(request => request.includes('/states'))).toBe(false)
  476 | 
  477 |     await page.goto('/settings?tab=workspace', { waitUntil: 'domcontentloaded' })
  478 |     await expect(page.locator('.settings-loading-skeleton')).toHaveCount(0)
  479 |     await expect(page.getByRole('option', { name: /No team/i })).toHaveCount(1)
  480 |     await expect(page.locator('[aria-labelledby="workflow-settings-heading"] .skeleton-list')).toHaveCount(0)
  481 |     expect(routes.requests.some(request => request.includes('/states'))).toBe(false)
  482 |     expect(routes.unexpected).toEqual([])
  483 |   })
  484 | })
  485 | 
  486 | test.describe('Task 6.4 Agents loading authority', () => {
  487 |   test.use({ viewport: { height: 900, width: 1440 } })
  488 | 
  489 |   test('keeps Registry authority and focus independent through a failed refresh', async ({ page }) => {
  490 |     const routes = new RouteScenarios()
  491 |     await routes.install(page)
  492 |     await page.context().addCookies([{ name: 'workmesh_locale', value: 'en', url: webUrl }])
  493 | 
  494 |     const agentsPending = deferredResponse()
  495 |     routes.set('/api/v1/agents', agentsPending.promise)
  496 |     await page.goto('/agents?tab=agents', { waitUntil: 'domcontentloaded' })
  497 | 
  498 |     const registry = page.locator('.agent-registry')
  499 |     await expect(registry.locator('.skeleton-list')).toBeVisible()
  500 |     await expect(registry).not.toHaveAttribute('aria-busy')
  501 |     await expect(registry.locator('[aria-busy="true"]')).toHaveCount(1)
  502 |     await expect(registry.locator('.skeleton-list button, .skeleton-list a, .skeleton-list input, .skeleton-list [tabindex]')).toHaveCount(0)
  503 | 
  504 |     const agentsResponse = { body: { items: [browserAgent], nextCursor: null } } satisfies JsonResponse
  505 |     routes.set('/api/v1/agents', agentsResponse)
  506 |     agentsPending.resolve(agentsResponse)
  507 |     const agentLink = page.locator('[data-agent-roving-link="true"]')
  508 |     await expect(agentLink).toHaveCount(1)
  509 |     await agentLink.focus()
  510 |     await agentLink.evaluate(element => { element.dataset.loadingIdentity = 'retained-agent-link' })
  511 | 
  512 |     const refreshPending = deferredResponse()
  513 |     const agentsPath = '/api/v1/agents?limit=100'
  514 |     const priorRequests = routes.requests.filter(request => request === agentsPath).length
  515 |     routes.set(agentsPath, refreshPending.promise)
  516 |     await page.getByRole('button', { name: 'Refresh', exact: true }).evaluate((button: HTMLButtonElement) => button.click())
  517 |     await routes.waitFor(agentsPath, priorRequests + 1)
  518 |     await expect(registry).toHaveAttribute('aria-busy', 'true')
  519 |     await expect(agentLink).toHaveAttribute('data-loading-identity', 'retained-agent-link')
  520 |     await expect(agentLink).toBeFocused()
  521 | 
  522 |     routes.set(agentsPath, agentsResponse)
  523 |     refreshPending.resolve({
  524 |       body: { error: { code: 'TEMPORARY_UNAVAILABLE', correlationId: 'safe-agent-refresh', message: 'Please retry.' } },
  525 |       status: 500,
  526 |     })
  527 |     await expect(registry).not.toHaveAttribute('aria-busy')
  528 |     await expect(agentLink).toHaveAttribute('data-loading-identity', 'retained-agent-link')
  529 |     await expect(agentLink).toBeFocused()
  530 |     await expect(page.getByText('Loading Matrix Agent')).toBeVisible()
  531 |     await expect(page.getByText('safe-agent-refresh')).toHaveCount(0)
  532 |     expect(routes.unexpected).toEqual([])
  533 |   })
  534 | })
  535 | 
  536 | test.describe('Task 6.4 Agent secondary surfaces', () => {
  537 |   test.use({ viewport: { height: 900, width: 1440 } })
  538 | 
  539 |   test('owns Sessions, Diagnostics, Connections and Approval states without stale actions', async ({ page }) => {
  540 |     const routes = new RouteScenarios()
  541 |     await routes.install(page)
  542 |     await page.context().addCookies([{ name: 'workmesh_locale', value: 'en', url: webUrl }])
  543 | 
  544 |     const sessionsPath = '/api/v1/agent-sessions?limit=100'
  545 |     const connectionsPath = '/api/v1/agent-connections?limit=50'
  546 |     const pendingPath = '/api/v1/approvals?status=pending&limit=100'
  547 |     const historyPath = '/api/v1/approvals?status=approved&limit=100'
  548 |     const sessionsPending = deferredResponse()
  549 |     const connectionsPending = deferredResponse()
  550 |     const attentionPending = deferredResponse()
  551 |     const pendingApprovals = deferredResponse()
  552 |     const historyPending = deferredResponse()
  553 |     routes.set('/api/v1/agents', { body: { items: [browserAgent], nextCursor: null } })
  554 |     routes.set(sessionsPath, sessionsPending.promise)
  555 |     routes.set(connectionsPath, connectionsPending.promise)
  556 |     routes.set('/api/v1/human-attention', attentionPending.promise)
  557 |     routes.set(pendingPath, pendingApprovals.promise)
  558 |     routes.set(historyPath, historyPending.promise)
  559 |     await page.goto('/agents?tab=sessions&approvalView=history&approvalStatus=approved', { waitUntil: 'domcontentloaded' })
  560 | 
  561 |     const sessions = page.getByRole('region', { name: 'Sessions', exact: true })
  562 |     const diagnostics = page.getByRole('region', { name: 'Diagnostics', exact: true })
  563 |     const connections = page.getByRole('region', { name: 'Connections', exact: true })
  564 |     await expect(sessions.locator('.skeleton-list')).toBeVisible()
  565 |     await expect(diagnostics.locator('.skeleton-list')).toBeVisible()
> 566 |     await expect(connections.locator('.skeleton-list')).toBeVisible()
      |                                                         ^ Error: expect(locator).toBeVisible() failed
  567 |     await expect(sessions).not.toHaveAttribute('aria-busy')
  568 |     await expect(diagnostics).not.toHaveAttribute('aria-busy')
  569 |     await expect(connections).not.toHaveAttribute('aria-busy')
  570 | 
  571 |     const notFound = {
  572 |       body: { error: { code: 'NOT_FOUND', correlationId: 'safe-optional-404', message: 'Not found.' } },
  573 |       status: 404,
  574 |     } satisfies JsonResponse
  575 |     routes.set(sessionsPath, { body: { items: [], nextCursor: null } })
  576 |     sessionsPending.resolve(notFound)
  577 |     routes.set(connectionsPath, { body: { items: [], nextCursor: null } })
  578 |     connectionsPending.resolve({ body: { items: [], nextCursor: null } })
  579 |     routes.set('/api/v1/human-attention', { body: { items: [], nextCursor: null } })
  580 |     attentionPending.resolve({ body: { items: [], nextCursor: null } })
  581 |     await expect(sessions.locator('.skeleton-list')).toHaveCount(0)
  582 |     await expect(diagnostics.locator('.skeleton-list')).toHaveCount(0)
  583 |     await expect(connections.locator('.skeleton-list')).toHaveCount(0)
  584 |     await expect(connections.locator('.connection-empty')).toBeVisible()
  585 |     await page.getByRole('tab', { name: 'Approvals', exact: true }).click()
  586 |     await expect(page.locator('.approval-history .skeleton-list')).toBeVisible()
  587 |     routes.set(historyPath, { body: { items: [], nextCursor: null } })
  588 |     historyPending.resolve(notFound)
  589 |     await expect(page.locator('.approval-history .skeleton-list')).toHaveCount(0)
  590 |     await expect(page.getByText('safe-optional-404')).toHaveCount(0)
  591 | 
  592 |     await page.getByRole('tab', { name: 'Pending', exact: true }).click()
  593 |     const pendingProjection = page.locator('.approval-projection').filter({ has: page.locator('.skeleton-list') })
  594 |     await expect(pendingProjection.locator('.skeleton-list')).toBeVisible()
  595 |     await expect(pendingProjection).not.toHaveAttribute('aria-busy')
  596 |     const pendingResponse = { body: { items: [browserApproval], nextCursor: 'cursor-pending' } } satisfies JsonResponse
  597 |     routes.set(pendingPath, pendingResponse)
  598 |     pendingApprovals.resolve(pendingResponse)
  599 |     await expect(page.getByTestId(`approval-row-${browserApproval.id}`)).toBeVisible()
  600 |     await expect(page.getByTestId('load-more-approvals')).toBeVisible()
  601 | 
  602 |     const priorPendingRequests = routes.requests.filter(request => request === pendingPath).length
  603 |     routes.set(pendingPath, {
  604 |       body: { error: { code: 'RESOURCE_SCOPE_DENIED', correlationId: 'safe-pending-revoke', message: 'Denied.' } },
  605 |       status: 403,
  606 |     })
  607 |     await page.getByRole('button', { name: 'Refresh', exact: true }).evaluate((button: HTMLButtonElement) => button.click())
  608 |     await routes.waitFor(pendingPath, priorPendingRequests + 1)
  609 |     await expect(page.getByTestId(`approval-row-${browserApproval.id}`)).toHaveCount(0)
  610 |     await expect(page.getByTestId('load-more-approvals')).toHaveCount(0)
  611 |     await expect(page.getByRole('heading', { name: 'Agent workspace needs attention' })).toBeVisible()
  612 |     await expect(page.locator('.control-summary')).toHaveCount(0)
  613 |     await expect(page.locator('.approval-projection .empty')).toHaveCount(0)
  614 |     await expect(page.getByText('safe-pending-revoke')).toHaveCount(0)
  615 |     expect(routes.unexpected).toEqual([])
  616 |   })
  617 | })
  618 | 
  619 | test.describe('Task 6.4 Settings loading authority', () => {
  620 |   test.use({ viewport: { height: 900, width: 1440 } })
  621 | 
  622 |   test('separates Team and State initialization and retains the State surface through refresh failure', async ({ page }) => {
  623 |     const routes = new RouteScenarios()
  624 |     await routes.install(page)
  625 |     await page.context().addCookies([{ name: 'workmesh_locale', value: 'en', url: webUrl }])
  626 | 
  627 |     const teamsPending = deferredResponse()
  628 |     const statesPending = deferredResponse()
  629 |     const statesPath = `/api/v1/teams/${team.id}/states`
  630 |     routes.set('/api/v1/teams', teamsPending.promise)
  631 |     routes.setRequest('GET', statesPath, statesPending.promise)
  632 |     await page.goto('/settings?tab=workspace', { waitUntil: 'domcontentloaded' })
  633 | 
  634 |     const settings = page.locator('.settings-page')
  635 |     const initialSkeleton = settings.locator('.settings-loading-skeleton .skeleton-list')
  636 |     await expect(initialSkeleton).toBeVisible()
  637 |     await expect(settings).not.toHaveAttribute('aria-busy')
  638 |     await expect(settings.locator('[aria-busy="true"]')).toHaveCount(1)
  639 |     await expect(settings.getByText('No Team', { exact: true })).toHaveCount(0)
  640 | 
  641 |     const teamsResponse = { body: { items: [team], nextCursor: null } } satisfies JsonResponse
  642 |     routes.set('/api/v1/teams', teamsResponse)
  643 |     teamsPending.resolve(teamsResponse)
  644 |     const workflow = settings.locator('[aria-labelledby="workflow-settings-heading"]')
  645 |     await expect(workflow.locator('.skeleton-list')).toBeVisible()
  646 |     await expect(workflow).not.toHaveAttribute('aria-busy')
  647 |     await expect(workflow.locator('[aria-busy="true"]')).toHaveCount(1)
  648 | 
  649 |     const state = { category: 'backlog', color: '#a8a29e', id: 'state-backlog', name: 'Backlog', revision: 1 }
  650 |     const statesResponse = { body: { items: [state], nextCursor: null } } satisfies JsonResponse
  651 |     routes.setRequest('GET', statesPath, statesResponse)
  652 |     statesPending.resolve(statesResponse)
  653 |     const stateRow = workflow.locator('.workflow-state-list article').first()
  654 |     await expect(stateRow).toContainText('Backlog')
  655 | 
  656 |     const stateName = workflow.locator('input[name="name"]')
  657 |     await stateName.fill('Review')
  658 |     await stateName.evaluate(element => { element.dataset.loadingIdentity = 'retained-state-form' })
  659 |     const refreshPending = deferredResponse()
  660 |     const pagedStatesPath = `${statesPath}?limit=100`
  661 |     const priorRequests = routes.requests.filter(request => request === pagedStatesPath).length
  662 |     routes.setRequest('POST', statesPath, { body: { ...state, id: 'state-review', name: 'Review' } })
  663 |     routes.setRequest('GET', pagedStatesPath, refreshPending.promise)
  664 |     await workflow.locator('form').evaluate((form: HTMLFormElement) => form.requestSubmit())
  665 |     await routes.waitFor(pagedStatesPath, priorRequests + 1)
  666 |     await expect(workflow).toHaveAttribute('aria-busy', 'true')
```