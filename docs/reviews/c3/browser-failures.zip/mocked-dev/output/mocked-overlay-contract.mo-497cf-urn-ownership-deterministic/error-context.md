# Instructions

- Following Playwright test failed.
- Explain why, be concise, respect Playwright best practices.
- Provide a snippet of code with the fix, if possible.

# Test info

- Name: mocked\overlay-contract.mocked.spec.ts >> overlay contract at 1920x1080 >> keeps Agent Peek and Team Access focus, scroll, containment, and return ownership deterministic
- Location: e2e\mocked\overlay-contract.mocked.spec.ts:328:5

# Error details

```
Error: expect(locator).toBeVisible() failed

Locator: locator('[data-agent-roving-link="true"]').first()
Expected: visible
Timeout: 10000ms
Error: element(s) not found

Call log:
  - Expect "toBeVisible" with timeout 10000ms
  - waiting for locator('[data-agent-roving-link="true"]').first()

```

```yaml
- alert
- link "跳到主要内容":
  - /url: "#workmesh-main"
- complementary "主导航":
  - strong: WorkMesh
  - text: Alex Morgan
  - button "收起导航栏" [expanded]
  - navigation "工作区导航":
    - paragraph: 工作台
    - link "工作台":
      - /url: /workbench
    - link "我的工作":
      - /url: /?view=home
    - link "Issues":
      - /url: /?view=my-work
    - link "指南":
      - /url: /?view=guidance
    - paragraph: 治理
    - link "需要我处理":
      - /url: /?view=inbox
    - link "Session":
      - /url: /?view=sessions
    - link "恢复中心":
      - /url: /?view=recovery
    - link "项目":
      - /url: /?view=projects
    - link "智能体":
      - /url: /agents
    - paragraph: 运营
    - link "运营":
      - /url: /operations
  - navigation "管理导航":
    - link "设置":
      - /url: /settings
  - button "退出登录"
  - text: v1.0.0 · 构建 project-work-preview · 数据库架构 24
- banner:
  - paragraph: 人类控制面
  - button "搜索": 搜索 Ctrl K
  - button "切换到浅色主题"
  - group "语言":
    - button "中" [pressed]
    - button "EN"
  - text: 正在重新连接
- main:
  - paragraph: 人类控制面
  - heading "智能体" [level=1]
  - paragraph: 监控委派工作、处理审批，并在不接触凭据的情况下诊断连接。
  - button "刷新"
  - alert:
    - heading "智能体工作区需要关注" [level=2]
    - paragraph: "[ { \"code\": \"invalid_type\", \"expected\": \"string\", \"received\": \"undefined\", \"path\": [ \"icon\" ], \"message\": \"Required\" }, { \"code\": \"invalid_type\", \"expected\": \"string\", \"received\": \"undefined\", \"path\": [ \"endpoint_url\" ], \"message\": \"Required\" }, { \"received\": \"agent:session:start\", \"code\": \"invalid_enum_value\", \"options\": [ \"work:read\", \"work:write\", \"comment:write\", \"plan:write\", \"message:write\", \"artifact:write\", \"repo:read\", \"repo:write_branch\", \"repo:open_pr\", \"repo:merge\", \"ci:run\", \"deploy:staging\", \"deploy:production\", \"secrets:use\", \"automation:manage\", \"admin:*\", \"agent:delegate\" ], \"path\": [ \"requested_capabilities\", 2 ], \"message\": \"Invalid enum value. Expected 'work:read' | 'work:write' | 'comment:write' | 'plan:write' | 'message:write' | 'artifact:write' | 'repo:read' | 'repo:write_branch' | 'repo:open_pr' | 'repo:merge' | 'ci:run' | 'deploy:staging' | 'deploy:production' | 'secrets:use' | 'automation:manage' | 'admin:*' | 'agent:delegate', received 'agent:session:start'\" }, { \"code\": \"invalid_type\", \"expected\": \"array\", \"received\": \"undefined\", \"path\": [ \"output_artifact_types\" ], \"message\": \"Required\" }, { \"code\": \"invalid_type\", \"expected\": \"object\", \"received\": \"undefined\", \"path\": [ \"metadata\" ], \"message\": \"Required\" }, { \"expected\": \"'active' | 'archived'\", \"received\": \"undefined\", \"code\": \"invalid_type\", \"path\": [ \"lifecycle_status\" ], \"message\": \"Required\" }, { \"code\": \"invalid_type\", \"expected\": \"string\", \"received\": \"undefined\", \"path\": [ \"archived_at\" ], \"message\": \"Required\" }, { \"code\": \"invalid_type\", \"expected\": \"string\", \"received\": \"undefined\", \"path\": [ \"archived_by_actor_id\" ], \"message\": \"Required\" }, { \"code\": \"invalid_type\", \"expected\": \"string\", \"received\": \"undefined\", \"path\": [ \"archived_reason\" ], \"message\": \"Required\" }, { \"code\": \"invalid_type\", \"expected\": \"string\", \"received\": \"undefined\", \"path\": [ \"created_at\" ], \"message\": \"Required\" }, { \"code\": \"invalid_type\", \"expected\": \"string\", \"received\": \"undefined\", \"path\": [ \"updated_at\" ], \"message\": \"Required\" } ]"
    - button "重试"
  - tablist "智能体工作区分区":
    - tab "智能体" [selected]
    - tab "连接"
    - tab "自动接入策略"
    - tab "已归档"
  - tabpanel "智能体":
    - region "注册表":
      - paragraph: 注册表
      - heading "智能体" [level=2]
      - paragraph: 先检查定义；仅在需要审阅时展开团队权限。
      - button "全部"
      - button "活跃"
      - button "停用"
      - group "智能体筛选":
        - text: 名称
        - searchbox "名称"
        - text: 团队
        - combobox "团队":
          - option "全部团队" [selected]
          - option "Runtime Reliability"
          - option "Acceptance Team 2"
          - option "Acceptance Team 3"
          - option "Acceptance Team 4"
          - option "Acceptance Team 5"
          - option "Acceptance Team 6"
          - option "Acceptance Team 7"
          - option "Acceptance Team 8"
          - option "Acceptance Team 9"
          - option "Acceptance Team 10"
          - option "Acceptance Team 11"
          - option "Acceptance Team 12"
          - option "Acceptance Team 13"
          - option "Acceptance Team 14"
        - text: 能力
        - combobox "能力":
          - option "全部能力" [selected]
        - text: 状态
        - combobox "状态":
          - option "全部" [selected]
          - option "活跃"
          - option "停用"
```

# Test source

```ts
  233 |       htmlOverflow: document.documentElement.style.overflow,
  234 |       inertCount: document.querySelectorAll('[inert]').length,
  235 |       internalScroll: { clientHeight: element.clientHeight, scrollHeight: element.scrollHeight, scrollTop: element.scrollTop },
  236 |       main: mainRect,
  237 |       mainShift: { left: Math.abs(mainRect.left - snapshot.main.left), width: Math.abs(mainRect.width - snapshot.main.width) },
  238 |       scroll: { x: window.scrollX, y: window.scrollY },
  239 |       viewport: { height: window.innerHeight, width: window.innerWidth },
  240 |     }
  241 |   }, before)
  242 | }
  243 | 
  244 | function expectContained(evidence: Awaited<ReturnType<typeof measureOverlay>>, maxWidth: number): void {
  245 |   expect(evidence.dialog.width).toBeLessThanOrEqual(maxWidth + 0.5)
  246 |   expect(evidence.dialog.left).toBeGreaterThanOrEqual(-0.5)
  247 |   expect(evidence.dialog.top).toBeGreaterThanOrEqual(-0.5)
  248 |   expect(evidence.dialog.right).toBeLessThanOrEqual(evidence.viewport.width + 0.5)
  249 |   expect(evidence.dialog.bottom).toBeLessThanOrEqual(evidence.viewport.height + 0.5)
  250 |   expect(evidence.document.scrollWidth).toBe(evidence.document.clientWidth)
  251 |   expect(evidence.mainShift.left).toBeLessThanOrEqual(1)
  252 |   expect(evidence.mainShift.width).toBeLessThanOrEqual(1)
  253 |   expect(evidence.bodyPosition).toBe('fixed')
  254 |   expect(evidence.htmlOverflow).toBe('hidden')
  255 |   expect(evidence.inertCount).toBeGreaterThan(0)
  256 |   expect(evidence.activeInside).toBe(true)
  257 | }
  258 | 
  259 | async function persistEvidence(page: Page, testInfo: TestInfo, name: string, payload: unknown): Promise<void> {
  260 |   await mkdir(evidenceRoot, { recursive: true })
  261 |   await page.evaluate(() => { document.querySelectorAll('nextjs-portal').forEach(element => element.remove()) })
  262 |   const jsonPath = join(evidenceRoot, `${name}.json`)
  263 |   const screenshotPath = join(evidenceRoot, `${name}.png`)
  264 |   await writeFile(jsonPath, JSON.stringify(payload, null, 2), 'utf8')
  265 |   await page.screenshot({ path: screenshotPath })
  266 |   await testInfo.attach(name, { path: jsonPath, contentType: 'application/json' })
  267 |   await testInfo.attach(`${name}-screenshot`, { path: screenshotPath, contentType: 'image/png' })
  268 | }
  269 | 
  270 | async function rejectBackgroundFocus(dialog: Locator) {
  271 |   return dialog.evaluate(element => {
  272 |     const candidates = [...document.querySelectorAll<HTMLElement>('a, button, input, select, textarea, [tabindex]')]
  273 |       .filter(candidate => candidate.isConnected && !element.contains(candidate))
  274 |     const background = candidates.find(candidate => candidate.closest('[inert]'))
  275 |     if (!background) throw new Error('Background focus target missing')
  276 |     const inertAncestor = background.closest<HTMLElement>('[inert]')
  277 |     background.focus()
  278 |     background.dispatchEvent(new FocusEvent('focusin', { bubbles: true }))
  279 |     return {
  280 |       activeInside: element.contains(document.activeElement),
  281 |       inertAncestor: Boolean(inertAncestor),
  282 |       target: {
  283 |         ariaLabel: background.getAttribute('aria-label'),
  284 |         className: background.className,
  285 |         id: background.id,
  286 |         tagName: background.tagName,
  287 |       },
  288 |     }
  289 |   })
  290 | }
  291 | 
  292 | async function assertBackgroundWheelLocked(page: Page, dialog: Locator) {
  293 |   const before = await page.evaluate(() => window.scrollY)
  294 |   const box = await dialog.boundingBox()
  295 |   if (!box) throw new Error('Overlay geometry missing for wheel assertion')
  296 |   await page.mouse.move(box.x + Math.min(24, box.width / 2), box.y + Math.min(24, box.height / 2))
  297 |   await page.mouse.wheel(0, 500)
  298 |   await page.waitForTimeout(50)
  299 |   const after = await page.evaluate(() => window.scrollY)
  300 |   expect(after).toBe(before)
  301 |   return { after, before, delta: after - before }
  302 | }
  303 | 
  304 | async function dispatchOutsidePointerChain(dialog: Locator) {
  305 |   return dialog.evaluate(element => {
  306 |     const backdrop = element.parentElement
  307 |     if (!(backdrop instanceof HTMLElement)) throw new Error('Overlay backdrop missing')
  308 |     const pointerdown = new PointerEvent('pointerdown', { bubbles: true, button: 0, cancelable: true, pointerId: 1, pointerType: 'mouse' })
  309 |     const mousedown = new MouseEvent('mousedown', { bubbles: true, button: 0, cancelable: true })
  310 |     const click = new MouseEvent('click', { bubbles: true, button: 0, cancelable: true })
  311 |     backdrop.dispatchEvent(pointerdown)
  312 |     backdrop.dispatchEvent(mousedown)
  313 |     backdrop.dispatchEvent(click)
  314 |     return {
  315 |       clickPrevented: click.defaultPrevented,
  316 |       mousedownPrevented: mousedown.defaultPrevented,
  317 |       pointerdownPrevented: pointerdown.defaultPrevented,
  318 |     }
  319 |   })
  320 | }
  321 | 
  322 | const viewports = [{ width: 390, height: 844 }, { width: 1920, height: 1080 }] as const
  323 | 
  324 | for (const viewport of viewports) {
  325 |   test.describe(`overlay contract at ${viewport.width}x${viewport.height}`, () => {
  326 |     test.use({ viewport })
  327 | 
  328 |     test('keeps Agent Peek and Team Access focus, scroll, containment, and return ownership deterministic', async ({ page }, testInfo) => {
  329 |       const requests: string[] = []
  330 |       await installAgentFixtures(page, requests)
  331 |       await page.goto('/agents')
  332 |       const agentLink = page.locator('[data-agent-roving-link="true"]').first()
> 333 |       await expect(agentLink).toBeVisible()
      |                               ^ Error: expect(locator).toBeVisible() failed
  334 |       const background = await prepareScrollableBackground(page)
  335 | 
  336 |       await agentLink.evaluate(element => element.focus({ preventScroll: true }))
  337 |       await page.keyboard.press('Space')
  338 |       const peek = page.locator('.agent-peek')
  339 |       await expect(peek).toBeVisible()
  340 |       const firstPeekControl = peek.locator(':scope > header button').first()
  341 |       await expect(firstPeekControl).toBeFocused()
  342 |       await page.keyboard.press('Shift+Tab')
  343 |       expect(await peek.evaluate(element => element.contains(document.activeElement))).toBe(true)
  344 |       await page.keyboard.press('Tab')
  345 |       await expect(firstPeekControl).toBeFocused()
  346 |       await peek.dispatchEvent('mousedown')
  347 |       await expect(peek).toBeVisible()
  348 |       const peekFocusRejection = await rejectBackgroundFocus(peek)
  349 |       expect(peekFocusRejection.activeInside).toBe(true)
  350 |       expect(peekFocusRejection.inertAncestor).toBe(true)
  351 |       const peekWheelLock = await assertBackgroundWheelLocked(page, peek)
  352 |       const peekEvidence = await measureOverlay(peek, background)
  353 |       expectContained(peekEvidence, 620)
  354 |       expect(peekEvidence.bodyTop).toBe(`-${background.scrollY}px`)
  355 |       await persistEvidence(page, testInfo, `agent-peek-${viewport.width}x${viewport.height}`, {
  356 |         contractLimits: { delete: 560, dialog: 760, sheet: 620 },
  357 |         focusRejection: peekFocusRejection,
  358 |         geometry: peekEvidence,
  359 |         requests,
  360 |         url: page.url(),
  361 |         wheelLock: peekWheelLock,
  362 |       })
  363 |       const peekBackdropChain = await dispatchOutsidePointerChain(peek)
  364 |       await expect(peek).toHaveCount(0)
  365 |       await expect(agentLink).toBeFocused()
  366 |       await assertBackgroundRestored(page, background)
  367 | 
  368 |       await page.keyboard.press('Space')
  369 |       await expect(peek).toBeVisible()
  370 |       await page.keyboard.press('Escape')
  371 |       await expect(peek).toHaveCount(0)
  372 |       await expect(agentLink).toBeFocused()
  373 |       await assertBackgroundRestored(page, background)
  374 | 
  375 |       const card = page.getByTestId('agent-registry-agent/overlay')
  376 |       const manage = card.getByRole('button').first()
  377 |       await manage.evaluate(element => element.focus({ preventScroll: true }))
  378 |       await page.keyboard.press('Space')
  379 |       const accessSheet = page.getByRole('dialog').filter({ has: page.locator('.team-access-drawer') })
  380 |       await expect(accessSheet).toBeVisible()
  381 |       const accessFocusRejection = await rejectBackgroundFocus(accessSheet)
  382 |       expect(accessFocusRejection.activeInside).toBe(true)
  383 |       expect(accessFocusRejection.inertAncestor).toBe(true)
  384 |       const accessWheelLock = await assertBackgroundWheelLocked(page, accessSheet)
  385 |       const internalScroll = await accessSheet.evaluate(element => {
  386 |         const before = element.scrollTop
  387 |         element.scrollTop = element.scrollHeight
  388 |         return { after: element.scrollTop, before, clientHeight: element.clientHeight, scrollHeight: element.scrollHeight }
  389 |       })
  390 |       expect(internalScroll.scrollHeight).toBeGreaterThan(internalScroll.clientHeight)
  391 |       expect(internalScroll.after).toBeGreaterThan(internalScroll.before)
  392 |       const accessEvidence = await measureOverlay(accessSheet, background)
  393 |       expectContained(accessEvidence, 620)
  394 |       expect(accessEvidence.bodyTop).toBe(`-${background.scrollY}px`)
  395 |       await accessSheet.dispatchEvent('mousedown')
  396 |       await expect(accessSheet).toBeVisible()
  397 |       await persistEvidence(page, testInfo, `team-access-${viewport.width}x${viewport.height}`, {
  398 |         backdropChain: peekBackdropChain,
  399 |         contractLimits: { delete: 560, dialog: 760, sheet: 620 },
  400 |         focusRejection: accessFocusRejection,
  401 |         geometry: accessEvidence,
  402 |         internalScroll,
  403 |         requests,
  404 |         url: page.url(),
  405 |         wheelLock: accessWheelLock,
  406 |       })
  407 |       await page.keyboard.press('Escape')
  408 |       await expect(accessSheet).toHaveCount(0)
  409 |       await expect(manage).toBeFocused()
  410 |       await assertBackgroundRestored(page, background)
  411 | 
  412 |       if (viewport.width === 390) {
  413 |         const removedRoutes = ['/preview-issues', '/preview-round2', '/human-control-plane-preview', '/evidence/collaboration-faults']
  414 |         for (const removedRoute of removedRoutes) {
  415 |           const response = await page.goto(removedRoute)
  416 |           expect(response?.status(), `${removedRoute} returns 404`).toBe(404)
  417 |         }
  418 |         await persistEvidence(page, testInfo, 'removed-preview-routes-390x844', { routes: removedRoutes, status: 404 })
  419 |       }
  420 | 
  421 |       await page.evaluate(() => document.querySelector('[data-task62-spacer="true"]')?.remove())
  422 |     })
  423 | 
  424 |     test('keeps busy delete nondismissible and restores the exact background after completion', async ({ page }, testInfo) => {
  425 |       const requests: string[] = []
  426 |       const fixture = await installSettingsFixtures(page, requests)
  427 |       await page.goto(`/settings?team=${encodeURIComponent(fixture.target.id)}`)
  428 |       const deleteTeam = page.getByRole('button', { name: /^(Delete team|删除团队)$/ })
  429 |       await expect(deleteTeam).toBeVisible()
  430 |       const background = await prepareScrollableBackground(page)
  431 |       await deleteTeam.evaluate(element => element.focus({ preventScroll: true }))
  432 |       expect(await page.evaluate(() => window.scrollY)).toBe(background.scrollY)
  433 |       await page.keyboard.press('Enter')
```