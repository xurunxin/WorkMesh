# Instructions

- Following Playwright test failed.
- Explain why, be concise, respect Playwright best practices.
- Provide a snippet of code with the fix, if possible.

# Test info

- Name: mocked\loading-states.mocked.spec.ts >> Task 6.4 Home loading authority >> distinguishes initial durable failure, real Team empty, and null downstream paths
- Location: e2e\mocked\loading-states.mocked.spec.ts:452:3

# Error details

```
Error: expect(locator).toHaveCount(expected) failed

Locator:  getByRole('option', { name: /No team/i })
Expected: 1
Received: 0
Timeout:  10000ms

Call log:
  - Expect "toHaveCount" with timeout 10000ms
  - waiting for getByRole('option', { name: /No team/i })
    23 × locator resolved to 0 elements
       - unexpected value "0"

```

# Page snapshot

```yaml
- generic [active] [ref=e1]:
  - button "Open Next.js Dev Tools" [ref=e7] [cursor=pointer]:
    - img [ref=e8]
  - alert [ref=e11]
  - main [ref=e12]:
    - generic [ref=e13]:
      - heading "Page not found" [level=1] [ref=e14]
      - paragraph [ref=e15]: The page you are looking for does not exist or has been moved.
      - link "Back to home" [ref=e16] [cursor=pointer]:
        - /url: /
```

# Test source

```ts
  379 |   revision: 1,
  380 |   risk_level: 'medium',
  381 |   session_id: 'session-loading-matrix',
  382 |   status: 'pending',
  383 | }
  384 | 
  385 | const workflowStates = [
  386 |   { category: 'backlog', color: '#a8a29e', id: 'state-backlog', name: 'Backlog', revision: 1 },
  387 |   { category: 'planned', color: '#7c3aed', id: 'state-planned', name: 'Planned', revision: 1 },
  388 |   { category: 'started', color: '#2563eb', id: 'state-started', name: 'In progress', revision: 1 },
  389 |   { category: 'completed', color: '#16a34a', id: 'state-completed', name: 'Completed', revision: 1 },
  390 |   { category: 'canceled', color: '#dc2626', id: 'state-canceled', name: 'Canceled', revision: 1 },
  391 | ] as const
  392 | 
  393 | test.describe('Task 6.4 Home loading authority', () => {
  394 |   test.use({ viewport: { height: 900, width: 1440 } })
  395 | 
  396 |   test('keeps one initial owner and isolates a late Work Item scope response', async ({ page }) => {
  397 |     const routes = new RouteScenarios()
  398 |     await routes.install(page)
  399 |     await page.context().addCookies([{ name: 'workmesh_locale', value: 'en', url: webUrl }])
  400 | 
  401 |     const teamsPending = deferredResponse()
  402 |     const workItemsPending = deferredResponse()
  403 |     routes.set('/api/v1/teams', teamsPending.promise)
  404 |     routes.set('/api/v1/work-items', workItemsPending.promise)
  405 |     await page.goto('/?view=my-work&layout=list', { waitUntil: 'domcontentloaded' })
  406 | 
  407 |     const content = page.locator('.content')
  408 |     await expect(content.locator('.skeleton-list')).toHaveCount(1)
  409 |     await expect(content.locator('[aria-busy="true"]')).toHaveCount(1)
  410 |     await expect(content.locator('.skeleton-list [tabindex], .skeleton-list button, .skeleton-list a, .skeleton-list input, .skeleton-list select')).toHaveCount(0)
  411 |     await expect(page.getByRole('option', { name: 'Loading Team' })).toHaveCount(1)
  412 |     await expect(page.getByRole('option', { name: 'No Team' })).toHaveCount(0)
  413 | 
  414 |     const teamsResponse = { body: { items: [team], nextCursor: null } } satisfies JsonResponse
  415 |     routes.set('/api/v1/teams', teamsResponse)
  416 |     teamsPending.resolve(teamsResponse)
  417 |     const workSurfaces = page.getByTestId('work-surfaces')
  418 |     await expect(workSurfaces.locator('.skeleton-list')).toBeVisible()
  419 |     await expect(workSurfaces).not.toHaveAttribute('aria-busy')
  420 |     await expect(workSurfaces.locator('[aria-busy="true"]')).toHaveCount(1)
  421 | 
  422 |     const initialItems = { body: { items: [browserWorkItem], nextCursor: null } } satisfies JsonResponse
  423 |     routes.set('/api/v1/work-items', initialItems)
  424 |     workItemsPending.resolve(initialItems)
  425 |     const retainedTitle = page.getByRole('button', { name: /Retained loading matrix item/ })
  426 |     await expect(retainedTitle).toBeVisible()
  427 | 
  428 |     const search = page.locator('[data-hotkey-filter="true"]')
  429 |     const oldPending = deferredResponse()
  430 |     const oldPath = `/api/v1/work-items?teamId=${team.id}&search=old-scope&limit=100`
  431 |     routes.set(oldPath, oldPending.promise)
  432 |     await search.fill('old-scope')
  433 |     await routes.waitFor(oldPath)
  434 |     await expect(retainedTitle).toHaveCount(0)
  435 |     await expect(workSurfaces.locator('.skeleton-list')).toBeVisible()
  436 | 
  437 |     const newItem = { ...browserWorkItem, id: 'work-new-scope', number: 65, title: 'New scope authority item' }
  438 |     const newPath = `/api/v1/work-items?teamId=${team.id}&search=new-scope&limit=100`
  439 |     routes.set(newPath, { body: { items: [newItem], nextCursor: null } })
  440 |     await search.fill('new-scope')
  441 |     await routes.waitFor(newPath)
  442 |     const newTitle = page.getByRole('button', { name: 'New scope authority item' })
  443 |     await expect(newTitle).toBeVisible()
  444 | 
  445 |     oldPending.resolve({ body: { items: [{ ...browserWorkItem, id: 'work-late-scope', title: 'Late stale scope item' }], nextCursor: null } })
  446 |     await page.waitForTimeout(100)
  447 |     await expect(newTitle).toBeVisible()
  448 |     await expect(page.getByText('Late stale scope item')).toHaveCount(0)
  449 |     expect(routes.unexpected).toEqual([])
  450 |   })
  451 | 
  452 |   test('distinguishes initial durable failure, real Team empty, and null downstream paths', async ({ page }) => {
  453 |     const routes = new RouteScenarios()
  454 |     await routes.install(page)
  455 |     await page.context().addCookies([{ name: 'workmesh_locale', value: 'en', url: webUrl }])
  456 |     const teamsPath = '/api/v1/teams?limit=100'
  457 |     routes.setRequest('GET', teamsPath, {
  458 |       body: { error: { code: 'TEMPORARY_UNAVAILABLE', correlationId: 'safe-team-initial', message: 'Unable to load Team.' } },
  459 |       status: 500,
  460 |     })
  461 |     await page.goto('/?view=my-work', { waitUntil: 'domcontentloaded' })
  462 |     const content = page.locator('.content')
  463 |     await expect(content.getByRole('alert')).toBeVisible()
  464 |     await expect(content.locator('.skeleton-list')).toHaveCount(0)
  465 |     await expect(page.getByTestId('work-surfaces')).toHaveCount(0)
  466 |     await expect(page.getByText('safe-team-initial')).toHaveCount(0)
  467 | 
  468 |     routes.setRequest('GET', teamsPath, { body: { items: [], nextCursor: null } })
  469 |     await page.reload({ waitUntil: 'domcontentloaded' })
  470 |     await expect(content.locator('.empty')).toContainText('No team')
  471 |     await expect(content.getByRole('alert')).toHaveCount(0)
  472 |     await expect(content.locator('.skeleton-list')).toHaveCount(0)
  473 |     await expect(page.getByTestId('work-surfaces')).toHaveCount(0)
  474 |     expect(routes.requests.some(request => request.startsWith('/api/v1/work-items'))).toBe(false)
  475 |     expect(routes.requests.some(request => request.includes('/states'))).toBe(false)
  476 | 
  477 |     await page.goto('/settings?tab=workspace', { waitUntil: 'domcontentloaded' })
  478 |     await expect(page.locator('.settings-loading-skeleton')).toHaveCount(0)
> 479 |     await expect(page.getByRole('option', { name: /No team/i })).toHaveCount(1)
      |                                                                  ^ Error: expect(locator).toHaveCount(expected) failed
  480 |     await expect(page.locator('[aria-labelledby="workflow-settings-heading"] .skeleton-list')).toHaveCount(0)
  481 |     expect(routes.requests.some(request => request.includes('/states'))).toBe(false)
  482 |     expect(routes.unexpected).toEqual([])
  483 |   })
  484 | })
  485 | 
  486 | test.describe('Task 6.4 Agents loading authority', () => {
  487 |   test.use({ viewport: { height: 900, width: 1440 } })
  488 | 
  489 |   test('keeps Registry authority and focus independent through a failed refresh', async ({ page }) => {
  490 |     const routes = new RouteScenarios()
  491 |     await routes.install(page)
  492 |     await page.context().addCookies([{ name: 'workmesh_locale', value: 'en', url: webUrl }])
  493 | 
  494 |     const agentsPending = deferredResponse()
  495 |     routes.set('/api/v1/agents', agentsPending.promise)
  496 |     await page.goto('/agents?tab=agents', { waitUntil: 'domcontentloaded' })
  497 | 
  498 |     const registry = page.locator('.agent-registry')
  499 |     await expect(registry.locator('.skeleton-list')).toBeVisible()
  500 |     await expect(registry).not.toHaveAttribute('aria-busy')
  501 |     await expect(registry.locator('[aria-busy="true"]')).toHaveCount(1)
  502 |     await expect(registry.locator('.skeleton-list button, .skeleton-list a, .skeleton-list input, .skeleton-list [tabindex]')).toHaveCount(0)
  503 | 
  504 |     const agentsResponse = { body: { items: [browserAgent], nextCursor: null } } satisfies JsonResponse
  505 |     routes.set('/api/v1/agents', agentsResponse)
  506 |     agentsPending.resolve(agentsResponse)
  507 |     const agentLink = page.locator('[data-agent-roving-link="true"]')
  508 |     await expect(agentLink).toHaveCount(1)
  509 |     await agentLink.focus()
  510 |     await agentLink.evaluate(element => { element.dataset.loadingIdentity = 'retained-agent-link' })
  511 | 
  512 |     const refreshPending = deferredResponse()
  513 |     const agentsPath = '/api/v1/agents?limit=100'
  514 |     const priorRequests = routes.requests.filter(request => request === agentsPath).length
  515 |     routes.set(agentsPath, refreshPending.promise)
  516 |     await page.getByRole('button', { name: 'Refresh', exact: true }).evaluate((button: HTMLButtonElement) => button.click())
  517 |     await routes.waitFor(agentsPath, priorRequests + 1)
  518 |     await expect(registry).toHaveAttribute('aria-busy', 'true')
  519 |     await expect(agentLink).toHaveAttribute('data-loading-identity', 'retained-agent-link')
  520 |     await expect(agentLink).toBeFocused()
  521 | 
  522 |     routes.set(agentsPath, agentsResponse)
  523 |     refreshPending.resolve({
  524 |       body: { error: { code: 'TEMPORARY_UNAVAILABLE', correlationId: 'safe-agent-refresh', message: 'Please retry.' } },
  525 |       status: 500,
  526 |     })
  527 |     await expect(registry).not.toHaveAttribute('aria-busy')
  528 |     await expect(agentLink).toHaveAttribute('data-loading-identity', 'retained-agent-link')
  529 |     await expect(agentLink).toBeFocused()
  530 |     await expect(page.getByText('Loading Matrix Agent')).toBeVisible()
  531 |     await expect(page.getByText('safe-agent-refresh')).toHaveCount(0)
  532 |     expect(routes.unexpected).toEqual([])
  533 |   })
  534 | })
  535 | 
  536 | test.describe('Task 6.4 Agent secondary surfaces', () => {
  537 |   test.use({ viewport: { height: 900, width: 1440 } })
  538 | 
  539 |   test('owns Sessions, Diagnostics, Connections and Approval states without stale actions', async ({ page }) => {
  540 |     const routes = new RouteScenarios()
  541 |     await routes.install(page)
  542 |     await page.context().addCookies([{ name: 'workmesh_locale', value: 'en', url: webUrl }])
  543 | 
  544 |     const sessionsPath = '/api/v1/agent-sessions?limit=100'
  545 |     const connectionsPath = '/api/v1/agent-connections?limit=50'
  546 |     const pendingPath = '/api/v1/approvals?status=pending&limit=100'
  547 |     const historyPath = '/api/v1/approvals?status=approved&limit=100'
  548 |     const sessionsPending = deferredResponse()
  549 |     const connectionsPending = deferredResponse()
  550 |     const attentionPending = deferredResponse()
  551 |     const pendingApprovals = deferredResponse()
  552 |     const historyPending = deferredResponse()
  553 |     routes.set('/api/v1/agents', { body: { items: [browserAgent], nextCursor: null } })
  554 |     routes.set(sessionsPath, sessionsPending.promise)
  555 |     routes.set(connectionsPath, connectionsPending.promise)
  556 |     routes.set('/api/v1/human-attention', attentionPending.promise)
  557 |     routes.set(pendingPath, pendingApprovals.promise)
  558 |     routes.set(historyPath, historyPending.promise)
  559 |     await page.goto('/agents?tab=sessions&approvalView=history&approvalStatus=approved', { waitUntil: 'domcontentloaded' })
  560 | 
  561 |     const sessions = page.getByRole('region', { name: 'Sessions', exact: true })
  562 |     const diagnostics = page.getByRole('region', { name: 'Diagnostics', exact: true })
  563 |     const connections = page.getByRole('region', { name: 'Connections', exact: true })
  564 |     await expect(sessions.locator('.skeleton-list')).toBeVisible()
  565 |     await expect(diagnostics.locator('.skeleton-list')).toBeVisible()
  566 |     await expect(connections.locator('.skeleton-list')).toBeVisible()
  567 |     await expect(sessions).not.toHaveAttribute('aria-busy')
  568 |     await expect(diagnostics).not.toHaveAttribute('aria-busy')
  569 |     await expect(connections).not.toHaveAttribute('aria-busy')
  570 | 
  571 |     const notFound = {
  572 |       body: { error: { code: 'NOT_FOUND', correlationId: 'safe-optional-404', message: 'Not found.' } },
  573 |       status: 404,
  574 |     } satisfies JsonResponse
  575 |     routes.set(sessionsPath, { body: { items: [], nextCursor: null } })
  576 |     sessionsPending.resolve(notFound)
  577 |     routes.set(connectionsPath, { body: { items: [], nextCursor: null } })
  578 |     connectionsPending.resolve({ body: { items: [], nextCursor: null } })
  579 |     routes.set('/api/v1/human-attention', { body: { items: [], nextCursor: null } })
```