# Instructions

- Following Playwright test failed.
- Explain why, be concise, respect Playwright best practices.
- Provide a snippet of code with the fix, if possible.

# Test info

- Name: mocked\operations-ux.mocked.spec.ts >> restores embedded current state without taking focus when the real Settings tab becomes visible
- Location: e2e\mocked\operations-ux.mocked.spec.ts:741:1

# Error details

```
Error: expect(locator).toHaveAttribute(expected) failed

Locator: getByRole('tab', { name: 'Workspace' })
Expected: "true"
Timeout: 10000ms
Error: element(s) not found

Call log:
  - Expect "toHaveAttribute" with timeout 10000ms
  - waiting for getByRole('tab', { name: 'Workspace' })

```

```yaml
- alert
- main:
  - heading "Page not found" [level=1]
  - paragraph: The page you are looking for does not exist or has been moved.
  - link "Back to home":
    - /url: /
```

# Test source

```ts
  645 |       const requestLog: string[] = []
  646 |       const label = `${scenario.name} / ${surface.name}`
  647 |       try {
  648 |         await installOperationsRoutes(scenarioPage, () => scenario.enabled, { requestLog })
  649 |         await scenarioPage.goto(surface.url)
  650 | 
  651 |         if (scenario.name === 'master-off') {
  652 |           await expect(scenarioPage.getByTestId('operations-disabled'), label).toBeVisible()
  653 |         } else if (scenario.name === 'Operations-only') {
  654 |           await expect(scenarioPage.getByTestId('operations-sections-empty'), label).toBeVisible()
  655 |         }
  656 | 
  657 |         const navigation = scenarioPage.getByTestId('operations-section-navigation')
  658 |         if (scenario.hrefs.length === 0) {
  659 |           await expect(navigation, `${label}: navigation`).toHaveCount(0)
  660 |         } else {
  661 |           await expect(navigation, `${label}: navigation`).toBeVisible()
  662 |           await expect.poll(
  663 |             () => navigationHrefs(scenarioPage),
  664 |             { message: `${label}: ordered anchors` },
  665 |           ).toEqual(scenario.hrefs)
  666 |         }
  667 | 
  668 |         const targets = scenarioPage.locator('.operations-section-target')
  669 |         await expect(targets, `${label}: target count`).toHaveCount(scenario.hrefs.length)
  670 |         expect(
  671 |           await targets.evaluateAll(elements => elements.map(element => `#${element.id}`)),
  672 |           `${label}: ordered targets`,
  673 |         ).toEqual(scenario.hrefs)
  674 |         for (const href of sectionHrefs) {
  675 |           await expect(
  676 |             scenarioPage.locator(href),
  677 |             `${label}: ${scenario.hrefs.includes(href) ? 'owned' : 'hidden'} target ${href}`,
  678 |           ).toHaveCount(scenario.hrefs.includes(href) ? 1 : 0)
  679 |         }
  680 | 
  681 |         await expect(
  682 |           scenarioPage.getByTestId('operations-search'),
  683 |           `${label}: search ${scenario.hasSearch ? 'present' : 'absent'}`,
  684 |         ).toHaveCount(scenario.hasSearch ? 1 : 0)
  685 | 
  686 |         await expect.poll(
  687 |           () => requestLog.some(value => new URL(value).pathname === '/api/v1/features'),
  688 |           { message: `${label}: feature registry request completed` },
  689 |         ).toBe(true)
  690 |         const expectedApiPaths = [...scenario.apiPaths].sort()
  691 |         const observedApiPaths = () => [...new Set(
  692 |           requestLog
  693 |             .map(value => new URL(value).pathname)
  694 |             .filter(path => relevantDataPathSet.has(path)),
  695 |         )].sort()
  696 |         if (expectedApiPaths.length > 0) {
  697 |           await expect.poll(
  698 |             observedApiPaths,
  699 |             { message: `${label}: relevant API presence and absence` },
  700 |           ).toEqual(expectedApiPaths)
  701 |         }
  702 |         await scenarioPage.evaluate(() => new Promise<void>(resolve => {
  703 |           requestAnimationFrame(() => requestAnimationFrame(() => resolve()))
  704 |         }))
  705 |         expect(observedApiPaths(), `${label}: zero unrelated Operations endpoints`).toEqual(expectedApiPaths)
  706 |       } finally {
  707 |         await scenarioPage.close()
  708 |       }
  709 |     }
  710 |   }
  711 | })
  712 | 
  713 | test('keeps real Operations controls in the initial viewport at supported widths', async ({ page }) => {
  714 |   await installOperationsRoutes(page, () => allOperationsFeatures)
  715 |   for (const viewport of [
  716 |     { width: 390, height: 844 },
  717 |     { width: 1440, height: 900 },
  718 |     { width: 1920, height: 1080 },
  719 |   ]) {
  720 |     await page.setViewportSize(viewport)
  721 |     await page.goto(`/operations?viewport=${viewport.width}`)
  722 |     const box = await page.getByTestId('operations-section-navigation').boundingBox()
  723 |     expect(box, `${viewport.width}x${viewport.height} navigation bounds`).not.toBeNull()
  724 |     expect(box?.y ?? viewport.height).toBeLessThan(viewport.height)
  725 |   }
  726 | })
  727 | 
  728 | test('scrolls an asynchronously mounted direct-hash target into view before focusing it', async ({ page }) => {
  729 |   await page.setViewportSize({ width: 1440, height: 900 })
  730 |   await installOperationsRoutes(page, () => allOperationsFeatures, { usageDelayMs: 250 })
  731 |   await page.goto('/operations#operations-runs')
  732 | 
  733 |   const navigation = page.getByTestId('operations-section-navigation')
  734 |   const runs = navigation.getByRole('link', { name: 'Recent runs' })
  735 |   const target = page.locator('#operations-runs')
  736 |   await expect(runs).toHaveAttribute('aria-current', 'location')
  737 |   await expect(target).toBeFocused()
  738 |   await expect.poll(async () => (await target.boundingBox())?.y ?? 900).toBeLessThan(900)
  739 | })
  740 | 
  741 | test('restores embedded current state without taking focus when the real Settings tab becomes visible', async ({ page }, testInfo) => {
  742 |   await installOperationsRoutes(page, () => allOperationsFeatures, settingsRouteFixtures)
  743 |   await page.goto('/settings?tab=workspace&team=team-1&opsQuery=Archived&x=keep#operations-runs')
  744 |   const workspaceTab = page.getByRole('tab', { name: 'Workspace' })
> 745 |   await expect(workspaceTab).toHaveAttribute('aria-selected', 'true')
      |                              ^ Error: expect(locator).toHaveAttribute(expected) failed
  746 | 
  747 |   const beforeMount = await page.evaluate(async () => {
  748 |     window.scrollTo(0, Math.min(120, document.documentElement.scrollHeight - window.innerHeight))
  749 |     await new Promise<void>(resolve => requestAnimationFrame(() => requestAnimationFrame(() => resolve())))
  750 |     return { scrollY: window.scrollY, viewportHeight: window.innerHeight }
  751 |   })
  752 |   expect(beforeMount.scrollY).toBeGreaterThan(0)
  753 |   const workspaceTabBox = await workspaceTab.boundingBox()
  754 |   expect(workspaceTabBox).not.toBeNull()
  755 |   expect(workspaceTabBox?.y ?? -1).toBeGreaterThanOrEqual(0)
  756 |   expect((workspaceTabBox?.y ?? beforeMount.viewportHeight) + (workspaceTabBox?.height ?? 0)).toBeLessThan(beforeMount.viewportHeight)
  757 | 
  758 |   const operationsTab = page.getByRole('tab', { name: 'Planning & Operations' })
  759 |   await operationsTab.click()
  760 |   const navigation = page.getByTestId('operations-section-navigation')
  761 |   await expect(navigation).toBeVisible()
  762 |   await expect(page).toHaveURL('/settings?tab=operations&team=team-1&opsQuery=Archived&x=keep#operations-runs')
  763 |   await expect(navigation.getByRole('link', { name: 'Recent runs' })).toHaveAttribute('aria-current', 'location')
  764 |   await expect(operationsTab).toBeFocused()
  765 |   const runsTarget = page.locator('#operations-runs')
  766 |   await expect(runsTarget).not.toBeFocused()
  767 |   const afterMount = await runsTarget.evaluate(element => ({
  768 |     scrollY: window.scrollY,
  769 |     targetTop: element.getBoundingClientRect().top,
  770 |     viewportHeight: window.innerHeight,
  771 |   }))
  772 |   expect(Math.abs(afterMount.scrollY - beforeMount.scrollY)).toBeLessThanOrEqual(1)
  773 |   expect(afterMount.targetTop).toBeGreaterThan(afterMount.viewportHeight)
  774 | 
  775 |   const localeControl = page.getByRole('button', { exact: true, name: 'EN' })
  776 |   await localeControl.focus()
  777 |   const templatesTarget = page.locator('#operations-templates')
  778 |   const beforeHash = await templatesTarget.evaluate(element => ({
  779 |     scrollY: window.scrollY,
  780 |     targetTop: element.getBoundingClientRect().top,
  781 |   }))
  782 |   await page.evaluate(() => {
  783 |     const url = new URL(window.location.href)
  784 |     url.hash = '#operations-templates'
  785 |     window.history.replaceState(window.history.state, '', url)
  786 |     window.dispatchEvent(new HashChangeEvent('hashchange'))
  787 |   })
  788 |   await expect(navigation.getByRole('link', { name: 'Templates' })).toHaveAttribute('aria-current', 'location')
  789 |   const afterHash = await templatesTarget.evaluate(element => ({
  790 |     scrollY: window.scrollY,
  791 |     targetTop: element.getBoundingClientRect().top,
  792 |   }))
  793 |   expect(Math.abs(afterHash.scrollY - beforeHash.scrollY)).toBeLessThanOrEqual(1)
  794 |   expect(Math.abs(afterHash.targetTop - beforeHash.targetTop)).toBeLessThanOrEqual(1)
  795 |   await expect(localeControl).toBeFocused()
  796 |   await expect(templatesTarget).not.toBeFocused()
  797 | 
  798 |   const beforePopstate = await runsTarget.evaluate(element => ({
  799 |     scrollY: window.scrollY,
  800 |     targetTop: element.getBoundingClientRect().top,
  801 |   }))
  802 |   await page.evaluate(() => {
  803 |     const url = new URL(window.location.href)
  804 |     url.hash = '#operations-runs'
  805 |     window.history.replaceState(window.history.state, '', url)
  806 |     window.dispatchEvent(new PopStateEvent('popstate', { state: window.history.state }))
  807 |   })
  808 |   await expect(navigation.getByRole('link', { name: 'Recent runs' })).toHaveAttribute('aria-current', 'location')
  809 |   const afterPopstate = await runsTarget.evaluate(element => ({
  810 |     scrollY: window.scrollY,
  811 |     targetTop: element.getBoundingClientRect().top,
  812 |   }))
  813 |   expect(Math.abs(afterPopstate.scrollY - beforePopstate.scrollY)).toBeLessThanOrEqual(1)
  814 |   expect(Math.abs(afterPopstate.targetTop - beforePopstate.targetTop)).toBeLessThanOrEqual(1)
  815 |   await expect(localeControl).toBeFocused()
  816 |   await expect(runsTarget).not.toBeFocused()
  817 | 
  818 |   const evidencePath = testInfo.outputPath('task-5.1-embedded-passive-scroll-pass.json')
  819 |   await writeFile(evidencePath, JSON.stringify({
  820 |     beforeMount,
  821 |     workspaceTabBox,
  822 |     afterMount,
  823 |     hashchange: { before: beforeHash, after: afterHash },
  824 |     popstate: { before: beforePopstate, after: afterPopstate },
  825 |   }, null, 2), 'utf8')
  826 |   await testInfo.attach('task-5.1-embedded-passive-scroll-pass', {
  827 |     contentType: 'application/json',
  828 |     path: evidencePath,
  829 |   })
  830 | })
  831 | 
  832 | test('keeps Settings route history, shared responsive semantics, and dense 390/1920 geometry', async ({ page }, testInfo) => {
  833 |   const directUrl = '/settings?tab=operations&team=team-1&opsQuery=Archived&x=keep#operations-templates'
  834 |   const routedOperationsUrl = '/settings?team=team-1&opsQuery=Archived&x=keep&tab=operations#operations-templates'
  835 |   await installOperationsRoutes(page, () => allOperationsFeatures, settingsRouteFixtures)
  836 | 
  837 |   await page.setViewportSize({ width: 1920, height: 1080 })
  838 |   await page.goto(directUrl)
  839 |   const operationsTab = page.getByRole('tab', { name: 'Planning & Operations' })
  840 |   const workspaceTab = page.getByRole('tab', { name: 'Workspace' })
  841 |   await expect(operationsTab).toHaveAttribute('aria-selected', 'true')
  842 |   await expect(page.getByRole('searchbox', { name: 'Search loaded Operations records' })).toHaveValue('Archived')
  843 |   await expect(page.getByRole('link', { name: 'Templates' })).toHaveAttribute('aria-current', 'location')
  844 |   await expect(page).toHaveURL(`${webUrl}${directUrl}`)
  845 | 
```