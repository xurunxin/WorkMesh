# Instructions

- Following Playwright test failed.
- Explain why, be concise, respect Playwright best practices.
- Provide a snippet of code with the fix, if possible.

# Test info

- Name: mocked\loading-states.mocked.spec.ts >> Task 6.4 loading geometry at 390px >> matches real Registry, Sessions and Connections grids without focusable placeholders
- Location: e2e\mocked\loading-states.mocked.spec.ts:916:5

# Error details

```
Error: expect(locator).toHaveCount(expected) failed

Locator:  locator('.registry-list > article')
Expected: 4
Received: 0
Timeout:  10000ms

Call log:
  - Expect "toHaveCount" with timeout 10000ms
  - waiting for locator('.registry-list > article')
    23 × locator resolved to 0 elements
       - unexpected value "0"

```

# Page snapshot

```yaml
- generic [active] [ref=e1]:
  - button "Open Next.js Dev Tools" [ref=e7] [cursor=pointer]:
    - img [ref=e8]
  - alert [ref=e11]
  - generic [ref=e12]:
    - link "Skip to content" [ref=e13] [cursor=pointer]:
      - /url: "#workmesh-main"
    - generic [ref=e14]:
      - banner [ref=e15]:
        - group [ref=e16]:
          - generic "Menu" [ref=e17] [cursor=pointer]
        - button "Search" [ref=e19] [cursor=pointer]:
          - img [ref=e21]
          - generic [ref=e24]: Search
      - main [ref=e25]:
        - generic [ref=e26]:
          - generic [ref=e27]:
            - generic [ref=e28]:
              - paragraph [ref=e29]: Human control plane
              - heading "Agents" [level=1] [ref=e30]
              - paragraph [ref=e31]: Monitor delegated work, respond to approvals, and diagnose Connections without handling credentials.
            - button "Refresh" [ref=e32] [cursor=pointer]:
              - generic [ref=e33]: Refresh
          - alert [ref=e34]:
            - generic [ref=e36]:
              - heading "Agent workspace needs attention" [level=2] [ref=e37]
              - paragraph [ref=e38]: "[ { \"code\": \"invalid_type\", \"expected\": \"string\", \"received\": \"undefined\", \"path\": [ \"icon\" ], \"message\": \"Required\" }, { \"code\": \"invalid_type\", \"expected\": \"string\", \"received\": \"undefined\", \"path\": [ \"endpoint_url\" ], \"message\": \"Required\" }, { \"code\": \"invalid_type\", \"expected\": \"array\", \"received\": \"undefined\", \"path\": [ \"output_artifact_types\" ], \"message\": \"Required\" }, { \"code\": \"invalid_type\", \"expected\": \"object\", \"received\": \"undefined\", \"path\": [ \"metadata\" ], \"message\": \"Required\" }, { \"expected\": \"'active' | 'archived'\", \"received\": \"undefined\", \"code\": \"invalid_type\", \"path\": [ \"lifecycle_status\" ], \"message\": \"Required\" }, { \"code\": \"invalid_type\", \"expected\": \"string\", \"received\": \"undefined\", \"path\": [ \"archived_at\" ], \"message\": \"Required\" }, { \"code\": \"invalid_type\", \"expected\": \"string\", \"received\": \"undefined\", \"path\": [ \"archived_by_actor_id\" ], \"message\": \"Required\" }, { \"code\": \"invalid_type\", \"expected\": \"string\", \"received\": \"undefined\", \"path\": [ \"archived_reason\" ], \"message\": \"Required\" }, { \"code\": \"invalid_type\", \"expected\": \"string\", \"received\": \"undefined\", \"path\": [ \"created_at\" ], \"message\": \"Required\" }, { \"code\": \"invalid_type\", \"expected\": \"string\", \"received\": \"undefined\", \"path\": [ \"updated_at\" ], \"message\": \"Required\" } ]"
            - button "Retry" [ref=e39] [cursor=pointer]:
              - generic [ref=e40]: Retry
          - generic [ref=e41]:
            - generic [ref=e42]:
              - generic [ref=e43]: Agents
              - combobox "Agent workspace sections" [ref=e44]:
                - option "Agents" [selected]
                - option "Connections"
                - option "Auto enrollment"
                - option "Archived"
            - tabpanel "Agents" [ref=e45]:
              - region "Registry" [ref=e46]:
                - generic [ref=e47]:
                  - generic [ref=e48]:
                    - paragraph [ref=e49]: Registry
                    - heading "Agents" [level=2] [ref=e50]
                    - paragraph [ref=e51]: Scan definitions first; expand Team authority only when it needs review.
                  - generic [ref=e52]:
                    - button "All" [ref=e53]
                    - button "Active" [ref=e54]
                    - button "Inactive" [ref=e55]
                - group "Agent filters" [ref=e56]:
                  - generic [ref=e57]:
                    - generic [ref=e58]: Name
                    - searchbox "Name" [ref=e59]
                  - generic [ref=e60]:
                    - generic [ref=e61]: Team
                    - combobox "Team" [ref=e62]:
                      - option "All teams" [selected]
                      - option "General"
                  - generic [ref=e63]:
                    - generic [ref=e64]: Capability
                    - combobox "Capability" [ref=e65]:
                      - option "All capabilities" [selected]
                  - generic [ref=e66]:
                    - generic [ref=e67]: Status
                    - combobox "Status" [ref=e68]:
                      - option "All" [selected]
                      - option "Active"
                      - option "Inactive"
```

# Test source

```ts
  835  | 
  836  |       const teamsPending = deferredResponse()
  837  |       const statesGeometryPending = deferredResponse()
  838  |       const statesPath = `/api/v1/teams/${team.id}/states`
  839  |       routes.setRequest('GET', '/api/v1/teams', teamsPending.promise)
  840  |       routes.setRequest('GET', statesPath, statesGeometryPending.promise)
  841  |       await page.goto('/settings?tab=workspace', { waitUntil: 'domcontentloaded' })
  842  |       const settingsHeader = page.locator('.settings-page > header').first()
  843  |       await settingsHeader.evaluate(element => { element.dataset.loadingIdentity = 'stable-settings-header' })
  844  |       const settingsHeaderPending = (await measureRects(page, '.settings-page > header'))[0]!
  845  |       const settingsPending = await measureSkeleton(page, '.settings-loading-skeleton .skeleton-list', { panelSelector: '.settings-grid' })
  846  |       expectContainedSkeleton(settingsPending, viewport.width <= 720 ? 1 : 2)
  847  |       expect(settingsPending.busyOwners).toBe(1)
  848  |       await page.screenshot({ path: join(evidenceRoot, `loading-settings-pending-${viewport.width}x${viewport.height}.png`) })
  849  | 
  850  |       const teamsResponse = { body: { items: [team], nextCursor: null } } satisfies JsonResponse
  851  |       routes.setRequest('GET', '/api/v1/teams', teamsResponse)
  852  |       teamsPending.resolve(teamsResponse)
  853  |       await expect(page.locator('.settings-states-loading .skeleton-list')).toBeVisible()
  854  |       const statesPending = await measureSkeleton(page, '.settings-states-loading .skeleton-list', { panelSelector: '.settings-card' })
  855  |       expectContainedSkeleton(statesPending, viewport.width <= 560 ? 1 : workflowStates.length)
  856  |       expect(statesPending.cells).toHaveLength(workflowStates.length)
  857  |       expect(statesPending.document.overflow).toBe(0)
  858  |       expect(statesPending.focusableCount).toBe(0)
  859  |       const statesResponse = { body: { items: workflowStates, nextCursor: null } } satisfies JsonResponse
  860  |       routes.setRequest('GET', statesPath, statesResponse)
  861  |       statesGeometryPending.resolve(statesResponse)
  862  |       await expect(page.locator('.settings-grid > .settings-card')).toHaveCount(3)
  863  |       await expect(page.locator('.workflow-state-list > article')).toHaveCount(workflowStates.length)
  864  |       const statesResolved = await measureResolvedGrid(page, '.workflow-state-list', ':scope > article')
  865  |       expect(statesResolved.columns).toBe(statesPending.columns)
  866  |       expect(statesResolved.document.overflow).toBe(0)
  867  |       expect(Math.abs(statesResolved.root.width - statesPending.root.width)).toBeLessThanOrEqual(2)
  868  |       statesResolved.items.forEach((card, index) => expect(Math.abs(card.width - statesPending.cells[index]!.width)).toBeLessThanOrEqual(2))
  869  |       const settingsResolved = await measureRects(page, '.settings-grid > .settings-card')
  870  |       const settingsContainment = await measureResolvedContainment(page)
  871  |       const settingsHeaderResolved = (await measureRects(page, '.settings-page > header'))[0]!
  872  |       expect(settingsContainment.document.overflow).toBe(0)
  873  |       await expect(settingsHeader).toHaveAttribute('data-loading-identity', 'stable-settings-header')
  874  |       expect(Math.abs(settingsHeaderPending.top - settingsHeaderResolved.top)).toBeLessThanOrEqual(2)
  875  |       for (const index of [0, 1, 2])
  876  |         expect(Math.abs(settingsPending.cells[index]!.width - settingsResolved[index]!.width)).toBeLessThanOrEqual(8)
  877  |       await persistEvidence(page, testInfo, `loading-settings-geometry-${viewport.width}x${viewport.height}`, {
  878  |         header: { pending: settingsHeaderPending, resolved: settingsHeaderResolved },
  879  |         pending: settingsPending,
  880  |         resolvedCards: settingsResolved,
  881  |         resolvedContainment: settingsContainment,
  882  |         states: { pending: statesPending, resolved: statesResolved },
  883  |       })
  884  | 
  885  |       const workItemsPending = deferredResponse()
  886  |       routes.setRequest('GET', `/api/v1/teams/${team.id}/states`, { body: { items: workflowStates, nextCursor: null } })
  887  |       routes.set('/api/v1/work-items', workItemsPending.promise)
  888  |       await page.goto('/?view=my-work&layout=board', { waitUntil: 'domcontentloaded' })
  889  |       const boardControls = page.locator('.work-surface-layout-toggle')
  890  |       await boardControls.evaluate(element => { element.dataset.loadingIdentity = 'stable-board-controls' })
  891  |       const boardControlsPending = (await measureRects(page, '.work-surface-layout-toggle'))[0]!
  892  |       const boardPending = await measureSkeleton(page, '.work-surfaces .skeleton-list', { panelSelector: '.work-surfaces' })
  893  |       expectContainedSkeleton(boardPending, viewport.width <= 560 ? 1 : workflowStates.length, viewport.width > 560)
  894  |       expect(boardPending.busyOwners).toBe(1)
  895  |       expect(boardPending.cells).toHaveLength(workflowStates.length)
  896  |       if (viewport.width > 560)
  897  |         expect(boardPending.cells.every(cell => Math.abs(cell.width - 320) <= 2)).toBe(true)
  898  |       await page.screenshot({ path: join(evidenceRoot, `loading-board-pending-${viewport.width}x${viewport.height}.png`) })
  899  | 
  900  |       const workItemsResponse = { body: { items: [browserWorkItem], nextCursor: null } } satisfies JsonResponse
  901  |       routes.set('/api/v1/work-items', workItemsResponse)
  902  |       workItemsPending.resolve(workItemsResponse)
  903  |       await expect(page.locator('.wm-work-item-column')).toHaveCount(workflowStates.length)
  904  |       const boardResolved = await measureRects(page, '.wm-work-item-column')
  905  |       const boardContainment = await measureResolvedContainment(page, '.wm-work-item-board-scroll')
  906  |       const boardControlsResolved = (await measureRects(page, '.work-surface-layout-toggle'))[0]!
  907  |       expect(boardContainment.document.overflow).toBe(0)
  908  |       await expect(boardControls).toHaveAttribute('data-loading-identity', 'stable-board-controls')
  909  |       expect(Math.abs(boardControlsPending.top - boardControlsResolved.top)).toBeLessThanOrEqual(2)
  910  |       if (viewport.width > 560)
  911  |         boardResolved.forEach((column, index) => expect(Math.abs(boardPending.cells[index]!.width - column.width)).toBeLessThanOrEqual(2))
  912  |       await persistEvidence(page, testInfo, `loading-board-geometry-${viewport.width}x${viewport.height}`, { controls: { pending: boardControlsPending, resolved: boardControlsResolved }, pending: boardPending, resolvedColumns: boardResolved, resolvedContainment: boardContainment })
  913  |       expect(routes.unexpected).toEqual([])
  914  |     })
  915  | 
  916  |     test('matches real Registry, Sessions and Connections grids without focusable placeholders', async ({ page }, testInfo) => {
  917  |       const routes = new RouteScenarios()
  918  |       await routes.install(page)
  919  |       await page.context().addCookies([{ name: 'workmesh_locale', value: 'en', url: webUrl }])
  920  | 
  921  |       const registryPendingResponse = deferredResponse()
  922  |       routes.set('/api/v1/agents', registryPendingResponse.promise)
  923  |       await page.goto('/agents?tab=agents', { waitUntil: 'domcontentloaded' })
  924  |       const registryHeader = page.locator('.agent-registry > .surface-header')
  925  |       await registryHeader.evaluate(element => { element.dataset.loadingIdentity = 'stable-registry-header' })
  926  |       const registryHeaderPending = (await measureRects(page, '.agent-registry > .surface-header'))[0]!
  927  |       const registryPending = await measureSkeleton(page, '.agent-registry > .skeleton-list', { panelSelector: '.agent-registry' })
  928  |       expectContainedSkeleton(registryPending, 1)
  929  |       expect(registryPending.busyOwners).toBe(1)
  930  |       await page.screenshot({ path: join(evidenceRoot, `loading-agents-registry-pending-${viewport.width}x${viewport.height}.png`) })
  931  | 
  932  |       const agentsResponse = { body: { items: browserAgents, nextCursor: null } } satisfies JsonResponse
  933  |       routes.set('/api/v1/agents', agentsResponse)
  934  |       registryPendingResponse.resolve(agentsResponse)
> 935  |       await expect(page.locator('.registry-list > article')).toHaveCount(browserAgents.length)
       |                                                              ^ Error: expect(locator).toHaveCount(expected) failed
  936  |       const registryResolved = await measureResolvedGrid(page, '.registry-list', ':scope > article')
  937  |       const registryHeaderResolved = (await measureRects(page, '.agent-registry > .surface-header'))[0]!
  938  |       expect(registryResolved.columns).toBe(1)
  939  |       expect(registryResolved.document.overflow).toBe(0)
  940  |       expect(Math.abs(registryResolved.root.width - registryPending.root.width)).toBeLessThanOrEqual(2)
  941  |       expect(Math.abs(registryResolved.items[0]!.width - registryPending.cells[0]!.width)).toBeLessThanOrEqual(2)
  942  |       expect(Math.abs(registryHeaderPending.top - registryHeaderResolved.top)).toBeLessThanOrEqual(2)
  943  |       await expect(registryHeader).toHaveAttribute('data-loading-identity', 'stable-registry-header')
  944  |       await persistEvidence(page, testInfo, `loading-agents-registry-geometry-${viewport.width}x${viewport.height}`, {
  945  |         header: { pending: registryHeaderPending, resolved: registryHeaderResolved },
  946  |         pending: registryPending,
  947  |         resolved: registryResolved,
  948  |       })
  949  | 
  950  |       const sessionsPath = '/api/v1/agent-sessions?limit=100'
  951  |       const connectionsPath = '/api/v1/agent-connections?limit=50'
  952  |       const sessionsPendingResponse = deferredResponse()
  953  |       const connectionsPendingResponse = deferredResponse()
  954  |       routes.set(sessionsPath, sessionsPendingResponse.promise)
  955  |       routes.set(connectionsPath, connectionsPendingResponse.promise)
  956  |       await page.goto('/agents?tab=sessions', { waitUntil: 'domcontentloaded' })
  957  |       const sessionsRegion = page.getByRole('region', { name: 'Sessions', exact: true })
  958  |       const connectionsRegion = page.getByRole('region', { name: 'Connections', exact: true })
  959  |       const sessionsHeader = sessionsRegion.locator('.surface-header')
  960  |       const connectionsHeader = connectionsRegion.locator('.surface-header')
  961  |       await sessionsHeader.evaluate(element => { element.dataset.loadingIdentity = 'stable-sessions-header' })
  962  |       await connectionsHeader.evaluate(element => { element.dataset.loadingIdentity = 'stable-connections-header' })
  963  |       const sessionsHeaderPending = (await measureRects(page, '[aria-label="Sessions"] > .surface-header'))[0]!
  964  |       const connectionsHeaderPending = (await measureRects(page, '.connection-panel > .surface-header'))[0]!
  965  |       const sessionsPending = await measureSkeleton(page, '.agent-sessions-loading .skeleton-list', { panelSelector: '.surface-panel' })
  966  |       const connectionsPending = await measureSkeleton(page, '.agent-connections-loading .skeleton-list', { panelSelector: '.connection-panel' })
  967  |       const expectedCardColumns = viewport.width <= 560 ? 1 : browserSessions.length
  968  |       expectContainedSkeleton(sessionsPending, expectedCardColumns)
  969  |       expectContainedSkeleton(connectionsPending, expectedCardColumns)
  970  |       expect(sessionsPending.busyOwners).toBe(1)
  971  |       expect(connectionsPending.busyOwners).toBe(1)
  972  |       if (viewport.width > 560) {
  973  |         expect(sessionsPending.cells.every(cell => cell.width > 224)).toBe(true)
  974  |         expect(connectionsPending.cells.every(cell => cell.width > 224)).toBe(true)
  975  |       }
  976  |       await page.screenshot({ path: join(evidenceRoot, `loading-agents-secondary-pending-${viewport.width}x${viewport.height}.png`) })
  977  | 
  978  |       const sessionsResponse = { body: { items: browserSessions, nextCursor: null } } satisfies JsonResponse
  979  |       const connectionsResponse = { body: { items: browserConnections, nextCursor: null } } satisfies JsonResponse
  980  |       routes.set(sessionsPath, sessionsResponse)
  981  |       sessionsPendingResponse.resolve(sessionsResponse)
  982  |       await expect(page.locator('.session-card-list > .session-card')).toHaveCount(browserSessions.length)
  983  |       const sessionsResolved = await measureResolvedGrid(page, '.session-card-list', ':scope > .session-card')
  984  |       const sessionsHeaderResolved = (await measureRects(page, '[aria-label="Sessions"] > .surface-header'))[0]!
  985  |       routes.set(connectionsPath, connectionsResponse)
  986  |       connectionsPendingResponse.resolve(connectionsResponse)
  987  |       await expect(page.locator('.connection-list > button')).toHaveCount(browserConnections.length)
  988  |       const connectionsResolved = await measureResolvedGrid(page, '.connection-list', ':scope > button')
  989  |       const connectionsHeaderResolved = (await measureRects(page, '.connection-panel > .surface-header'))[0]!
  990  |       expect(sessionsResolved.columns).toBe(sessionsPending.columns)
  991  |       expect(connectionsResolved.columns).toBe(connectionsPending.columns)
  992  |       expect(sessionsResolved.document.overflow).toBe(0)
  993  |       expect(connectionsResolved.document.overflow).toBe(0)
  994  |       expect(Math.abs(sessionsResolved.root.width - sessionsPending.root.width)).toBeLessThanOrEqual(2)
  995  |       expect(Math.abs(connectionsResolved.root.width - connectionsPending.root.width)).toBeLessThanOrEqual(2)
  996  |       sessionsResolved.items.forEach((card, index) => expect(Math.abs(card.width - sessionsPending.cells[index]!.width)).toBeLessThanOrEqual(2))
  997  |       connectionsResolved.items.forEach((card, index) => expect(Math.abs(card.width - connectionsPending.cells[index]!.width)).toBeLessThanOrEqual(2))
  998  |       expect(Math.abs(sessionsHeaderPending.top - sessionsHeaderResolved.top)).toBeLessThanOrEqual(2)
  999  |       expect(Math.abs(connectionsHeaderPending.top - connectionsHeaderResolved.top)).toBeLessThanOrEqual(2)
  1000 |       await expect(sessionsHeader).toHaveAttribute('data-loading-identity', 'stable-sessions-header')
  1001 |       await expect(connectionsHeader).toHaveAttribute('data-loading-identity', 'stable-connections-header')
  1002 |       await persistEvidence(page, testInfo, `loading-agents-secondary-geometry-${viewport.width}x${viewport.height}`, {
  1003 |         connections: { header: { pending: connectionsHeaderPending, resolved: connectionsHeaderResolved }, pending: connectionsPending, resolved: connectionsResolved },
  1004 |         sessions: { header: { pending: sessionsHeaderPending, resolved: sessionsHeaderResolved }, pending: sessionsPending, resolved: sessionsResolved },
  1005 |       })
  1006 |       expect(routes.unexpected).toEqual([])
  1007 |     })
  1008 |   })
  1009 | }
  1010 | 
```