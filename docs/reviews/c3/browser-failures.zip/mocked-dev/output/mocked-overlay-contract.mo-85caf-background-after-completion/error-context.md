# Instructions

- Following Playwright test failed.
- Explain why, be concise, respect Playwright best practices.
- Provide a snippet of code with the fix, if possible.

# Test info

- Name: mocked\overlay-contract.mocked.spec.ts >> overlay contract at 390x844 >> keeps busy delete nondismissible and restores the exact background after completion
- Location: e2e\mocked\overlay-contract.mocked.spec.ts:424:5

# Error details

```
Error: expect(received).toBeGreaterThan(expected)

Expected: > 0
Received:   0
```

# Page snapshot

```yaml
- generic [active] [ref=e1]:
  - button "Open Next.js Dev Tools" [ref=e7] [cursor=pointer]:
    - img [ref=e8]
  - alert [ref=e11]
  - generic [ref=e12]:
    - link "跳到主要内容" [ref=e13] [cursor=pointer]:
      - /url: "#workmesh-main"
    - generic [ref=e14]:
      - banner [ref=e15]:
        - group [ref=e16]:
          - generic "菜单" [ref=e17] [cursor=pointer]
          - option "无团队" [disabled]
          - option "Runtime Reliability (RUN)" [selected]
          - option "Platform (PLAT)"
        - button "搜索" [ref=e19] [cursor=pointer]:
          - img [ref=e21]
          - generic [ref=e24]: 搜索
      - main [ref=e25]:
        - generic [ref=e26]:
          - generic [ref=e28]:
            - heading "设置" [level=1] [ref=e29]
            - paragraph [ref=e30]: 工作区管理与日常规划保持分离。
          - generic [ref=e31]:
            - generic [ref=e32]:
              - generic [ref=e33]: 工作区
              - combobox "设置分区" [ref=e34]:
                - option "工作区" [selected]
            - tabpanel "工作区" [ref=e35]:
              - generic [ref=e36]:
                - region "团队" [ref=e37]:
                  - paragraph [ref=e38]: 工作区结构
                  - heading "团队" [level=2] [ref=e39]
                  - generic [ref=e40]:
                    - generic [ref=e41]:
                      - text: 团队名称
                      - textbox "团队名称" [ref=e42]
                    - generic [ref=e43]:
                      - text: 团队标识
                      - textbox "团队标识" [ref=e44]:
                        - /placeholder: ENG
                    - button "新建团队" [ref=e45] [cursor=pointer]:
                      - img [ref=e47]
                      - generic [ref=e49]: 新建团队
                - region "团队详情" [ref=e50]:
                  - paragraph [ref=e51]: 已选团队
                  - heading "团队详情" [level=2] [ref=e52]
                  - generic [ref=e53]:
                    - generic [ref=e54]:
                      - text: 团队名称
                      - textbox "团队名称" [ref=e55]: Runtime Reliability
                    - generic [ref=e56]:
                      - text: 团队标识
                      - textbox "团队标识" [ref=e57]: RUN
                    - button "保存更改" [ref=e58] [cursor=pointer]:
                      - img [ref=e60]
                      - generic [ref=e62]: 保存更改
                  - generic [ref=e63]:
                    - generic [ref=e64]:
                      - strong [ref=e65]: 删除团队
                      - paragraph [ref=e66]: 从活动导航中移除此团队；关联工作将保留，但不可用。
                    - button "删除团队" [ref=e67] [cursor=pointer]:
                      - img [ref=e69]
                      - generic [ref=e71]: 删除团队
                - region "工作流状态" [ref=e72]:
                  - paragraph [ref=e73]: 团队工作流
                  - heading "工作流状态" [level=2] [ref=e74]
                  - article [ref=e76]:
                    - generic [ref=e79]:
                      - strong [ref=e80]: Ready
                      - generic [ref=e81]: 已规划
                    - button "编辑状态 Ready" [ref=e82] [cursor=pointer]:
                      - img [ref=e84]
                      - generic [ref=e86]: 编辑
                  - generic [ref=e87]:
                    - generic [ref=e88]:
                      - text: 状态名称
                      - textbox "状态名称" [ref=e89]
                    - generic [ref=e90]:
                      - text: 分类
                      - combobox "分类" [ref=e91]:
                        - option "待办"
                        - option "已规划" [selected]
                        - option "进行中"
                        - option "已完成"
                        - option "已取消"
                    - group "状态颜色" [ref=e92]:
                      - generic [ref=e93]: 状态颜色
                      - generic [ref=e94]:
                        - generic [ref=e95] [cursor=pointer]:
                          - radio "中性" [checked] [ref=e96]
                          - generic [ref=e98]: 中性
                        - generic [ref=e99] [cursor=pointer]:
                          - radio "蓝色" [ref=e100]
                          - generic [ref=e102]: 蓝色
                        - generic [ref=e103] [cursor=pointer]:
                          - radio "绿色" [ref=e104]
                          - generic [ref=e106]: 绿色
                        - generic [ref=e107] [cursor=pointer]:
                          - radio "琥珀色" [ref=e108]
                          - generic [ref=e110]: 琥珀色
                        - generic [ref=e111] [cursor=pointer]:
                          - radio "红色" [ref=e112]
                          - generic [ref=e114]: 红色
                        - generic [ref=e115] [cursor=pointer]:
                          - radio "自定义" [ref=e116]
                          - generic [ref=e118]: 自定义
                    - button "新建状态" [ref=e119] [cursor=pointer]:
                      - img [ref=e121]
                      - generic [ref=e123]: 新建状态
              - region "模型服务接入" [ref=e124]:
                - paragraph [ref=e125]: Agent workbench
                - heading "模型服务接入" [level=2] [ref=e126]
                - paragraph [ref=e127]: 管理 Chat Completions 与 Responses 模型服务、凭据和模型目录。
                - link "打开接入设置" [ref=e128] [cursor=pointer]:
                  - /url: /settings/agent-workbench
```

# Test source

```ts
  69  |   bodyStyle: string | null
  70  |   htmlStyle: string | null
  71  |   main: Rect
  72  |   scrollX: number
  73  |   scrollY: number
  74  | }
  75  | 
  76  | function deferred(): { promise: Promise<void>; resolve: () => void } {
  77  |   let resolve: () => void = () => undefined
  78  |   const promise = new Promise<void>(done => { resolve = done })
  79  |   return { promise, resolve }
  80  | }
  81  | 
  82  | async function fulfillJson(route: Parameters<Parameters<Page['route']>[1]>[0], payload: unknown): Promise<void> {
  83  |   await route.fulfill({ status: 200, headers: responseHeaders, body: JSON.stringify(payload) })
  84  | }
  85  | 
  86  | async function installAgentFixtures(page: Page, requests: string[]): Promise<void> {
  87  |   await page.route(`${apiUrl}/api/v1/**`, async route => {
  88  |     const request = route.request()
  89  |     const url = new URL(request.url())
  90  |     requests.push(`${request.method()} ${url.pathname}`)
  91  |     if (request.method() === 'OPTIONS') return route.fulfill({ status: 204, headers: responseHeaders, body: '' })
  92  |     if (url.pathname === '/api/v1/features') return fulfillJson(route, {
  93  |       features: canonicalFeatures.map(key => ({ key, tier: key.includes('EXPERIMENTAL') ? 'experimental' : 'beta', enabled: key === 'WORKMESH_BETA_PLANNING' || key === 'WORKMESH_BETA_OPERATIONS_UI' })),
  94  |     })
  95  |     if (url.pathname === '/api/v1/agents') return fulfillJson(route, { items: [agent], nextCursor: null })
  96  |     if (url.pathname === '/api/v1/teams') return fulfillJson(route, { items: teams, nextCursor: null })
  97  |     if (url.pathname === '/api/v1/agent-sessions' || url.pathname === '/api/v1/actors/humans')
  98  |       return fulfillJson(route, { items: [], nextCursor: null })
  99  |     if (url.pathname === '/api/v1/approvals') return fulfillJson(route, { items: [], nextCursor: null })
  100 |     await route.continue()
  101 |   })
  102 | }
  103 | 
  104 | async function installSettingsFixtures(page: Page, requests: string[]) {
  105 |   const deletion = deferred()
  106 |   const target = { id: 'team/delete-overlay', name: 'Runtime Reliability', key: 'RUN', revision: 11 }
  107 |   const survivor = { id: 'team-survivor', name: 'Platform', key: 'PLAT', revision: 4 }
  108 |   let deleted = false
  109 |   let deleteCount = 0
  110 |   await page.route(`${apiUrl}/api/v1/**`, async route => {
  111 |     const request = route.request()
  112 |     const url = new URL(request.url())
  113 |     requests.push(`${request.method()} ${url.pathname}`)
  114 |     if (request.method() === 'OPTIONS') return route.fulfill({ status: 204, headers: responseHeaders, body: '' })
  115 |     if (url.pathname === '/api/v1/features') return fulfillJson(route, {
  116 |       features: canonicalFeatures.map(key => ({ key, tier: key.includes('EXPERIMENTAL') ? 'experimental' : 'beta', enabled: true })),
  117 |     })
  118 |     if (request.method() === 'DELETE' && url.pathname === '/api/v1/teams/team%2Fdelete-overlay') {
  119 |       deleteCount += 1
  120 |       await deletion.promise
  121 |       deleted = true
  122 |       return route.fulfill({ status: 204, headers: responseHeaders, body: '' })
  123 |     }
  124 |     if (url.pathname === '/api/v1/teams') return fulfillJson(route, {
  125 |       items: deleted ? [survivor] : [target, survivor],
  126 |       nextCursor: null,
  127 |     })
  128 |     const stateMatch = url.pathname.match(/^\/api\/v1\/teams\/([^/]+)\/states$/)
  129 |     if (stateMatch) return fulfillJson(route, {
  130 |       items: [{ id: `state-${decodeURIComponent(stateMatch[1]!)}`, name: 'Ready', category: 'planned', color: '#64748b', revision: 1 }],
  131 |       nextCursor: null,
  132 |     })
  133 |     await route.continue()
  134 |   })
  135 |   return {
  136 |     deleteCount: () => deleteCount,
  137 |     release: deletion.resolve,
  138 |     survivor,
  139 |     target,
  140 |   }
  141 | }
  142 | 
  143 | async function prepareScrollableBackground(page: Page): Promise<BackgroundSnapshot> {
  144 |   await page.evaluate(async () => {
  145 |     document.documentElement.style.setProperty('--task-6-2-html-preserved', '1')
  146 |     document.body.style.setProperty('--task-6-2-body-preserved', '1')
  147 |     const spacer = document.createElement('div')
  148 |     spacer.dataset.task62Spacer = 'true'
  149 |     spacer.style.height = '1800px'
  150 |     spacer.style.pointerEvents = 'none'
  151 |     spacer.style.width = '1px'
  152 |     document.body.append(spacer)
  153 |     await new Promise<void>(resolve => requestAnimationFrame(() => resolve()))
  154 |     window.scrollTo(0, 180)
  155 |     await new Promise<void>(resolve => requestAnimationFrame(() => resolve()))
  156 |   })
  157 |   const snapshot = await page.evaluate(() => {
  158 |     const main = document.querySelector<HTMLElement>('#workmesh-main')
  159 |     if (!main) throw new Error('Main landmark missing')
  160 |     const rect = main.getBoundingClientRect()
  161 |     return {
  162 |       bodyStyle: document.body.getAttribute('style'),
  163 |       htmlStyle: document.documentElement.getAttribute('style'),
  164 |       main: { bottom: rect.bottom, height: rect.height, left: rect.left, right: rect.right, top: rect.top, width: rect.width },
  165 |       scrollX: window.scrollX,
  166 |       scrollY: window.scrollY,
  167 |     }
  168 |   })
> 169 |   expect(snapshot.scrollY).toBeGreaterThan(0)
      |                            ^ Error: expect(received).toBeGreaterThan(expected)
  170 |   return snapshot
  171 | }
  172 | 
  173 | async function assertBackgroundRestored(page: Page, snapshot: BackgroundSnapshot): Promise<void> {
  174 |   await expect.poll(() => page.evaluate(() => window.scrollY)).toBe(snapshot.scrollY)
  175 |   const restored = await page.evaluate(() => ({
  176 |     bodyStyle: document.body.getAttribute('style'),
  177 |     htmlStyle: document.documentElement.getAttribute('style'),
  178 |     scrollX: window.scrollX,
  179 |   }))
  180 |   expect(restored).toEqual({ bodyStyle: snapshot.bodyStyle, htmlStyle: snapshot.htmlStyle, scrollX: snapshot.scrollX })
  181 | }
  182 | 
  183 | async function expectValidPostDeleteFocus(page: Page): Promise<{
  184 |   connected: boolean
  185 |   identity: string
  186 |   visible: boolean
  187 | }> {
  188 |   await expect.poll(() => page.evaluate(() => {
  189 |     const active = document.activeElement
  190 |     if (!(active instanceof HTMLElement)) return false
  191 |     return active.matches('.app-team-switcher select, #team-settings-heading, #workmesh-main')
  192 |   })).toBe(true)
  193 | 
  194 |   const evidence = await page.evaluate(() => {
  195 |     const active = document.activeElement
  196 |     if (!(active instanceof HTMLElement)) throw new Error('Post-delete focus is not an HTML element')
  197 |     const rect = active.getBoundingClientRect()
  198 |     const style = window.getComputedStyle(active)
  199 |     return {
  200 |       connected: active.isConnected,
  201 |       identity: active.id ? `#${active.id}` : `${active.tagName.toLowerCase()}${active.className ? `.${String(active.className).trim().replace(/\s+/g, '.')}` : ''}`,
  202 |       visible: style.display !== 'none'
  203 |         && style.visibility !== 'hidden'
  204 |         && active.getClientRects().length > 0
  205 |         && rect.width > 0
  206 |         && rect.height > 0,
  207 |     }
  208 |   })
  209 |   expect(evidence.connected).toBe(true)
  210 |   expect(evidence.visible).toBe(true)
  211 |   expect(evidence.identity).not.toBe('body')
  212 |   return evidence
  213 | }
  214 | 
  215 | async function measureOverlay(dialog: Locator, before: BackgroundSnapshot) {
  216 |   return dialog.evaluate((element, snapshot) => {
  217 |     if (!(element instanceof HTMLElement)) throw new Error('Overlay root missing')
  218 |     const main = document.querySelector<HTMLElement>('#workmesh-main')
  219 |     if (!main) throw new Error('Main landmark missing')
  220 |     const toRect = (target: HTMLElement) => {
  221 |       const rect = target.getBoundingClientRect()
  222 |       return { bottom: rect.bottom, height: rect.height, left: rect.left, right: rect.right, top: rect.top, width: rect.width }
  223 |     }
  224 |     const rect = toRect(element)
  225 |     const mainRect = toRect(main)
  226 |     return {
  227 |       activeInside: element.contains(document.activeElement),
  228 |       bodyPosition: document.body.style.position,
  229 |       bodyTop: document.body.style.top,
  230 |       centerDelta: Math.abs(rect.left - (window.innerWidth - rect.right)),
  231 |       dialog: rect,
  232 |       document: { clientWidth: document.documentElement.clientWidth, scrollWidth: document.documentElement.scrollWidth },
  233 |       htmlOverflow: document.documentElement.style.overflow,
  234 |       inertCount: document.querySelectorAll('[inert]').length,
  235 |       internalScroll: { clientHeight: element.clientHeight, scrollHeight: element.scrollHeight, scrollTop: element.scrollTop },
  236 |       main: mainRect,
  237 |       mainShift: { left: Math.abs(mainRect.left - snapshot.main.left), width: Math.abs(mainRect.width - snapshot.main.width) },
  238 |       scroll: { x: window.scrollX, y: window.scrollY },
  239 |       viewport: { height: window.innerHeight, width: window.innerWidth },
  240 |     }
  241 |   }, before)
  242 | }
  243 | 
  244 | function expectContained(evidence: Awaited<ReturnType<typeof measureOverlay>>, maxWidth: number): void {
  245 |   expect(evidence.dialog.width).toBeLessThanOrEqual(maxWidth + 0.5)
  246 |   expect(evidence.dialog.left).toBeGreaterThanOrEqual(-0.5)
  247 |   expect(evidence.dialog.top).toBeGreaterThanOrEqual(-0.5)
  248 |   expect(evidence.dialog.right).toBeLessThanOrEqual(evidence.viewport.width + 0.5)
  249 |   expect(evidence.dialog.bottom).toBeLessThanOrEqual(evidence.viewport.height + 0.5)
  250 |   expect(evidence.document.scrollWidth).toBe(evidence.document.clientWidth)
  251 |   expect(evidence.mainShift.left).toBeLessThanOrEqual(1)
  252 |   expect(evidence.mainShift.width).toBeLessThanOrEqual(1)
  253 |   expect(evidence.bodyPosition).toBe('fixed')
  254 |   expect(evidence.htmlOverflow).toBe('hidden')
  255 |   expect(evidence.inertCount).toBeGreaterThan(0)
  256 |   expect(evidence.activeInside).toBe(true)
  257 | }
  258 | 
  259 | async function persistEvidence(page: Page, testInfo: TestInfo, name: string, payload: unknown): Promise<void> {
  260 |   await mkdir(evidenceRoot, { recursive: true })
  261 |   await page.evaluate(() => { document.querySelectorAll('nextjs-portal').forEach(element => element.remove()) })
  262 |   const jsonPath = join(evidenceRoot, `${name}.json`)
  263 |   const screenshotPath = join(evidenceRoot, `${name}.png`)
  264 |   await writeFile(jsonPath, JSON.stringify(payload, null, 2), 'utf8')
  265 |   await page.screenshot({ path: screenshotPath })
  266 |   await testInfo.attach(name, { path: jsonPath, contentType: 'application/json' })
  267 |   await testInfo.attach(`${name}-screenshot`, { path: screenshotPath, contentType: 'image/png' })
  268 | }
  269 | 
```