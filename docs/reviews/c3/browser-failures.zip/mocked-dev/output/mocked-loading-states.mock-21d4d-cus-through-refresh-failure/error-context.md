# Instructions

- Following Playwright test failed.
- Explain why, be concise, respect Playwright best practices.
- Provide a snippet of code with the fix, if possible.

# Test info

- Name: mocked\loading-states.mocked.spec.ts >> Task 6.4 Operations loading authority >> uses real pending owners, resolves independently, and retains focus through refresh failure
- Location: e2e\mocked\loading-states.mocked.spec.ts:691:3

# Error details

```
Error: expect(locator).toHaveCount(expected) failed

Locator:  locator('.operations-tab > .sr-only[role="status"]')
Expected: 1
Received: 0
Timeout:  10000ms

Call log:
  - Expect "toHaveCount" with timeout 10000ms
  - waiting for locator('.operations-tab > .sr-only[role="status"]')
    23 × locator resolved to 0 elements
       - unexpected value "0"

```

# Page snapshot

```yaml
- generic [ref=e1]:
  - button "Open Next.js Dev Tools" [ref=e7] [cursor=pointer]:
    - img [ref=e8]
  - alert [ref=e11]
  - generic [ref=e12]:
    - link "Skip to content" [ref=e13] [cursor=pointer]:
      - /url: "#workmesh-main"
    - complementary "Main navigation" [ref=e14]:
      - generic [ref=e15]:
        - strong [ref=e17]: WorkMesh
        - generic [ref=e18]: Alex Morgan
      - button "Collapse sidebar" [expanded] [ref=e19] [cursor=pointer]:
        - img [ref=e20]
        - generic [ref=e22]: Collapse sidebar
      - navigation "Workspace" [ref=e23]:
        - generic [ref=e24]:
          - paragraph [ref=e25]: Workbench
          - link "Workbench" [ref=e26] [cursor=pointer]:
            - /url: /workbench
            - img [ref=e28]
            - generic [ref=e30]: Workbench
          - link "My work" [ref=e31] [cursor=pointer]:
            - /url: /?view=home
            - img [ref=e33]
            - generic [ref=e35]: My work
          - link "Issues" [ref=e36] [cursor=pointer]:
            - /url: /?view=my-work
            - img [ref=e38]
            - generic [ref=e40]: Issues
          - link "Guidance" [ref=e41] [cursor=pointer]:
            - /url: /?view=guidance
            - img [ref=e43]
            - generic [ref=e45]: Guidance
        - generic [ref=e46]:
          - paragraph [ref=e47]: Governance
          - link "Needs You" [ref=e48] [cursor=pointer]:
            - /url: /?view=inbox
            - img [ref=e50]
            - generic [ref=e52]: Needs You
          - link "Session" [ref=e53] [cursor=pointer]:
            - /url: /?view=sessions
            - img [ref=e55]
            - generic [ref=e57]: Session
          - link "Recovery" [ref=e58] [cursor=pointer]:
            - /url: /?view=recovery
            - img [ref=e60]
            - generic [ref=e62]: Recovery
          - link "Projects" [ref=e63] [cursor=pointer]:
            - /url: /?view=projects
            - img [ref=e65]
            - generic [ref=e67]: Projects
          - link "Agents" [ref=e68] [cursor=pointer]:
            - /url: /agents
            - img [ref=e70]
            - generic [ref=e72]: Agents
        - generic [ref=e73]:
          - paragraph [ref=e74]: Operations
          - link "Operations" [ref=e75] [cursor=pointer]:
            - /url: /operations
            - img [ref=e77]
            - generic [ref=e79]: Operations
      - navigation "Administration" [ref=e80]:
        - link "Settings" [ref=e81] [cursor=pointer]:
          - /url: /settings
          - img [ref=e83]
          - generic [ref=e85]: Settings
      - generic [ref=e87]:
        - button "Sign out" [ref=e88] [cursor=pointer]:
          - img [ref=e90]
          - generic [ref=e92]: Sign out
        - generic [ref=e93]: v1.0.0 · build loading-state-fixture · schema 24
    - generic [ref=e94]:
      - banner [ref=e95]:
        - paragraph [ref=e96]:
          - generic [ref=e97]: Planning & Operations
        - button "Search" [ref=e99] [cursor=pointer]:
          - img [ref=e101]
          - generic [ref=e103]:
            - generic [ref=e104]: Search
            - generic [ref=e105]: Ctrl K
        - generic [ref=e106]:
          - button "Switch to the light theme" [ref=e107]:
            - img [ref=e108]
          - generic [ref=e110]:
            - group "Language" [ref=e111]:
              - button "中" [ref=e112]
              - button "EN" [pressed] [ref=e113]
            - generic "Reconnecting" [ref=e114]:
              - generic [ref=e115]: Reconnecting
      - main [ref=e116]:
        - generic [ref=e118]:
          - generic [ref=e119]:
            - generic [ref=e120]:
              - link "Back to work" [ref=e121] [cursor=pointer]:
                - /url: /
              - heading "Planning & Operations" [level=1] [ref=e122]
              - paragraph [ref=e123]: Durable planning, automation, health, and cost observability.
            - button "Refresh" [ref=e124] [cursor=pointer]:
              - generic [ref=e125]: Refresh
          - status [ref=e126]: Loading Operations
          - generic [ref=e127]:
            - generic [ref=e128]: Search loaded Operations records
            - searchbox "Search loaded Operations records" [ref=e129]
            - generic [ref=e130]: Filters only Operations records already loaded in this view. Load more to expand the searchable set.
          - navigation "Operations sections" [ref=e131]:
            - link "Usage and cost" [ref=e132] [cursor=pointer]:
              - /url: "#operations-metrics"
            - link "Cycles" [ref=e133] [cursor=pointer]:
              - /url: "#operations-cycles"
            - link "Initiatives" [ref=e134] [cursor=pointer]:
              - /url: "#operations-initiatives"
            - link "Automation rules" [ref=e135] [cursor=pointer]:
              - /url: "#operations-automation"
            - link "Loops" [ref=e136] [cursor=pointer]:
              - /url: "#operations-loops"
            - link "Recent runs" [ref=e137] [cursor=pointer]:
              - /url: "#operations-runs"
            - link "Templates & playbooks" [ref=e138] [cursor=pointer]:
              - /url: "#operations-templates"
          - region "Usage and cost" [ref=e139]:
            - list "Usage and cost" [ref=e140]:
              - listitem "Tokens" [ref=e141]:
                - generic [ref=e143]:
                  - term [ref=e144]: Tokens
                  - definition [ref=e145]:
                    - strong [ref=e146]: 1,500
              - listitem "Runtime" [ref=e147]:
                - generic [ref=e149]:
                  - term [ref=e150]: Runtime
                  - definition [ref=e151]:
                    - strong [ref=e152]: 45s
              - listitem "Tool calls" [ref=e153]:
                - generic [ref=e155]:
                  - term [ref=e156]: Tool calls
                  - definition [ref=e157]:
                    - strong [ref=e158]: "7"
              - listitem "Unknown cost" [ref=e159]:
                - generic [ref=e161]:
                  - term [ref=e162]: Unknown cost
                  - definition [ref=e163]:
                    - strong [ref=e164]: "0"
                    - text: records
              - listitem "Known cost" [ref=e165]:
                - generic [ref=e167]:
                  - term [ref=e168]: Known cost
                  - definition [ref=e169]: No known cost
          - generic [ref=e170]:
            - generic [ref=e171]:
              - heading "Cycles" [level=2] [ref=e172]
              - status [ref=e173]:
                - generic [ref=e175]:
                  - heading "No Cycles configured" [level=2] [ref=e176]
                  - paragraph [ref=e177]: Create a Cycle when a planning window is ready.
            - generic [ref=e178]:
              - heading "Initiatives" [level=2] [ref=e179]
              - status [ref=e180]:
                - generic [ref=e182]:
                  - heading "No Initiatives configured" [level=2] [ref=e183]
                  - paragraph [ref=e184]: Initiatives will appear here when the feature has durable data.
            - generic [ref=e185]:
              - heading "Automation rules" [level=2] [ref=e186]
              - article [ref=e187]:
                - generic [ref=e188]:
                  - strong [ref=e189]: Retained browser rule
                  - generic [ref=e190]: v1 · manual
                - generic [ref=e191]: Enabled
                - button "Dry run" [active] [ref=e192]
                - button "Pause" [ref=e193]
            - generic [ref=e194]:
              - heading "Loops" [level=2] [ref=e195]
              - status [ref=e196]:
                - generic [ref=e198]:
                  - heading "No Loops configured" [level=2] [ref=e199]
                  - paragraph [ref=e200]: Agent Loops will appear after they are created through an authorized command.
            - generic [ref=e201]:
              - heading "Recent runs" [level=2] [ref=e202]
              - region "Recent runs" [ref=e203]:
                - table "Recent runs" [ref=e204]:
                  - caption [ref=e205]: Recent runs
                  - rowgroup [ref=e213]:
                    - row "Run Kind Status Attempts Session Created" [ref=e214]:
                      - columnheader "Run" [ref=e215]
                      - columnheader "Kind" [ref=e216]
                      - columnheader "Status" [ref=e217]
                      - columnheader "Attempts" [ref=e218]
                      - columnheader "Session" [ref=e219]
                      - columnheader "Created" [ref=e220]
                  - rowgroup
              - status [ref=e221]:
                - generic [ref=e223]:
                  - heading "No run history yet" [level=2] [ref=e224]
                  - paragraph [ref=e225]: Durable run history will appear after an automation or loop executes.
            - generic [ref=e226]:
              - heading "Templates & playbooks" [level=2] [ref=e227]
              - status [ref=e228]:
                - generic [ref=e230]:
                  - heading "No Templates configured" [level=2] [ref=e231]
                  - paragraph [ref=e232]: Templates and playbooks will appear when they are available to this workspace.
```

# Test source

```ts
  644 |     const workflow = settings.locator('[aria-labelledby="workflow-settings-heading"]')
  645 |     await expect(workflow.locator('.skeleton-list')).toBeVisible()
  646 |     await expect(workflow).not.toHaveAttribute('aria-busy')
  647 |     await expect(workflow.locator('[aria-busy="true"]')).toHaveCount(1)
  648 | 
  649 |     const state = { category: 'backlog', color: '#a8a29e', id: 'state-backlog', name: 'Backlog', revision: 1 }
  650 |     const statesResponse = { body: { items: [state], nextCursor: null } } satisfies JsonResponse
  651 |     routes.setRequest('GET', statesPath, statesResponse)
  652 |     statesPending.resolve(statesResponse)
  653 |     const stateRow = workflow.locator('.workflow-state-list article').first()
  654 |     await expect(stateRow).toContainText('Backlog')
  655 | 
  656 |     const stateName = workflow.locator('input[name="name"]')
  657 |     await stateName.fill('Review')
  658 |     await stateName.evaluate(element => { element.dataset.loadingIdentity = 'retained-state-form' })
  659 |     const refreshPending = deferredResponse()
  660 |     const pagedStatesPath = `${statesPath}?limit=100`
  661 |     const priorRequests = routes.requests.filter(request => request === pagedStatesPath).length
  662 |     routes.setRequest('POST', statesPath, { body: { ...state, id: 'state-review', name: 'Review' } })
  663 |     routes.setRequest('GET', pagedStatesPath, refreshPending.promise)
  664 |     await workflow.locator('form').evaluate((form: HTMLFormElement) => form.requestSubmit())
  665 |     await routes.waitFor(pagedStatesPath, priorRequests + 1)
  666 |     await expect(workflow).toHaveAttribute('aria-busy', 'true')
  667 |     await expect(stateRow).toContainText('Backlog')
  668 |     await expect(stateName).toHaveAttribute('data-loading-identity', 'retained-state-form')
  669 |     await expect(stateName).toBeFocused()
  670 | 
  671 |     routes.setRequest('GET', pagedStatesPath, statesResponse)
  672 |     refreshPending.resolve({
  673 |       body: { error: { code: 'TEMPORARY_UNAVAILABLE', correlationId: 'safe-state-refresh', message: 'Please retry.' } },
  674 |       status: 500,
  675 |     })
  676 |     await expect(workflow).not.toHaveAttribute('aria-busy')
  677 |     await expect(stateRow).toContainText('Backlog')
  678 |     await expect(stateName).toHaveAttribute('data-loading-identity', 'retained-state-form')
  679 |     await expect(stateName).toBeFocused()
  680 |     await expect(workflow.locator('[role="status"]')).toHaveCount(0)
  681 |     await expect(page.locator('.settings-page [role="alert"]')).toContainText('Unable to load Settings.')
  682 |     await expect(page.getByRole('button', { name: 'Retry', exact: true })).toBeVisible()
  683 |     await expect(page.getByText('safe-state-refresh')).toHaveCount(0)
  684 |     expect(routes.unexpected).toEqual([])
  685 |   })
  686 | })
  687 | 
  688 | test.describe('Task 6.4 Operations loading authority', () => {
  689 |   test.use({ viewport: { height: 900, width: 1440 } })
  690 | 
  691 |   test('uses real pending owners, resolves independently, and retains focus through refresh failure', async ({ page }) => {
  692 |     const routes = new RouteScenarios()
  693 |     await routes.install(page)
  694 |     await page.context().addCookies([{ name: 'workmesh_locale', value: 'en', url: webUrl }])
  695 | 
  696 |     const featuresPending = deferredResponse()
  697 |     routes.set('/api/v1/features', featuresPending.promise)
  698 |     await page.goto('/operations', { waitUntil: 'domcontentloaded' })
  699 | 
  700 |     const featureStatus = page.getByRole('status', { name: 'Loading Operations' })
  701 |     await expect(featureStatus).toBeVisible()
  702 |     await expect(page.locator('.operations-loading')).not.toHaveAttribute('aria-busy')
  703 |     await expect(page.locator('.operations-loading [aria-busy="true"]')).toHaveCount(1)
  704 | 
  705 |     const pendingCollections = new Map<string, ReturnType<typeof deferredResponse>>()
  706 |     for (const path of Object.keys(collectionPayloads)) {
  707 |       const pending = deferredResponse()
  708 |       pendingCollections.set(path, pending)
  709 |       routes.set(path, pending.promise)
  710 |     }
  711 |     const usagePending = deferredResponse()
  712 |     routes.set('/api/v1/usage-summary', usagePending.promise)
  713 |     routes.set('/api/v1/features', allFeatures)
  714 |     featuresPending.resolve(allFeatures)
  715 | 
  716 |     await expect(page.locator('.operations-usage-loading .skeleton-list')).toBeVisible()
  717 |     await expect(page.locator('.operations-grid .skeleton-list')).toHaveCount(6)
  718 |     await expect(page.locator('.operations-grid section[aria-busy="true"]')).toHaveCount(0)
  719 |     await expect(page.locator('.operations-grid .skeleton-list[aria-busy="true"]')).toHaveCount(6)
  720 | 
  721 |     routes.set('/api/v1/usage-summary', usage)
  722 |     usagePending.resolve(usage)
  723 |     for (const [path, pending] of pendingCollections) {
  724 |       const response = collectionPayloads[path]!
  725 |       routes.set(path, response)
  726 |       pending.resolve(response)
  727 |     }
  728 | 
  729 |     const dryRun = page.getByRole('button', { name: 'Dry run' })
  730 |     await expect(dryRun).toBeVisible()
  731 |     await dryRun.focus()
  732 |     const automation = page.getByTestId('automation-panel')
  733 |     await dryRun.evaluate(element => { element.dataset.loadingIdentity = 'retained-rule-control' })
  734 | 
  735 |     const rulesFailure = deferredResponse()
  736 |     routes.set('/api/v1/automation-rules', rulesFailure.promise)
  737 |     const rulesPath = '/api/v1/automation-rules?limit=100'
  738 |     const priorRuleRequests = routes.requests.filter(request => request === rulesPath).length
  739 |     await page.getByRole('button', { name: 'Refresh' }).evaluate((button: HTMLButtonElement) => button.click())
  740 |     await routes.waitFor(rulesPath, priorRuleRequests + 1)
  741 |     await expect(automation).toHaveAttribute('aria-busy', 'true')
  742 |     await expect(dryRun).toHaveAttribute('data-loading-identity', 'retained-rule-control')
  743 |     await expect(dryRun).toBeFocused()
> 744 |     await expect(page.locator('.operations-tab > .sr-only[role="status"]')).toHaveCount(1)
      |                                                                             ^ Error: expect(locator).toHaveCount(expected) failed
  745 | 
  746 |     routes.set('/api/v1/automation-rules', collectionPayloads['/api/v1/automation-rules']!)
  747 |     rulesFailure.resolve({
  748 |       body: { error: { code: 'TEMPORARY_UNAVAILABLE', correlationId: 'safe-browser-diagnostic', message: 'Please retry.' } },
  749 |       status: 500,
  750 |     })
  751 |     await expect(automation).not.toHaveAttribute('aria-busy')
  752 |     await expect(dryRun).toHaveAttribute('data-loading-identity', 'retained-rule-control')
  753 |     await expect(dryRun).toBeFocused()
  754 |     await expect(page.getByText('Retained browser rule')).toBeVisible()
  755 |     await expect(automation.getByText('Unable to load Operations.')).toBeVisible()
  756 |     await expect(page.locator('.operations-tab > .sr-only[role="status"]')).toHaveCount(0)
  757 |     expect(routes.unexpected).toEqual([])
  758 |   })
  759 | })
  760 | 
  761 | const loadingViewports = [
  762 |   { height: 844, width: 390 },
  763 |   { height: 900, width: 1440 },
  764 |   { height: 1080, width: 1920 },
  765 | ] as const
  766 | 
  767 | for (const viewport of loadingViewports) {
  768 |   test.describe(`Task 6.4 loading geometry at ${viewport.width}px`, () => {
  769 |     test.use({ viewport })
  770 | 
  771 |     test('fills real Operations, Settings and Board panels without a narrow skeleton island', async ({ page }, testInfo) => {
  772 |       const routes = new RouteScenarios()
  773 |       await routes.install(page)
  774 |       await page.context().addCookies([{ name: 'workmesh_locale', value: 'en', url: webUrl }])
  775 |       await mkdir(evidenceRoot, { recursive: true })
  776 | 
  777 |       const featuresPending = deferredResponse()
  778 |       const usageGeometryPending = deferredResponse()
  779 |       routes.set('/api/v1/features', featuresPending.promise)
  780 |       routes.set('/api/v1/usage-summary', usageGeometryPending.promise)
  781 |       for (const [path, response] of Object.entries(collectionPayloads)) routes.set(path, response)
  782 |       await page.goto('/operations', { waitUntil: 'domcontentloaded' })
  783 |       const operationsHeader = page.locator('.operations-tab > .operations-header')
  784 |       await expect(operationsHeader).toBeVisible()
  785 |       await operationsHeader.evaluate(element => { element.dataset.loadingIdentity = 'stable-operations-header' })
  786 |       const operationsHeaderPending = (await measureRects(page, '.operations-tab > .operations-header'))[0]!
  787 |       const operationsPending = await measureSkeleton(page, '.operations-loading .skeleton-list', { panelSelector: '.operations-tab' })
  788 |       expectContainedSkeleton(operationsPending, viewport.width <= 960 ? 1 : 2)
  789 |       expect(operationsPending.busyOwners).toBe(1)
  790 |       await page.screenshot({ path: join(evidenceRoot, `loading-operations-pending-${viewport.width}x${viewport.height}.png`) })
  791 | 
  792 |       routes.set('/api/v1/features', allFeatures)
  793 |       featuresPending.resolve(allFeatures)
  794 |       await expect(page.locator('.operations-usage-loading .skeleton-list')).toBeVisible()
  795 |       await expect(page.locator('.operations-grid > .operations-panel')).toHaveCount(6)
  796 |       const usagePending = await measureSkeleton(page, '.operations-usage-loading .skeleton-list', { panelSelector: '.operations-metrics' })
  797 |       // Task 6.5 supersedes the original 1920px five-column snapshot: keeping
  798 |       // the metrics root at 85% of the workspace yields four readable columns
  799 |       // and two rows without changing the loading owner or pending/resolved seam.
  800 |       const expectedUsageColumns = viewport.width <= 560 ? 1 : viewport.width >= 1440 ? 4 : 5
  801 |       expectContainedSkeleton(usagePending, expectedUsageColumns)
  802 |       expect(usagePending.cells).toHaveLength(5)
  803 |       expect(usagePending.focusableCount).toBe(0)
  804 |       expect(usagePending.document.overflow).toBe(0)
  805 |       if (viewport.width === 1920) {
  806 |         expect(usagePending.root.width / usagePending.main.width).toBeGreaterThanOrEqual(.85)
  807 |         expect(new Set(usagePending.cells.map(cell => Math.round(cell.top))).size).toBe(2)
  808 |       }
  809 |       routes.set('/api/v1/usage-summary', usage)
  810 |       usageGeometryPending.resolve(usage)
  811 |       await expect(page.locator('.operations-metrics-grid > .operations-metric-card')).toHaveCount(5)
  812 |       const usageResolved = await measureResolvedGrid(page, '.operations-metrics-grid', ':scope > .operations-metric-card')
  813 |       expect(usageResolved.columns).toBe(usagePending.columns)
  814 |       expect(usageResolved.document.overflow).toBe(0)
  815 |       expect(Math.abs(usageResolved.root.width - usagePending.root.width)).toBeLessThanOrEqual(2)
  816 |       usageResolved.items.forEach((card, index) => expect(Math.abs(card.width - usagePending.cells[index]!.width)).toBeLessThanOrEqual(2))
  817 |       if (viewport.width === 1920)
  818 |         expect(new Set(usageResolved.items.map(card => Math.round(card.top))).size).toBe(2)
  819 |       const operationsResolved = await measureRects(page, '.operations-grid > .operations-panel')
  820 |       const operationsContainment = await measureResolvedContainment(page)
  821 |       const operationsHeaderResolved = (await measureRects(page, '.operations-tab > .operations-header'))[0]!
  822 |       expect(operationsContainment.document.overflow).toBe(0)
  823 |       await expect(operationsHeader).toHaveAttribute('data-loading-identity', 'stable-operations-header')
  824 |       expect(Math.abs(operationsHeaderPending.top - operationsHeaderResolved.top)).toBeLessThanOrEqual(2)
  825 |       expect(Math.abs(operationsPending.cells[0]!.width - operationsResolved[0]!.width)).toBeLessThanOrEqual(2)
  826 |       expect(Math.abs(operationsPending.cells[1]!.width - operationsResolved[1]!.width)).toBeLessThanOrEqual(2)
  827 |       expect(Math.abs(operationsPending.cells[2]!.width - operationsResolved[2]!.width)).toBeLessThanOrEqual(2)
  828 |       await persistEvidence(page, testInfo, `loading-operations-geometry-${viewport.width}x${viewport.height}`, {
  829 |         header: { pending: operationsHeaderPending, resolved: operationsHeaderResolved },
  830 |         pending: operationsPending,
  831 |         resolvedContainment: operationsContainment,
  832 |         resolvedPanels: operationsResolved,
  833 |         usage: { pending: usagePending, resolved: usageResolved },
  834 |       })
  835 | 
  836 |       const teamsPending = deferredResponse()
  837 |       const statesGeometryPending = deferredResponse()
  838 |       const statesPath = `/api/v1/teams/${team.id}/states`
  839 |       routes.setRequest('GET', '/api/v1/teams', teamsPending.promise)
  840 |       routes.setRequest('GET', statesPath, statesGeometryPending.promise)
  841 |       await page.goto('/settings?tab=workspace', { waitUntil: 'domcontentloaded' })
  842 |       const settingsHeader = page.locator('.settings-page > header').first()
  843 |       await settingsHeader.evaluate(element => { element.dataset.loadingIdentity = 'stable-settings-header' })
  844 |       const settingsHeaderPending = (await measureRects(page, '.settings-page > header'))[0]!
```