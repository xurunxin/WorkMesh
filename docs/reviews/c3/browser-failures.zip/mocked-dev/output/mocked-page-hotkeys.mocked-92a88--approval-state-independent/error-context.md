# Instructions

- Following Playwright test failed.
- Explain why, be concise, respect Playwright best practices.
- Provide a snippet of code with the fix, if possible.

# Test info

- Name: mocked\page-hotkeys.mocked.spec.ts >> page hotkeys at 390px >> wraps Agent links, preserves native controls and keeps focus, Peek and approval state independent
- Location: e2e\mocked\page-hotkeys.mocked.spec.ts:279:5

# Error details

```
Error: expect(locator).toHaveCount(expected) failed

Locator:  locator('[data-agent-roving-link="true"]')
Expected: 2
Received: 0
Timeout:  10000ms

Call log:
  - Expect "toHaveCount" with timeout 10000ms
  - waiting for locator('[data-agent-roving-link="true"]')
    23 × locator resolved to 0 elements
       - unexpected value "0"

```

# Page snapshot

```yaml
- generic [ref=e1]:
  - button "Open Next.js Dev Tools" [ref=e7] [cursor=pointer]:
    - img [ref=e8]
  - alert [ref=e11]
  - generic [ref=e12]:
    - link "跳到主要内容" [ref=e13] [cursor=pointer]:
      - /url: "#workmesh-main"
    - generic [ref=e14]:
      - banner [ref=e15]:
        - group [ref=e16]:
          - generic "菜单" [ref=e17] [cursor=pointer]
        - button "搜索" [ref=e19] [cursor=pointer]:
          - img [ref=e21]
          - generic [ref=e24]: 搜索
      - main [ref=e25]:
        - generic [ref=e26]:
          - generic [ref=e27]:
            - generic [ref=e28]:
              - paragraph [ref=e29]: 人类控制面
              - heading "智能体" [level=1] [ref=e30]
              - paragraph [ref=e31]: 监控委派工作、处理审批，并在不接触凭据的情况下诊断连接。
            - button "刷新" [ref=e32] [cursor=pointer]:
              - generic [ref=e33]: 刷新
          - alert [ref=e34]:
            - generic [ref=e36]:
              - heading "智能体工作区需要关注" [level=2] [ref=e37]
              - paragraph [ref=e38]: "[ { \"code\": \"invalid_type\", \"expected\": \"string\", \"received\": \"undefined\", \"path\": [ \"icon\" ], \"message\": \"Required\" }, { \"code\": \"invalid_type\", \"expected\": \"string\", \"received\": \"undefined\", \"path\": [ \"endpoint_url\" ], \"message\": \"Required\" }, { \"code\": \"invalid_type\", \"expected\": \"array\", \"received\": \"undefined\", \"path\": [ \"output_artifact_types\" ], \"message\": \"Required\" }, { \"code\": \"invalid_type\", \"expected\": \"object\", \"received\": \"undefined\", \"path\": [ \"metadata\" ], \"message\": \"Required\" }, { \"expected\": \"'active' | 'archived'\", \"received\": \"undefined\", \"code\": \"invalid_type\", \"path\": [ \"lifecycle_status\" ], \"message\": \"Required\" }, { \"code\": \"invalid_type\", \"expected\": \"string\", \"received\": \"undefined\", \"path\": [ \"archived_at\" ], \"message\": \"Required\" }, { \"code\": \"invalid_type\", \"expected\": \"string\", \"received\": \"undefined\", \"path\": [ \"archived_by_actor_id\" ], \"message\": \"Required\" }, { \"code\": \"invalid_type\", \"expected\": \"string\", \"received\": \"undefined\", \"path\": [ \"archived_reason\" ], \"message\": \"Required\" }, { \"code\": \"invalid_type\", \"expected\": \"string\", \"received\": \"undefined\", \"path\": [ \"created_at\" ], \"message\": \"Required\" }, { \"code\": \"invalid_type\", \"expected\": \"string\", \"received\": \"undefined\", \"path\": [ \"updated_at\" ], \"message\": \"Required\" } ]"
            - button "重试" [ref=e39] [cursor=pointer]:
              - generic [ref=e40]: 重试
          - generic [ref=e41]:
            - generic [ref=e42]:
              - generic [ref=e43]: 智能体
              - combobox "智能体工作区分区" [ref=e44]:
                - option "智能体" [selected]
                - option "连接"
                - option "自动接入策略"
                - option "已归档"
            - tabpanel "智能体" [ref=e45]:
              - region "注册表" [ref=e46]:
                - generic [ref=e47]:
                  - generic [ref=e48]:
                    - paragraph [ref=e49]: 注册表
                    - heading "智能体" [level=2] [ref=e50]
                    - paragraph [ref=e51]: 先检查定义；仅在需要审阅时展开团队权限。
                  - generic [ref=e52]:
                    - button "全部" [ref=e53]
                    - button "活跃" [ref=e54]
                    - button "停用" [ref=e55]
                - group "智能体筛选" [ref=e56]:
                  - generic [ref=e57]:
                    - generic [ref=e58]: 名称
                    - searchbox "名称" [active] [ref=e59]
                  - generic [ref=e60]:
                    - generic [ref=e61]: 团队
                    - combobox "团队" [ref=e62]:
                      - option "全部团队" [selected]
                      - option "WorkMesh Product"
                  - generic [ref=e63]:
                    - generic [ref=e64]: 能力
                    - combobox "能力" [ref=e65]:
                      - option "全部能力" [selected]
                  - generic [ref=e66]:
                    - generic [ref=e67]: 状态
                    - combobox "状态" [ref=e68]:
                      - option "全部" [selected]
                      - option "活跃"
                      - option "停用"
```

# Test source

```ts
  188 |       await expect.poll(() => new URL(page.url()).searchParams.get('search')).toBeNull()
  189 |       await page.evaluate(() => (document.activeElement as HTMLElement | null)?.blur())
  190 | 
  191 |       const contextUrl = page.url()
  192 |       const select = page.locator('select:visible').first()
  193 |       await select.focus()
  194 |       await pressChord(page, 'a')
  195 |       await expect(select).toBeFocused()
  196 |       expect(page.url()).toBe(contextUrl)
  197 | 
  198 |       const button = page.getByTestId('command-center-trigger')
  199 |       await button.focus()
  200 |       await pressChord(page, 's')
  201 |       await expect(button).toBeFocused()
  202 |       expect(page.url()).toBe(contextUrl)
  203 | 
  204 |       const link = page.locator('a:visible').first()
  205 |       await link.focus()
  206 |       await pressChord(page, 'a')
  207 |       await expect(link).toBeFocused()
  208 |       expect(page.url()).toBe(contextUrl)
  209 | 
  210 |       await page.evaluate(() => {
  211 |         const editable = document.createElement('div')
  212 |         editable.contentEditable = 'plaintext-only'
  213 |         editable.dataset.hotkeyContext = 'contenteditable'
  214 |         editable.tabIndex = 0
  215 |         editable.textContent = 'Editable shortcut guard'
  216 |         document.body.append(editable)
  217 |       })
  218 |       const editable = page.locator('[data-hotkey-context="contenteditable"]')
  219 |       await editable.focus()
  220 |       await pressChord(page, 's')
  221 |       await expect(editable).toBeFocused()
  222 |       expect(page.url()).toBe(contextUrl)
  223 |       await editable.evaluate(element => element.remove())
  224 |       await page.evaluate(() => (document.activeElement as HTMLElement | null)?.blur())
  225 | 
  226 |       const stableHomeUrl = page.url()
  227 |       await page.keyboard.press('g')
  228 |       await page.keyboard.press('z')
  229 |       expect(page.url()).toBe(stableHomeUrl)
  230 |       await page.keyboard.press('g')
  231 |       await page.waitForTimeout(1_050)
  232 |       await page.keyboard.press('a')
  233 |       expect(page.url()).toBe(stableHomeUrl)
  234 | 
  235 |       await pressChord(page, 'a')
  236 |       await expect(page).toHaveURL(`${webUrl}/agents`)
  237 | 
  238 |       await page.goto('/?view=my-work')
  239 |       await page.keyboard.press('/')
  240 |       await expect(page.getByTestId('command-center')).toHaveCount(1)
  241 |       await page.evaluate(() => (document.activeElement as HTMLElement | null)?.blur())
  242 |       const modalUrl = page.url()
  243 |       await pressChord(page, 'a')
  244 |       expect(page.url()).toBe(modalUrl)
  245 |       await page.keyboard.press('f')
  246 |       expect(page.url()).toBe(modalUrl)
  247 |       await page.keyboard.press('/')
  248 |       await expect(page.getByTestId('command-center')).toHaveCount(1)
  249 |       await page.getByRole('button', { name: /关闭|Close/ }).click()
  250 |       await page.keyboard.press('Control+K')
  251 |       await expect(page.getByTestId('command-center')).toHaveCount(1)
  252 |       await page.getByRole('button', { name: /关闭|Close/ }).click()
  253 | 
  254 |       for (const path of ['/?view=inbox', '/?view=guidance', '/settings']) {
  255 |         await page.goto(path)
  256 |         await expect(page.locator('[data-hotkey-filter="true"]')).toHaveCount(0)
  257 |         const anchor = page.locator('a:visible').first()
  258 |         await anchor.focus()
  259 |         await page.keyboard.press('f')
  260 |         await expect(anchor).toBeFocused()
  261 |       }
  262 | 
  263 |       await page.goto('/operations')
  264 |       const operationsSearch = page.locator('[data-hotkey-filter="true"]')
  265 |       await expect(operationsSearch).toHaveCount(1)
  266 |       await page.keyboard.press('f')
  267 |       await expect(operationsSearch).toBeFocused()
  268 |       await attachGeometry(testInfo, `operations-filter-${viewport.width}`, operationsSearch)
  269 | 
  270 |       await page.evaluate(() => (document.activeElement as HTMLElement | null)?.blur())
  271 |       await pressChord(page, 's')
  272 |       await expect(page).toHaveURL(`${webUrl}/settings`)
  273 |       await page.waitForTimeout(300)
  274 |       await page.evaluate(() => (document.activeElement as HTMLElement | null)?.blur())
  275 |       await pressChord(page, 'i')
  276 |       await expect(page).toHaveURL(`${webUrl}/?view=my-work`)
  277 |     })
  278 | 
  279 |     test('wraps Agent links, preserves native controls and keeps focus, Peek and approval state independent', async ({ page }, testInfo) => {
  280 |       await installHotkeyFixtures(page)
  281 |       await page.goto('/agents')
  282 |       const links = page.locator('[data-agent-roving-link="true"]')
  283 |       const agentSearch = page.locator('[data-hotkey-filter="true"]')
  284 |       await expect(agentSearch).toHaveCount(1)
  285 |       await page.evaluate(() => (document.activeElement as HTMLElement | null)?.blur())
  286 |       await page.keyboard.press('f')
  287 |       await expect(agentSearch).toBeFocused()
> 288 |       await expect(links).toHaveCount(2)
      |                           ^ Error: expect(locator).toHaveCount(expected) failed
  289 |       await expect(links.nth(0)).toHaveAttribute('tabindex', '0')
  290 |       await expect(links.nth(1)).toHaveAttribute('tabindex', '-1')
  291 | 
  292 |       for (const tab of ['sessions', 'approvals'] as const) {
  293 |         await chooseAgentsTab(page, tab)
  294 |         await expect(page.locator('[data-hotkey-filter="true"]')).toHaveCount(0)
  295 |         await page.evaluate(() => (document.activeElement as HTMLElement | null)?.blur())
  296 |         await page.keyboard.press('f')
  297 |         expect(await page.evaluate(() => document.activeElement === document.body)).toBe(true)
  298 |       }
  299 |       await chooseAgentsTab(page, 'agents')
  300 | 
  301 |       await links.nth(0).focus()
  302 |       await page.keyboard.press('j')
  303 |       await expect(links.nth(1)).toBeFocused()
  304 |       await page.keyboard.press('ArrowDown')
  305 |       await expect(links.nth(0)).toBeFocused()
  306 |       await page.keyboard.press('k')
  307 |       await expect(links.nth(1)).toBeFocused()
  308 |       await page.keyboard.press('ArrowUp')
  309 |       await expect(links.nth(0)).toBeFocused()
  310 | 
  311 |       if (viewport.width === 1920) {
  312 |         await chooseAgentsTab(page, 'approvals')
  313 |         const approval = page.getByRole('checkbox').last()
  314 |         await approval.check()
  315 |         await chooseAgentsTab(page, 'agents')
  316 |         await links.nth(0).focus()
  317 |         await page.keyboard.press('Space')
  318 |         await expect(page.locator('.agent-peek')).toBeVisible()
  319 |         await page.keyboard.press('Escape')
  320 |         await expect(links.nth(0)).toBeFocused()
  321 |         await page.keyboard.press('Escape')
  322 |         await chooseAgentsTab(page, 'approvals')
  323 |         await expect(page.getByRole('checkbox').last()).not.toBeChecked()
  324 |         await chooseAgentsTab(page, 'agents')
  325 |       }
  326 | 
  327 |       await links.nth(0).focus()
  328 |       await page.keyboard.press('Space')
  329 |       await expect(page.locator('.agent-peek')).toBeVisible()
  330 |       await page.keyboard.press('/')
  331 |       await expect(page.getByTestId('command-center')).toHaveCount(0)
  332 |       await page.keyboard.press('Escape')
  333 |       await expect(links.nth(0)).toBeFocused()
  334 | 
  335 |       const firstCard = page.getByTestId('agent-registry-agent/one')
  336 |       const manage = firstCard.getByRole('button')
  337 |       await manage.focus()
  338 |       await page.keyboard.press('Space')
  339 |       await expect(page.locator('.team-access-drawer')).toBeVisible()
  340 |       await expect(page.locator('.agent-peek')).toHaveCount(0)
  341 |       await page.keyboard.press('Escape')
  342 |       await expect(manage).toBeFocused()
  343 | 
  344 |       const search = page.locator('[data-hotkey-filter="true"]')
  345 |       await search.fill('Percent')
  346 |       await expect(links).toHaveCount(1)
  347 |       await expect(links.first()).toHaveAttribute('data-agent-id', 'agent%two')
  348 |       await expect(links.first()).toHaveAttribute('tabindex', '0')
  349 |       await search.fill('no matching agent')
  350 |       await expect(links).toHaveCount(0)
  351 |       await search.fill('')
  352 |       await expect(links).toHaveCount(2)
  353 | 
  354 |       const targetIndex = viewport.width === 390 ? 0 : 1
  355 |       const target = links.nth(targetIndex)
  356 |       const expectedPath = targetIndex === 0 ? '/agents/agent%2Fone' : '/agents/agent%25two'
  357 |       await expect(target).toHaveAttribute('href', expectedPath)
  358 |       await target.focus()
  359 |       await attachGeometry(testInfo, `agent-roving-${viewport.width}`, target)
  360 |       await page.keyboard.press('Enter')
  361 |       await expect(page).toHaveURL(`${webUrl}${expectedPath}`)
  362 |     })
  363 |   })
  364 | }
  365 | 
```