# Instructions

- Following Playwright test failed.
- Explain why, be concise, respect Playwright best practices.
- Provide a snippet of code with the fix, if possible.

# Test info

- Name: mocked\loading-states.mocked.spec.ts >> Task 6.4 loading geometry at 390px >> fills real Operations, Settings and Board panels without a narrow skeleton island
- Location: e2e\mocked\loading-states.mocked.spec.ts:771:5

# Error details

```
Error: expect(locator).toHaveCount(expected) failed

Locator:  locator('.operations-metrics-grid > .operations-metric-card')
Expected: 5
Received: 0
Timeout:  10000ms

Call log:
  - Expect "toHaveCount" with timeout 10000ms
  - waiting for locator('.operations-metrics-grid > .operations-metric-card')
    23 × locator resolved to 0 elements
       - unexpected value "0"

```

# Page snapshot

```yaml
- generic [active] [ref=e1]:
  - button "Open Next.js Dev Tools" [ref=e7] [cursor=pointer]:
    - img [ref=e8]
  - alert [ref=e11]
  - generic [ref=e12]:
    - link "Skip to content" [ref=e13] [cursor=pointer]:
      - /url: "#workmesh-main"
    - generic [ref=e14]:
      - banner [ref=e15]:
        - group [ref=e16]:
          - generic "Menu" [ref=e17] [cursor=pointer]
        - button "Search" [ref=e19] [cursor=pointer]:
          - img [ref=e21]
          - generic [ref=e24]: Search
      - main [ref=e25]:
        - generic [ref=e27]:
          - generic [ref=e28]:
            - generic [ref=e29]:
              - link "Back to work" [ref=e30] [cursor=pointer]:
                - /url: /
              - heading "Planning & Operations" [level=1] [ref=e31]
              - paragraph [ref=e32]: Durable planning, automation, health, and cost observability.
            - button "Refresh" [ref=e33] [cursor=pointer]:
              - generic [ref=e34]: Refresh
          - generic [ref=e35]:
            - generic [ref=e36]: Search loaded Operations records
            - searchbox "Search loaded Operations records" [ref=e37]
            - generic [ref=e38]: Filters only Operations records already loaded in this view. Load more to expand the searchable set.
          - navigation "Operations sections" [ref=e39]:
            - link "Usage and cost" [ref=e40] [cursor=pointer]:
              - /url: "#operations-metrics"
            - link "Cycles" [ref=e41] [cursor=pointer]:
              - /url: "#operations-cycles"
            - link "Initiatives" [ref=e42] [cursor=pointer]:
              - /url: "#operations-initiatives"
            - link "Automation rules" [ref=e43] [cursor=pointer]:
              - /url: "#operations-automation"
            - link "Loops" [ref=e44] [cursor=pointer]:
              - /url: "#operations-loops"
            - link "Recent runs" [ref=e45] [cursor=pointer]:
              - /url: "#operations-runs"
            - link "Templates & playbooks" [ref=e46] [cursor=pointer]:
              - /url: "#operations-templates"
          - region "Usage and cost" [ref=e47]:
            - list "Usage and cost" [ref=e48]:
              - listitem "Tokens" [ref=e49]:
                - generic [ref=e51]:
                  - term [ref=e52]: Tokens
                  - definition [ref=e53]:
                    - strong [ref=e54]: 1,500
              - listitem "Runtime" [ref=e55]:
                - generic [ref=e57]:
                  - term [ref=e58]: Runtime
                  - definition [ref=e59]:
                    - strong [ref=e60]: 45s
              - listitem "Tool calls" [ref=e61]:
                - generic [ref=e63]:
                  - term [ref=e64]: Tool calls
                  - definition [ref=e65]:
                    - strong [ref=e66]: "7"
              - listitem "Unknown cost" [ref=e67]:
                - generic [ref=e69]:
                  - term [ref=e70]: Unknown cost
                  - definition [ref=e71]:
                    - strong [ref=e72]: "0"
                    - text: records
              - listitem "Known cost" [ref=e73]:
                - generic [ref=e75]:
                  - term [ref=e76]: Known cost
                  - definition [ref=e77]: No known cost
          - generic [ref=e78]:
            - generic [ref=e79]:
              - heading "Cycles" [level=2] [ref=e80]
              - status [ref=e81]:
                - generic [ref=e83]:
                  - heading "No Cycles configured" [level=2] [ref=e84]
                  - paragraph [ref=e85]: Create a Cycle when a planning window is ready.
            - generic [ref=e86]:
              - heading "Initiatives" [level=2] [ref=e87]
              - status [ref=e88]:
                - generic [ref=e90]:
                  - heading "No Initiatives configured" [level=2] [ref=e91]
                  - paragraph [ref=e92]: Initiatives will appear here when the feature has durable data.
            - generic [ref=e93]:
              - heading "Automation rules" [level=2] [ref=e94]
              - article [ref=e95]:
                - generic [ref=e96]:
                  - strong [ref=e97]: Retained browser rule
                  - generic [ref=e98]: v1 · manual
                - generic [ref=e99]: Enabled
                - button "Dry run" [ref=e100]
                - button "Pause" [ref=e101]
            - generic [ref=e102]:
              - heading "Loops" [level=2] [ref=e103]
              - status [ref=e104]:
                - generic [ref=e106]:
                  - heading "No Loops configured" [level=2] [ref=e107]
                  - paragraph [ref=e108]: Agent Loops will appear after they are created through an authorized command.
            - generic [ref=e109]:
              - heading "Recent runs" [level=2] [ref=e110]
              - region "Recent runs" [ref=e111]:
                - table "Recent runs" [ref=e112]:
                  - caption [ref=e113]: Recent runs
                  - rowgroup [ref=e121]:
                    - row "Run Kind Status Attempts Session Created" [ref=e122]:
                      - columnheader "Run" [ref=e123]
                      - columnheader "Kind" [ref=e124]
                      - columnheader "Status" [ref=e125]
                      - columnheader "Attempts" [ref=e126]
                      - columnheader "Session" [ref=e127]
                      - columnheader "Created" [ref=e128]
                  - rowgroup
              - status [ref=e129]:
                - generic [ref=e131]:
                  - heading "No run history yet" [level=2] [ref=e132]
                  - paragraph [ref=e133]: Durable run history will appear after an automation or loop executes.
            - generic [ref=e134]:
              - heading "Templates & playbooks" [level=2] [ref=e135]
              - status [ref=e136]:
                - generic [ref=e138]:
                  - heading "No Templates configured" [level=2] [ref=e139]
                  - paragraph [ref=e140]: Templates and playbooks will appear when they are available to this workspace.
```

# Test source

```ts
  711 |     const usagePending = deferredResponse()
  712 |     routes.set('/api/v1/usage-summary', usagePending.promise)
  713 |     routes.set('/api/v1/features', allFeatures)
  714 |     featuresPending.resolve(allFeatures)
  715 | 
  716 |     await expect(page.locator('.operations-usage-loading .skeleton-list')).toBeVisible()
  717 |     await expect(page.locator('.operations-grid .skeleton-list')).toHaveCount(6)
  718 |     await expect(page.locator('.operations-grid section[aria-busy="true"]')).toHaveCount(0)
  719 |     await expect(page.locator('.operations-grid .skeleton-list[aria-busy="true"]')).toHaveCount(6)
  720 | 
  721 |     routes.set('/api/v1/usage-summary', usage)
  722 |     usagePending.resolve(usage)
  723 |     for (const [path, pending] of pendingCollections) {
  724 |       const response = collectionPayloads[path]!
  725 |       routes.set(path, response)
  726 |       pending.resolve(response)
  727 |     }
  728 | 
  729 |     const dryRun = page.getByRole('button', { name: 'Dry run' })
  730 |     await expect(dryRun).toBeVisible()
  731 |     await dryRun.focus()
  732 |     const automation = page.getByTestId('automation-panel')
  733 |     await dryRun.evaluate(element => { element.dataset.loadingIdentity = 'retained-rule-control' })
  734 | 
  735 |     const rulesFailure = deferredResponse()
  736 |     routes.set('/api/v1/automation-rules', rulesFailure.promise)
  737 |     const rulesPath = '/api/v1/automation-rules?limit=100'
  738 |     const priorRuleRequests = routes.requests.filter(request => request === rulesPath).length
  739 |     await page.getByRole('button', { name: 'Refresh' }).evaluate((button: HTMLButtonElement) => button.click())
  740 |     await routes.waitFor(rulesPath, priorRuleRequests + 1)
  741 |     await expect(automation).toHaveAttribute('aria-busy', 'true')
  742 |     await expect(dryRun).toHaveAttribute('data-loading-identity', 'retained-rule-control')
  743 |     await expect(dryRun).toBeFocused()
  744 |     await expect(page.locator('.operations-tab > .sr-only[role="status"]')).toHaveCount(1)
  745 | 
  746 |     routes.set('/api/v1/automation-rules', collectionPayloads['/api/v1/automation-rules']!)
  747 |     rulesFailure.resolve({
  748 |       body: { error: { code: 'TEMPORARY_UNAVAILABLE', correlationId: 'safe-browser-diagnostic', message: 'Please retry.' } },
  749 |       status: 500,
  750 |     })
  751 |     await expect(automation).not.toHaveAttribute('aria-busy')
  752 |     await expect(dryRun).toHaveAttribute('data-loading-identity', 'retained-rule-control')
  753 |     await expect(dryRun).toBeFocused()
  754 |     await expect(page.getByText('Retained browser rule')).toBeVisible()
  755 |     await expect(automation.getByText('Unable to load Operations.')).toBeVisible()
  756 |     await expect(page.locator('.operations-tab > .sr-only[role="status"]')).toHaveCount(0)
  757 |     expect(routes.unexpected).toEqual([])
  758 |   })
  759 | })
  760 | 
  761 | const loadingViewports = [
  762 |   { height: 844, width: 390 },
  763 |   { height: 900, width: 1440 },
  764 |   { height: 1080, width: 1920 },
  765 | ] as const
  766 | 
  767 | for (const viewport of loadingViewports) {
  768 |   test.describe(`Task 6.4 loading geometry at ${viewport.width}px`, () => {
  769 |     test.use({ viewport })
  770 | 
  771 |     test('fills real Operations, Settings and Board panels without a narrow skeleton island', async ({ page }, testInfo) => {
  772 |       const routes = new RouteScenarios()
  773 |       await routes.install(page)
  774 |       await page.context().addCookies([{ name: 'workmesh_locale', value: 'en', url: webUrl }])
  775 |       await mkdir(evidenceRoot, { recursive: true })
  776 | 
  777 |       const featuresPending = deferredResponse()
  778 |       const usageGeometryPending = deferredResponse()
  779 |       routes.set('/api/v1/features', featuresPending.promise)
  780 |       routes.set('/api/v1/usage-summary', usageGeometryPending.promise)
  781 |       for (const [path, response] of Object.entries(collectionPayloads)) routes.set(path, response)
  782 |       await page.goto('/operations', { waitUntil: 'domcontentloaded' })
  783 |       const operationsHeader = page.locator('.operations-tab > .operations-header')
  784 |       await expect(operationsHeader).toBeVisible()
  785 |       await operationsHeader.evaluate(element => { element.dataset.loadingIdentity = 'stable-operations-header' })
  786 |       const operationsHeaderPending = (await measureRects(page, '.operations-tab > .operations-header'))[0]!
  787 |       const operationsPending = await measureSkeleton(page, '.operations-loading .skeleton-list', { panelSelector: '.operations-tab' })
  788 |       expectContainedSkeleton(operationsPending, viewport.width <= 960 ? 1 : 2)
  789 |       expect(operationsPending.busyOwners).toBe(1)
  790 |       await page.screenshot({ path: join(evidenceRoot, `loading-operations-pending-${viewport.width}x${viewport.height}.png`) })
  791 | 
  792 |       routes.set('/api/v1/features', allFeatures)
  793 |       featuresPending.resolve(allFeatures)
  794 |       await expect(page.locator('.operations-usage-loading .skeleton-list')).toBeVisible()
  795 |       await expect(page.locator('.operations-grid > .operations-panel')).toHaveCount(6)
  796 |       const usagePending = await measureSkeleton(page, '.operations-usage-loading .skeleton-list', { panelSelector: '.operations-metrics' })
  797 |       // Task 6.5 supersedes the original 1920px five-column snapshot: keeping
  798 |       // the metrics root at 85% of the workspace yields four readable columns
  799 |       // and two rows without changing the loading owner or pending/resolved seam.
  800 |       const expectedUsageColumns = viewport.width <= 560 ? 1 : viewport.width >= 1440 ? 4 : 5
  801 |       expectContainedSkeleton(usagePending, expectedUsageColumns)
  802 |       expect(usagePending.cells).toHaveLength(5)
  803 |       expect(usagePending.focusableCount).toBe(0)
  804 |       expect(usagePending.document.overflow).toBe(0)
  805 |       if (viewport.width === 1920) {
  806 |         expect(usagePending.root.width / usagePending.main.width).toBeGreaterThanOrEqual(.85)
  807 |         expect(new Set(usagePending.cells.map(cell => Math.round(cell.top))).size).toBe(2)
  808 |       }
  809 |       routes.set('/api/v1/usage-summary', usage)
  810 |       usageGeometryPending.resolve(usage)
> 811 |       await expect(page.locator('.operations-metrics-grid > .operations-metric-card')).toHaveCount(5)
      |                                                                                        ^ Error: expect(locator).toHaveCount(expected) failed
  812 |       const usageResolved = await measureResolvedGrid(page, '.operations-metrics-grid', ':scope > .operations-metric-card')
  813 |       expect(usageResolved.columns).toBe(usagePending.columns)
  814 |       expect(usageResolved.document.overflow).toBe(0)
  815 |       expect(Math.abs(usageResolved.root.width - usagePending.root.width)).toBeLessThanOrEqual(2)
  816 |       usageResolved.items.forEach((card, index) => expect(Math.abs(card.width - usagePending.cells[index]!.width)).toBeLessThanOrEqual(2))
  817 |       if (viewport.width === 1920)
  818 |         expect(new Set(usageResolved.items.map(card => Math.round(card.top))).size).toBe(2)
  819 |       const operationsResolved = await measureRects(page, '.operations-grid > .operations-panel')
  820 |       const operationsContainment = await measureResolvedContainment(page)
  821 |       const operationsHeaderResolved = (await measureRects(page, '.operations-tab > .operations-header'))[0]!
  822 |       expect(operationsContainment.document.overflow).toBe(0)
  823 |       await expect(operationsHeader).toHaveAttribute('data-loading-identity', 'stable-operations-header')
  824 |       expect(Math.abs(operationsHeaderPending.top - operationsHeaderResolved.top)).toBeLessThanOrEqual(2)
  825 |       expect(Math.abs(operationsPending.cells[0]!.width - operationsResolved[0]!.width)).toBeLessThanOrEqual(2)
  826 |       expect(Math.abs(operationsPending.cells[1]!.width - operationsResolved[1]!.width)).toBeLessThanOrEqual(2)
  827 |       expect(Math.abs(operationsPending.cells[2]!.width - operationsResolved[2]!.width)).toBeLessThanOrEqual(2)
  828 |       await persistEvidence(page, testInfo, `loading-operations-geometry-${viewport.width}x${viewport.height}`, {
  829 |         header: { pending: operationsHeaderPending, resolved: operationsHeaderResolved },
  830 |         pending: operationsPending,
  831 |         resolvedContainment: operationsContainment,
  832 |         resolvedPanels: operationsResolved,
  833 |         usage: { pending: usagePending, resolved: usageResolved },
  834 |       })
  835 | 
  836 |       const teamsPending = deferredResponse()
  837 |       const statesGeometryPending = deferredResponse()
  838 |       const statesPath = `/api/v1/teams/${team.id}/states`
  839 |       routes.setRequest('GET', '/api/v1/teams', teamsPending.promise)
  840 |       routes.setRequest('GET', statesPath, statesGeometryPending.promise)
  841 |       await page.goto('/settings?tab=workspace', { waitUntil: 'domcontentloaded' })
  842 |       const settingsHeader = page.locator('.settings-page > header').first()
  843 |       await settingsHeader.evaluate(element => { element.dataset.loadingIdentity = 'stable-settings-header' })
  844 |       const settingsHeaderPending = (await measureRects(page, '.settings-page > header'))[0]!
  845 |       const settingsPending = await measureSkeleton(page, '.settings-loading-skeleton .skeleton-list', { panelSelector: '.settings-grid' })
  846 |       expectContainedSkeleton(settingsPending, viewport.width <= 720 ? 1 : 2)
  847 |       expect(settingsPending.busyOwners).toBe(1)
  848 |       await page.screenshot({ path: join(evidenceRoot, `loading-settings-pending-${viewport.width}x${viewport.height}.png`) })
  849 | 
  850 |       const teamsResponse = { body: { items: [team], nextCursor: null } } satisfies JsonResponse
  851 |       routes.setRequest('GET', '/api/v1/teams', teamsResponse)
  852 |       teamsPending.resolve(teamsResponse)
  853 |       await expect(page.locator('.settings-states-loading .skeleton-list')).toBeVisible()
  854 |       const statesPending = await measureSkeleton(page, '.settings-states-loading .skeleton-list', { panelSelector: '.settings-card' })
  855 |       expectContainedSkeleton(statesPending, viewport.width <= 560 ? 1 : workflowStates.length)
  856 |       expect(statesPending.cells).toHaveLength(workflowStates.length)
  857 |       expect(statesPending.document.overflow).toBe(0)
  858 |       expect(statesPending.focusableCount).toBe(0)
  859 |       const statesResponse = { body: { items: workflowStates, nextCursor: null } } satisfies JsonResponse
  860 |       routes.setRequest('GET', statesPath, statesResponse)
  861 |       statesGeometryPending.resolve(statesResponse)
  862 |       await expect(page.locator('.settings-grid > .settings-card')).toHaveCount(3)
  863 |       await expect(page.locator('.workflow-state-list > article')).toHaveCount(workflowStates.length)
  864 |       const statesResolved = await measureResolvedGrid(page, '.workflow-state-list', ':scope > article')
  865 |       expect(statesResolved.columns).toBe(statesPending.columns)
  866 |       expect(statesResolved.document.overflow).toBe(0)
  867 |       expect(Math.abs(statesResolved.root.width - statesPending.root.width)).toBeLessThanOrEqual(2)
  868 |       statesResolved.items.forEach((card, index) => expect(Math.abs(card.width - statesPending.cells[index]!.width)).toBeLessThanOrEqual(2))
  869 |       const settingsResolved = await measureRects(page, '.settings-grid > .settings-card')
  870 |       const settingsContainment = await measureResolvedContainment(page)
  871 |       const settingsHeaderResolved = (await measureRects(page, '.settings-page > header'))[0]!
  872 |       expect(settingsContainment.document.overflow).toBe(0)
  873 |       await expect(settingsHeader).toHaveAttribute('data-loading-identity', 'stable-settings-header')
  874 |       expect(Math.abs(settingsHeaderPending.top - settingsHeaderResolved.top)).toBeLessThanOrEqual(2)
  875 |       for (const index of [0, 1, 2])
  876 |         expect(Math.abs(settingsPending.cells[index]!.width - settingsResolved[index]!.width)).toBeLessThanOrEqual(8)
  877 |       await persistEvidence(page, testInfo, `loading-settings-geometry-${viewport.width}x${viewport.height}`, {
  878 |         header: { pending: settingsHeaderPending, resolved: settingsHeaderResolved },
  879 |         pending: settingsPending,
  880 |         resolvedCards: settingsResolved,
  881 |         resolvedContainment: settingsContainment,
  882 |         states: { pending: statesPending, resolved: statesResolved },
  883 |       })
  884 | 
  885 |       const workItemsPending = deferredResponse()
  886 |       routes.setRequest('GET', `/api/v1/teams/${team.id}/states`, { body: { items: workflowStates, nextCursor: null } })
  887 |       routes.set('/api/v1/work-items', workItemsPending.promise)
  888 |       await page.goto('/?view=my-work&layout=board', { waitUntil: 'domcontentloaded' })
  889 |       const boardControls = page.locator('.work-surface-layout-toggle')
  890 |       await boardControls.evaluate(element => { element.dataset.loadingIdentity = 'stable-board-controls' })
  891 |       const boardControlsPending = (await measureRects(page, '.work-surface-layout-toggle'))[0]!
  892 |       const boardPending = await measureSkeleton(page, '.work-surfaces .skeleton-list', { panelSelector: '.work-surfaces' })
  893 |       expectContainedSkeleton(boardPending, viewport.width <= 560 ? 1 : workflowStates.length, viewport.width > 560)
  894 |       expect(boardPending.busyOwners).toBe(1)
  895 |       expect(boardPending.cells).toHaveLength(workflowStates.length)
  896 |       if (viewport.width > 560)
  897 |         expect(boardPending.cells.every(cell => Math.abs(cell.width - 320) <= 2)).toBe(true)
  898 |       await page.screenshot({ path: join(evidenceRoot, `loading-board-pending-${viewport.width}x${viewport.height}.png`) })
  899 | 
  900 |       const workItemsResponse = { body: { items: [browserWorkItem], nextCursor: null } } satisfies JsonResponse
  901 |       routes.set('/api/v1/work-items', workItemsResponse)
  902 |       workItemsPending.resolve(workItemsResponse)
  903 |       await expect(page.locator('.wm-work-item-column')).toHaveCount(workflowStates.length)
  904 |       const boardResolved = await measureRects(page, '.wm-work-item-column')
  905 |       const boardContainment = await measureResolvedContainment(page, '.wm-work-item-board-scroll')
  906 |       const boardControlsResolved = (await measureRects(page, '.work-surface-layout-toggle'))[0]!
  907 |       expect(boardContainment.document.overflow).toBe(0)
  908 |       await expect(boardControls).toHaveAttribute('data-loading-identity', 'stable-board-controls')
  909 |       expect(Math.abs(boardControlsPending.top - boardControlsResolved.top)).toBeLessThanOrEqual(2)
  910 |       if (viewport.width > 560)
  911 |         boardResolved.forEach((column, index) => expect(Math.abs(boardPending.cells[index]!.width - column.width)).toBeLessThanOrEqual(2))
```