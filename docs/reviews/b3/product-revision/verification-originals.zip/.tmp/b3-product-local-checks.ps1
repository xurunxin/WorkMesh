$ErrorActionPreference = 'Stop'
$b3Node='I:/tds_workspace/workspaces/01a12a8e-cadc-7c05-a07a-1d6a77c8f64c/.tmp/blueberry-runtime/node-v22.19.0-win-x64/node.exe'
$b3Pnpm='X:/packages/npm/_npx/32b21065a482fe57/node_modules/pnpm/bin/pnpm.cjs'
$env:PATH=(Join-Path (Get-Location).Path '.tmp/b3-bin')+';'+(Split-Path $b3Node)+';'+$env:PATH
$env:APPDATA=(Get-Content .tmp/b3-appdata-owner.json -Raw|ConvertFrom-Json).path
$b3Root=Join-Path (Get-Location).Path 'docs/reviews/b3/product-revision/local-checks'
New-Item -ItemType Directory -Force -Path $b3Root | Out-Null
$b3Checks=@('lint','typecheck','test','build','check:integration-docs','ci:test','ci:validate','check:route-policy','smoke:agents:ci','test:conformance')
$b3Rows=@()
foreach ($b3Check in $b3Checks) {
  $b3Log=Join-Path $b3Root ($b3Check.Replace(':','-')+'.log')
  $b3Start=[DateTime]::UtcNow.ToString('o')
  & $b3Node $b3Pnpm $b3Check *> $b3Log
  $b3Code=$LASTEXITCODE
  $b3Rows+=[ordered]@{command="pnpm $b3Check";startedAt=$b3Start;finishedAt=[DateTime]::UtcNow.ToString('o');exitCode=$b3Code;log=$b3Log;node='22.19.0';pnpm='9.15.4'}
  ConvertTo-Json -Depth 5 -InputObject $b3Rows | Set-Content -Encoding utf8 (Join-Path $b3Root 'results.json')
  Write-Output "$b3Check exit=$b3Code"
  if ($b3Code -ne 0) { exit $b3Code }
}
