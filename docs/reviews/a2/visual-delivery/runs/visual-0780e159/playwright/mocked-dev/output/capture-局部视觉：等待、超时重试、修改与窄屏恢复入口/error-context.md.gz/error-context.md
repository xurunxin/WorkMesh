# Instructions

- Following Playwright test failed.
- Explain why, be concise, respect Playwright best practices.
- Provide a snippet of code with the fix, if possible.

# Test info

- Name: capture.spec.ts >> 局部视觉：等待、超时重试、修改与窄屏恢复入口
- Location: ..\..\docs\reviews\a2\visual-delivery\capture.spec.ts:5:1

# Error details

```
Error: expect(locator).toBeEnabled() failed

Locator: locator('#project-repository-configuration').getByLabel('基线提交 SHA')
Expected: enabled
Timeout: 10000ms
Error: element(s) not found

Call log:
  - Expect "toBeEnabled" with timeout 10000ms
  - waiting for locator('#project-repository-configuration').getByLabel('基线提交 SHA')

```

```yaml
- alert
- link "跳到主要内容":
  - /url: "#workmesh-main"
- complementary "主导航":
  - strong: WorkMesh
  - text: Alex Morgan
  - button "收起导航栏" [expanded]
  - text: 团队
  - combobox "当前团队":
    - option "无团队" [disabled]
    - option "Final Tour (FT)"
    - option "Agent Operations (AOP)" [selected]
  - button "加载更多 团队"
  - navigation "工作区导航":
    - paragraph: 工作台
    - link "工作台":
      - /url: /workbench
    - link "我的工作":
      - /url: /?view=home
    - link "Issues":
      - /url: /?view=my-work
    - link "指南":
      - /url: /?view=guidance
    - paragraph: 治理
    - link "需要我处理":
      - /url: /?view=inbox
    - link "Session":
      - /url: /?view=sessions
    - link "恢复中心":
      - /url: /?view=recovery
    - link "项目":
      - /url: /?view=projects
    - link "智能体":
      - /url: /agents
    - paragraph: 运营
    - link "运营":
      - /url: /operations
  - navigation "管理导航":
    - link "设置":
      - /url: /settings
  - button "退出登录"
  - text: v1.29.0-final-tour · 构建 final-tour-preview · 数据库架构 24
- banner:
  - paragraph: 项目
  - button "搜索": 搜索 Ctrl K
  - button "切换到深色主题"
  - group "语言":
    - button "中" [pressed]
    - button "EN"
  - text: 正在重新连接
- main:
  - complementary "项目":
    - text: Workspace
    - heading "项目" [level=1]
    - button "新建项目"
    - strong: 尚无项目。
  - heading "Runtime Reliability" [level=1]
  - text: 刚刚更新
  - paragraph: A deterministic non-empty project for the final product tour.
  - button "编辑项目"
  - button "里程碑"
  - button "文档"
  - button "新建 Issue"
  - button "查看工作"
  - group: 项目说明
  - term: 项目状态
  - definition: in progress
  - term: 负责人
  - definition: Alex Morgan
  - term: Target date
  - definition: 2026-09-30
  - term: 新鲜度
  - definition: rev 5
  - strong: 0%
  - text: 0/2 个 Issue 已完成
  - progressbar "项目 Issue 完成进度"
  - tablist "项目导航":
    - tab "概览" [selected]
    - tab "工作"
    - tab "关注事项"
    - tab "运行"
  - group: ▸Project Control Center 筛选
  - region "项目运行摘要":
    - article:
      - strong: "0"
      - text: 需要我处理
    - article:
      - strong: "0"
      - text: 运行中
    - article:
      - strong: "0"
      - text: 存在风险
    - article:
      - strong: "0"
      - text: 最近已验证
    - article:
      - strong: "0"
      - text: 就绪
    - article:
      - strong: "0"
      - text: 阻塞
  - region "需要我处理":
    - heading "需要我处理" [level=2]
    - text: "0"
    - paragraph: 等待负责人决策或审阅的事项。
    - text: 当前没有此类项目。
  - region "运行中":
    - heading "运行中" [level=2]
    - text: "0"
    - paragraph: Agent 当前正在执行的工作。
    - text: 当前没有此类项目。
  - region "存在风险":
    - heading "存在风险" [level=2]
    - text: "0"
    - paragraph: 需要恢复或重新同步的执行。
    - text: 当前没有此类项目。
  - region "最近已验证":
    - heading "最近已验证" [level=2]
    - text: "0"
    - paragraph: 已完成验证并留有证据的工作。
    - text: 当前没有此类项目。
  - region "就绪":
    - heading "就绪" [level=2]
    - text: "0"
    - paragraph: 已满足服务端就绪条件、可进入执行的工作。
    - text: 当前没有此类项目。
  - region "阻塞":
    - heading "阻塞" [level=2]
    - text: "0"
    - paragraph: 被执行状态或依赖阻塞的工作。
    - text: 当前没有此类项目。
  - region "仓库配置":
    - heading "仓库配置" [level=2]
    - button "刷新"
    - paragraph:
      - text: 选择或新建项目后配置仓库。
      - button "新建配置目标项目"
    - text: 仓库
    - combobox "仓库":
      - option "WorkMesh / visual-fixture" [selected]
    - group: 注册仓库
    - group: 创建提供商连接
```

# Test source

```ts
  1  | import { expect, test } from '@playwright/test'
  2  | import { createHash } from 'node:crypto'
  3  | import { writeFile } from 'node:fs/promises'
  4  | 
  5  | test('局部视觉：等待、超时重试、修改与窄屏恢复入口', async ({ page, request, browser }, testInfo) => {
  6  |   const reset = await request.post('http://127.0.0.1:3201/__test/reset', { data: { scenario: 'final-tour' } })
  7  |   expect(reset.ok()).toBe(true)
  8  |   const projectId = '11111111-1111-4111-8111-111111111111'
  9  |   const teamId = '22222222-2222-4222-8222-222222222222'
  10 |   const repositoryId = '33333333-3333-4333-8333-333333333333'
  11 |   const workspaceId = '44444444-4444-4444-8444-444444444444'
  12 |   const actionId = '55555555-5555-4555-8555-555555555555'
  13 |   const connectionId = '66666666-6666-4666-8666-666666666666'
  14 |   let posts = 0
  15 |   const errors: string[] = []
  16 |   page.on('pageerror', error => errors.push(error.message))
  17 |   await page.context().addCookies([{ name: 'workmesh_locale', value: 'zh-CN', url: 'http://127.0.0.1:3200' }])
  18 |   await page.addInitScript(() => localStorage.setItem('workmesh.theme', 'light'))
  19 |   // 原有 final-tour 只读项目夹具使用非 UUID ID；只在这次采集的传输边界映射。
  20 |   // 页面、组件、apiMutation、期限与按钮均执行当前产品源码，不替换 DOM。
  21 |   await page.route('**/api/v1/**', async route => {
  22 |     const pathname = new URL(route.request().url()).pathname
  23 |     if (pathname === '/api/v1/repositories') {
  24 |       await route.fulfill({ json: { items: [{
  25 |         id: repositoryId, workspace_id: workspaceId, connection_id: connectionId, team_id: teamId,
  26 |         external_id: 'visual-fixture', full_name: 'WorkMesh / visual-fixture', default_branch: 'main',
  27 |         required_checks: [], can_configure_context: true,
  28 |       }], nextCursor: null } })
  29 |       return
  30 |     }
  31 |     if (pathname === `/api/v1/repositories/${repositoryId}/context`) {
  32 |       if (route.request().method() === 'POST') {
  33 |         ++posts
  34 |         await route.fulfill({ status: 202, json: { id: actionId, kind: 'resolve_repository_context', status: 'pending' } })
  35 |       } else await route.fulfill({ json: [] })
  36 |       return
  37 |     }
  38 |     const url = route.request().url().replaceAll(projectId, 'project-1').replaceAll(teamId, 'team-2')
  39 |     const response = await route.fetch({ url })
  40 |     const contentType = response.headers()['content-type'] ?? ''
  41 |     if (!contentType.includes('application/json')) { await route.fulfill({ response }); return }
  42 |     const raw = (await response.text()).replaceAll('project-1', projectId).replaceAll('team-2', teamId).replaceAll('workspace-preview', workspaceId)
  43 |     await route.fulfill({ response, body: raw })
  44 |   })
  45 |   await page.goto(`/?view=projects&teamId=${teamId}&project=${projectId}#project-repository-configuration`, { waitUntil: 'networkidle' })
  46 |   const section = page.locator('#project-repository-configuration')
  47 |   const sha = section.getByLabel('基线提交 SHA')
> 48 |   await expect(sha).toBeEnabled()
     |                     ^ Error: expect(locator).toBeEnabled() failed
  49 |   await page.evaluate(() => document.fonts.ready)
  50 |   await page.clock.install({ time: new Date('2026-10-09T00:00:00.000Z') })
  51 |   await sha.fill('a'.repeat(40))
  52 |   await section.getByRole('button', { name: '提交上下文配置', exact: true }).click()
  53 |   await expect(section.getByRole('status')).toHaveText('已提交，等待解析。')
  54 |   await expect(sha).toBeDisabled()
  55 |   const captures: Array<{ name: string; bytes: number; sha256: string; width: number; height: number }> = []
  56 |   const capture = async (name: string) => {
  57 |     const bytes = await section.screenshot({ path: testInfo.outputPath(`${name}.png`), animations: 'disabled', caret: 'hide' })
  58 |     captures.push({ name, bytes: bytes.length, sha256: createHash('sha256').update(bytes).digest('hex'), width: bytes.readUInt32BE(16), height: bytes.readUInt32BE(20) })
  59 |   }
  60 |   await capture('waiting-desktop')
  61 |   await page.clock.fastForward(61_000)
  62 |   await expect(section.getByRole('button', { name: '重试确认', exact: true })).toBeEnabled()
  63 |   await expect(sha).toBeEnabled()
  64 |   await capture('timeout-desktop')
  65 |   await section.getByRole('button', { name: '重试确认', exact: true }).click()
  66 |   await expect(sha).toBeDisabled()
  67 |   expect(posts).toBe(1)
  68 |   await page.clock.fastForward(61_000)
  69 |   await expect(sha).toBeEnabled()
  70 |   await section.getByRole('button', { name: '修改配置', exact: true }).click()
  71 |   await expect(sha).toBeFocused()
  72 |   await sha.fill('b'.repeat(40))
  73 |   await capture('edit-desktop')
  74 |   await page.setViewportSize({ width: 390, height: 844 })
  75 |   await capture('edit-mobile')
  76 |   expect(errors).toEqual([])
  77 |   expect(posts).toBe(1)
  78 |   await writeFile(testInfo.outputPath('capture.json'), JSON.stringify({
  79 |     browserVersion: browser.version(), platform: process.platform,
  80 |     source: '当前 Next 页面和组件；final-tour 传输夹具加仓库动作待处理响应，不运行 API/Worker，不计作安装或领域验收',
  81 |     fixedClientTime: '2026-10-09T00:00:00.000Z', clockAdvancesMs: [61_000, 61_000],
  82 |     viewport: [{ width: 1440, height: 1000 }, { width: 390, height: 844 }],
  83 |     screenshot: { region: '#project-repository-configuration', animations: 'disabled', caret: 'hide' },
  84 |     postCount: posts, pageErrors: errors, captures,
  85 |   }, null, 2))
  86 | })
  87 | 
```