# Instructions

- Following Playwright test failed.
- Explain why, be concise, respect Playwright best practices.
- Provide a snippet of code with the fix, if possible.

# Test info

- Name: configuration-readiness.spec.ts >> Lite 安装后逐项补齐直到横幅消失 @lite
- Location: e2e\configuration-readiness.spec.ts:177:1

# Error details

```
Error: expect(page).not.toHaveURL(expected) failed

Expected pattern: not /\/install/
Received string: "http://127.0.0.1:56494/install"
Timeout: 5000ms

Call log:
  - Expect "not toHaveURL" with timeout 5000ms
    14 × unexpected value "http://127.0.0.1:56494/install"

```

```yaml
- link "跳到主要内容":
  - /url: "#workmesh-main"
- banner:
  - banner:
    - strong: WorkMesh
  - paragraph: Workspace
  - button "切换到浅色主题"
  - group "语言":
    - button "中" [pressed]
    - button "EN"
- main:
  - heading "安装 WorkMesh" [level=1]
  - paragraph: 首次启动时初始化工作区与管理员账号
  - text: 启动令牌
  - textbox "启动令牌":
    - /placeholder: 部署启动令牌
    - text: T2kyVg4GZwSXVVtBKUEBO7VnNVymO3H9PnY-scCap30
  - paragraph: 除非 API 处于显式 loopback-only 开发启动模式，否则必填。令牌仅发送一次，本页不保存。
  - text: 工作区名称
  - textbox "工作区名称":
    - /placeholder: My Workspace
    - text: A2 Lite
  - text: 工作区标识
  - textbox "工作区标识":
    - /placeholder: workspace-slug
    - text: a2-b0fe7e6d
  - text: 管理员姓名
  - textbox "管理员姓名": A2 Human
  - text: 邮箱
  - textbox "邮箱":
    - /placeholder: name@example.com
    - text: a2-b0fe7e6d@example.test
  - text: 密码
  - textbox "密码":
    - /placeholder: 至少 12 个字符
    - text: a2-browser-password
  - alert: Request failed (500)
  - button "安装"
- alert
```

# Test source

```ts
  1   | import { randomUUID } from 'node:crypto'
  2   | import { expect, type Page } from '@playwright/test'
  3   | import { createDb } from '../../../../packages/db/src/index.js'
  4   | import { resolveReadinessContext } from './configuration-readiness-provider.js'
  5   | 
  6   | const apiUrl = process.env.WORKMESH_A2_LITE_URL ?? 'http://127.0.0.1:3101'
  7   | const lite = process.env.WORKMESH_A2_LITE === '1'
  8   | type RecordBody = Record<string, unknown>
  9   | export async function readinessFixture(page: Page) {
  10  |   const suffix = randomUUID().slice(0, 8)
  11  |   if (lite) {
  12  |     await page.goto('/install')
  13  |     for (const [name, value] of Object.entries({ bootstrapToken: process.env.WORKMESH_BOOTSTRAP_TOKEN!, workspace: 'A2 Lite', slug: `a2-${suffix}`, name: 'A2 Human', email: `a2-${suffix}@example.test`, password: 'a2-browser-password' })) await page.locator(`input[name="${name}"]`).fill(value)
  14  |     await page.getByTestId('install-submit').click()
> 15  |     await expect(page).not.toHaveURL(/\/install/)
      |                            ^ Error: expect(page).not.toHaveURL(expected) failed
  16  |   }
  17  |   const meResponse = await page.request.get(`${apiUrl}/api/v1/auth/me`)
  18  |   expect(meResponse.ok()).toBe(true)
  19  |   let me = await meResponse.json() as { actor: { id: string; workspace_id: string }; csrfToken: string }
  20  |   let csrf = me.csrfToken
  21  |   const call = async <T>(method: string, path: string, body?: RecordBody, headers: Record<string, string> = {}): Promise<T> => {
  22  |     const response = await page.request.fetch(`${apiUrl}${path}`, { method, ...(body ? { data: body } : {}), headers: { 'x-csrf-token': csrf, 'idempotency-key': randomUUID(), ...headers } })
  23  |     expect(response.ok(), `${path}: ${response.status()} ${await response.text()}`).toBe(true)
  24  |     return await response.json() as T
  25  |   }
  26  |   const team = await call<{ id: string }>('POST', '/api/v1/teams', { name: `A2 ${suffix}`, key: `A${suffix.replaceAll('-', '').slice(0, 6).toUpperCase()}` })
  27  |   if (!lite) {
  28  |     // Only Human identity is seeded. Every readiness/configuration fact uses its real command.
  29  |     const db = createDb()
  30  |     const email = `a2-${suffix}@example.test`
  31  |     try {
  32  |       const human = (await db.query<{ id: string }>(`INSERT INTO actors(workspace_id,kind,display_name,email,password_hash,workspace_role)
  33  |         SELECT workspace_id,'human','A2 Human',$2,password_hash,'admin' FROM actors WHERE id=$1 RETURNING id`, [me.actor.id, email])).rows[0]!
  34  |       await db.query("INSERT INTO memberships(workspace_id,team_id,actor_id,role) SELECT workspace_id,$2,$3,'admin' FROM actors WHERE id=$1", [me.actor.id, team.id, human.id])
  35  |     } finally { await db.end() }
  36  |     const login = await page.request.post(`${apiUrl}/api/v1/auth/login`, { data: { email, password: 'password-acceptance' }, headers: { 'idempotency-key': randomUUID() } })
  37  |     expect(login.ok(), await login.text()).toBe(true)
  38  |     csrf = (await login.json() as { csrfToken: string }).csrfToken
  39  |     me = await call<typeof me>('GET', '/api/v1/auth/me')
  40  |   }
  41  |   const project = await call<{ id: string }>('POST', '/api/v1/projects', { teamId: team.id, name: `A2 project ${suffix}` })
  42  |   const sessionBaseline = await call<{ items: unknown[] }>('GET', '/api/v1/agent-sessions')
  43  |   const href = `/workbench?workKind=repository&teamId=${team.id}&projectId=${project.id}`
  44  |   const setModel = async () => {
  45  |     const connection = await call<{ id: string; revision: number }>('POST', '/api/v1/workbench/llm-connections', { scope: 'team', teamId: team.id, name: `A2 model ${suffix}`, apiType: 'openai-completions', baseUrl: 'https://models.example.test/v1', secretMaterial: 'a2-model-placeholder' })
  46  |     await call('POST', `/api/v1/workbench/llm-connections/${connection.id}/models`, { externalModelId: 'a2-test', displayName: 'A2 test model', enabled: true, capabilities: { inputModalities: ['text'], toolCalling: true, reasoning: false, contextWindowTokens: 10000, maxOutputTokens: 1000 } }, { 'if-match': `"revision-${connection.revision}"` })
  47  |     return connection
  48  |   }
  49  |   const setAgent = async () => {
  50  |     const agent = await call<{ id: string }>('POST', '/api/v1/agents/register', { name: `A2 ${suffix}`, slug: `a2-${suffix}`, provider: 'fake', version: '1', supportedProtocols: ['native_http'], requestedCapabilities: ['work:read'], approvedCapabilities: ['work:read'], maxConcurrency: 1 })
  51  |     await call('PUT', `/api/v1/agents/${agent.id}/team-access/${team.id}`, { approvedCapabilities: ['work:read'] })
  52  |     return agent
  53  |   }
  54  |   const configureRepository = async (github = false, loseFirstResponse = false, existingConnectionId?: string) => {
  55  |     const connection = existingConnectionId ? { id: existingConnectionId } : await call<{ id: string }>('POST', '/api/v1/provider-connections', lite ? {
  56  |       provider: 'gitea', externalAccountId: suffix, displayName: 'A2 HTTPS Gitea', webhookSecret: 'a2-webhook-placeholder', baseUrl: process.env.WORKMESH_A2_GITEA_URL!, accessToken: 'a2-provider-placeholder',
  57  |     } : { provider: github ? 'github' : 'fake', externalAccountId: suffix, displayName: 'A2 deterministic provider', webhookSecret: 'a2-webhook-placeholder', ...(github ? { installationId: '42', appId: '42', privateKey: 'a2-fixture-key-'.repeat(6) } : {}) })
  58  |     const section = page.locator('#project-repository-configuration')
  59  |     await expect(section).toBeVisible()
  60  |     await section.locator('summary').filter({ hasText: /注册仓库|Register repository/ }).click()
  61  |     await section.getByLabel(/已有连接 ID|Existing connection ID/).fill(connection.id)
  62  |     await section.getByLabel(/提供商仓库 ID|Provider repository ID/).fill('42')
  63  |     await section.getByLabel(/仓库全名|Repository full name/).fill('a2/fixture')
  64  |     const registered = page.waitForResponse(response => response.url().endsWith('/api/v1/repositories') && response.request().method() === 'POST')
  65  |     await section.getByRole('button', { name: /注册仓库|Register repository/ }).click()
  66  |     const registeredResponse = await registered
  67  |     expect(registeredResponse.ok()).toBe(true)
  68  |     const repository = await registeredResponse.json() as { id: string }
  69  |     await expect(section.getByLabel(/仓库$|^Repository$/)).toBeVisible()
  70  |     await section.getByLabel(/仓库$|^Repository$/).selectOption(repository.id)
  71  |     await expect(section.getByLabel(/基线提交 SHA|Base commit SHA/)).toBeVisible()
  72  |     await section.getByLabel(/基线提交 SHA|Base commit SHA/).fill('a2-base-sha')
  73  |     let originalKey: string | undefined
  74  |     let originalAction: string | undefined
  75  |     if (loseFirstResponse) {
  76  |       let lost!: () => void
  77  |       const lostResponse = new Promise<void>(resolve => { lost = resolve })
  78  |       await page.route('**/api/v1/repositories/*/context', async route => {
  79  |         if (route.request().method() !== 'POST' || originalKey) { await route.continue(); return }
  80  |         originalKey = route.request().headers()['idempotency-key']
  81  |         const committed = await route.fetch(); expect(committed.ok()).toBe(true)
  82  |         originalAction = (await committed.json() as { id: string }).id
  83  |         await route.abort('failed'); lost()
  84  |       })
  85  |       await section.getByRole('button', { name: /提交上下文配置|Submit context configuration/ }).click()
  86  |       await lostResponse; await expect(section.getByRole('alert')).toBeVisible()
  87  |       await section.getByRole('button', { name: /刷新|Refresh/, exact: true }).click()
  88  |       await expect(section.getByRole('button', { name: /提交上下文配置|Submit context configuration/ })).toBeEnabled()
  89  |       await expect(section.getByLabel(/基线提交 SHA|Base commit SHA/)).toHaveValue('a2-base-sha')
  90  |     }
  91  |     const resolution = page.waitForResponse(response => response.url().endsWith('/context') && response.request().method() === 'POST')
  92  |     await section.getByRole('button', { name: /提交上下文配置|Submit context configuration/ }).click()
  93  |     const response = await resolution; expect(response.ok()).toBe(true)
  94  |     const action = await response.json() as { id: string }
  95  |     if (loseFirstResponse) {
  96  |       expect(response.request().headers()['idempotency-key']).toBe(originalKey)
  97  |       expect(action.id).toBe(originalAction)
  98  |       await page.unroute('**/api/v1/repositories/*/context')
  99  |     }
  100 |     await expect(section).toContainText(/已提交，等待解析|Submitted; waiting/)
  101 |     if (!lite) await resolveReadinessContext(action.id)
  102 |     await expect(section).toContainText(/上下文已配置|Context configured/, { timeout: 60000 })
  103 |   }
  104 |   return { call, teamId: team.id, projectId: project.id, actorId: me.actor.id, href, setModel, setAgent, configureRepository, sessionBaseline: sessionBaseline.items }
  105 | }
  106 | 
```