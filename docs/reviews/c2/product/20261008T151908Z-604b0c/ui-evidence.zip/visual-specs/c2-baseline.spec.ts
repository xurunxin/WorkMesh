import {test,expect} from '@playwright/test'
import {randomUUID} from 'node:crypto'
import {createDb} from '../../../packages/db/src/index'
test('C2 实施前：登录丢失目的地，手动 canonical 网页仍可见',async({page,context},info)=>{
 const db=createDb(process.env.DATABASE_URL!),api='http://127.0.0.1:3101';let item='';
 try{
  await context.request.post(api+'/api/v1/auth/login',{headers:{origin:'http://127.0.0.1:3100','idempotency-key':randomUUID()},data:{email:'alice@example.test',password:'password-acceptance'}});
  const auth=await(await context.request.get(api+'/api/v1/auth/me')).json();const team=(await db.query('SELECT id FROM teams WHERE workspace_id=$1 LIMIT 1',[auth.actor.workspace_id])).rows[0];
  item=(await db.query(`INSERT INTO inbox_items(workspace_id,recipient_human_actor_id,team_id,kind,source_type,source_id,payload) VALUES($1,$2,$3,'ask','activity',$4,'{"summary":"C2 仅授权 Human 可见"}') RETURNING id`,[auth.actor.workspace_id,auth.actor.id,team.id,randomUUID()])).rows[0].id;
  const href='/?view=inbox&attentionSelected='+encodeURIComponent('v1:inbox_item:'+item);
  await context.clearCookies();await page.goto(href);await expect(page).toHaveURL(url=>url.pathname==='/login'&&url.search==='');
  await page.screenshot({path:info.outputPath('c2-baseline-login.png'),fullPage:true,animations:'disabled'});
  const form=page.getByTestId('login-form');await form.locator('[name=email]').fill('alice@example.test');await form.locator('[name=password]').fill('password-acceptance');await page.getByTestId('login-submit').click();
  await expect(page).toHaveURL(url=>url.pathname==='/'&&url.search==='');await page.goto(href);const heading=page.locator('.attention-detail-heading h3');await expect(heading).toBeVisible();await expect(heading).not.toBeFocused();
  await page.screenshot({path:info.outputPath('c2-baseline-authorized.png'),fullPage:true,animations:'disabled'});
 }finally{if(item)await db.query('DELETE FROM inbox_items WHERE id=$1',[item]);await db.end()}
})
