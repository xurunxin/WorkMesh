# Instructions

- Following Playwright test failed.
- Explain why, be concise, respect Playwright best practices.
- Provide a snippet of code with the fix, if possible.

# Test info

- Name: attention-center.spec.ts >> Attention Center preserves URL state, uses governed forms, retains partial bulk failures, and blocks stale recovery
- Location: e2e\attention-center.spec.ts:124:1

# Error details

```
Error: expect(locator).toBeFocused() failed

Locator:  getByTestId('attention-center').locator('.attention-list > [role="listitem"]').filter({ hasText: 'recovery 4' }).getByRole('button', { name: 'Review and respond' })
Expected: focused
Received: inactive
Timeout:  10000ms

Call log:
  - Expect "toBeFocused" with timeout 10000ms
  - waiting for getByTestId('attention-center').locator('.attention-list > [role="listitem"]').filter({ hasText: 'recovery 4' }).getByRole('button', { name: 'Review and respond' })
    23 × locator resolved to <button type="button" class="wm-button wm-button-ghost ui-button ui-button-ghost">…</button>
       - unexpected value "inactive"

```

```yaml
- button "Review and respond"
```

# Test source

```ts
  82  | 
  83  | async function installAttentionRoutes(page: Page) {
  84  |   const active = [
  85  |     item(1, 'approval'),
  86  |     item(2, 'approval'),
  87  |     item(3, 'clarification'),
  88  |     item(4, 'recovery', {
  89  |       freshness: {
  90  |         state: 'stale',
  91  |         observedAt: '2026-08-26T00:00:00.000Z',
  92  |         sourceUpdatedAt: '2026-08-25T23:00:00.000Z',
  93  |       },
  94  |     }),
  95  |   ]
  96  |   const history = [item(5, 'completion_review', {
  97  |     status: 'verified',
  98  |     audience: { relationship: 'assigned_to_me', canRespond: false },
  99  |     options: [],
  100 |     recommendedOptionId: null,
  101 |   })]
  102 |   const attempts = new Map<string, number>()
  103 | 
  104 |   await page.route('**/api/v1/human-attention**', async route => {
  105 |     const url = new URL(route.request().url())
  106 |     if (!url.pathname.endsWith('/human-attention')) return route.fallback()
  107 |     const source = url.searchParams.get('view') === 'history' ? history : active
  108 |     const kind = url.searchParams.get('kind')
  109 |     return fulfillJson(route, {
  110 |       items: kind ? source.filter(candidate => candidate.kind === kind) : source,
  111 |       nextCursor: null,
  112 |     })
  113 |   })
  114 |   await page.route('**/api/v1/test-attention/*', async route => {
  115 |     const path = new URL(route.request().url()).pathname
  116 |     const count = (attempts.get(path) ?? 0) + 1
  117 |     attempts.set(path, count)
  118 |     if (path.endsWith('/2')) return fulfillJson(route, { error: { code: 'REVISION_CONFLICT', message: 'Changed concurrently', correlationId: 'bulk-2' } }, 409)
  119 |     return fulfillJson(route, { ok: true, attempt: count })
  120 |   })
  121 |   return { attempts }
  122 | }
  123 | 
  124 | test('Attention Center preserves URL state, uses governed forms, retains partial bulk failures, and blocks stale recovery', async ({ page, context }, testInfo) => {
  125 |   const login = await context.request.post('http://127.0.0.1:3101/api/v1/auth/login', {
  126 |     data: { email: 'alice@example.test', password: 'password-acceptance' },
  127 |     headers: { 'idempotency-key': `attention-center-login-${Date.now()}`, origin: 'http://127.0.0.1:3100' },
  128 |   })
  129 |   expect(login.ok()).toBeTruthy()
  130 |   await context.addCookies([{ name: 'workmesh_locale', value: 'en', url: 'http://127.0.0.1:3100' }])
  131 |   const { attempts } = await installAttentionRoutes(page)
  132 |   await page.goto('/?view=inbox')
  133 |   const center = page.getByTestId('attention-center')
  134 |   const queueItems = center.locator('.attention-list > [role="listitem"]')
  135 |   await expect(center).toBeVisible()
  136 |   await expect(queueItems).toHaveCount(4)
  137 | 
  138 |   // The filter grid is a collapsed native disclosure in the resting layout, so
  139 |   // the comboboxes do not exist until the summary is opened. <summary> carries
  140 |   // no ARIA role, so the component's test id addresses the disclosure itself.
  141 |   const filters = page.getByTestId('attention-filters')
  142 |   await expect(center.getByRole('combobox', { name: 'Kind', exact: true })).toHaveCount(0)
  143 |   await filters.locator('summary').click()
  144 |   await expect(filters).toHaveAttribute('open', '')
  145 |   await center.getByRole('combobox', { name: 'Kind', exact: true }).selectOption('clarification')
  146 |   await center.getByRole('button', { name: 'Apply filters' }).click()
  147 |   await expect(page).toHaveURL(/attentionKind=clarification/)
  148 |   await expect(queueItems).toHaveCount(1)
  149 |   const clarificationTrigger = center.getByRole('button', { name: 'Review and respond' })
  150 |   await clarificationTrigger.click()
  151 |   await expect(page).toHaveURL(/attentionSelected=/)
  152 |   await center.getByRole('textbox', { name: 'Response', exact: true }).fill('Use the current release branch.')
  153 |   await center.getByRole('button', { name: 'answer', exact: true }).click()
  154 |   await expect.poll(() => attempts.get('/api/v1/test-attention/3') ?? 0).toBe(1)
  155 |   await expect.poll(() => page.evaluate(() => performance.getEntriesByType('measure')
  156 |     .filter(entry => entry.name.startsWith('workmesh.product.'))
  157 |     .map(entry => entry.name))).toEqual(expect.arrayContaining([
  158 |       'workmesh.product.first_attention_detail',
  159 |       'workmesh.product.attention_response',
  160 |     ]))
  161 |   const attentionMetrics = await page.evaluate(() => performance.getEntriesByType('measure')
  162 |     .filter(entry => entry.name.startsWith('workmesh.product.'))
  163 |     .map(entry => ({ name: entry.name, detail: (entry as PerformanceMeasure).detail })))
  164 |   expect(JSON.stringify(attentionMetrics)).not.toMatch(/attentionSelected|correlation|test-attention|release branch/i)
  165 | 
  166 |   await center.getByRole('button', { name: 'Clear' }).click()
  167 |   const bulkOne = center.getByLabel('Bulk response: approval 1')
  168 |   const bulkTwo = center.getByLabel('Bulk response: approval 2')
  169 |   await bulkOne.check()
  170 |   await bulkTwo.check()
  171 |   await center.getByLabel('Bulk reason').fill('Evidence matches the exact payload.')
  172 |   await center.getByRole('button', { name: 'Bulk approve' }).click()
  173 |   await expect(center.getByText('1 succeeded; 1 remain actionable.')).toBeVisible()
  174 |   await expect(bulkOne).not.toBeChecked()
  175 |   await expect(bulkTwo).toBeChecked()
  176 | 
  177 |   const recoveryRow = queueItems.filter({ hasText: 'recovery 4' })
  178 |   const recoveryTrigger = recoveryRow.getByRole('button', { name: 'Review and respond' })
  179 |   await recoveryTrigger.click()
  180 |   await expect(center.getByRole('button', { name: 'retry', exact: true })).toBeDisabled()
  181 |   await page.keyboard.press('Escape')
> 182 |   await expect(recoveryTrigger).toBeFocused()
      |                                 ^ Error: expect(locator).toBeFocused() failed
  183 | 
  184 |   await center.getByRole('tab', { name: 'History' }).click()
  185 |   await expect(page).toHaveURL(/attentionView=history/)
  186 |   await expect(center.getByText('completion review 5')).toBeVisible()
  187 |   await page.goBack()
  188 |   await expect(page).not.toHaveURL(/attentionView=history/)
  189 |   await expect(queueItems).toHaveCount(4)
  190 |   await page.goForward()
  191 |   await expect(page).toHaveURL(/attentionView=history/)
  192 |   await expect(center.getByText('completion review 5')).toBeVisible()
  193 |   await page.goBack()
  194 |   await expect(queueItems).toHaveCount(4)
  195 | 
  196 |   await page.screenshot({ animations: 'disabled', fullPage: true, path: testInfo.outputPath('attention-center.png') })
  197 | })
  198 | 
```