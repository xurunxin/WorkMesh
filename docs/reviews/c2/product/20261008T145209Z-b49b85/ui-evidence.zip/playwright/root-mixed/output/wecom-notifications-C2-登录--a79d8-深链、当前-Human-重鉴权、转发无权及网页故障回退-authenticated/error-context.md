# Instructions

- Following Playwright test failed.
- Explain why, be concise, respect Playwright best practices.
- Provide a snippet of code with the fix, if possible.

# Test info

- Name: wecom-notifications.spec.ts >> C2 登录 canonical 深链、当前 Human 重鉴权、转发无权及网页故障回退
- Location: e2e\wecom-notifications.spec.ts:9:1

# Error details

```
Error: expect(page).toHaveURL(expected) failed

Expected: predicate to succeed
Received: "http://127.0.0.1:3100/login?email=c2-forward-0f8161e3-6fd1-4483-b2db-23e68cc10a38%40example.test&password=password-acceptance"
Timeout:  10000ms

```

# Page snapshot

```yaml
- generic [active] [ref=e1]:
  - generic [ref=e2]:
    - link "Skip to content" [ref=e3] [cursor=pointer]:
      - /url: "#workmesh-main"
    - generic [ref=e4]:
      - banner [ref=e5]:
        - banner [ref=e6]:
          - strong [ref=e8]: WorkMesh
        - paragraph [ref=e9]:
          - generic [ref=e10]: Sign in
        - generic [ref=e12]:
          - button "Switch to the light theme" [ref=e13]:
            - img [ref=e14]
          - group "Language" [ref=e16]:
            - button "中" [ref=e17]
            - button "EN" [pressed] [ref=e18]
      - main [ref=e19]:
        - generic [ref=e21]:
          - generic [ref=e23]:
            - heading "Sign in" [level=1] [ref=e24]
            - paragraph [ref=e25]: Sign in with your workspace account
          - generic [ref=e27]:
            - generic [ref=e28]:
              - text: Email
              - textbox "Email" [ref=e29]
            - generic [ref=e30]:
              - text: Password
              - textbox "Password" [ref=e31]
            - button "Sign in" [ref=e32] [cursor=pointer]:
              - generic [ref=e33]: Sign in
  - button "Open Next.js Dev Tools" [ref=e39] [cursor=pointer]:
    - img [ref=e40]
  - alert [ref=e43]
```

# Test source

```ts
  1  | import { expect, test } from '@playwright/test'
  2  | import { randomUUID } from 'node:crypto'
  3  | import { createDb } from '../../../packages/db/src/index'
  4  | 
  5  | const api = process.env.C2_E2E_API_URL ?? 'http://127.0.0.1:3101'
  6  | const databaseUrl = process.env.DATABASE_URL!
  7  | if (!/(^|[_-])test(?:[_-]|$)/i.test(new URL(databaseUrl).pathname.slice(1))) throw new Error('C2 E2E requires a dedicated test database')
  8  | 
  9  | test('C2 登录 canonical 深链、当前 Human 重鉴权、转发无权及网页故障回退', async ({ page, context }, testInfo) => {
  10 |   const db = createDb(databaseUrl)
  11 |   const email = `c2-forward-${randomUUID()}@example.test`
  12 |   let itemId = ''
  13 |   try {
  14 |     const loginResponse = await context.request.post(api + '/api/v1/auth/login', { headers: { origin: String(testInfo.project.use.baseURL), 'idempotency-key': `c2-login-${randomUUID()}` }, data: { email: 'alice@example.test', password: 'password-acceptance' } })
  15 |     expect(loginResponse.ok()).toBe(true)
  16 |     const auth = await (await context.request.get(api + '/api/v1/auth/me')).json() as { actor: { id: string; workspace_id: string } }
  17 |     const team = (await db.query<{ id: string }>('SELECT id FROM teams WHERE workspace_id=$1 LIMIT 1', [auth.actor.workspace_id])).rows[0]!
  18 |     const bob = (await db.query<{ id: string }>(`INSERT INTO actors(workspace_id,kind,email,display_name,password_hash,workspace_role)
  19 |       SELECT workspace_id,'human',$2,'C2 forwarding Human',password_hash,'member' FROM actors WHERE id=$1 RETURNING id`, [auth.actor.id, email])).rows[0]!
  20 |     await db.query(`INSERT INTO memberships(workspace_id,team_id,actor_id,role) VALUES($1,$2,$3,'member')`, [auth.actor.workspace_id, team.id, bob.id])
  21 |     const item = (await db.query<{ id: string }>(`INSERT INTO inbox_items(workspace_id,recipient_human_actor_id,team_id,kind,source_type,source_id,payload)
  22 |       VALUES($1,$2,$3,'ask','activity',$4,'{"summary":"C2 仅授权 Human 可见"}') RETURNING id`, [auth.actor.workspace_id, auth.actor.id, team.id, randomUUID()])).rows[0]!
  23 |     itemId = item.id
  24 |     const id = `v1:inbox_item:${item.id}`, href = `/?view=inbox&attentionSelected=${encodeURIComponent(id)}`
  25 |     const counters = async () => (await db.query(`SELECT (SELECT count(*)::int FROM domain_events WHERE event_type LIKE 'decision.%' OR event_type LIKE 'approval.decision.%') AS events,
  26 |       (SELECT count(*)::int FROM outbox_events o JOIN domain_events e ON e.id=o.domain_event_id WHERE e.event_type LIKE 'decision.%' OR e.event_type LIKE 'approval.decision.%') AS outbox`)).rows[0]
  27 |     const before = await counters()
  28 |     await context.clearCookies()
  29 |     await page.goto(href)
  30 |     await expect(page).toHaveURL(/\/login\?returnTo=/)
  31 |     expect(new URL(page.url()).searchParams.get('returnTo')).toBe(href)
  32 |     await page.screenshot({ path: testInfo.outputPath('c2-before-login.png'), fullPage: true, animations: 'disabled' })
  33 |     const login = page.getByTestId('login-form')
  34 |     await login.locator('[name=email]').fill('alice@example.test')
  35 |     await login.locator('[name=password]').fill('password-acceptance')
  36 |     await page.getByTestId('login-submit').click()
  37 |     await expect(page).toHaveURL(url => url.searchParams.get('attentionSelected') === id)
  38 |     const center = page.getByTestId('attention-center')
  39 |     const heading = center.locator('.attention-detail-heading h3')
  40 |     await expect(heading).toBeVisible()
  41 |     await expect(heading).toBeFocused()
  42 |     await expect(center).toContainText('C2 仅授权 Human 可见')
  43 |     const title = await heading.innerText()
  44 |     await page.screenshot({ path: testInfo.outputPath('c2-after-authorized-login.png'), fullPage: true, animations: 'disabled' })
  45 |     // 没有启动提供方，渠道故障或关闭不影响普通网页可见。
  46 |     await page.reload(); await expect(heading).toBeVisible()
  47 |     await center.locator('.attention-detail-heading button').click()
  48 |     await expect(center.locator('.attention-select-prompt')).toBeFocused()
  49 |     await page.goto(href); await expect(heading).toBeFocused()
  50 |     await page.goto('/?view=inbox'); await expect(heading).toHaveCount(0)
  51 |     await page.goBack(); await expect(heading).toBeFocused()
  52 |     await page.goForward(); await expect(heading).toHaveCount(0)
  53 |     await context.clearCookies()
  54 |     await page.goto(href); await expect(page).toHaveURL(/\/login\?returnTo=/)
  55 |     await login.locator('[name=email]').fill(email)
  56 |     await login.locator('[name=password]').fill('password-acceptance')
  57 |     await page.getByTestId('login-submit').click()
> 58 |     await expect(page).toHaveURL(url => url.searchParams.get('attentionSelected') === id)
     |                        ^ Error: expect(page).toHaveURL(expected) failed
  59 |     await expect(center).toBeVisible()
  60 |     await expect(heading).toHaveCount(0)
  61 |     await expect(center).not.toContainText('C2 仅授权 Human 可见')
  62 |     await expect(center).not.toContainText(title)
  63 |     const current = await (await context.request.get(api + '/api/v1/auth/me')).json() as { actor: { id: string } }
  64 |     expect(current.actor.id).toBe(bob.id)
  65 |     await page.screenshot({ path: testInfo.outputPath('c2-forwarded-unauthorized.png'), fullPage: true, animations: 'disabled' })
  66 |     expect(await counters()).toEqual(before)
  67 |   } finally {
  68 |     if (itemId) await db.query('DELETE FROM inbox_items WHERE id=$1', [itemId])
  69 |     await db.query('DELETE FROM actors WHERE email=$1', [email])
  70 |     await db.end()
  71 |   }
  72 | })
  73 | 
  74 | test('C2 登录返回拒绝外域、协议相对和编码路径，回到首页', async ({ page, context }) => {
  75 |   for (const returnTo of ['https://evil.example/', '//evil.example/', '/%2f%2fevil.example', '/login']) {
  76 |     await context.clearCookies()
  77 |     await page.goto(`/login?${new URLSearchParams({ returnTo })}`)
  78 |     const form = page.getByTestId('login-form')
  79 |     await form.locator('[name=email]').fill('alice@example.test')
  80 |     await form.locator('[name=password]').fill('password-acceptance')
  81 |     await page.getByTestId('login-submit').click()
  82 |     await expect(page).toHaveURL(url => url.pathname === '/' && url.search === '')
  83 |   }
  84 | })
  85 | 
```