# 实施合同问题与修正证据

原审查全文保存在 [implementation-contract-review-original.md](implementation-contract-review-original.md)。这份实施内合同审查不代表平台成果独审，也不代表完整产品验收。最新用户要求继续同分支产品实现，修完问题、完整检查后交平台另一 Agent 成果独审。

## 实际来源和首败

恢复时工作树干净，精确源码 HEAD 为 `f0fcf961672541c234a7d1ce6194ea1d2b4f01ea`；其父主线整合提交为 `f4463da42e8c`。远端 `refs/heads/main` 本轮实读仍为 `69085317c88d84b702af727dc0ac7152589626d8`。原审查是在实施过程内只读追踪 schema、生成器、API 状态门禁和 SDK 凭据选择，不是运行产品测试。原报告的行号对应过程中所读文本，未保存该中间工作树精确 hash，故不伪填原报告受测 head；恢复时已提交的部分 variant/team scope 修正与原报告问题分别记录。原失败与旧受控方案都保持可达，未重写。

前轮首个 contracts typecheck 因 identityVariants.credentialMode 同时存在字符串与数组失败；规范化后 contracts 与 MCP typecheck 退出 0。原命令输出仅在工具会话内可见，没有当时原始文件，不能补造原始 stdout/runtime。当前轮所有新检查保存实际命令、进程退出码、运行时间、Git blob 与工作树输入，产品结果另列。

## 四项 High 与另外两项问题

| 问题、发现方法 | 已知拒绝/合法正例 | 修正与产品验证落点 |
| --- | --- | --- |
| 生成器丢失 proposed.variant；adapter 固定查 null；SDK reviewer 分支未选择。对照审定 variant、生成 TS 和实际 lookup。 | open_pull_request 缺 repo:open_pr 必须在发现层 blocked；reviewer complete/fail 缺 artifact:write 同样 blocked；完整联合能力保留目标前提。 | 生成 binding.variant，操作基础行纳入当前 role 的联合能力，SDK 与 adapter 选择真实变体；contracts 与 SDK 反例测试。 |
| typeRequired 未入 predicates。对照九项 Team planning 写的已审 scope 与生成规则。 | C/coordinator/team scope 正例；相同能力但非 team scope 必须 blocked，E 不能由 work:write 获协调 CRUD。 | 生成显式 delegationScopeType 谓词；九项逐操作测试及 MCP E 广告反例。 |
| C stale ACK 被先读拒 stale 的 manifest 阻断。交叉读取 commands.refreshAgentToken 与 authorize.sessionActiveForOperation。 | stale refresh→ACK 是既有合法 SDK 恢复；受保护 401/403 不刷新、不重发。 | 显式 ACK/Stop ACK/diagnostic heartbeat 保留既有 refresh 路径；普通目标 bridge 仍查 qualified，不放宽 manifest；SDK 实际顺序/计数验证。 |
| C room 多变体首匹配压掉省略目标的当前路径。按真实可选 sessionId 输入与 SDK refresh 分支追踪。 | C 未传 sessionId 且无 target bridge 可读取授权 work-item room；提供目标仅在安装 bridge 与目标 E 资格存在时走另一分支。 | 分别投影 identityVariants，调用按输入分支选；contracts/MCP 省略目标正例、显式目标无 bridge 反例。 |
| deploymentSupported 永等 registered。对照实际协调开关、只读模式及安装 bridge。 | callback 存在但部署未配置 bridge 的目标变体 deploymentSupported=false；当前变体可独立支持。 | registered 与部署支持分离；相同注册表不同部署参数测试。 |
| 两层 manifest actorId 与精确目标 actor 未核。交叉核 identity DTO 与局部 Token client。 | 同 actor、准确 E session 正例；agent.actorId 与 discovery.identity.actorId 不一致，或目标 actor 与当前 C actor 不符，立即拒绝，零领域命令。 | SDK strict 解析与 source/target actor/session/kind 核对，不写共享 token；SDK 错绑反例与并发目标隔离测试。 |

具体新运行证据由后续实际回执补充，未运行项不标通过。既有 stale 恢复只维持原 SDK/REST 门禁，不新增 MCP 清理入口；M1–M5 仍按已审范围承接。
