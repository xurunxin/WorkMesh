import { readFileSync } from 'node:fs'
import { dirname, resolve } from 'node:path'
import { fileURLToPath } from 'node:url'
import { parseDocument } from 'yaml'
import { externalTestInputs, externalTypecheckInputs } from './ci-test-inputs.mjs'
import { readWorkspaces } from './ci-policy.mjs'

const root = resolve(dirname(fileURLToPath(import.meta.url)), '..')
const workflow = readFileSync(resolve(root, '.github/workflows/ci.yml'), 'utf8')
const packageJson = JSON.parse(readFileSync(resolve(root, 'package.json'), 'utf8'))
const turboJson = JSON.parse(readFileSync(resolve(root, 'turbo.json'), 'utf8'))
const bootstrapHelperSource = readFileSync(resolve(root, 'scripts/set-ci-bootstrap-token.mjs'), 'utf8')
const nodeVersion = readFileSync(resolve(root, '.node-version'), 'utf8').trim()
const failures = []

const requireCondition = (condition, message) => {
  if (!condition) failures.push(message)
}
const occurrences = (pattern, value = workflow) => [...value.matchAll(pattern)].length
const workflowDocument = parseDocument(workflow, { prettyErrors: true })
requireCondition(workflowDocument.errors.length === 0, 'workflow must be valid YAML')
const parsedWorkflow = workflowDocument.toJS()

requireCondition(!workflow.includes('\t'), 'workflow must use spaces, not tabs')
requireCondition(
  workflow.split(/\r?\n/).every(line => line.trim() === '' || line.match(/^ */)[0].length % 2 === 0),
  'workflow indentation must use two-space increments',
)
requireCondition(!/[ \t]+$/m.test(workflow), 'workflow must not contain trailing whitespace')

requireCondition(/^name: CI$/m.test(workflow), 'workflow name must be CI')
requireCondition(/^on:\s*$/m.test(workflow), 'workflow must declare an on mapping')
requireCondition(/^  pull_request:\s*$/m.test(workflow), 'workflow must run for pull requests')
requireCondition(!/pull_request:\s*\n\s+branches:/m.test(workflow), 'pull requests must support every base branch')
requireCondition(/^  push:\s*\n    branches: \[main\]$/m.test(workflow), 'workflow must run for pushes to main')
requireCondition(/^  workflow_dispatch:\s*$/m.test(workflow), 'workflow must support manual dispatch')
requireCondition(/^  workflow_call:\s*$/m.test(workflow), 'workflow must support release-candidate reuse')
requireCondition(!workflow.includes('pull_request_target'), 'pull_request_target is forbidden')

requireCondition(
  /^permissions:\s*\n  contents: read$/m.test(workflow),
  'top-level permissions must be exactly contents: read',
)
requireCondition(
  !/^\s+[A-Za-z-]+:\s*write\s*$/m.test(workflow),
  'write permissions are forbidden',
)
requireCondition(
  /^concurrency:\s*\r?\n  group: .+github\.event_name.+github\.event\.pull_request\.number.+github\.run_id.+\r?\n  cancel-in-progress: .+github\.event_name == 'pull_request'/m.test(workflow),
  'concurrency must be pull-request scoped and cancel only pull-request runs',
)

const forbiddenMutationPatterns = [
  [/\b(?:npm|pnpm|yarn)\s+publish\b/i, 'package publication'],
  [/\b(?:npm|pnpm|yarn)\s+(?:version|pack)\b/i, 'package mutation'],
  [/\bdocker\s+(?:buildx\s+)?push\b/i, 'container publication'],
  [/\bgit\s+(?:push|tag)\b/i, 'Git history or tag mutation'],
  [/\bgh\s+release\b/i, 'GitHub release mutation'],
  [/\bpackages:\s*write\b/i, 'package write permission'],
  [/\bcontinue-on-error\s*:/i, 'continue-on-error'],
  [/\b(?:retry|max-attempts)\s*:/i, 'automatic retry'],
]
for (const [pattern, label] of forbiddenMutationPatterns)
  requireCondition(!pattern.test(workflow), `${label} is forbidden in foundational CI`)

const expectedActions = new Map([
  ['actions/checkout', '11d5960a326750d5838078e36cf38b85af677262'],
  ['actions/setup-node', '49933ea5288caeca8642d1e84afbd3f7d6820020'],
  ['actions/upload-artifact', 'ea165f8d65b6e75b540449e92b4886f43607fa02'],
  ['actions/cache/restore', '0400d5f644dc74513175e3cd8d07132dd4860809'],
  ['actions/cache/save', '0400d5f644dc74513175e3cd8d07132dd4860809'],
])
const uses = [...workflow.matchAll(/^\s*uses:\s*([^@\s]+)@([^\s]+)\s*$/gm)]
requireCondition(uses.length > 0, 'workflow must use pinned actions')
for (const [, action, revision] of uses) {
  requireCondition(/^[0-9a-f]{40}$/.test(revision), `${action} must use a full 40-character SHA`)
  requireCondition(expectedActions.has(action), `${action} is not an approved foundational CI action`)
  requireCondition(expectedActions.get(action) === revision, `${action} does not use the reviewed SHA`)
}
requireCondition(
  occurrences(/^\s*uses:\s*/gm) === uses.length,
  'every uses entry must have an explicit immutable revision',
)

const jobsStart = workflow.split(/\r?\n/).findIndex(line => line === 'jobs:')
requireCondition(jobsStart >= 0, 'workflow must declare jobs')
const lines = workflow.split(/\r?\n/)
const jobStarts = []
for (let index = jobsStart + 1; index < lines.length; index += 1) {
  const match = lines[index].match(/^  ([a-z0-9][a-z0-9-]*):\s*$/)
  if (match) jobStarts.push({ id: match[1], index })
}
const jobSections = new Map(jobStarts.map((job, index) => [
  job.id,
  lines.slice(job.index, jobStarts[index + 1]?.index ?? lines.length).join('\n'),
]))
const parseSteps = section => {
  const sectionLines = section.split('\n')
  const stepStarts = []
  for (let index = 0; index < sectionLines.length; index += 1) {
    const match = sectionLines[index].match(/^      - name:\s*(.+?)\s*$/)
    if (match) stepStarts.push({ name: match[1], index })
  }
  return stepStarts.map((step, index) => ({
    name: step.name,
    section: sectionLines.slice(step.index, stepStarts[index + 1]?.index ?? sectionLines.length).join('\n'),
  }))
}
const stepValue = (step, key, indentation) =>
  step.section.match(new RegExp(`^\\s{${indentation}}${key}:\\s*(.*?)\\s*$`, 'm'))?.[1]
const uploadAction = 'actions/upload-artifact@ea165f8d65b6e75b540449e92b4886f43607fa02'
const uploadStepsByJob = new Map([...jobSections].map(([jobId, section]) => [
  jobId,
  parseSteps(section)
    .filter(step => stepValue(step, 'uses', 8) === uploadAction)
    .map(step => ({
      ...step,
      condition: stepValue(step, 'if', 8),
      artifact: stepValue(step, 'name', 10),
      path: stepValue(step, 'path', 10),
      missingFiles: stepValue(step, 'if-no-files-found', 10),
      retentionDays: stepValue(step, 'retention-days', 10),
    })),
]))
const requiredJobs = [
  'changes',
  'source-gates',
  'db-integration',
  'api-integration',
  'worker-integration',
  'e2e',
  'recovery-integration',
  'agent-smoke',
  'required-ci',
]
requireCondition(
  JSON.stringify([...jobSections.keys()].sort()) === JSON.stringify([...requiredJobs].sort()),
  `workflow job IDs must be exactly: ${requiredJobs.join(', ')}`,
)

const rawArtifacts = new Map([
  ['changes', 'changes-raw-${{ github.run_id }}-${{ github.run_attempt }}'],
  ['source-gates', 'source-gates-raw-${{ github.run_id }}-${{ github.run_attempt }}'],
  ['db-integration', 'db-integration-raw-${{ github.run_id }}-${{ github.run_attempt }}'],
  ['api-integration', 'api-integration-raw-${{ github.run_id }}-${{ github.run_attempt }}'],
  ['worker-integration', 'worker-integration-raw-${{ github.run_id }}-${{ github.run_attempt }}'],
  ['e2e', 'e2e-raw-shard-${{ matrix.shard }}-${{ github.run_id }}-${{ github.run_attempt }}'],
  ['recovery-integration', 'recovery-integration-raw-${{ github.run_id }}-${{ github.run_attempt }}'],
  ['agent-smoke', 'agent-smoke-raw-${{ github.run_id }}-${{ github.run_attempt }}'],
  ['required-ci', 'required-ci-raw-${{ github.run_id }}-${{ github.run_attempt }}'],
])
for (const jobId of requiredJobs) {
  const section = jobSections.get(jobId) ?? ''
  requireCondition(/^\s{4}timeout-minutes:\s*\d+\s*$/m.test(section), `${jobId} needs a timeout`)
  requireCondition(section.includes('ci-logs'), `${jobId} must upload raw logs`)
  requireCondition(
    section.includes('actions/upload-artifact@ea165f8d65b6e75b540449e92b4886f43607fa02'),
    `${jobId} must use the reviewed upload-artifact action`,
  )
  requireCondition(section.includes('retention-days: 14'), `${jobId} logs must be retained for 14 days`)

  const expectedArtifact = rawArtifacts.get(jobId)
  const rawUploads = (uploadStepsByJob.get(jobId) ?? [])
    .filter(step => step.artifact === expectedArtifact)
  requireCondition(
    rawUploads.length === 1,
    `${jobId}/${expectedArtifact} must have exactly one upload step`,
  )
  const rawUpload = rawUploads[0]
  if (rawUpload) {
    requireCondition(
      rawUpload.condition === '${{ always() }}',
      `${jobId}/${expectedArtifact} must run with always()`,
    )
    requireCondition(rawUpload.path === 'ci-logs', `${jobId}/${expectedArtifact} must upload ci-logs`)
    requireCondition(
      rawUpload.missingFiles === 'error',
      `${jobId}/${expectedArtifact} must fail when raw logs are missing`,
    )
    requireCondition(rawUpload.retentionDays === '14', `${jobId}/${expectedArtifact} must be retained for 14 days`)
  }
}

const playwrightArtifact = 'e2e-playwright-shard-${{ matrix.shard }}-${{ github.run_id }}-${{ github.run_attempt }}'
const playwrightUploads = (uploadStepsByJob.get('e2e') ?? [])
  .filter(step => step.artifact === playwrightArtifact)
requireCondition(
  playwrightUploads.length === 1,
  `e2e/${playwrightArtifact} must have exactly one upload step`,
)
const playwrightUpload = playwrightUploads[0]
if (playwrightUpload) {
  requireCondition(
    playwrightUpload.condition === '${{ always() }}',
    `e2e/${playwrightArtifact} must run with always()`,
  )
  requireCondition(
    playwrightUpload.path === '|' &&
      playwrightUpload.section.includes('            apps/web/playwright-report') &&
      playwrightUpload.section.includes('            apps/web/test-results'),
    `e2e/${playwrightArtifact} must upload Playwright evidence from the web package directory`,
  )
  requireCondition(
    playwrightUpload.missingFiles === 'error',
    `e2e/${playwrightArtifact} must fail when Playwright evidence is missing`,
  )
  requireCondition(playwrightUpload.retentionDays === '14', `e2e/${playwrightArtifact} must be retained for 14 days`)
}

for (const [jobId, uploads] of uploadStepsByJob) {
  for (const upload of uploads) {
    const failureOnlyServiceLogs =
      upload.condition === '${{ failure() }}' &&
      upload.section.includes('ci-logs/services')
    if (failureOnlyServiceLogs)
      requireCondition(
        upload.missingFiles === 'ignore' || upload.missingFiles === 'error',
        `${jobId}/${upload.artifact ?? upload.name} failure-only service logs may use ignore or error`,
      )
  }
}

const executableJobs = requiredJobs.filter(job => job !== 'required-ci' && job !== 'changes')
for (const jobId of executableJobs) {
  const section = jobSections.get(jobId) ?? ''
  requireCondition(
    section.includes('actions/checkout@11d5960a326750d5838078e36cf38b85af677262'),
    `${jobId} must check out the source`,
  )
  requireCondition(section.includes('persist-credentials: false'), `${jobId} must disable persisted credentials`)
  requireCondition(section.includes('node-version-file: .node-version'), `${jobId} must use .node-version`)
  requireCondition(section.includes('cache: pnpm'), `${jobId} must cache the pnpm store`)
  requireCondition(section.includes('pnpm install --frozen-lockfile'), `${jobId} must use the frozen lockfile`)
}
requireCondition(
  occurrences(/persist-credentials:\s*false/g) === occurrences(/actions\/checkout@/g),
  'every checkout must disable persisted credentials',
)
requireCondition(!/(?:node_modules|\.next|dist\/\*\*)\s*$/m.test(workflow), 'build or install outputs must not be cached or uploaded')

const source = jobSections.get('source-gates') ?? ''
const browserInstall = parsedWorkflow.jobs.e2e.steps.find(step => step.name === 'Install Playwright Chromium')
requireCondition(browserInstall?.['timeout-minutes'] === 8, 'browser installation must have an eight-minute bound')
for (const input of ['https://archive.ubuntu.com/ubuntu/', 'https://security.ubuntu.com/ubuntu/', 'Acquire::Retries "2";', 'Acquire::http::Timeout "15";', 'Acquire::https::Timeout "15";']) {
  requireCondition(browserInstall?.run?.includes(input), `browser preparation must retain official mirrors and bounded downloads: ${input}`)
}
requireCondition(browserInstall?.run?.includes('playwright install --with-deps chromium'), 'browser preparation must retain required OS dependencies')
const cacheSteps = Object.entries(parsedWorkflow.jobs).flatMap(([jobId, job]) =>
  (job.steps ?? []).filter(step => step.uses?.startsWith('actions/cache/')).map(step => ({ jobId, ...step })))
requireCondition(cacheSteps.length === 2, 'only one compiler/static cache restore and save pair is allowed')
for (const step of cacheSteps) {
  requireCondition(step.jobId === 'source-gates', 'compiler/static caches belong only to source-gates')
  requireCondition(step.with?.path === '.turbo/typecheck\napps/web/.next/cache\n', 'cross-run cache paths must be exactly pure typechecks and Next compiler intermediates')
  requireCondition(step.with?.key === "source-v2-${{ runner.os }}-node22-${{ hashFiles('pnpm-lock.yaml') }}-${{ github.sha }}", 'cache key must bind platform, toolchain, lockfile and commit')
  if (step.uses?.startsWith('actions/cache/save@')) {
    requireCondition(step.if === "${{ success() && github.event_name == 'push' && github.ref == 'refs/heads/main' }}", 'only successful main pushes may publish compiler/static caches')
  }
}
requireCondition(!turboJson.globalEnv, 'runtime credentials must not invalidate pure static tasks globally')
const sourceRunner = readFileSync(resolve(root, 'scripts/run-ci-source.mjs'), 'utf8')
requireCondition(sourceRunner.includes("if (task === 'lint') args.push('--only')") && !/if\s*\([^\n]*typecheck[^\n]*\)[^\n]*args\.push\('--only'\)/.test(sourceRunner), 'cached typechecks must retain Turbo upstream dependency hashes')
for (const input of ['scripts/**', 'playwright*.ts']) requireCondition(turboJson.globalDependencies?.includes(input), `static caches must hash imported root input ${input}`)
for (const [name, inputs] of Object.entries(externalTypecheckInputs)) {
  requireCondition(JSON.stringify(turboJson.tasks?.[`${name}#typecheck`]?.inputs) === JSON.stringify(['$TURBO_DEFAULT$', ...inputs.map(input => `$TURBO_ROOT$/${input}`)]), `${name} typecheck must hash directly imported fixture source outside runtime dependencies`)
  requireCondition(JSON.stringify(turboJson.tasks?.[`${name}#typecheck`]?.dependsOn) === JSON.stringify(turboJson.tasks.typecheck.dependsOn), `${name} typecheck must retain upstream typechecks`)
}
for (const [name, inputs] of Object.entries(externalTestInputs)) {
  requireCondition(JSON.stringify(turboJson.tasks?.[`${name}#test`]?.inputs) === JSON.stringify(['$TURBO_DEFAULT$', ...inputs.map(input => `$TURBO_ROOT$/${input}`)]), `${name} tests must hash their complete declared external inputs`)
  requireCondition(JSON.stringify(turboJson.tasks?.[`${name}#test`]?.env) === JSON.stringify(turboJson.tasks.test.env), `${name} tests must retain runtime environment hashing`)
  requireCondition(JSON.stringify(turboJson.tasks?.[`${name}#test`]?.dependsOn) === JSON.stringify(turboJson.tasks.test.dependsOn), `${name} tests must retain prerequisite builds`)
}
for (const task of ['build', 'test', 'test:integration', 'test:e2e']) {
  requireCondition(JSON.stringify(turboJson.tasks?.[task]?.env) === JSON.stringify(turboJson.globalPassThroughEnv), `${task} must retain runtime environment hashing`)
}
for (const task of ['test:integration', 'test:e2e']) requireCondition(turboJson.tasks?.[task]?.cache === false, `${task} results must never be cached`)
requireCondition(parsedWorkflow.jobs.changes.outputs['test-packages'] === '${{ steps.scope.outputs.test-packages }}', 'changes must expose external test consumers')
requireCondition(parsedWorkflow.jobs['source-gates'].env.CI_TEST_PACKAGES === '${{ needs.changes.outputs.test-packages }}', 'source tests must consume the separate audit selection')
requireCondition(packageJson.scripts['test:e2e'] === 'turbo run test:e2e --filter=@workmesh/web', 'browser acceptance must avoid synthetic E2E builds in unrelated packages')
requireCondition(JSON.stringify(readWorkspaces().filter(workspace => workspace.scripts['test:e2e']).map(workspace => workspace.name)) === JSON.stringify(['@workmesh/web']), 'review the E2E scope when another workspace gains an executable acceptance suite')
requireCondition(JSON.stringify(parsedWorkflow.jobs.e2e.strategy) === JSON.stringify({ 'fail-fast': false, matrix: { shard: [1, 2] } }), 'browser acceptance must run both isolated shards without cancelling evidence')
requireCondition((jobSections.get('e2e') ?? '').includes('pnpm test:e2e -- --shard=${{ matrix.shard }}/2'), 'E2E must execute the matrix shard')
requireCondition((jobSections.get('e2e') ?? '').includes('node ../../scripts/check-e2e-shards.mjs'), 'E2E must prove complete and disjoint shard collection before execution')
for (const command of [
  'pnpm ci:validate',
  'pnpm ci:source lint',
  'pnpm ci:source typecheck',
  'pnpm check:route-policy',
  'pnpm check:workmesh-skill',
  'pnpm check:runner-skill',
  'pnpm ci:source build',
  'pnpm ci:source test',
  'docker compose config',
  'git diff --exit-code',
  'git diff --cached --exit-code',
])
  requireCondition(source.includes(command), `source-gates must run ${command}`)
requireCondition(!source.includes('format:check'), 'format:check is deferred beyond Issue #10A')

requireCondition(!source.includes('pnpm --filter @workmesh/contracts test'), 'contracts must run only in the selected unit suite')
requireCondition(!source.includes('pnpm lint 2>&1'), 'CI must not repeat identical lint/typecheck commands')
for (const jobId of executableJobs) {
  requireCondition(
    parsedWorkflow.jobs[jobId].needs === 'changes',
    `${jobId} must start after classification without waiting for the build/unit critical path`,
  )
  requireCondition(
    parsedWorkflow.jobs[jobId].if === '${{ needs.changes.outputs.' + jobId + " == 'true' }}",
    `${jobId} must use exactly the classifier decision`,
  )
}
const changes = jobSections.get('changes') ?? ''
requireCondition(parsedWorkflow.jobs.changes?.outputs?.plan === '${{ steps.scope.outputs.plan }}', 'changes must expose the exact plan used by the aggregate')
for (const jobId of executableJobs) {
  requireCondition(parsedWorkflow.jobs.changes?.outputs?.[jobId] === '${{ steps.scope.outputs.' + jobId + ' }}', `changes must expose ${jobId}`)
}
requireCondition(changes.includes('fetch-depth: 0'), 'change classification needs complete comparison history')
requireCondition(changes.includes('node scripts/ci-policy.mjs'), 'changes must run the classifier')
requireCondition(changes.includes('node --test scripts/ci-policy.test.mjs'), 'changes must test selection and aggregation before deciding skips')
requireCondition(!changes.includes('pnpm install'), 'documentation classification must not install the monorepo')
requireCondition(!parsedWorkflow.on?.pull_request?.paths && !parsedWorkflow.on?.pull_request?.['paths-ignore'], 'required workflow must not be skipped by path filters')
requireCondition(!parsedWorkflow.on?.push?.paths && !parsedWorkflow.on?.push?.['paths-ignore'], 'main must always produce Required CI')
requireCondition(Boolean(parsedWorkflow.on?.schedule?.length), 'CI must retain scheduled full acceptance')
requireCondition(Object.hasOwn(parsedWorkflow.on ?? {}, 'merge_group'), 'merge queues must produce Required CI')
requireCondition((jobSections.get('db-integration') ?? '').includes('pnpm test:integration:db'), 'db integration command is missing')
requireCondition((jobSections.get('api-integration') ?? '').includes('pnpm test:integration:api'), 'API integration command is missing')
// The workbench runner integration suite authenticates with this shared secret,
// and the route rejects a missing or shorter value. Without it the suite fails
// with `invalid value "undefined" for header x-workmesh-runner-token`, which no
// other assertion would catch because the failure is inside the test run.
requireCondition(
  /^\s{6}WORKMESH_RUNNER_SERVICE_TOKEN:\s*\S{32,}\s*$/m.test(jobSections.get('api-integration') ?? ''),
  'API integration must declare a WORKMESH_RUNNER_SERVICE_TOKEN of at least 32 characters',
)
requireCondition((jobSections.get('worker-integration') ?? '').includes('pnpm test:integration:worker'), 'worker integration command is missing')
requireCondition((jobSections.get('recovery-integration') ?? '').includes('pnpm --filter @workmesh/recovery test:integration'), 'recovery integration command is missing')
requireCondition((jobSections.get('recovery-integration') ?? '').includes('pnpm --filter @workmesh/recovery smoke:restored'), 'restored service and Agent smoke command is missing')
for (const dockerfile of ['api.production.Dockerfile', 'worker.production.Dockerfile', 'web.production.Dockerfile']) {
  requireCondition((jobSections.get('recovery-integration') ?? '').includes(dockerfile), `recovery integration must build ${dockerfile}`)
}
for (const service of ['api', 'worker', 'web']) {
  requireCondition((jobSections.get('recovery-integration') ?? '').includes(`--name workmesh-ci-recovery-${service}`), `recovery integration must start the production ${service} image`)
}
requireCondition((jobSections.get('recovery-integration') ?? '').includes('RECOVERY_TEST_REPORT_PATH: ${{ github.workspace }}/ci-logs/recovery-report.json'), 'recovery report evidence path is missing')
requireCondition((jobSections.get('recovery-integration') ?? '').includes('RECOVERY_SMOKE_REPORT_PATH: ${{ github.workspace }}/ci-logs/recovery-service-smoke.json'), 'recovery smoke evidence path is missing')
requireCondition(!(jobSections.get('worker-integration') ?? '').includes('redis:'), 'worker integration must not provision Redis')
requireCondition((jobSections.get('e2e') ?? '').includes('playwright install --with-deps chromium'), 'E2E must install Chromium only')
requireCondition((jobSections.get('e2e') ?? '').includes('playwright-report'), 'E2E must upload playwright-report')
requireCondition((jobSections.get('e2e') ?? '').includes('test-results'), 'E2E must upload test-results')
const requiredE2eEnvironment = [
  'RUN_INTEGRATION',
  'DATABASE_URL',
  'SESSION_SECRET',
  'WORKMESH_MASTER_KEY',
]
const e2e = jobSections.get('e2e') ?? ''
for (const name of requiredE2eEnvironment) {
  requireCondition(
    new RegExp(`^\\s{6}${name}:`, 'm').test(e2e),
    `E2E must declare ${name}`,
  )
  requireCondition(
    Array.isArray(turboJson.tasks['test:e2e'].env) && turboJson.tasks['test:e2e'].env.includes(name),
    `Turbo E2E env must forward and hash ${name}`,
  )
}
const expectedBootstrapInvocations = [
  ['source-gates', 'source-gates'],
  ['db-integration', 'db-integration'],
  ['api-integration', 'api-integration'],
  ['worker-integration', 'worker-integration'],
  ['e2e', 'e2e'],
  ['recovery-integration', 'recovery-integration'],
]
const bootstrapHelper = 'scripts/set-ci-bootstrap-token.mjs'
const bootstrapInvocations = []
for (const [jobId, job] of Object.entries(parsedWorkflow?.jobs ?? {})) {
  for (const step of job?.steps ?? []) {
    if (typeof step?.run !== 'string') continue
    for (const rawLine of step.run.split(/\r?\n/)) {
      const line = rawLine.trim()
      if (!line.includes(bootstrapHelper)) continue
      const match = /^node scripts\/set-ci-bootstrap-token\.mjs ([a-z0-9-]+)$/.exec(line)
      requireCondition(
        Boolean(match),
        `${jobId} must invoke the bootstrap helper directly with exactly one literal scope`,
      )
      bootstrapInvocations.push({ jobId, scope: match?.[1] ?? null })
    }
  }
}
const actualBootstrapScopes = bootstrapInvocations
  .map(invocation => invocation.scope)
  .filter(scope => scope !== null)
  .sort()
const expectedBootstrapScopes = expectedBootstrapInvocations
  .map(([, scope]) => scope)
  .sort()
requireCondition(
  bootstrapInvocations.length === expectedBootstrapInvocations.length
    && JSON.stringify(actualBootstrapScopes) === JSON.stringify(expectedBootstrapScopes),
  'CI must invoke the bootstrap helper exactly once for each approved scope',
)
requireCondition(
  occurrences(new RegExp(bootstrapHelper.replace(/[.*+?^${}()|[\]\\]/g, '\\$&'), 'g'))
    === bootstrapInvocations.length,
  'CI must not reference the bootstrap helper outside a direct run command',
)
requireCondition(
  !Object.values(packageJson.scripts ?? {}).some(command =>
    typeof command === 'string' && command.includes(bootstrapHelper)),
  'CI bootstrap helper invocations must not be hidden behind package script aliases',
)
for (const [jobId, scope] of expectedBootstrapInvocations) {
  requireCondition(
    (jobSections.get(jobId) ?? '').includes(`node scripts/set-ci-bootstrap-token.mjs ${scope}`),
    `${jobId} must derive its test-only bootstrap credential without logging it`,
  )
  requireCondition(
    bootstrapInvocations.some(invocation =>
      invocation.jobId === jobId && invocation.scope === scope),
    `${jobId} must own bootstrap scope ${scope}`,
  )
}
requireCondition(
  !/^\s+WORKMESH_BOOTSTRAP_TOKEN:/m.test(workflow),
  'CI must not publish a fixed bootstrap credential',
)
requireCondition(
  !/\b(?:echo|printf|cat|tee)\b[^\r\n]*WORKMESH_BOOTSTRAP_TOKEN/.test(workflow)
    && !workflow.includes('$GITHUB_ENV'),
  'CI steps must not print or inspect the runtime-generated bootstrap credential',
)
requireCondition(
  Array.isArray(turboJson.globalPassThroughEnv) && turboJson.globalPassThroughEnv.includes('WORKMESH_BOOTSTRAP_TOKEN'),
  'Turbo must forward the runtime-generated bootstrap credential',
)
for (const name of ['PAGINATION_CURSOR_KEYS', 'PAGINATION_CURSOR_ACTIVE_KID']) {
  requireCondition(
    bootstrapHelperSource.includes(`${name}=`),
    `CI credential helper must derive ${name} without logging it`,
  )
  requireCondition(
    Array.isArray(turboJson.globalPassThroughEnv) && turboJson.globalPassThroughEnv.includes(name),
    `Turbo must forward ${name}`,
  )
}
requireCondition(
  source.includes('docker compose config --quiet'),
  'source-gates must validate Compose without rendering expanded environment values',
)
requireCondition(
  !/docker compose config(?! --quiet)[^\r\n]*(?:tee|>)/.test(source)
    && !source.includes('docker compose config 2>&1 | tee'),
  'source-gates must not upload raw rendered Compose configuration',
)
requireCondition(
  source.includes("printf '%s\\n' 'Compose configuration is valid.' | tee ci-logs/compose-config.log"),
  'source-gates must record only a constant Compose validation success line',
)
requireCondition((jobSections.get('agent-smoke') ?? '').includes('pnpm smoke:agents:ci'), 'agent construction/protocol smoke command is missing')
requireCondition(packageJson.scripts?.['smoke:agents:ci'] === 'pnpm --filter @workmesh/mcp smoke && pnpm --filter @workmesh/fake-agent smoke', 'CI smoke must not rerun SDK unit tests')
requireCondition(
  (jobSections.get('agent-smoke') ?? '').includes('Construction and protocol smoke'),
  'agent smoke must be labelled as construction/protocol evidence',
)

const postgresImage = 'postgres:16-alpine@sha256:57c72fd2a128e416c7fcc499958864df5301e940bca0a56f58fddf30ffc07777'
// MinIO withdrew the `minio/minio` and `minio/mc` repositories from Docker Hub
// (hub.docker.com/v2/repositories/minio/minio/ now returns 404), and its quay.io
// namespace then began answering unauthenticated manifest requests with 401, so
// both the server and the `mc` bucket-initializer image became unpullable and
// every job that started artifact storage died in its infrastructure step.
// Artifact storage now runs on RustFS, which is actively published and passes the
// S3 semantics WorkMesh depends on (versioning, Object Lock on create, COMPLIANCE
// retention, legal hold, delete markers, ListObjectVersions). One image covers
// both roles: it ships curl with --aws-sigv4, so the bucket step no longer needs
// a second image. The digest pins the exact reviewed build.
const artifactStorageImage = 'rustfs/rustfs:1.0.0@sha256:8cc9801755448b71a786705ce76692c77e14936cccd87cf2fc31842e58f4d1ff'
requireCondition(occurrences(new RegExp(postgresImage.replace(/[.*+?^${}()|[\]\\]/g, '\\$&'), 'g')) === 5, 'five isolated jobs must use the reviewed PostgreSQL image')
const api = jobSections.get('api-integration') ?? ''
requireCondition(api.includes(artifactStorageImage), 'API integration must use the reviewed artifact-storage image')
requireCondition(
  api.includes('--aws-sigv4') && api.includes('workmesh-artifacts'),
  'API integration must initialize the artifact bucket through a signed request',
)
const recovery = jobSections.get('recovery-integration') ?? ''
requireCondition(recovery.includes(artifactStorageImage), 'recovery integration must use the reviewed artifact-storage image')
requireCondition(recovery.includes('http://127.0.0.1:9000/health/ready'), 'recovery integration must wait for artifact-storage readiness')
requireCondition(
  api.includes('http://127.0.0.1:9000/health/ready'),
  'API integration must wait for artifact-storage readiness before bucket initialization',
)
requireCondition(
  !api.includes('9000/health/live'),
  'API integration must not use artifact-storage liveness as its bucket-initialization gate',
)
requireCondition(
  !api.includes('quay.io/minio') && !recovery.includes('quay.io/minio'),
  'artifact storage must not reference the withdrawn MinIO images',
)
for (const database of [
  'workmesh_db_integration_test',
  'workmesh_api_integration_test',
  'workmesh_worker_integration_test',
  'workmesh_e2e_test',
  'workmesh_recovery_source_test',
  'workmesh_recovery_target_test',
])
  requireCondition(workflow.includes(database), `missing isolated database ${database}`)
for (const jobId of ['db-integration', 'api-integration', 'worker-integration', 'e2e', 'recovery-integration']) {
  const section = jobSections.get(jobId) ?? ''
  requireCondition(section.includes("${{ failure() }}"), `${jobId} must capture service logs on failure`)
  requireCondition(section.includes('docker logs'), `${jobId} must capture raw service logs`)
}

const required = jobSections.get('required-ci') ?? ''
const needs = required.match(/needs:\s*\[([^\]]+)\]/)?.[1]
  ?.split(',')
  .map(value => value.trim())
  .filter(Boolean) ?? []
const expectedNeeds = requiredJobs.filter(job => job !== 'required-ci')
requireCondition(
  JSON.stringify([...needs].sort()) === JSON.stringify([...expectedNeeds].sort()),
  'required-ci must need source-gates and every constituent job',
)
requireCondition(required.includes('if: ${{ always() }}'), 'required-ci must aggregate with always()')
requireCondition(required.includes('node scripts/ci-policy.mjs aggregate'), 'required-ci must validate successes and only explicitly planned skips')
requireCondition(required.includes('node-version: 22.19.0'), 'required-ci must pin its Node runtime')

requireCondition(packageJson.packageManager === 'pnpm@9.15.4', 'packageManager must be pnpm@9.15.4')
requireCondition(nodeVersion === '22.19.0', 'Node must be pinned to 22.19.0')
requireCondition(
  occurrences(/corepack prepare pnpm@9\.15\.4 --activate/g) === executableJobs.length,
  'every executable job must activate pnpm@9.15.4 with Corepack',
)
const expectedIntegrationScripts = {
  'test:integration': 'pnpm test:integration:db && pnpm test:integration:api && pnpm test:conformance:integration && pnpm test:integration:worker && pnpm test:integration:recovery',
  'test:conformance:integration': 'node scripts/require-integration-env.mjs && pnpm --filter @workmesh/db test:reset && pnpm --filter @workmesh/conformance test:integration',
  'test:integration:db': 'node scripts/require-integration-env.mjs && pnpm --filter @workmesh/db test:reset && pnpm --filter @workmesh/db test:integration',
  'test:integration:api': 'node scripts/require-integration-env.mjs && pnpm --filter @workmesh/db test:reset && pnpm --filter @workmesh/api test:integration',
  'test:integration:worker': 'node scripts/require-integration-env.mjs && pnpm --filter @workmesh/db test:reset && pnpm --filter @workmesh/worker test:integration',
  'test:integration:recovery': 'node scripts/require-integration-env.mjs && pnpm --filter @workmesh/recovery test:integration',
}
for (const [name, command] of Object.entries(expectedIntegrationScripts))
  requireCondition(packageJson.scripts?.[name] === command, `${name} must preserve the reviewed reset and execution order`)

const mcpConfig = readFileSync(resolve(root, 'packages/conformance/vitest.integration.config.ts'), 'utf8')
const conformanceManifest = JSON.parse(readFileSync(resolve(root, 'packages/conformance/package.json'), 'utf8'))
const realMcpStep = parsedWorkflow.jobs?.['api-integration']?.steps?.find(step => step.name === 'Run real MCP and Pi conformance')
requireCondition(realMcpStep?.run?.includes('pnpm test:conformance:integration'), 'Required API job must execute real MCP conformance')
requireCondition(realMcpStep?.run?.includes('set -o pipefail') && !realMcpStep?.['continue-on-error'], 'MCP conformance failures must propagate')
requireCondition(api.indexOf('pnpm test:conformance:integration') > api.indexOf('pnpm test:integration:api'), 'MCP services must run after API integration')
requireCondition(realMcpStep?.run?.includes('ci-logs/mcp-coverage/conformance.log'), 'MCP evidence must be included in always-uploaded API logs')
requireCondition(conformanceManifest.scripts?.['test:integration'] === 'vitest run --config vitest.integration.config.ts', 'Real conformance entry must use the dedicated config')
requireCondition(mcpConfig.includes("include: ['src/mcp-coverage.conformance.test.ts']") && mcpConfig.includes('passWithNoTests: false') && mcpConfig.includes('fileParallelism: false'), 'Real conformance must be explicit, nonempty and serial')
requireCondition(readFileSync(resolve(root, 'vitest.config.ts'), 'utf8').includes('**/mcp-coverage.conformance.test.ts'), 'Real conformance must be excluded from memory unit discovery')

if (failures.length > 0) {
  console.error('[ci:validate] CI policy validation failed:')
  for (const failure of failures) console.error(`- ${failure}`)
  process.exitCode = 1
} else {
  console.log(`[ci:validate] OK: ${requiredJobs.length} jobs, ${uses.length} immutable action references, Node ${nodeVersion}, ${packageJson.packageManager}`)
}
