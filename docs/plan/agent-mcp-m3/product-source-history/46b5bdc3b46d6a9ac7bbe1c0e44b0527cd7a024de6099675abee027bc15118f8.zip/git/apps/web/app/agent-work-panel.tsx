'use client'

import { type FormEvent, useCallback, useEffect, useId, useMemo, useRef, useState } from 'react'
import { Button } from '@workmesh/ui'
import { ApiError, apiRequest, json } from './lib/api'
import { agentDelegationScopeKey, type Agent, type AgentSession, type Approval, type PlanVersion, activeAgentTeamAccess, agentName, agentProvider, agentStateClass, agentStateLabel, approvedAgentCapabilitiesForTeam, canAgentExecuteWorkForTeam, canPauseAgentSession, canRetryAgentSession, canStopAgentSession, createAgentSession, formatTime, isCurrentAgentDelegationScope, normalizeApproval, normalizePlan, parseAgent } from './lib/agents'
import { LoadMoreButton, type PagedCollection, usePagedApiList } from './lib/pagination'
import { type RealtimeResource, useRealtimeSubscription } from './lib/realtime'
import { agentWorkRefreshTargets } from './lib/realtime-refresh'
import { useLocale } from './lib/i18n'
import { AgentRunTimeline } from './agent-run-timeline'
import { AgentControlDialog, type AgentControlAction } from './agent-control-dialog'

type DelegationControllerInput = { workItemId: string | null; workItemTeamId: string | null; workItemRevision: number; humanActorId: string; workItemTitle?: string; scopeKey?: string | null }
export type LatestAgentSession = { agent: Agent; session: AgentSession }
export type AgentDelegationAvailabilityReason = 'missing_responsible_human' | 'loading_agents' | 'agents_unavailable' | 'no_eligible_agent' | 'delegating' | null
export type AgentDelegationController = {
  scopeKey: string
  agentsPage: PagedCollection<Agent>
  eligibleAgents: Agent[]
  directAgent: Agent | undefined
  canDirect: boolean
  canChoose: boolean
  disabled: boolean
  reason: AgentDelegationAvailabilityReason
  chooserRequest: number
  requestChooser: () => void
  consumeChooserRequest: () => void
  create: (agent: Agent, prompt: string) => Promise<AgentSession>
  error: unknown
  busy: boolean
  latest: LatestAgentSession | null
  clearLatest: () => void
  clearError: () => void
}

type DelegationControllerState = {
  scopeKey: string
  chooserRequest: number
  error: unknown
  busy: boolean
  latest: LatestAgentSession | null
}

const emptyDelegationControllerState = (scopeKey: string): DelegationControllerState => ({ scopeKey, chooserRequest: 0, error: null, busy: false, latest: null })

export function useAgentDelegationController(input: DelegationControllerInput): AgentDelegationController {
  const generationKey = agentDelegationScopeKey(input)
  const generationRef = useRef(generationKey)
  if (generationRef.current !== generationKey) generationRef.current = generationKey
  const agentsPage = usePagedApiList<Agent, Agent>(input.workItemId ? '/api/v1/agents' : null, { map: parseAgent, optional: true, scopeKey: input.scopeKey })
  const [state, setState] = useState<DelegationControllerState>(() => emptyDelegationControllerState(generationKey))
  // React preserves hook state for a rerender. Mask the old scope during the
  // render that observes a new Issue so a pending request cannot flash in the
  // next Issue before the reset effect runs.
  const scopedState = state.scopeKey === generationKey ? state : emptyDelegationControllerState(generationKey)
  const eligibleAgents = useMemo(() => agentsPage.items.filter(agent => agent.is_active && input.workItemTeamId !== null && canAgentExecuteWorkForTeam(agent, input.workItemTeamId)), [agentsPage.items, input.workItemTeamId])
  const agentsComplete = agentsPage.initialized && !agentsPage.loading && !agentsPage.loadingMore && agentsPage.nextCursor === null
  const canDirect = Boolean(input.humanActorId && agentsComplete && eligibleAgents.length === 1)
  const canChoose = Boolean(input.humanActorId && agentsPage.initialized && !agentsPage.error && (eligibleAgents.length > 0 || agentsPage.nextCursor !== null))
  const reason: AgentDelegationAvailabilityReason = scopedState.busy
    ? 'delegating'
    : !input.humanActorId
      ? 'missing_responsible_human'
      : agentsPage.error
        ? 'agents_unavailable'
        : !agentsPage.initialized || (!canChoose && (agentsPage.loading || agentsPage.loadingMore))
          ? 'loading_agents'
          : agentsComplete && eligibleAgents.length === 0
            ? 'no_eligible_agent'
            : null
  const disabled = scopedState.busy || (!canDirect && !canChoose)
  const create = useCallback(async (agent: Agent, prompt: string) => {
    const requestGeneration = generationKey
    setState(current => current.scopeKey === requestGeneration ? { ...current, busy: true, error: null } : current)
    try {
      const session = await createAgentSession({ workItemId: input.workItemId ?? '', workItemTeamId: input.workItemTeamId ?? '', workItemRevision: input.workItemRevision, humanActorId: input.humanActorId, agent, prompt, budget: {} })
      if (isCurrentAgentDelegationScope(generationRef.current, requestGeneration)) setState(current => current.scopeKey === requestGeneration ? { ...current, latest: { agent, session } } : current)
      return session
    } catch (reason) {
      if (isCurrentAgentDelegationScope(generationRef.current, requestGeneration)) setState(current => current.scopeKey === requestGeneration ? { ...current, error: reason } : current)
      throw reason
    } finally {
      if (isCurrentAgentDelegationScope(generationRef.current, requestGeneration)) setState(current => current.scopeKey === requestGeneration ? { ...current, busy: false } : current)
    }
  }, [generationKey, input.humanActorId, input.workItemId, input.workItemRevision, input.workItemTeamId])
  const clearLatest = useCallback(() => setState(current => current.scopeKey === generationKey ? { ...current, latest: null } : current), [generationKey])
  const clearError = useCallback(() => setState(current => current.scopeKey === generationKey ? { ...current, error: null } : current), [generationKey])
  const requestChooser = useCallback(() => setState(current => current.scopeKey === generationKey
    ? { ...current, chooserRequest: current.chooserRequest + 1 }
    : { ...emptyDelegationControllerState(generationKey), chooserRequest: 1 }), [generationKey])
  const consumeChooserRequest = useCallback(() => setState(current => current.scopeKey === generationKey && current.chooserRequest !== 0
    ? { ...current, chooserRequest: 0 }
    : current), [generationKey])
  useEffect(() => {
    setState(emptyDelegationControllerState(generationKey))
  }, [generationKey])
  return {
    scopeKey: generationKey,
    agentsPage,
    eligibleAgents,
    directAgent: canDirect ? eligibleAgents[0] : undefined,
    canDirect,
    canChoose,
    disabled,
    reason,
    chooserRequest: scopedState.chooserRequest,
    requestChooser,
    consumeChooserRequest,
    create,
    error: scopedState.error,
    busy: scopedState.busy,
    latest: scopedState.latest,
    clearLatest,
    clearError,
  }
}

type Props = { workspaceId: string; workItemId: string; workItemTeamId: string; workItemRevision: number; humanActorId: string; workItemTitle?: string; activeAssignmentName?: string | null; controller: AgentDelegationController; onReloadWorkItem?: () => void; onSessionCreated?: (session: AgentSession) => void }

const capacityStates = new Set(['queued', 'acknowledged', 'planning', 'executing', 'awaiting_input', 'awaiting_approval', 'blocked', 'paused', 'stopping', 'stale'])
const safeCount = (value: unknown): number | undefined => typeof value === 'number' && Number.isSafeInteger(value) && value >= 0 && value <= 1_000_000 ? value : undefined
const safeDiagnosticId = (value: unknown): string | undefined => typeof value === 'string' && /^[A-Za-z0-9][A-Za-z0-9._:-]{0,127}$/.test(value) ? value : undefined

function capacityErrorDetails(error: ApiError, format: (active: string, max: string, states: string) => string): string | null {
  if (error.code !== 'AGENT_CONCURRENCY_LIMIT' || !error.details || typeof error.details !== 'object') return null
  const details = error.details as Record<string, unknown>
  const active = safeCount(details.activeExecutionSessionCount)
  const max = safeCount(details.maxConcurrency)
  if (active === undefined || max === undefined) return null
  const states = details.activeExecutionSessionsByState && typeof details.activeExecutionSessionsByState === 'object'
    ? Object.entries(details.activeExecutionSessionsByState as Record<string, unknown>)
      .filter(([state, count]) => capacityStates.has(state) && safeCount(count) !== undefined)
      .sort(([left], [right]) => left.localeCompare(right))
      .map(([state, count]) => `${state} ${safeCount(count)}`)
      .join(', ')
    : ''
  return format(String(active), String(max), states)
}

export function AgentBadge({ state }: { state: AgentSession['state'] }) {
  const { agentWorkCopy: text } = useLocale()
  return <span aria-label={text.badgeAria(agentStateLabel(state))} className={agentStateClass(state)}>{agentStateLabel(state)}</span>
}

function AgentExecutionProjection({ session }: { session: AgentSession }) {
  const { agentWorkCopy: text } = useLocale()
  const plansPage = usePagedApiList<PlanVersion, PlanVersion>(
    `/api/v1/agent-sessions/${session.id}/plans`,
    { optional: true, map: value => normalizePlan(value as unknown as Record<string, unknown>) },
  )
  const approvalsPage = usePagedApiList<Approval, Approval>(
    `/api/v1/approvals?sessionId=${encodeURIComponent(session.id)}`,
    { optional: true, map: value => normalizeApproval(value as unknown as Record<string, unknown>) },
  )
  const plan = plansPage.items.find(candidate => candidate.id === session.current_plan_version_id) ?? plansPage.items.at(-1)
  const currentStep = plan?.steps.find(step => step.status === 'in_progress')
  const pendingApprovals = approvalsPage.items.filter(approval => approval.status === 'pending')
  return <dl className="agent-execution-facts" data-testid={`agent-execution-projection-${session.id}`}>
    <div><dt>{text.projectionCurrentStep}</dt><dd>{currentStep?.title ?? text.notReported}</dd></div>
    <div><dt>{text.projectionPendingApprovals}</dt><dd>{pendingApprovals.length}</dd></div>
    {(plansPage.error || approvalsPage.error) && <div><dt>{text.projectionStatus}</dt><dd>{text.projectionFailedStatus}。{text.projectionFailedHint}</dd></div>}
  </dl>
}

export function AgentWorkPanel({ workspaceId, workItemId, workItemTeamId, workItemRevision, humanActorId, workItemTitle, activeAssignmentName, controller, onReloadWorkItem, onSessionCreated }: Props) {
  const { agentWorkCopy: text } = useLocale()
  const availabilityReasonId = useId()
  const panelScopeRef = useRef(controller.scopeKey)
  const panelScopeCurrent = panelScopeRef.current === controller.scopeKey
  if (!panelScopeCurrent) panelScopeRef.current = controller.scopeKey
  const [error, setError] = useState<unknown>(null)
  const [showDelegate, setShowDelegate] = useState(false)
  const [busy, setBusy] = useState(false)
  const [success, setSuccess] = useState('')
  const [prompt, setPrompt] = useState('')
  const [control, setControl] = useState<{ action: AgentControlAction; sessionId: string } | null>(null)
  const [timelineOpen, setTimelineOpen] = useState(false)
  const latestProjectionRefreshRef = useRef<string | null>(null)
  const sessionsPage = usePagedApiList<AgentSession>(
    `/api/v1/agent-sessions?workItemId=${encodeURIComponent(workItemId)}`,
    { optional: true, scopeKey: controller.scopeKey },
  )
  const displayedError = panelScopeCurrent ? error : null
  const displayedShowDelegate = panelScopeCurrent ? showDelegate : false
  const displayedBusy = panelScopeCurrent ? busy : false
  const displayedSuccess = panelScopeCurrent ? success : ''
  const displayedPrompt = panelScopeCurrent ? prompt : ''
  const agentsPage = controller.agentsPage
  const agents = agentsPage.items
  const sessions = sessionsPage.items
  const visibleSessions = useMemo(() => {
    const latestSession = controller.latest?.session
    if (!latestSession || sessions.some(session => session.id === latestSession.id)) return sessions
    return [latestSession, ...sessions]
  }, [controller.latest, sessions])
  const collectionError = agentsPage.error ?? sessionsPage.error
  const agentSelectRef = useRef<HTMLSelectElement>(null)
  useEffect(() => {
    setBusy(false)
    setError(null)
    setSuccess('')
    setPrompt('')
    setShowDelegate(false)
  }, [controller.scopeKey])
  useEffect(() => {
    if (controller.chooserRequest <= 0) return
    setShowDelegate(true)
    controller.consumeChooserRequest()
  }, [controller.chooserRequest, controller.consumeChooserRequest])
  useEffect(() => {
    if (displayedShowDelegate) agentSelectRef.current?.focus()
  }, [displayedShowDelegate])
  useEffect(() => {
    const latest = controller.latest
    if (!latest) {
      latestProjectionRefreshRef.current = null
      return
    }
    if (latestProjectionRefreshRef.current === latest.session.id) return
    latestProjectionRefreshRef.current = latest.session.id
    void sessionsPage.refresh()
    setShowDelegate(false)
    setPrompt('')
    setSuccess(text.delegateSuccess(agentName(latest.agent), latest.session.state))
    onSessionCreated?.(latest.session)
  }, [controller.latest, onSessionCreated, sessionsPage.refresh, text.delegateSuccess])
  useEffect(() => {
    const latestSession = controller.latest?.session
    if (!latestSession || !sessions.some(session => session.id === latestSession.id)) return
    controller.clearLatest()
    onReloadWorkItem?.()
  }, [controller.clearLatest, controller.latest, onReloadWorkItem, sessions])
  const realtimeResources = useMemo<RealtimeResource[]>(() => [
    { type: 'workspace', id: workspaceId },
    { type: 'team', id: workItemTeamId },
    { type: 'work_item', id: workItemId },
    ...visibleSessions.map(session => ({
      type: 'session' as const,
      id: session.id,
    })),
  ], [visibleSessions, workItemId, workItemTeamId, workspaceId])
  useRealtimeSubscription(realtimeResources, invalidation => {
    const targets = agentWorkRefreshTargets(invalidation, {
      teamId: workItemTeamId,
      workItemId,
      sessionIds: new Set(visibleSessions.map(session => session.id)),
    })
    if (invalidation.reason === 'resync')
      return Promise.all([
        agentsPage.refresh(),
        sessionsPage.refresh(),
      ]).then(() => undefined)
    if (targets.has('agents')) void agentsPage.refresh()
    if (targets.has('sessions')) void sessionsPage.refresh()
  })

  const delegateWith = async (agent: Agent | undefined, initialPrompt: string) => {
    if (!agent || !controller.canChoose) return
    try {
      setBusy(true); setError(null); setSuccess(''); controller.clearError()
      await controller.create(agent, initialPrompt)
    } catch (reason) { setError(reason) } finally { setBusy(false) }
  }

  const delegate = async (event: FormEvent<HTMLFormElement>) => {
    event.preventDefault()
    const form = new FormData(event.currentTarget)
    await delegateWith(agents.find(candidate => candidate.id === String(form.get('agentId'))), String(form.get('prompt') ?? '').trim())
  }

  const activeAgents = agents.filter(agent => agent.is_active)
  const unavailableReason = (agent: Agent): string => activeAgentTeamAccess(agent, workItemTeamId)
    ? text.missingExecutionCapabilities
    : text.noActiveGrant
  const delegationUnavailableMessage = activeAgents.length === 0
    ? text.noActiveAgents
    : activeAgents.some(agent => activeAgentTeamAccess(agent, workItemTeamId))
      ? text.missingExecutionCapabilities
    : text.noActiveGrant

  const directAgent = controller.directAgent
  const replacingActiveAssignment = activeAssignmentName !== undefined && activeAssignmentName !== null
  const primaryDisabled = displayedBusy || controller.disabled
  const surfacedError = displayedError ?? controller.error
  const errorApi = surfacedError instanceof ApiError ? surfacedError : collectionError instanceof ApiError ? collectionError : null
  const errorMessage = surfacedError instanceof Error ? surfacedError.message : collectionError?.message ?? text.delegateError
  const recoveryNeedsAgents = errorApi?.code ? ['AGENT_DELEGATE_NOT_GRANTED', 'AGENT_TEAM_GRANT_REQUIRED', 'AGENT_CAPABILITY_NOT_APPROVED', 'AGENT_TEAM_ACCESS_NOT_FOUND', 'APPROVED_CAPABILITY_NOT_REQUESTED', 'AGENT_CONCURRENCY_LIMIT', 'AGENT_NOT_ACTIVE', 'AGENT_NOT_AVAILABLE', 'DELEGATION_NOT_ACTIVE', 'CAPABILITY_DENIED'].includes(errorApi.code) : false
  const recoveryNeedsReload = errorApi?.code ? ['RESPONSIBLE_HUMAN_REQUIRED', 'AGENT_DELEGATION_FORBIDDEN', 'REVISION_CONFLICT', 'STALE_REVISION'].includes(errorApi.code) : false
  const capacityDetails = errorApi ? capacityErrorDetails(errorApi, text.capacitySummary) : null
  const diagnosticId = errorApi ? safeDiagnosticId(errorApi.correlationId) : undefined
  const availabilityMessage = controller.reason === 'missing_responsible_human'
    ? text.noResponsible
    : controller.reason === 'loading_agents'
      ? `${text.liveAgents}…`
      : controller.reason === 'agents_unavailable'
        ? text.refresh
        : delegationUnavailableMessage
  const refreshPanel = () => {
    setError(null)
    controller.clearError()
    void agentsPage.refresh()
    void sessionsPage.refresh()
    onReloadWorkItem?.()
  }
  const sessionsBusy = !sessionsPage.initialized || sessionsPage.loading || sessionsPage.loadingMore
  const showSessionsLoading = visibleSessions.length === 0 && !sessionsPage.error && sessionsBusy
  const showSessionsEmpty = visibleSessions.length === 0 && sessionsPage.initialized && !sessionsPage.loading && !sessionsPage.error
  const primaryLabel = directAgent ? text.oneClickDelegate : text.chooseAgent
  return <section className="agent-work-panel" aria-busy={sessionsBusy} aria-label={text.liveAgents} data-testid="live-agent-panel">
    <header><div><h3>{text.liveAgents}</h3><p>{text.liveAgentsHint}</p></div><div className="agent-work-panel-actions"><Button aria-describedby={controller.disabled && availabilityMessage ? availabilityReasonId : undefined} disabled={primaryDisabled} onClick={() => directAgent ? void delegateWith(directAgent, text.oneClickPrompt(workItemTitle ?? '')) : controller.canChoose ? setShowDelegate(true) : undefined} title={controller.disabled && availabilityMessage ? availabilityMessage : undefined} type="button" variant="primary">{primaryLabel}</Button><Button aria-controls="agent-delegation-form" aria-expanded={displayedShowDelegate} disabled={displayedBusy || controller.busy || !controller.canChoose} onClick={() => setShowDelegate(current => !current)} type="button" variant="secondary">{text.advancedOptions}</Button></div></header>
    <p className="agent-assignment-policy">{text.forcedAssignmentPolicy}</p>
    {replacingActiveAssignment && <p className="agent-replacement-notice" role="status">{text.replacementHint(activeAssignmentName)}</p>}
    {controller.disabled && availabilityMessage && <span className="wm-visually-hidden" id={availabilityReasonId}>{availabilityMessage}</span>}
    {controller.reason !== 'loading_agents' && controller.reason !== 'missing_responsible_human' && !controller.canChoose && <p className="empty" data-testid="delegate-unavailable-reason">{text.delegateUnavailableReason(availabilityMessage)}</p>}
    {!humanActorId && <p className="empty" data-testid="delegate-no-responsible">{text.noResponsible}</p>}
    {displayedSuccess && <p className="success" role="status" data-testid="delegate-success">{displayedSuccess}</p>}
    {(surfacedError || collectionError) && <div className="error-state"><p className="error" role="alert">{errorMessage}{errorApi?.code && ` [${text.errorCode(errorApi.code)}]`}{capacityDetails && ` ${capacityDetails}`}{diagnosticId && ` ${text.diagnosticId(diagnosticId)}`}{errorApi?.safeNextAction && ` ${errorApi.safeNextAction}`}</p>{(errorApi || collectionError) && <Button disabled={displayedBusy} onClick={refreshPanel} type="button" variant="secondary">{recoveryNeedsReload ? text.reloadIssue : text.refresh}</Button>}{recoveryNeedsAgents && <a href="/agents">{text.openAgents}</a>}</div>}
    <form className="delegate-form" hidden={!displayedShowDelegate} id="agent-delegation-form" onSubmit={event => void delegate(event)} data-testid="delegate-agent-form">
      <label>{text.delegateFormAgent}<select defaultValue="" name="agentId" ref={agentSelectRef} required><option value="">{text.delegateFormAgentPlaceholder}</option>{activeAgents.map(agent => { const capabilities = approvedAgentCapabilitiesForTeam(agent, workItemTeamId); const canExecute = canAgentExecuteWorkForTeam(agent, workItemTeamId); return <option key={agent.id} value={agent.id} disabled={!canExecute}>{agentName(agent)} · {canExecute ? text.capabilitiesLine(agentProvider(agent), capabilities.join(', ')) : text.unavail(unavailableReason(agent))}</option> })}</select></label>
      <label>{text.delegateFormInitialPrompt}<textarea name="prompt" onChange={event => setPrompt(event.currentTarget.value)} placeholder={text.delegateFormInitialPromptPlaceholder} required value={displayedPrompt} /></label>
      <Button disabled={displayedBusy || !humanActorId || !controller.canChoose} type="submit" variant="primary">{text.forceAssign}</Button>
    </form>
    {showSessionsLoading ? <p className="empty" data-testid="sessions-loading" role="status">{text.loadingSessions}</p> : showSessionsEmpty ? <p className="empty">{text.noSessions}</p> : visibleSessions.length > 0 && <div className="session-mini-list">{visibleSessions.map(session => <article key={session.id}><div><AgentBadge state={session.state} /><strong>{agentName(agents.find(agent => agent.id === session.agent_id) ?? { id: '', workspace_id: '', actor_id: '', slug: 'Agent', description: null, supported_protocols: [], skills: [], requested_capabilities: [], approved_capabilities: [], max_concurrency: 1, is_active: true, revision: 1 })}</strong></div><p>{session.state_reason || text.blockingReasonMissing}</p><small>{text.heartbeat(formatTime(session.last_heartbeat_at))}</small><AgentExecutionProjection session={session} /><div className="session-actions">{session.state === 'paused' && <Button onClick={() => setControl({ action: 'resume', sessionId: session.id })} type="button" variant="secondary">{text.resume}</Button>}{canPauseAgentSession(session.state) && <Button onClick={() => setControl({ action: 'pause', sessionId: session.id })} type="button" variant="secondary">{text.pause}</Button>}{canRetryAgentSession(session.state) && <Button onClick={() => setControl({ action: 'retry', sessionId: session.id })} type="button" variant="secondary">{text.retry}</Button>}<Button disabled={!canStopAgentSession(session.state)} onClick={() => setControl({ action: 'stop', sessionId: session.id })} type="button" variant="danger">{text.stop}</Button><a href={`/agent-sessions/${session.id}`}>{text.details}</a></div></article>)}</div>}
    {visibleSessions[0] && <details className="embedded-run-timeline" onToggle={event => setTimelineOpen(event.currentTarget.open)}><summary>{text.details} · {visibleSessions[0].id.slice(0, 8)}</summary>{timelineOpen && <AgentRunTimeline compact sessionId={visibleSessions[0].id} />}</details>}
    {control && <AgentControlDialog action={control.action} onClose={() => setControl(null)} onCommitted={async result => { await sessionsPage.refresh(); if (control.action === 'retry' && result?.session) onSessionCreated?.(result.session) }} open sessionId={control.sessionId} />}
    <LoadMoreButton collection={agentsPage} label={text.availableAgentsLabel} />
    <LoadMoreButton collection={sessionsPage} label={text.workItemSessionsLabel} />
  </section>
}
