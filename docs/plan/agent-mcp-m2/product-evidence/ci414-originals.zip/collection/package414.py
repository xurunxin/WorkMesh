import datetime, hashlib, io, json, pathlib, re, zipfile

HERE = pathlib.Path(__file__).resolve().parent
ROOT = HERE.parents[2]
BASE = ROOT/'docs/plan/agent-mcp-m2'
OUT = BASE/'product-evidence'
def read(name): return json.loads((HERE/name).read_text(encoding='utf-8'))
def digest(b): return dict(bytes=len(b),sha256=hashlib.sha256(b).hexdigest())
summary=read('latest-summary.json')
assert summary['runId']==38027599886 and summary['status']=='completed' and summary['conclusion']=='success'
jobs=read('latest-jobs.json')
assert len(jobs['jobs'])==10 and all(j['status']=='completed' and j['conclusion']=='success' for j in jobs['jobs'])
binding=read('ci-source-binding.json')
assert binding['head']==summary['head'] and len(binding['entries'])==50
rows=[]
for j in jobs['jobs']:
    text=(HERE/('job-'+str(j['id'])+'.stdout')).read_text(encoding='utf-8',errors='replace')
    assert binding['merge'] in text, j['name']
    rows.append(dict(job=j['name'],id=j['id'],conclusion=j['conclusion'],checkoutExpectedSeen=True,
        runtimeSeconds=(datetime.datetime.fromisoformat(j['completed_at'].replace('Z','+00:00'))-datetime.datetime.fromisoformat(j['started_at'].replace('Z','+00:00'))).total_seconds(),
        summaries=[line for line in text.splitlines() if re.search(r'Test Files|Tests\s+\d|Tasks:|\d+ passed \(|\d+ skipped',line)]))
(HERE/'ci414-test-summaries.json').write_text(json.dumps(rows,indent=2)+'\n',encoding='utf-8')
# Validate preserved command output against its original bytes. Previously
# overwritten binding snapshots remain in the immutable CI413 archive.
old=zipfile.ZipFile(OUT/'ci413-originals.zip')
commands=read('commands.json')
command_sources=[]
for command in commands:
    for stream in ['stdout','stderr']:
        name=command['name']+'.'+stream
        expected={'bytes':command[stream+'Bytes'],'sha256':command[stream+'Sha256']}
        p=HERE/name
        if p.exists() and digest(p.read_bytes())==expected:
            source='ci414:collection/'+name
        else:
            member='collection/'+name
            assert member in old.namelist() and digest(old.read(member))==expected, name
            source='ci413:'+member
        command_sources.append(dict(command=command['name'],stream=stream,source=source,**expected))
(HERE/'command-original-resolution.json').write_text(json.dumps(command_sources,indent=2)+'\n',encoding='utf-8')
# Inspect runtime outputs, including nested CI artifact files, before archiving.
patterns=[rb'gh[pousr]_[A-Za-z0-9]{25,}',rb'github_pat_[A-Za-z0-9_]{30,}',rb'-----BEGIN (?:RSA |EC |OPENSSH )?PRIVATE KEY-----']
checked=0
def scan(b, name, depth=0):
    global checked
    checked+=1
    assert not any(re.search(p,b) for p in patterns), 'credential shape in '+name
    if b[:4]==b'PK\x03\x04' and depth<4:
        with zipfile.ZipFile(io.BytesIO(b)) as z:
            assert z.testzip() is None
            for m in z.infolist():
                if not m.is_dir(): scan(z.read(m),name+'/'+m.filename,depth+1)
for p in HERE.rglob('*'):
    if p.is_file() and (p.name.startswith(('job-','logs-','artifact-')) or p.name=='gh-auth-status.stdout'):
        scan(p.read_bytes(),p.name)
(HERE/'ci414-secret-shape-scan.json').write_text(json.dumps(dict(checkedMembers=checked,unknownCredentialFindings=[],authTokenLineRedactedBeforeStorage=True),indent=2)+'\n',encoding='utf-8')
archive=OUT/'ci414-originals.zip'
assert not archive.exists(), 'never overwrite an existing evidence archive'
members=[]
with zipfile.ZipFile(archive,'w',zipfile.ZIP_DEFLATED) as z:
    for path in sorted(HERE.rglob('*')):
        if not path.is_file() or '__pycache__' in path.parts: continue
        b=path.read_bytes();name='collection/'+path.relative_to(HERE).as_posix()
        z.writestr(name,b);members.append(dict(member=name,**digest(b)))
with zipfile.ZipFile(archive) as z:
    assert z.testzip() is None
    for m in members: assert digest(z.read(m['member']))=={k:m[k] for k in ['bytes','sha256']}
index=dict(archive=archive.name,archiveDigest=digest(archive.read_bytes()),members=members,
    commandOriginalResolution='collection/command-original-resolution.json',
    previousImmutableArchive='ci413-originals.zip',ciConclusion='success',runId=summary['runId'],head=summary['head'])
(OUT/'ci414-original-index.json').write_text(json.dumps(index,indent=2)+'\n',encoding='utf-8',newline='\n')
result=dict(pr=read('latest-pr.json'),run=read('latest-run.json'),jobs=jobs,sourceBinding=binding,testSummaries=rows,
    originalArchive=index['archiveDigest'],originalIndex='product-evidence/ci414-original-index.json',
    remoteRuntimeLimitation='actual checkout/commit/tree/log binding; no remote per-file before/after or absent native child exit fabricated',
    reviewDelta='runtime product code unchanged; Worker integration fixture and Playwright metadata config require formal incremental review',
    nextHeadGate='Evidence-only commit must get its own latest Required CI; CI414 originals are not the subsequent run')
(BASE/'product-ci414-results.json').write_text(json.dumps(result,indent=2)+'\n',encoding='utf-8',newline='\n')
print(json.dumps(dict(archiveBytes=archive.stat().st_size,archiveMembers=len(members),sourceEntries=len(binding['entries']),summaries=rows)))
