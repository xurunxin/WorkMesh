import datetime, hashlib, json, pathlib, subprocess, sys, time, urllib.parse, zipfile

HERE = pathlib.Path(__file__).resolve().parent
ROOT = HERE.parents[2]
REPO = 'xurunxin/WorkMesh'
GH = r'C:\Program Files\GitHub CLI\gh.EXE'
STATE = json.loads((HERE / 'state.json').read_text(encoding='utf-8'))

def run(name, args):
    # Keep native output immutable across repeated bindings/downloads. Earlier
    # overwritten binding snapshots remain available in the committed CI413 ZIP.
    original_name=name; suffix=1
    while (HERE/(name+'.stdout')).exists():
        suffix+=1; name=original_name+'-'+str(suffix)
    started = time.perf_counter()
    process = subprocess.run([GH, *args], capture_output=True)
    (HERE / (name + '.stdout')).write_bytes(process.stdout)
    (HERE / (name + '.stderr')).write_bytes(process.stderr)
    records = json.loads((HERE / 'commands.json').read_text(encoding='utf-8'))
    records.append(dict(name=name, argv=[GH, *args], nativeExit=process.returncode,
        runtimeSeconds=time.perf_counter()-started,
        observedUtc=datetime.datetime.now(datetime.timezone.utc).isoformat(),
        stdoutBytes=len(process.stdout), stdoutSha256=hashlib.sha256(process.stdout).hexdigest(),
        stderrBytes=len(process.stderr), stderrSha256=hashlib.sha256(process.stderr).hexdigest()))
    (HERE / 'commands.json').write_text(json.dumps(records, indent=2), encoding='utf-8')
    if process.returncode:
        print(json.dumps(dict(commandFailed=name, nativeExit=process.returncode,
            stderr=process.stderr.decode('utf-8','replace'))))
        raise SystemExit(process.returncode)
    return process.stdout

def api(name, path):
    return json.loads(run(name, ['api', path]))

def poll():
    tag = 'observe-' + datetime.datetime.now(datetime.timezone.utc).strftime('%Y%m%dT%H%M%S%f')
    pr = api(tag+'-pr', f'repos/{REPO}/pulls/{STATE["prNumber"]}')
    query = urllib.parse.urlencode(dict(branch=STATE['branch'], event='pull_request', per_page=10))
    runs = api(tag+'-runs', f'repos/{REPO}/actions/runs?{query}')['workflow_runs']
    matches = [r for r in runs if r['head_sha']==pr['head']['sha'] and r['name']=='CI']
    assert pr['state']=='open' and not pr['merged'], 'unexpected PR state'
    result = dict(prNumber=pr['number'], head=pr['head']['sha'], base=pr['base']['sha'],
        mergeCommitSha=pr.get('merge_commit_sha'), runId=None, status='not_created')
    if matches:
        selected = max(matches, key=lambda r:r['id'])
        r = api(tag+'-run', f'repos/{REPO}/actions/runs/{selected["id"]}')
        jobs = api(tag+'-jobs', f'repos/{REPO}/actions/runs/{r["id"]}/jobs?per_page=100')
        assert jobs['total_count']==len(jobs['jobs']), 'jobs pagination required'
        result.update(runId=r['id'], runNumber=r['run_number'], runAttempt=r['run_attempt'],
            status=r['status'], conclusion=r['conclusion'], url=r['html_url'],
            jobs=[dict(id=j['id'],name=j['name'],status=j['status'],conclusion=j['conclusion'],
                startedAt=j['started_at'],completedAt=j['completed_at']) for j in jobs['jobs']])
        (HERE / 'latest-run.json').write_text(json.dumps(r,indent=2),encoding='utf-8')
        (HERE / 'latest-jobs.json').write_text(json.dumps(jobs,indent=2),encoding='utf-8')
    (HERE / 'latest-pr.json').write_text(json.dumps(pr,indent=2),encoding='utf-8')
    (HERE / 'latest-summary.json').write_text(json.dumps(result,indent=2),encoding='utf-8')
    if sys.argv[1]=='poll-brief':
        print(json.dumps({**{k:v for k,v in result.items() if k!='jobs'},
            'jobs':[dict(name=j['name'],status=j['status'],conclusion=j['conclusion']) for j in result.get('jobs',[])]}))
    else: print(json.dumps(result))

def download(run_id):
    r = api('run-'+run_id, f'repos/{REPO}/actions/runs/{run_id}')
    assert r['status']=='completed', 'do not archive unfinished healthy CI as final'
    jobs = api('jobs-'+run_id, f'repos/{REPO}/actions/runs/{run_id}/jobs?per_page=100')
    assert jobs['total_count']==len(jobs['jobs'])
    logs = run('logs-'+run_id, ['api','--allow-escape-sequences',f'repos/{REPO}/actions/runs/{run_id}/logs'])
    with zipfile.ZipFile(HERE / ('logs-'+run_id+'.stdout')) as archive:
        assert archive.testzip() is None
    for j in jobs['jobs']:
        run('job-'+str(j['id']),['api','--allow-escape-sequences',f'repos/{REPO}/actions/jobs/{j["id"]}/logs'])
    artifacts = api('artifacts-'+run_id, f'repos/{REPO}/actions/runs/{run_id}/artifacts?per_page=100')
    assert artifacts['total_count']==len(artifacts['artifacts'])
    for a in artifacts['artifacts']:
        assert not a['expired'], a['id']
        name = 'artifact-'+str(a['id'])
        run(name,['api','--allow-escape-sequences',f'repos/{REPO}/actions/artifacts/{a["id"]}/zip'])
        with zipfile.ZipFile(HERE/(name+'.stdout')) as archive:
            assert archive.testzip() is None
    print(json.dumps(dict(runId=r['id'],head=r['head_sha'],conclusion=r['conclusion'],
        jobs=len(jobs['jobs']),artifacts=len(artifacts['artifacts']),downloadComplete=True)))

def bind(updated=False):
    pr = api('binding-pr', f'repos/{REPO}/pulls/{STATE["prNumber"]}')
    for label, sha in [('head',pr['head']['sha']),('base',pr['base']['sha']),('merge',pr['merge_commit_sha'])]:
        obj = api('binding-'+label, f'repos/{REPO}/git/commits/{sha}')
        (HERE / ('binding-'+label+'.json')).write_text(json.dumps(obj,indent=2),encoding='utf-8')
    head = json.loads((HERE/'binding-head.json').read_text(encoding='utf-8'))
    base = json.loads((HERE/'binding-base.json').read_text(encoding='utf-8'))
    merge = json.loads((HERE/'binding-merge.json').read_text(encoding='utf-8'))
    local_tree = subprocess.check_output(['git','rev-parse',pr['head']['sha']+'^{tree}'],cwd=ROOT).decode().strip()
    assert local_tree==head['tree']['sha']
    assert [p['sha'] for p in merge['parents']]==[base['sha'],head['sha']]
    assert merge['tree']['sha']==head['tree']['sha'], 'base changes require substantive diff review'
    old = json.loads((ROOT/'docs/plan/agent-mcp-m2/product-review-repair-commit-binding.json').read_text(encoding='utf-8'))
    entries=[]
    items=old['entries']+[dict(path='playwright.config.ts',gitBlob=None,worktree=None)] if updated else old['entries']
    for item in items:
        path=item['path']; raw=subprocess.check_output(['git','show',pr['head']['sha']+':'+path],cwd=ROOT)
        blob=subprocess.check_output(['git','rev-parse',pr['head']['sha']+':'+path],cwd=ROOT).decode().strip()
        runtime=(ROOT/path).read_bytes()
        if updated and path in ['apps/worker/integration/stage1-lifecycle.integration.test.ts','playwright.config.ts']:
            repaired=json.loads((HERE/'ci413-repair-binding.json').read_text(encoding='utf-8'))
            bound=next(x for x in repaired['sourceChanges'] if x['path']==path)
            assert blob==bound['expectedCleanFilteredBlob'] and hashlib.sha256(runtime).hexdigest()==bound['worktreeSha256'],path
        else:
            assert blob==item['gitBlob'] and hashlib.sha256(runtime).hexdigest()==item['worktree']['sha256'],path
        entries.append(dict(path=path,gitBlob=blob,gitBytes=len(raw),gitSha256=hashlib.sha256(raw).hexdigest(),
            worktreeBytes=len(runtime),worktreeSha256=hashlib.sha256(runtime).hexdigest()))
    ci_paths=['.github/workflows/ci.yml','scripts/ci-policy.mjs','scripts/ci-policy.test.mjs','scripts/ci-bootstrap/package.json',
        'scripts/ci-bootstrap/package-lock.json','package.json','packages/conformance/vitest.integration.config.ts','vitest.config.ts']
    all_paths=sorted(set(ci_paths+[p['path'] for p in entries]))
    with zipfile.ZipFile(HERE/'ci-bound-source.zip','w',zipfile.ZIP_DEFLATED) as archive:
        for path in all_paths:
            archive.writestr('git/'+path,subprocess.check_output(['git','show',pr['head']['sha']+':'+path],cwd=ROOT))
            archive.writestr('worktree/'+path,(ROOT/path).read_bytes())
    result=dict(prNumber=pr['number'],head=head['sha'],base=base['sha'],merge=merge['sha'],headTree=head['tree']['sha'],
        mergeTree=merge['tree']['sha'],mergeParents=[p['sha'] for p in merge['parents']],entries=entries,ciPaths=ci_paths,
        boundSourceArchive='ci-bound-source.zip',remoteRuntimeLimitation='GitHub checkout commit/tree and raw logs bind sources; no remote per-file before/after read is invented')
    (HERE/'ci-source-binding.json').write_text(json.dumps(result,indent=2),encoding='utf-8')
    print(json.dumps({k:v for k,v in result.items() if k not in ['entries','ciPaths']}))

if __name__=='__main__':
    if sys.argv[1] in ['poll','poll-brief']: poll()
    elif sys.argv[1]=='download': download(sys.argv[2])
    elif sys.argv[1]=='bind': bind()
    elif sys.argv[1]=='bind-updated': bind(True)
    else: raise ValueError(sys.argv[1])
