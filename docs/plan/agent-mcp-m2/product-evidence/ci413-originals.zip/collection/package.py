import datetime, hashlib, io, json, pathlib, re, subprocess, zipfile

HERE = pathlib.Path(__file__).resolve().parent
ROOT = HERE.parents[2]
BASE = ROOT / 'docs/plan/agent-mcp-m2'
OUT = BASE / 'product-evidence'
summary = json.loads((HERE/'latest-summary.json').read_text(encoding='utf-8'))
assert summary['status']=='completed' and summary['runId']==38026590315
scan = json.loads((HERE/'secret-shape-scan.json').read_text(encoding='utf-8'))
assert not scan['unknownCredentialFindings']
source = json.loads((HERE/'ci-source-binding.json').read_text(encoding='utf-8'))
repair = json.loads((HERE/'ci413-repair-binding.json').read_text(encoding='utf-8'))
jobs = json.loads((HERE/'latest-jobs.json').read_text(encoding='utf-8'))
assert len(jobs['jobs'])==10 and all(j['status']=='completed' for j in jobs['jobs'])
members=[]
archive=OUT/'ci413-originals.zip'
def digest(b): return dict(bytes=len(b),sha256=hashlib.sha256(b).hexdigest())
with zipfile.ZipFile(archive,'w',zipfile.ZIP_DEFLATED) as z:
    for path in sorted(HERE.rglob('*')):
        if not path.is_file(): continue
        name='collection/'+path.relative_to(HERE).as_posix()
        b=path.read_bytes();z.writestr(name,b);members.append(dict(member=name,**digest(b)))
    for path in sorted(OUT.glob('m2-f18243ff2d68-*')):
        b=path.read_bytes();name='local-owned/'+path.name
        z.writestr(name,b);members.append(dict(member=name,**digest(b)))
with zipfile.ZipFile(archive) as z:
    assert z.testzip() is None
    assert len(z.infolist())==len(members)
    for m in members: assert digest(z.read(m['member']))=={k:m[k] for k in ['bytes','sha256']}
index=dict(archive=archive.name,archiveDigest=digest(archive.read_bytes()),members=members,
    runtimeSecrets='auth token line redacted before storage; raw CI and nested artifacts passed shape scan',
    nativeCollectionCommands='collection/commands.json',ciConclusion='failure',
    previousPreparationArchive='pr-preparation-7d54-originals.zip')
(OUT/'ci413-original-index.json').write_text(json.dumps(index,indent=2)+'\n',encoding='utf-8',newline='\n')
for path in OUT.glob('m2-f18243ff2d68-*-service.log'):
    # Raw redacted bytes already archived and verified; only normalize new reading copies.
    text=path.read_text(encoding='utf-8',errors='replace')
    path.write_text('\n'.join(l.rstrip() for l in text.splitlines()).rstrip()+'\n',encoding='utf-8',newline='\n')
result=dict(pr=json.loads((HERE/'latest-pr.json').read_text(encoding='utf-8')),
    run=json.loads((HERE/'latest-run.json').read_text(encoding='utf-8')),jobs=jobs,
    sourceBinding=source,repairBinding=repair,
    testSummaries=json.loads((HERE/'ci413-test-summaries.json').read_text(encoding='utf-8')),
    originalArchive=index['archiveDigest'],originalIndex='product-evidence/ci413-original-index.json',
    remoteNativeExitLimitation='job/step conclusion is actual; native child exit unavailable unless explicit raw log; gh collection native exits/runtime are recorded',
    productReview='runtime implementation unchanged; two verification files changed, submit delta for formal independent review',
    nextHeadGate='this report records failed exact 7d54 run413, never future candidate success; next candidate must obtain its own latest Required CI')
(BASE/'product-ci413-results.json').write_text(json.dumps(result,indent=2)+'\n',encoding='utf-8',newline='\n')
print(json.dumps(dict(archiveBytes=archive.stat().st_size,archiveMembers=len(members),
    sourceFilesBound=len(source['entries']),newVerificationFiles=len(repair['sourceChanges']),
    jobs=[dict(id=j['id'],name=j['name'],conclusion=j['conclusion']) for j in jobs['jobs']],
    sourceBinding=source['headTree'],localReceipts=repair['localReceipts'])))
