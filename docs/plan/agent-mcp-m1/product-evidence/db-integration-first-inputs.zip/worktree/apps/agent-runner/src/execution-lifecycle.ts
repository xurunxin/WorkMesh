import { z } from 'zod'

export const sessionWaitIntentSchema = z.object({
  state: z.enum(['awaiting_approval', 'awaiting_input', 'blocked']),
  reason: z.string().min(1).max(2_000),
  approval: z.object({ id: z.string().uuid(), actionPayloadHash: z.string().regex(/^sha256:[a-f0-9]{64}$/) }).strict().optional(),
}).strict().superRefine((value, ctx) => {
  if ((value.state === 'awaiting_approval') !== Boolean(value.approval))
    ctx.addIssue({ code: z.ZodIssueCode.custom, message: 'Approval binding is required only for approval waits.' })
})
export type SessionWaitIntent = z.infer<typeof sessionWaitIntentSchema>
export type ExecutionExit = 'wait' | 'stop' | 'revoked' | 'shutdown' | 'timeout' | 'external_state'

// All model tools and steering share this gate, including callbacks already in flight.
export class ExecutionLifecycle {
  #exit: ExecutionExit | undefined
  #inFlight = 0
  #uncertain = false
  get exit(): ExecutionExit | undefined { return this.#exit }
  get reconciled(): boolean { return this.#inFlight === 0 && !this.#uncertain }
  assertOpen(): void { if (this.#exit) throw new Error('RUNNER_TOOL_CLOSED') }
  close(reason: ExecutionExit): void {
    if (!this.#exit || (this.#exit === 'wait' && reason !== 'wait')) this.#exit = reason
  }
  async tool<T>(run: () => Promise<T>): Promise<T> {
    this.assertOpen()
    this.#inFlight += 1
    try { return await run() }
    catch (error) {
      // Structured HTTP rejections are definite; transport failures may have committed.
      if (!(error instanceof Error && (error.message === 'RUNNER_TOOL_CLOSED' || 'code' in error
        || ('cause' in error && error.cause instanceof Error && 'code' in error.cause))))
        this.#uncertain = true
      throw error
    } finally { this.#inFlight -= 1 }
  }
}
