import { createHash, randomUUID } from 'node:crypto'
import { afterAll, beforeAll, describe, expect, it } from 'vitest'
import { applyMigrations, createDb } from '@workmesh/db'
import { buildApp } from '../src/server.js'
import { seedAgentSessionBearer } from './agent-session-test-credentials.js'
import { createSessionLifecycleWorker } from '../../worker/src/session-lifecycle.js'

const databaseUrl = process.env.DATABASE_URL
if (process.env.RUN_INTEGRATION !== '1' || !databaseUrl || !/(^|[_-])test(?:[_-]|$)/i.test(new URL(databaseUrl).pathname.slice(1)))
  throw new Error('Execution waits require a dedicated test database and RUN_INTEGRATION=1')
const db = createDb(databaseUrl)
const app = buildApp({ logger: { level: 'silent' } })
type Reply = { statusCode: number; body: string; headers: Record<string, string | string[] | number | undefined>; json: <T>() => T }
let cookie = '', csrf = '', humanId = '', teamId = '', stateId = '', agentId = '', installation = '', connectionId = '', modelId = ''
const originalEnabled = process.env.WORKMESH_EXECUTION_WAITS_ENABLED
const human = (method: 'GET' | 'POST' | 'PUT', url: string, payload?: object, headers: Record<string, string> = {}) =>
  app.inject({ method, url, payload, headers: { cookie, 'x-csrf-token': csrf, 'idempotency-key': randomUUID(), ...headers } }) as unknown as Promise<Reply>
const agent = (token: string, method: 'GET' | 'POST', url: string, payload?: object, headers: Record<string, string> = {}) =>
  app.inject({ method, url, payload, headers: { authorization: `Bearer ${token}`,
    'x-workmesh-runner-token': process.env.WORKMESH_RUNNER_SERVICE_TOKEN!, 'idempotency-key': randomUUID(), ...headers } }) as unknown as Promise<Reply>
const revision = async (sessionId: string) => (await db.query<{ revision: number }>('SELECT revision FROM agent_sessions WHERE id=$1', [sessionId])).rows[0]!.revision
const match = (revision: number) => ({ 'if-match': `"revision-${revision}"` })
const sessionFixture = async () => {
  const work = await human('POST', '/api/v1/work-items', { teamId, title: 'Wait continuation', statusId: stateId, responsibleHumanActorId: humanId })
  expect(work.statusCode, work.body).toBe(200)
  const workId = work.json<{ id: string }>().id
  const workRevision = (await db.query<{ revision: number }>('SELECT revision FROM work_items WHERE id=$1', [workId])).rows[0]!.revision
  const started = await human('POST', `/api/v1/work-items/${workId}/agent-session`, { agentId, principalHumanActorId: humanId,
    role: 'executor', requestedCapabilities: ['work:read','work:write'], initialPrompt: 'Wait, then continue', budget: {} }, match(workRevision))
  expect(started.statusCode, started.body).toBe(200)
  const sessionId = started.json<{ session: { id: string } }>().session.id
  const token = await seedAgentSessionBearer(db, sessionId, agentId)
  expect((await agent(token, 'POST', `/api/v1/agent-sessions/${sessionId}/ack`, { summary: 'Ready', externalUrls: [] })).statusCode).toBe(200)
  expect((await agent(token, 'POST', `/api/v1/agent-sessions/${sessionId}/state`, { state: 'executing', reason: 'Start' }, match(await revision(sessionId)))).statusCode).toBe(200)
  const conversation = await human('POST', '/api/v1/workbench/conversations', { title: 'Wait continuation', workItemId: workId,
    agentSessionId: sessionId, llmConnectionId: connectionId, llmModelId: modelId })
  expect(conversation.statusCode, conversation.body).toBe(201)
  const conversationId = conversation.json<{ id: string }>().id
  const turn = await human('POST', `/api/v1/workbench/conversations/${conversationId}/turns`, { messageMarkdown: 'Please continue after the condition.' }, match(1))
  expect(turn.statusCode, turn.body).toBe(201)
  const turnId = turn.json<{ turn: { id: string } }>().turn.id
  const claim = await agent(token, 'POST', `/api/v1/workbench/turns/${turnId}/claim`, { executionWaits: true })
  expect(claim.statusCode, claim.body).toBe(200)
  const attemptId = claim.json<{ runnerAttemptId: string }>().runnerAttemptId
  const credential = await agent(token, 'GET', `/api/v1/workbench/runner-attempts/${attemptId}/credential`)
  expect(credential.statusCode, credential.body).toBe(200)
  const { fenceToken, executionWaitsEnabled } = credential.json<{ fenceToken: string; executionWaitsEnabled: boolean }>()
  expect(executionWaitsEnabled).toBe(true)
  expect((await agent(token, 'POST', `/api/v1/workbench/runner-attempts/${attemptId}/start`, { fenceToken })).statusCode).toBe(200)
  return { sessionId, token, conversationId, turnId, attemptId, fenceToken }
}
const worker = () => createSessionLifecycleWorker({ db, workerId: `wait-${randomUUID()}` })

describe('persisted execution wait and Worker continuation', () => {
  beforeAll(async () => {
    process.env.WORKMESH_EXECUTION_WAITS_ENABLED = 'true'
    await applyMigrations(db)
    await db.query('TRUNCATE workspaces CASCADE')
    const install = await app.inject({ method: 'POST', url: '/api/v1/auth/install', payload: {
      name: 'Wait Test', slug: `wait-${randomUUID().slice(0,8)}`, adminName: 'Owner', email: `${randomUUID()}@wait.test`, password: 'wait-test-password',
    }, headers: { 'idempotency-key': randomUUID(), 'x-workmesh-bootstrap-token': process.env.WORKMESH_BOOTSTRAP_TOKEN! } }) as unknown as Reply
    expect(install.statusCode, install.body).toBe(200)
    const raw = install.headers['set-cookie']; cookie = String(Array.isArray(raw) ? raw[0] : raw).split(';')[0]!
    csrf = install.json<{ csrfToken: string }>().csrfToken
    humanId = (await human('GET', '/api/v1/auth/me')).json<{ actor: { id: string } }>().actor.id
    teamId = (await human('GET', '/api/v1/teams')).json<{ items: { id: string }[] }>().items[0]!.id
    stateId = (await human('GET', `/api/v1/teams/${teamId}/states`)).json<{ items: { id: string; name: string }[] }>().items.find(state => state.name === 'Ready')!.id
    const registration = await human('POST', '/api/v1/agents/register', { name: 'Wait Runner', slug: `wait-runner-${randomUUID().slice(0,8)}`,
      provider: 'fake', version: '1', supportedProtocols: ['native_http'], requestedCapabilities: ['work:read','work:write'], approvedCapabilities: ['work:read','work:write'] })
    expect(registration.statusCode, registration.body).toBe(200)
    const registered = registration.json<{ id: string; installation_token: string }>(); agentId = registered.id; installation = registered.installation_token
    expect((await human('PUT', `/api/v1/agents/${agentId}/team-access/${teamId}`, { approvedCapabilities: ['work:read','work:write'] })).statusCode).toBe(200)
    const connection = await human('POST', '/api/v1/workbench/llm-connections', { scope: 'workspace', name: 'Wait model', apiType: 'openai-completions', baseUrl: 'https://api.minimax.cn/v1', secretMaterial: 'fixture-only-secret' })
    expect(connection.statusCode, connection.body).toBe(201); connectionId = connection.json<{ id: string }>().id
    const model = await human('POST', `/api/v1/workbench/llm-connections/${connectionId}/models`, { externalModelId: 'wait-model', displayName: 'Wait model', enabled: true,
      capabilities: { inputModalities: ['text'], toolCalling: true, reasoning: false, contextWindowTokens: 16384, maxOutputTokens: 2048 } }, match(1))
    expect(model.statusCode, model.body).toBe(201); modelId = model.json<{ id: string }>().id
  }, 300_000)
  afterAll(async () => {
    if (originalEnabled === undefined) delete process.env.WORKMESH_EXECUTION_WAITS_ENABLED
    else process.env.WORKMESH_EXECUTION_WAITS_ENABLED = originalEnabled
    await app.close(); await db.end()
  })

  it.each(['awaiting_approval', 'awaiting_input', 'blocked'] as const)('settles %s publicly and resumes exactly once through live admission', async state => {
    const f = await sessionFixture()
    let approval: { id: string; actionPayloadHash: string } | undefined
    if (state === 'awaiting_approval') {
      const payload = { action: 'text-continuation' }
      const requested = await agent(f.token, 'POST', '/api/v1/approvals', { sessionId: f.sessionId,
        approvalType: 'manual_gate', actionName: 'text-continuation', actionPayloadSanitized: payload,
        actionPayloadHash: `sha256:${createHash('sha256').update(JSON.stringify(payload)).digest('hex')}`,
        riskLevel: 'low', rationaleSummary: 'Human approval before continuing', requiredApprovals: 1,
        expiresAt: new Date(Date.now()+3600_000).toISOString() })
      expect(requested.statusCode, requested.body).toBe(200)
      const original = requested.json<{ id: string; action_payload_hash: string }>()
      approval = { id: original.id, actionPayloadHash: original.action_payload_hash }
      expect(approval.actionPayloadHash).toMatch(/^sha256:[a-f0-9]{64}$/)
    }
    const body = { fenceToken: f.fenceToken, assistantMessageMarkdown: `Waiting: ${state}`,
      settlement: { outcome: 'settled', summaryMarkdown: 'Public wait', noArtifactReason: 'Waiting for Human', externalEffectsReconciled: true },
      sessionWait: { ifMatch: await revision(f.sessionId), state, reason: 'Please approve or provide input', ...(approval ? { approval } : {}) } }
    const key = randomUUID()
    const settled = await agent(f.token, 'POST', `/api/v1/workbench/runner-attempts/${f.attemptId}/settle`, body, { 'idempotency-key': key })
    expect(settled.statusCode, settled.body).toBe(200)
    expect((await agent(f.token, 'POST', `/api/v1/workbench/runner-attempts/${f.attemptId}/settle`, body, { 'idempotency-key': key })).body).toBe(settled.body)
    const waitId = settled.json<{ executionWait: { id: string } }>().executionWait.id
    expect((await db.query('SELECT id FROM workbench_runner_attempts WHERE agent_session_id=$1 AND status IN (\'preparing\',\'running\')', [f.sessionId])).rowCount).toBe(0)
    expect(await worker().reconcileWorkbenchWaits()).toBe(0)
    const monitors = await agent(installation, 'GET', '/api/v1/workbench/runner/assignments?executionWaits=true')
    expect(monitors.statusCode, monitors.body).toBe(200)
    expect(monitors.json<{ items: unknown[] }>().items).toContainEqual({ sessionId: f.sessionId, state, purpose: 'monitor', waitId })
    if (approval) {
      const decided = await human('POST', `/api/v1/approvals/${approval.id}/decide`, { decision: 'approved', reason: 'Continue this exact action' }, match(1))
      expect(decided.statusCode, decided.body).toBe(200)
    } else {
      expect((await human('POST', `/api/v1/agent-sessions/${f.sessionId}/prompt`, { bodyMarkdown: 'The requested input is supplied.' })).statusCode).toBe(200)
    }
    const results = await Promise.all([worker().reconcileWorkbenchWaits(), worker().reconcileWorkbenchWaits()])
    expect(results.reduce((sum, count) => sum+count, 0)).toBe(1)
    expect(await worker().reconcileWorkbenchWaits()).toBe(0)
    const wait = (await db.query<{ continuation_turn_id: string; status: string; trigger_prompt_id: string | null }>('SELECT * FROM workbench_execution_waits WHERE id=$1', [waitId])).rows[0]!
    expect(wait.status).toBe('continued')
    const oldClaim = await agent(f.token, 'POST', `/api/v1/workbench/turns/${wait.continuation_turn_id}/claim`, {})
    expect(oldClaim.statusCode).toBe(403)
    const claim = await agent(f.token, 'POST', `/api/v1/workbench/turns/${wait.continuation_turn_id}/claim`, { executionWaits: true })
    expect(claim.statusCode, claim.body).toBe(200)
    const nextAttemptId = claim.json<{ runnerAttemptId: string }>().runnerAttemptId
    const credential = await agent(f.token, 'GET', `/api/v1/workbench/runner-attempts/${nextAttemptId}/credential`)
    expect(credential.statusCode, credential.body).toBe(200)
    const next = credential.json<{ fenceToken: string; continuation: { waitId: string } }>()
    expect(next.continuation.waitId).toBe(waitId)
    expect((await agent(f.token, 'POST', `/api/v1/workbench/runner-attempts/${nextAttemptId}/start`, { fenceToken: next.fenceToken })).statusCode).toBe(200)
    const finished = await agent(f.token, 'POST', `/api/v1/workbench/runner-attempts/${nextAttemptId}/settle`, { fenceToken: next.fenceToken,
      assistantMessageMarkdown: 'Continued successfully.', settlement: { outcome: 'settled', summaryMarkdown: 'Continued', noArtifactReason: 'Text only', externalEffectsReconciled: true } })
    expect(finished.statusCode, finished.body).toBe(200)
    expect((await db.query('SELECT id FROM workbench_runner_attempts WHERE turn_id=$1', [wait.continuation_turn_id])).rowCount).toBe(1)
    expect((await db.query('SELECT id FROM workbench_runner_attempts WHERE agent_session_id=$1 AND status IN (\'preparing\',\'running\')', [f.sessionId])).rowCount).toBe(0)
  }, 120_000)

  it('keeps pause ahead of a real prompt and only resumes after the Human control command', async () => {
    const f = await sessionFixture()
    const settled = await agent(f.token, 'POST', `/api/v1/workbench/runner-attempts/${f.attemptId}/settle`, {
      fenceToken: f.fenceToken, assistantMessageMarkdown: 'Waiting for input.',
      settlement: { outcome: 'settled', summaryMarkdown: 'Waiting', noArtifactReason: 'Waiting', externalEffectsReconciled: true },
      sessionWait: { ifMatch: await revision(f.sessionId), state: 'awaiting_input', reason: 'Input required' },
    })
    expect(settled.statusCode, settled.body).toBe(200)
    expect((await human('POST', `/api/v1/agent-sessions/${f.sessionId}/signals`, { signal: 'pause', reason: 'Hold execution' }, match(await revision(f.sessionId)))).statusCode).toBe(200)
    expect((await human('POST', `/api/v1/agent-sessions/${f.sessionId}/prompt`, { bodyMarkdown: 'Input while paused' })).statusCode).toBe(200)
    expect(await worker().reconcileWorkbenchWaits()).toBe(0)
    expect((await db.query<{ state: string }>('SELECT state FROM agent_sessions WHERE id=$1', [f.sessionId])).rows[0]!.state).toBe('paused')
    expect((await human('POST', `/api/v1/agent-sessions/${f.sessionId}/signals`, { signal: 'resume', reason: 'Continue now' }, match(await revision(f.sessionId)))).statusCode).toBe(200)
    expect(await worker().reconcileWorkbenchWaits()).toBe(1)
  }, 120_000)
})
