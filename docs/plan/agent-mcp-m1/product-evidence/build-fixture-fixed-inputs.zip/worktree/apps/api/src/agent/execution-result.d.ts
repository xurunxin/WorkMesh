import type { Pool, PoolClient } from 'pg';
import type { ApiActor } from './types.js';
/** Identity recognition only. No usage update, C Session creation, mirror reconciliation, or token signing. */
export declare function resolveExecutionResultIdentity(db: Pool | PoolClient, credentialHash: string, connectionHeader: boolean): Promise<ApiActor>;
export declare function getExecutionResult(db: Pool, actor: ApiActor, sessionId: string, rawQuery: unknown): Promise<{
    session: {
        state: "queued" | "acknowledged" | "planning" | "executing" | "awaiting_input" | "awaiting_approval" | "blocked" | "paused" | "stopping" | "stale" | "completed" | "failed" | "canceled";
        id: string;
        revision: number;
    };
    action: {
        kind: "complete" | "stop_ack";
        operationKey: string;
        confirmation: "confirmed" | "unavailable";
        unavailableReason: "receipt_missing" | "receipt_expired" | "result_unavailable" | null;
    };
    originalResult: {
        operationId: "acknowledgeAgentSessionStop" | "completeAgentSession";
        state: "completed" | "canceled";
        sessionId: string;
        revision: number;
        resultReference: {
            id: string;
            type: "agent_session";
            revision: number;
        };
        eventReference: {
            id: string;
            cursor: string;
        } | null;
    } | null;
    cleanup: {
        cleanupSummary: string;
        residualRisks: string[];
    } | null;
}>;
